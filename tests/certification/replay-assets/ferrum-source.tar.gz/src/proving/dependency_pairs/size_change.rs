//! Subterm and size-change termination algorithms for dependency pairs.
//!
//! These routines compute and validate one atomic processor transition.  The
//! residual worklist and proof reconstruction are owned by `processors::dp`.

use super::*;

#[cfg(test)]
pub(crate) fn synthesize_subterm_criterion(
    pairs: &[DependencyPair],
) -> Option<Vec<DpSizeChangeGraph>> {
    let stats = DpProofStats::default();
    let graph = pairs
        .iter()
        .map(|pair| {
            pairs
                .iter()
                .enumerate()
                .filter(|(_, target)| pair.rhs().root_symbol() == target.lhs().root_symbol())
                .map(|(index, _)| index)
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    synthesize_general_size_change_criterion(&stats, pairs, &graph)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SizeChangeClosureGraph {
    pub(crate) source: Symbol,
    pub(crate) target: Symbol,
    pub(crate) source_arity: usize,
    pub(crate) target_arity: usize,
    pub(crate) edges: BTreeMap<(usize, usize), bool>,
}

impl SizeChangeClosureGraph {
    fn key(&self) -> SizeChangeClosureGraphKey {
        SizeChangeClosureGraphKey {
            source: self.source.clone(),
            target: self.target.clone(),
            source_arity: self.source_arity,
            target_arity: self.target_arity,
            edges: self.edges.clone(),
        }
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(crate) struct SizeChangeClosureGraphKey {
    source: Symbol,
    target: Symbol,
    source_arity: usize,
    target_arity: usize,
    edges: BTreeMap<(usize, usize), bool>,
}

pub(crate) fn synthesize_projection_subterm_criterion(
    pairs: &[DependencyPair],
    options: &DpOptions,
    deadline: Option<Instant>,
    improved_csr: Option<&CsrTrs>,
) -> Option<(Vec<DpSubtermProjectionEntry>, Vec<usize>)> {
    synthesize_projection_subterm_criterion_standard(pairs, options, deadline, improved_csr)
        .or_else(|| {
            improved_csr
                .and_then(|csr| synthesize_frozen_recursive_subterm_criterion(csr, pairs, deadline))
        })
}

fn synthesize_projection_subterm_criterion_standard(
    pairs: &[DependencyPair],
    options: &DpOptions,
    deadline: Option<Instant>,
    improved_csr: Option<&CsrTrs>,
) -> Option<(Vec<DpSubtermProjectionEntry>, Vec<usize>)> {
    if let Some(csr) = improved_csr
        && !csr_mixed_subterm_pair_shapes_are_valid(csr, pairs)
    {
        return None;
    }
    let mut roots = Vec::<(Symbol, usize)>::new();
    for pair in pairs {
        for term in [pair.lhs(), pair.rhs()] {
            let Term::App { symbol, args } = term else {
                return None;
            };
            if !roots.iter().any(|(root, _)| root == symbol) {
                roots.push((symbol.clone(), args.len()));
            }
        }
    }
    if roots.iter().any(|(_, arity)| *arity == 0) {
        return None;
    }
    let root_indices = roots
        .iter()
        .enumerate()
        .map(|(index, (symbol, _))| (symbol.clone(), index))
        .collect::<BTreeMap<_, _>>();
    let encode_started = Instant::now();
    let mut script = String::from("(set-logic QF_LIA)\n");
    for (index, (_, arity)) in roots.iter().enumerate() {
        script.push_str(&format!("(declare-fun sp{index} () Int)\n"));
        script.push_str(&format!(
            "(assert (and (<= 0 sp{index}) (< sp{index} {arity})))\n"
        ));
    }
    let mut strict_choices = Vec::new();
    for pair in pairs {
        let (Some((lhs_symbol, lhs_args)), Some((rhs_symbol, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let lhs_root = *root_indices.get(lhs_symbol)?;
        let rhs_root = *root_indices.get(rhs_symbol)?;
        let mut weak_choices = Vec::new();
        for (lhs_position, lhs_arg) in lhs_args.iter().enumerate() {
            for (rhs_position, rhs_arg) in rhs_args.iter().enumerate() {
                let strict = improved_csr.map_or_else(
                    || rhs_arg.is_proper_subterm_of(lhs_arg),
                    |csr| csr_is_mu_proper_subterm(csr, lhs_arg, rhs_arg),
                );
                if rhs_arg == lhs_arg || strict {
                    let choice = format!(
                        "(and (= sp{lhs_root} {lhs_position}) (= sp{rhs_root} {rhs_position}))"
                    );
                    if strict {
                        strict_choices.push(choice.clone());
                    }
                    weak_choices.push(choice);
                }
            }
        }
        if weak_choices.is_empty() {
            return None;
        }
        script.push_str(&format!("(assert {})\n", smt_or(weak_choices)));
    }
    if strict_choices.is_empty() {
        return None;
    }
    script.push_str(&format!("(assert {})\n", smt_or(strict_choices)));
    script.push_str("(check-sat)\n(get-model)\n");
    write_smt_encoding_event(
        "subterm-projection",
        encode_started,
        &script,
        pairs,
        &[],
        "",
    );
    let Some(stdout) = run_smt_script(&script, options, deadline) else {
        write_progress_event(
            "dp-sct-expensive",
            "timeout",
            "linear-polynomial-mc-symbolic-closure",
            0,
            "solver did not return before deadline or cancellation",
        );
        return None;
    };
    let values = parse_smt_values(&stdout)?;
    let projection = roots
        .iter()
        .enumerate()
        .map(|(index, (symbol, arity))| {
            Some(DpSubtermProjectionEntry {
                symbol: symbol.clone(),
                arity: *arity,
                position: usize::try_from(*values.get(&format!("sp{index}"))?).ok()?,
            })
        })
        .collect::<Option<Vec<_>>>()?;
    let projection_map = projection
        .iter()
        .map(|entry| (entry.symbol.clone(), entry.position))
        .collect::<BTreeMap<_, _>>();
    let strict_pair_indices =
        subterm_strict_pairs_for_projection_with_csr(pairs, &projection_map, improved_csr)?;
    (!strict_pair_indices.is_empty()).then_some((projection, strict_pair_indices))
}

fn collect_term_symbol_arities(term: &Term, symbols: &mut BTreeMap<Symbol, usize>) {
    let Term::App { symbol, args } = term else {
        return;
    };
    symbols.entry(symbol.clone()).or_insert(args.len());
    for arg in args {
        collect_term_symbol_arities(arg, symbols);
    }
}

fn recursively_collapsed_term(term: &Term, projection: &BTreeMap<Symbol, usize>) -> Option<Term> {
    match term {
        Term::Var(variable) => Some(Term::Var(variable.clone())),
        Term::App { symbol, args } => {
            if let Some(position) = projection.get(symbol) {
                return recursively_collapsed_term(args.get(*position)?, projection);
            }
            Some(Term::app(
                symbol.as_str(),
                args.iter()
                    .map(|arg| recursively_collapsed_term(arg, projection))
                    .collect::<Option<Vec<_>>>()?,
            ))
        }
    }
}

fn frozen_recursive_pair_comparison(
    pair: &DependencyPair,
    projection: &BTreeMap<Symbol, usize>,
) -> Option<bool> {
    let (lhs_symbol, lhs_args) = term_app_parts(pair.lhs())?;
    let (rhs_symbol, rhs_args) = term_app_parts(pair.rhs())?;
    let lhs = recursively_collapsed_term(lhs_args.get(*projection.get(lhs_symbol)?)?, projection)?;
    let rhs = recursively_collapsed_term(rhs_args.get(*projection.get(rhs_symbol)?)?, projection)?;
    if lhs == rhs {
        Some(false)
    } else if rhs.is_proper_subterm_of(&lhs) {
        Some(true)
    } else {
        None
    }
}

/// Validate the root projection premise of CeTA-CSR's frozen recursive
/// subterm processor.  Marked roots may select only a replacement-map-
/// inactive argument; the fresh unhiding root has exactly one argument.
fn frozen_recursive_projection_roots_are_valid(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    projection: &BTreeMap<Symbol, usize>,
) -> bool {
    let unhiding = fresh_unhiding_symbol(csr.trs());
    pairs.iter().all(|pair| {
        [pair.lhs(), pair.rhs()].into_iter().all(|term| {
            let Some((symbol, args)) = term_app_parts(term) else {
                return false;
            };
            let Some(&position) = projection.get(symbol) else {
                return false;
            };
            if symbol == &unhiding {
                args.len() == 1 && position == 0
            } else {
                position < args.len() && !csr_symbol_allows_argument(csr, symbol, position)
            }
        })
    })
}

/// Search a collapsing argument filter below a frozen CS-DP root argument.
/// Connecting CS-DP steps preserve that argument verbatim, so recursive
/// collapsing is sound there even though it would not be sound at an active
/// root position.
fn synthesize_frozen_recursive_subterm_criterion(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<(Vec<DpSubtermProjectionEntry>, Vec<usize>)> {
    if !csr_mixed_subterm_pair_shapes_are_valid(csr, pairs) {
        return None;
    }
    let unhiding = fresh_unhiding_symbol(csr.trs());
    let mut roots = BTreeMap::<Symbol, usize>::new();
    for pair in pairs {
        for term in [pair.lhs(), pair.rhs()] {
            let (symbol, args) = term_app_parts(term)?;
            roots.entry(symbol.clone()).or_insert(args.len());
        }
    }
    let mut candidates = vec![BTreeMap::<Symbol, usize>::new()];
    for (symbol, arity) in &roots {
        let positions = if symbol == &unhiding {
            (arity == &1).then_some(vec![0])?
        } else {
            (0..*arity)
                .filter(|position| !csr_symbol_allows_argument(csr, symbol, *position))
                .collect::<Vec<_>>()
        };
        if positions.is_empty() {
            return None;
        }
        candidates = candidates
            .into_iter()
            .flat_map(|base| {
                positions.iter().map(move |position| {
                    let mut next = base.clone();
                    next.insert(symbol.clone(), *position);
                    next
                })
            })
            .collect();
    }
    let mut all_symbols = BTreeMap::<Symbol, usize>::new();
    for pair in pairs {
        collect_term_symbol_arities(pair.lhs(), &mut all_symbols);
        collect_term_symbol_arities(pair.rhs(), &mut all_symbols);
    }
    let symbol_arities = all_symbols.clone();
    let inner_symbols = all_symbols
        .into_iter()
        .filter(|(symbol, arity)| !roots.contains_key(symbol) && *arity > 0)
        .collect::<Vec<_>>();
    for (symbol, arity) in inner_symbols {
        if strategy_timed_out(deadline) {
            return None;
        }
        candidates = candidates
            .into_iter()
            .flat_map(|base| {
                let nested_symbol = symbol.clone();
                std::iter::once(base.clone()).chain((0..arity).map(move |position| {
                    let mut next = base.clone();
                    next.insert(nested_symbol.clone(), position);
                    next
                }))
            })
            .take(100_000)
            .collect();
    }
    for projection in candidates {
        if strategy_timed_out(deadline) {
            return None;
        }
        let comparisons = pairs
            .iter()
            .map(|pair| frozen_recursive_pair_comparison(pair, &projection))
            .collect::<Option<Vec<_>>>();
        let Some(comparisons) = comparisons else {
            continue;
        };
        let strict = comparisons
            .iter()
            .enumerate()
            .filter_map(|(index, strict)| strict.then_some(index))
            .collect::<Vec<_>>();
        if strict.is_empty() {
            continue;
        }
        let entries = projection
            .into_iter()
            .map(|(symbol, position)| DpSubtermProjectionEntry {
                arity: *symbol_arities.get(&symbol).unwrap_or(&1),
                symbol,
                position,
            })
            .collect();
        return Some((entries, strict));
    }
    None
}

pub(crate) fn subterm_strict_pairs_for_projection_with_csr(
    pairs: &[DependencyPair],
    projection: &BTreeMap<Symbol, usize>,
    improved_csr: Option<&CsrTrs>,
) -> Option<Vec<usize>> {
    let recursive_projection = improved_csr.is_some()
        && projection.keys().any(|symbol| {
            !pairs.iter().any(|pair| {
                pair.lhs().root_symbol() == Some(symbol) || pair.rhs().root_symbol() == Some(symbol)
            })
        });
    (!recursive_projection)
        .then(|| subterm_strict_pairs_for_projection_standard(pairs, projection, improved_csr))
        .flatten()
        .or_else(|| {
            let csr = improved_csr?;
            if !csr_mixed_subterm_pair_shapes_are_valid(csr, pairs)
                || !frozen_recursive_projection_roots_are_valid(csr, pairs, projection)
            {
                return None;
            }
            let strict = pairs
                .iter()
                .enumerate()
                .map(|(index, pair)| {
                    frozen_recursive_pair_comparison(pair, projection)
                        .map(|is_strict| (index, is_strict))
                })
                .collect::<Option<Vec<_>>>()?
                .into_iter()
                .filter_map(|(index, is_strict)| is_strict.then_some(index))
                .collect::<Vec<_>>();
            (!strict.is_empty()).then_some(strict)
        })
}

fn subterm_strict_pairs_for_projection_standard(
    pairs: &[DependencyPair],
    projection: &BTreeMap<Symbol, usize>,
    improved_csr: Option<&CsrTrs>,
) -> Option<Vec<usize>> {
    if let Some(csr) = improved_csr
        && !csr_mixed_subterm_pair_shapes_are_valid(csr, pairs)
    {
        return None;
    }
    let mut strict_pairs = Vec::new();
    for (index, pair) in pairs.iter().enumerate() {
        let (Some((lhs_symbol, lhs_args)), Some((rhs_symbol, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let lhs_position = *projection.get(lhs_symbol)?;
        let rhs_position = *projection.get(rhs_symbol)?;
        let lhs_arg = lhs_args.get(lhs_position)?;
        let rhs_arg = rhs_args.get(rhs_position)?;
        if rhs_arg == lhs_arg {
            continue;
        }
        let strict = improved_csr.map_or_else(
            || rhs_arg.is_proper_subterm_of(lhs_arg),
            |csr| csr_is_mu_proper_subterm(csr, lhs_arg, rhs_arg),
        );
        if !strict {
            return None;
        }
        strict_pairs.push(index);
    }
    Some(strict_pairs)
}

pub(crate) fn subterm_graphs_for_projection_entries_with_csr(
    pairs: &[DependencyPair],
    projection: &[DpSubtermProjectionEntry],
    improved_csr: Option<&CsrTrs>,
) -> Option<Vec<DpSizeChangeGraph>> {
    let Some(csr) = improved_csr else {
        return subterm_graphs_for_projection_entries(pairs, projection);
    };
    let projection_map = projection
        .iter()
        .map(|entry| (entry.symbol.clone(), entry.position))
        .collect::<BTreeMap<_, _>>();

    // The marked/unhiding CSR processor compares the selected arguments with
    // the mu-subterm relation.  Do not first construct ordinary-subterm
    // graphs here: an ordinary comparison and the independently selected
    // mu/frozen strict-pair set can both succeed while disagreeing about
    // which pairs are deleted, producing a CPF that CeTA must reject.
    let recursive_projection = projection_map.keys().any(|symbol| {
        !pairs.iter().any(|pair| {
            pair.lhs().root_symbol() == Some(symbol) || pair.rhs().root_symbol() == Some(symbol)
        })
    });
    let direct = (!recursive_projection)
        .then(|| {
            pairs
                .iter()
                .map(|pair| {
                    let (lhs_symbol, lhs_args) = term_app_parts(pair.lhs())?;
                    let (rhs_symbol, rhs_args) = term_app_parts(pair.rhs())?;
                    let lhs_position = *projection_map.get(lhs_symbol)?;
                    let rhs_position = *projection_map.get(rhs_symbol)?;
                    let lhs_arg = lhs_args.get(lhs_position)?;
                    let rhs_arg = rhs_args.get(rhs_position)?;
                    let strict = csr_is_mu_proper_subterm(csr, lhs_arg, rhs_arg);
                    (strict || rhs_arg == lhs_arg).then_some(DpSizeChangeGraph {
                        pair: pair.clone(),
                        edges: vec![DpSizeChangeEdge {
                            left_position: lhs_position + 1,
                            strict,
                            right_position: rhs_position + 1,
                        }],
                    })
                })
                .collect::<Option<Vec<_>>>()
        })
        .flatten();
    direct.or_else(|| {
        let projection_map = projection
            .iter()
            .map(|entry| (entry.symbol.clone(), entry.position))
            .collect::<BTreeMap<_, _>>();
        pairs
            .iter()
            .map(|pair| {
                let (lhs_symbol, _) = term_app_parts(pair.lhs())?;
                let (rhs_symbol, _) = term_app_parts(pair.rhs())?;
                let lhs_position = *projection_map.get(lhs_symbol)?;
                let rhs_position = *projection_map.get(rhs_symbol)?;
                let strict = frozen_recursive_pair_comparison(pair, &projection_map)?;
                Some(DpSizeChangeGraph {
                    pair: pair.clone(),
                    edges: vec![DpSizeChangeEdge {
                        left_position: lhs_position + 1,
                        strict,
                        right_position: rhs_position + 1,
                    }],
                })
            })
            .collect()
    })
}

fn csr_mixed_subterm_pair_shapes_are_valid(csr: &CsrTrs, pairs: &[DependencyPair]) -> bool {
    let unhiding = fresh_unhiding_symbol(csr.trs());
    pairs.iter().all(|pair| {
        [pair.lhs(), pair.rhs()].into_iter().all(|term| {
            let Term::App { symbol, args } = term else {
                return false;
            };
            symbol.as_str().ends_with('#') || (*symbol == unhiding && args.len() == 1)
        })
    })
}

pub(crate) fn subterm_graphs_for_projection_entries(
    pairs: &[DependencyPair],
    projection: &[DpSubtermProjectionEntry],
) -> Option<Vec<DpSizeChangeGraph>> {
    let projection = projection
        .iter()
        .map(|entry| (entry.symbol.clone(), entry.position))
        .collect::<BTreeMap<_, _>>();
    pairs
        .iter()
        .map(|pair| {
            let (lhs_symbol, lhs_args) = term_app_parts(pair.lhs())?;
            let (rhs_symbol, rhs_args) = term_app_parts(pair.rhs())?;
            let lhs_position = *projection.get(lhs_symbol)?;
            let rhs_position = *projection.get(rhs_symbol)?;
            let lhs_arg = lhs_args.get(lhs_position)?;
            let rhs_arg = rhs_args.get(rhs_position)?;
            let strict = rhs_arg.is_proper_subterm_of(lhs_arg);
            (strict || rhs_arg == lhs_arg).then_some(DpSizeChangeGraph {
                pair: pair.clone(),
                edges: vec![DpSizeChangeEdge {
                    left_position: lhs_position + 1,
                    strict,
                    right_position: rhs_position + 1,
                }],
            })
        })
        .collect()
}

pub(crate) fn synthesize_general_size_change_criterion(
    stats: &DpProofStats,
    pairs: &[DependencyPair],
    dependency_graph: &[Vec<usize>],
) -> Option<Vec<DpSizeChangeGraph>> {
    if dependency_graph.len() != pairs.len() {
        return None;
    }
    let mut graphs = Vec::new();
    for pair in pairs {
        let graph = size_change_graph_for_pair(pair)?;
        graphs.push(graph);
    }
    cached_size_change_graphs_are_terminating_for_certificate(Some(stats), &graphs, None)
        .or_else(|| {
            cached_size_change_graphs_are_terminating_on_dependency_graph(
                Some(stats),
                &graphs,
                dependency_graph,
            )
        })
        .map(|()| graphs)
}

pub(crate) fn synthesize_polynomial_size_change(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    trs: &Trs,
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(
    Vec<DpSizeChangeGraph>,
    DpReductionPairProof,
    Vec<RewriteRule>,
)> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        write_progress_event(
            "dp-sct",
            "q-minimality-reject",
            "size-change",
            0,
            &format!(
                "pairs={} q_lhss={} reason=non-q-minimal-lhs",
                pairs.len(),
                innermost_lhss.map_or(0, <[Term]>::len)
            ),
        );
        return None;
    }
    let usable = if trs.strategy() == RewriteStrategy::Innermost {
        innermost_reduction_pair_usable_rules(trs, pairs, innermost_lhss.unwrap_or(&[]))
    } else {
        reduction_pair_context_rules(trs, pairs, innermost_lhss)
    };
    if linear_sct_only_experiment_enabled() {
        write_progress_event(
            "dp-sct-expensive",
            "experiment-only",
            "linear-polynomial-mc-symbolic-closure",
            0,
            "running only the linear-polynomial SCT closure hook",
        );
        return synthesize_direct_linear_polynomial_size_change_proof(
            stats,
            pairs,
            &usable,
            options,
            dependency_graph,
            deadline,
        )
        .map(|(graphs, reduction_pair)| (graphs, reduction_pair, usable));
    }
    if let Some((graphs, reduction_pair)) = synthesize_pair_oriented_polynomial_size_change_proof(
        stats,
        pairs,
        &usable,
        options,
        dependency_graph,
        deadline,
    ) {
        return Some((graphs, reduction_pair, usable));
    }
    if trs.strategy() != RewriteStrategy::Innermost {
        return None;
    }
    let expensive_deadline = capped_deadline(deadline, EXPENSIVE_SIZE_CHANGE_BUDGET)?;
    if let Some((graphs, reduction_pair)) = synthesize_expensive_innermost_size_change_parallel(
        pairs,
        &usable,
        options,
        innermost_lhss,
        dependency_graph,
        stats,
        Some(expensive_deadline),
    ) {
        return Some((graphs, reduction_pair, usable));
    }
    None
}

pub(crate) fn capped_deadline(outer: Option<Instant>, budget: Duration) -> Option<Instant> {
    let local = Instant::now() + budget;
    let deadline = outer.map_or(local, |outer| outer.min(local));
    (Instant::now() < deadline).then_some(deadline)
}

pub(crate) fn symbolic_sct_only_experiment_enabled() -> bool {
    std::env::var_os("FERRUM_EXPERIMENTAL_SYMBOLIC_SCT_ONLY").is_some()
}

pub(crate) fn linear_sct_only_experiment_enabled() -> bool {
    symbolic_sct_only_experiment_enabled()
        || std::env::var_os("FERRUM_EXPERIMENTAL_LINEAR_SCT_ONLY").is_some()
}

pub(crate) fn synthesize_expensive_innermost_size_change_parallel(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    dependency_graph: Option<&[Vec<usize>]>,
    stats: Option<&DpProofStats>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    type SizeChangeAttemptFn = Box<
        dyn FnOnce() -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> + Send + 'static,
    >;
    type SizeChangeAttempt = (
        &'static str,
        DpSizeChangeAttemptCacheKey,
        SizeChangeAttemptFn,
    );

    let mut attempts: Vec<SizeChangeAttempt> = Vec::new();

    {
        let name = "scnp-max-polynomial";
        let key =
            size_change_attempt_cache_key(name, pairs, usable, options, None, dependency_graph);
        if cached_size_change_attempt_is_inapplicable(stats, &key) {
            write_progress_event(
                "dp-sct-attempt-cache",
                "hit",
                name,
                0,
                "skipped cached inapplicable SCT attempt",
            );
        } else {
            let pairs = pairs.to_vec();
            let usable = usable.to_vec();
            let options = options.clone();
            let dependency_graph = dependency_graph.map(<[Vec<usize>]>::to_vec);
            let stats = stats.cloned();
            attempts.push((
                name,
                key,
                Box::new(move || {
                    synthesize_scnp_max_polynomial_size_change_proof(
                        stats.as_ref(),
                        &pairs,
                        &usable,
                        &options,
                        dependency_graph.as_deref(),
                        deadline,
                    )
                }),
            ));
        }
    }

    {
        let name = "linear-polynomial-mc";
        let key =
            size_change_attempt_cache_key(name, pairs, usable, options, None, dependency_graph);
        if cached_size_change_attempt_is_inapplicable(stats, &key) {
            write_progress_event(
                "dp-sct-attempt-cache",
                "hit",
                name,
                0,
                "skipped cached inapplicable SCT attempt",
            );
        } else {
            let pairs = pairs.to_vec();
            let usable = usable.to_vec();
            let options = options.clone();
            let dependency_graph = dependency_graph.map(<[Vec<usize>]>::to_vec);
            let stats = stats.cloned();
            attempts.push((
                name,
                key,
                Box::new(move || {
                    synthesize_direct_linear_polynomial_size_change_proof(
                        stats.as_ref(),
                        &pairs,
                        &usable,
                        &options,
                        dependency_graph.as_deref(),
                        deadline,
                    )
                }),
            ));
        }
    }

    {
        let name = "path-order-mc";
        let key = size_change_attempt_cache_key(
            name,
            pairs,
            usable,
            options,
            innermost_lhss,
            dependency_graph,
        );
        if cached_size_change_attempt_is_inapplicable(stats, &key) {
            write_progress_event(
                "dp-sct-attempt-cache",
                "hit",
                name,
                0,
                "skipped cached inapplicable SCT attempt",
            );
        } else {
            let pairs = pairs.to_vec();
            let usable = usable.to_vec();
            let options = options.clone();
            let innermost_lhss = innermost_lhss.map(<[Term]>::to_vec);
            let dependency_graph = dependency_graph.map(<[Vec<usize>]>::to_vec);
            let stats = stats.cloned();
            attempts.push((
                name,
                key,
                Box::new(move || {
                    synthesize_path_order_size_change_proof(
                        stats.as_ref(),
                        &pairs,
                        &usable,
                        &options,
                        innermost_lhss.as_deref(),
                        dependency_graph.as_deref(),
                        deadline,
                    )
                }),
            ));
        }
    }

    {
        let name = "kbo-mc";
        let key = size_change_attempt_cache_key(
            name,
            pairs,
            usable,
            options,
            innermost_lhss,
            dependency_graph,
        );
        if cached_size_change_attempt_is_inapplicable(stats, &key) {
            write_progress_event(
                "dp-sct-attempt-cache",
                "hit",
                name,
                0,
                "skipped cached inapplicable SCT attempt",
            );
        } else {
            let pairs = pairs.to_vec();
            let usable = usable.to_vec();
            let options = options.clone();
            let innermost_lhss = innermost_lhss.map(<[Term]>::to_vec);
            let dependency_graph = dependency_graph.map(<[Vec<usize>]>::to_vec);
            let stats = stats.cloned();
            attempts.push((
                name,
                key,
                Box::new(move || {
                    synthesize_kbo_size_change_proof(
                        stats.as_ref(),
                        &pairs,
                        &usable,
                        &options,
                        innermost_lhss.as_deref(),
                        dependency_graph.as_deref(),
                        deadline,
                    )
                }),
            ));
        }
    }

    for dimension in [1, 2] {
        let name = if dimension == 1 {
            "matrix-1-mc"
        } else {
            "matrix-2-mc"
        };
        let key =
            size_change_attempt_cache_key(name, pairs, usable, options, None, dependency_graph);
        if cached_size_change_attempt_is_inapplicable(stats, &key) {
            write_progress_event(
                "dp-sct-attempt-cache",
                "hit",
                name,
                0,
                "skipped cached inapplicable SCT attempt",
            );
            continue;
        }
        let pairs = pairs.to_vec();
        let usable = usable.to_vec();
        let options = options.clone();
        let dependency_graph = dependency_graph.map(<[Vec<usize>]>::to_vec);
        let stats = stats.cloned();
        attempts.push((
            name,
            key,
            Box::new(move || {
                synthesize_matrix_size_change_proof(
                    stats.as_ref(),
                    &pairs,
                    &usable,
                    &options,
                    dimension,
                    dependency_graph.as_deref(),
                    deadline,
                )
            }),
        ));
    }

    let cancellation = CancellationScope::current(deadline);
    let (parallel_cancellation, cancellation_trigger) = cancellation.child_scope(deadline);
    let (sender, receiver) = mpsc::channel();
    let attempts_len = attempts.len();
    let selected = rayon::scope(move |scope| {
        for (name, cache_key, attempt) in attempts {
            let sender = sender.clone();
            let attempt_cancellation = parallel_cancellation.clone();
            let stats_for_cache = stats.cloned();
            scope.spawn(move |_| {
                let started = Instant::now();
                write_progress_event(
                    "dp-sct-expensive",
                    "start",
                    name,
                    0,
                    "monotonicity-constraint size-change attempt",
                );
                let result = with_cancellation_flags(attempt_cancellation.tokens(), attempt);
                if result.is_none()
                    && !attempt_cancellation.is_cancelled()
                    && !strategy_timed_out(deadline)
                {
                    record_size_change_attempt_inapplicable(stats_for_cache.as_ref(), cache_key);
                }
                write_progress_event(
                    "dp-sct-expensive",
                    "finish",
                    name,
                    started.elapsed().as_millis(),
                    if result.is_some() {
                        "proved"
                    } else {
                        "inapplicable"
                    },
                );
                let _ = sender.send((name, result));
            });
        }
        drop(sender);

        'result: {
            let mut pending = attempts_len;
            while pending > 0 {
                if parallel_cancellation.is_cancelled() {
                    cancel(&cancellation_trigger);
                    write_progress_event(
                        "dp-sct-expensive",
                        "timeout",
                        "parallel",
                        0,
                        "expensive innermost size-change search deadline expired",
                    );
                    break;
                }
                match receiver.try_recv() {
                    Ok((name, result)) => {
                        pending -= 1;
                        if result.is_some() {
                            cancel(&cancellation_trigger);
                            write_progress_event(
                                "dp-sct-expensive",
                                "cancel",
                                name,
                                0,
                                "successful size-change attempt cancelled sibling attempts",
                            );
                            break 'result result;
                        }
                    }
                    Err(TryRecvError::Empty) => {
                        cooperative_parallel_wait_tick(parallel_cancellation.remaining());
                    }
                    Err(TryRecvError::Disconnected) => break,
                }
            }
            if pending > 0 {
                write_progress_event(
                    "dp-sct-expensive",
                    "abandoned",
                    "parallel",
                    0,
                    &format!("{pending} attempt(s) did not report before scope joined"),
                );
            }
            None
        }
    });
    selected
}

pub(crate) fn size_change_attempt_cache_key(
    attempt: &'static str,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    dependency_graph: Option<&[Vec<usize>]>,
) -> DpSizeChangeAttemptCacheKey {
    DpSizeChangeAttemptCacheKey {
        attempt,
        option_key: DpProcessorOptionCacheKey::from_options(options),
        pairs: pairs.to_vec(),
        usable: usable.to_vec(),
        innermost_lhss: innermost_lhss.map(<[Term]>::to_vec),
        dependency_graph: dependency_graph.map(<[Vec<usize>]>::to_vec),
    }
}

pub(crate) fn cached_size_change_attempt_is_inapplicable(
    stats: Option<&DpProofStats>,
    key: &DpSizeChangeAttemptCacheKey,
) -> bool {
    stats
        .and_then(|stats| stats.size_change_attempt_cache.lock().ok())
        .is_some_and(|cache| cache.contains(key))
}

pub(crate) fn record_size_change_attempt_inapplicable(
    stats: Option<&DpProofStats>,
    key: DpSizeChangeAttemptCacheKey,
) {
    if let Some(stats) = stats
        && let Ok(mut cache) = stats.size_change_attempt_cache.lock()
        && !cache.contains(&key)
    {
        cache.insert(key);
    }
}

pub(crate) fn synthesize_direct_linear_polynomial_size_change_proof(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    if std::env::var_os("FERRUM_EXPERIMENTAL_SYMBOLIC_SCT_CLOSURE").is_some()
        && let Some((graphs, interpretations)) =
            synthesize_linear_polynomial_size_change_symbolic_closure_proof(
                pairs, usable, options, deadline,
            )
    {
        cached_size_change_graphs_are_terminating_for_certificate(
            stats,
            &graphs,
            dependency_graph,
        )?;
        return Some((
            graphs,
            DpReductionPairProof::Polynomial {
                interpretation: interpretations
                    .iter()
                    .map(|(name, interpretation)| {
                        (
                            name.clone(),
                            interpretation.constant,
                            interpretation.coefficients.clone(),
                        )
                    })
                    .collect(),
                backend: DpSearchBackend::Sat,
            },
        ));
    }
    if symbolic_sct_only_experiment_enabled() {
        return None;
    }
    let interpretations =
        synthesize_linear_polynomial_for_size_change_with_sat(pairs, usable, options, deadline)?;
    linear_polynomial_size_change_proof_from_interpretations(
        stats,
        pairs,
        &interpretations,
        dependency_graph,
    )
}

pub(crate) fn synthesize_pair_oriented_polynomial_size_change_proof(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    if let Some(interpretations) =
        synthesize_pair_polynomial_for_size_change(pairs, usable, options, deadline, &|model| {
            linear_polynomial_size_change_proof_from_interpretations(
                stats, pairs, model, dependency_graph,
            ).is_some()
        })
    {
        if let Some(proof) = linear_polynomial_size_change_proof_from_interpretations(
            stats, pairs, &interpretations, dependency_graph,
        ) {
            return Some(proof);
        }
    }
    // Orienting pairs does not require the model's induced SCT graphs to
    // close. A different first SAT model (including after symbol renaming)
    // must not end the search here. Use the existing bounded SCT model
    // blocking search, then independently check its graphs as usual.
    let interpretations =
        synthesize_linear_polynomial_for_size_change_with_sat(pairs, usable, options, deadline)?;
    linear_polynomial_size_change_proof_from_interpretations(
        stats,
        pairs,
        &interpretations,
        dependency_graph,
    )
}

pub(crate) fn synthesize_scnp_max_polynomial_size_change_proof(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    let arities = arities_for_constraints(pairs, usable);
    if !polynomial_sat_bounds_hold(&arities, options) {
        return None;
    }
    let width = polynomial_bv_width(pairs, usable, options)?;
    let encode_started = Instant::now();
    let script =
        scnp_max_polynomial_bv_sat_script(pairs, usable, options, &arities, width, deadline)?;
    write_smt_encoding_event(
        "scnp-max-polynomial",
        encode_started,
        &script,
        pairs,
        usable,
        format!("width={width}"),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    let interpretations = parse_bv_polynomial_model(&stdout, &arities)?;
    let projections = parse_scnp_projection_model(&stdout, pairs)?;
    let graphs = polynomial_size_change_graphs(pairs, &interpretations)?;
    cached_size_change_graphs_are_terminating_for_certificate(stats, &graphs, dependency_graph)?;
    write_progress_event(
        "dp-sct-expensive",
        "selected",
        "scnp-max-polynomial",
        0,
        &format!(
            "smt_calls=1 pairs={} projections={}",
            pairs.len(),
            projections
                .iter()
                .map(|(symbol, position)| format!("{symbol}:{position}"))
                .collect::<Vec<_>>()
                .join(",")
        ),
    );
    Some((
        graphs,
        DpReductionPairProof::Polynomial {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| {
                    (
                        name.clone(),
                        interpretation.constant,
                        interpretation.coefficients.clone(),
                    )
                })
                .collect(),
            backend: DpSearchBackend::Sat,
        },
    ))
}

pub(crate) fn linear_polynomial_size_change_proof_from_interpretations(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    interpretations: &LinearPolynomialInterpretations,
    dependency_graph: Option<&[Vec<usize>]>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    let graphs = polynomial_size_change_graphs(pairs, &interpretations)?;
    cached_size_change_graphs_are_terminating_for_certificate(stats, &graphs, dependency_graph)?;
    Some((
        graphs,
        DpReductionPairProof::Polynomial {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| {
                    (
                        name.clone(),
                        interpretation.constant,
                        interpretation.coefficients.clone(),
                    )
                })
                .collect(),
            backend: DpSearchBackend::Sat,
        },
    ))
}

pub(crate) fn synthesize_linear_polynomial_for_size_change_with_sat(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    if std::env::var_os("FERRUM_EXPERIMENTAL_SYMBOLIC_SCT_CLOSURE").is_some() {
        let result = synthesize_linear_polynomial_for_size_change_symbolic_closure(
            pairs, usable, options, deadline,
        );
        if symbolic_sct_only_experiment_enabled() {
            return result;
        }
        if let Some(result) = result {
            return Some(result);
        }
    }
    if std::env::var_os("FERRUM_EXPERIMENTAL_INCREMENTAL_SCT_SMT").is_some() {
        match synthesize_linear_polynomial_for_size_change_incrementally(
            pairs, usable, options, deadline,
        ) {
            Ok(result) => return result,
            Err(error) => write_progress_event(
                "dp-sct-expensive",
                "incremental-fallback",
                "linear-polynomial-mc",
                0,
                &error,
            ),
        }
    }
    synthesize_linear_polynomial_for_size_change_rebuilding(pairs, usable, options, deadline)
}

pub(crate) fn synthesize_linear_polynomial_for_size_change_symbolic_closure(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_size_change_symbolic_closure_proof(
        pairs, usable, options, deadline,
    )
    .map(|(_, interpretations)| interpretations)
}

pub(crate) fn synthesize_linear_polynomial_size_change_symbolic_closure_proof(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, LinearPolynomialInterpretations)> {
    let arities = arities_for_constraints(pairs, usable);
    if !polynomial_sat_bounds_hold(&arities, options) {
        return None;
    }
    let width = polynomial_bv_width(pairs, usable, options)?;
    let encode_started = Instant::now();
    let encoding = symbolic_polynomial_size_change_closure_script(
        pairs, usable, options, &arities, width, deadline,
    )?;
    write_smt_encoding_event(
        "linear-polynomial-mc-symbolic-closure",
        encode_started,
        &encoding.script,
        pairs,
        usable,
        format!("width={width}"),
    );
    if std::env::var_os("FERRUM_PROGRESS_LOG_SMT_SCRIPT").is_some() {
        write_progress_event(
            "dp-sct-expensive",
            "script",
            "linear-polynomial-mc-symbolic-closure",
            0,
            &encoding.script.replace('\n', "\\n"),
        );
    }
    let stdout = run_smt_script(&encoding.script, options, deadline)?;
    let Some(interpretations) = parse_bv_polynomial_model(&stdout, &arities) else {
        write_progress_event(
            "dp-sct-expensive",
            "finish",
            "linear-polynomial-mc-symbolic-closure",
            0,
            &format!(
                "inapplicable: solver did not return a parsable sat model ({})",
                stdout.lines().next().unwrap_or("")
            ),
        );
        return None;
    };
    let Some(graphs) =
        selected_symbolic_size_change_graphs(pairs, &encoding, &stdout, &interpretations)
    else {
        write_progress_event(
            "dp-sct-expensive",
            "finish",
            "linear-polynomial-mc-symbolic-closure",
            0,
            "inapplicable: model did not select justified size-change graphs",
        );
        return None;
    };
    if size_change_graphs_are_terminating(&graphs).is_none() {
        write_progress_event(
            "dp-sct-expensive",
            "finish",
            "linear-polynomial-mc-symbolic-closure",
            0,
            "inapplicable: model failed concrete size-change closure validation",
        );
        return None;
    }
    write_progress_event(
        "dp-sct-expensive",
        "selected",
        "linear-polynomial-mc-symbolic-closure",
        0,
        "symbolic SCT closure encoding produced a terminating graph family",
    );
    Some((graphs, interpretations))
}

pub(crate) fn synthesize_linear_polynomial_for_size_change_rebuilding(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    let arities = arities_for_constraints(pairs, usable);
    if !polynomial_sat_bounds_hold(&arities, options) {
        return None;
    }
    let width = polynomial_bv_width(pairs, usable, options)?;
    let encode_started = Instant::now();
    let base_script = smt_script_without_final_query(polynomial_size_change_bv_sat_script(
        pairs, usable, options, &arities, width, deadline,
    )?);
    write_smt_encoding_event(
        "linear-polynomial-mc-base",
        encode_started,
        &base_script,
        pairs,
        usable,
        format!("width={width}"),
    );
    let max_models = options.max_search_space.clamp(1, 64);
    let mut blocked_models = Vec::new();
    let mut blocked_graph_patterns: Vec<String> = Vec::new();
    for attempt in 0..max_models {
        if current_thread_cancelled() || strategy_timed_out(deadline) {
            return None;
        }
        let encode_started = Instant::now();
        let mut script = base_script.clone();
        for blocked in &blocked_models {
            push_bv_polynomial_model_block(&mut script, blocked, &arities, width)?;
        }
        for cut in &blocked_graph_patterns {
            script.push_str(cut);
        }
        script.push_str("(check-sat)\n(get-model)\n");
        write_smt_encoding_event(
            "linear-polynomial-mc-query",
            encode_started,
            &script,
            pairs,
            usable,
            format!("width={width} blocked_models={}", blocked_models.len()),
        );
        let stdout = run_smt_script(&script, options, deadline)?;
        let interpretations = parse_bv_polynomial_model(&stdout, &arities)?;
        if !polynomial_coefficients_are_strictly_monotone(pairs, usable, &interpretations)
            || !usable.iter().all(|rule| {
                weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
            })
        {
            blocked_models.push(interpretations);
            write_progress_event(
                "dp-sct-expensive",
                "block-model",
                "linear-polynomial-mc",
                0,
                &format!(
                    "attempt={} candidate interpretation failed polynomial monotonicity checks",
                    attempt + 1
                ),
            );
            continue;
        }
        let Some(graphs) = polynomial_size_change_graphs(pairs, &interpretations) else {
            blocked_models.push(interpretations);
            write_progress_event(
                "dp-sct-expensive",
                "block-model",
                "linear-polynomial-mc",
                0,
                &format!(
                    "attempt={} candidate interpretation did not induce total size-change edges",
                    attempt + 1
                ),
            );
            continue;
        };
        if size_change_graphs_are_terminating(&graphs).is_some() {
            return Some(interpretations);
        }
        blocked_graph_patterns.push(polynomial_size_change_graph_pattern_cut(
            pairs, &graphs, width,
        )?);
        write_progress_event(
            "dp-sct-expensive",
            "block-graph",
            "linear-polynomial-mc",
            0,
            &format!(
                "attempt={} candidate interpretation failed size-change closure check",
                attempt + 1
            ),
        );
    }
    None
}

pub(crate) fn synthesize_linear_polynomial_for_size_change_incrementally(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Result<Option<LinearPolynomialInterpretations>, String> {
    let arities = arities_for_constraints(pairs, usable);
    if !polynomial_sat_bounds_hold(&arities, options) {
        return Ok(None);
    }
    let Some(width) = polynomial_bv_width(pairs, usable, options) else {
        return Ok(None);
    };
    let Some(base_script) =
        polynomial_size_change_bv_sat_script(pairs, usable, options, &arities, width, deadline)
            .map(smt_script_without_final_query)
    else {
        return Ok(None);
    };
    let solver = options
        .smt_solver
        .as_deref()
        .or_else(|| command_exists("z3").then_some("z3"));
    let Some(solver) = solver else {
        return Ok(None);
    };
    let solver_name = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(solver);
    if solver_name != "z3" || std::env::var_os("FERRUM_DISABLE_PERSISTENT_SMT").is_some() {
        return Err(format!(
            "solver={solver} does not support the persistent Z3 path"
        ));
    }
    let mut lease = acquire_persistent_smt_session(solver, smt_solver_args(solver))
        .map_err(|error| format!("solver={solver} setup failed: {error}"))?;
    let max_models = options.max_search_space.clamp(1, 64);
    let mut pending_cut: Option<String> = None;
    for attempt in 0..max_models {
        if current_thread_cancelled() || strategy_timed_out(deadline) {
            return Ok(None);
        }
        let mut query = if attempt == 0 {
            base_script.clone()
        } else {
            String::new()
        };
        if let Some(cut) = pending_cut.take() {
            query.push_str(&cut);
        }
        query.push_str("(check-sat)\n(get-model)\n");
        check_smt_script_size(&query)
            .ok_or_else(|| "incremental SMT query exceeds the script limit".to_string())?;
        let output = if attempt == 0 {
            lease.reset_and_query(&query, deadline)
        } else {
            lease.query_incremental(&query, deadline)
        }
        .map_err(|error| format!("solver={solver} query failed: {error}"))?;
        let Some(stdout) = output else {
            return Ok(None);
        };
        let Some(interpretations) = parse_bv_polynomial_model(&stdout, &arities) else {
            return Ok(None);
        };
        let rejection =
            if !polynomial_coefficients_are_strictly_monotone(pairs, usable, &interpretations)
                || !usable.iter().all(|rule| {
                    weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                })
            {
                Some((
                    "block-model",
                    "candidate interpretation failed polynomial monotonicity checks",
                    bv_polynomial_model_block(&interpretations, &arities, width)
                        .ok_or_else(|| "failed to encode an incremental model block".to_string())?,
                ))
            } else {
                match polynomial_size_change_graphs(pairs, &interpretations) {
                    None => Some((
                        "block-model",
                        "candidate interpretation did not induce total size-change edges",
                        bv_polynomial_model_block(&interpretations, &arities, width).ok_or_else(
                            || "failed to encode an incremental model block".to_string(),
                        )?,
                    )),
                    Some(graphs) if size_change_graphs_are_terminating(&graphs).is_none() => {
                        Some((
                            "block-graph",
                            "candidate interpretation failed size-change closure check",
                            polynomial_size_change_graph_pattern_cut(pairs, &graphs, width)
                                .ok_or_else(|| {
                                    "failed to encode an incremental graph pattern block"
                                        .to_string()
                                })?,
                        ))
                    }
                    Some(_) => None,
                }
            };
        if let Some((kind, reason, cut)) = rejection {
            write_progress_event(
                "dp-sct-expensive",
                kind,
                "linear-polynomial-mc-incremental",
                0,
                &format!("attempt={} {reason}", attempt + 1),
            );
            pending_cut = Some(cut);
            continue;
        }
        write_progress_event(
            "dp-sct-expensive",
            "selected",
            "linear-polynomial-mc-incremental",
            0,
            &format!(
                "attempt={} persistent_reused={}",
                attempt + 1,
                lease.reused_session()
            ),
        );
        return Ok(Some(interpretations));
    }
    Ok(None)
}

pub(crate) fn polynomial_size_change_bv_sat_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    width: usize,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_BV)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        push_bv_parameter_declaration(
            &mut script,
            &smt_c(symbol),
            0,
            options.max_polynomial_constant,
            width,
        )?;
        for index in 0..*arity {
            push_bv_parameter_declaration(
                &mut script,
                &smt_a(symbol, index),
                1,
                options.max_polynomial_coefficient,
                width,
            )?;
        }
    }
    for rule in usable {
        check_smt_build(&script, deadline)?;
        push_polynomial_bv_weak(&mut script, rule.lhs(), rule.rhs(), width);
    }
    let mut any_strict_edge = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut pair_edges = Vec::new();
        for lhs_arg in lhs_args {
            for rhs_arg in rhs_args {
                pair_edges.push(polynomial_bv_weak_edge(lhs_arg, rhs_arg, width));
                any_strict_edge.push(polynomial_bv_strict(lhs_arg, rhs_arg, width));
            }
        }
        if pair_edges.is_empty() {
            return None;
        }
        script.push_str(&format!("(assert {})\n", smt_or(pair_edges)));
    }
    if any_strict_edge.is_empty() {
        return None;
    }
    script.push_str(&format!("(assert {})\n", smt_or(any_strict_edge)));
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn scnp_max_polynomial_bv_sat_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    width: usize,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_BV)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        push_bv_parameter_declaration(
            &mut script,
            &smt_c(symbol),
            0,
            options.max_polynomial_constant,
            width,
        )?;
        for index in 0..*arity {
            push_bv_parameter_declaration(
                &mut script,
                &smt_a(symbol, index),
                1,
                options.max_polynomial_coefficient,
                width,
            )?;
        }
    }
    for rule in usable {
        check_smt_build(&script, deadline)?;
        push_polynomial_bv_weak(&mut script, rule.lhs(), rule.rhs(), width);
    }
    let projection_symbols = scnp_projection_symbols(pairs)?;
    let mut selector_names = Vec::new();
    for (symbol, arity) in &projection_symbols {
        if *arity == 0 {
            return None;
        }
        let selectors = (0..*arity)
            .map(|index| scnp_projection_name(symbol, index))
            .collect::<Vec<_>>();
        for selector in &selectors {
            script.push_str(&format!("(declare-fun {selector} () Bool)\n"));
        }
        selector_names.extend(selectors.iter().cloned());
        script.push_str(&format!("(assert {})\n", smt_or(selectors.clone())));
        for left in 0..selectors.len() {
            for right in (left + 1)..selectors.len() {
                script.push_str(&format!(
                    "(assert (not (and {} {})))\n",
                    selectors[left], selectors[right]
                ));
            }
        }
    }
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let (Some((lhs_symbol, lhs_args)), Some((rhs_symbol, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        if lhs_args.is_empty() || rhs_args.is_empty() {
            return None;
        }
        for (lhs_index, lhs_arg) in lhs_args.iter().enumerate() {
            for (rhs_index, rhs_arg) in rhs_args.iter().enumerate() {
                let guard = smt_and(vec![
                    scnp_projection_name(lhs_symbol.as_str(), lhs_index),
                    scnp_projection_name(rhs_symbol.as_str(), rhs_index),
                ]);
                let strict = polynomial_bv_strict(lhs_arg, rhs_arg, width);
                script.push_str(&format!("(assert (=> {guard} {strict}))\n"));
            }
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    if !selector_names.is_empty() {
        script.push_str(&format!("(get-value ({}))\n", selector_names.join(" ")));
    }
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) struct SymbolicSizeChangeClosureEncoding {
    pub(crate) script: String,
    closure_graphs: Vec<SizeChangeClosureGraph>,
    graph_names: BTreeMap<SizeChangeClosureGraphKey, String>,
}

pub(crate) fn symbolic_polynomial_size_change_closure_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    width: usize,
    deadline: Option<Instant>,
) -> Option<SymbolicSizeChangeClosureEncoding> {
    let mut script = smt_script_without_final_query(polynomial_size_change_bv_sat_script(
        pairs, usable, options, arities, width, deadline,
    )?);
    let closure_graphs = enumerate_symbolic_size_change_graphs(pairs, deadline)?;
    let graph_names = closure_graphs
        .iter()
        .enumerate()
        .map(|(index, graph)| (graph.key(), symbolic_size_change_graph_name(index)))
        .collect::<BTreeMap<_, _>>();
    for name in graph_names.values() {
        check_smt_build(&script, deadline)?;
        script.push_str(&format!("(declare-fun {name} () Bool)\n"));
    }
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let (Some((source, _)), Some((target, _))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut initial_choices = Vec::new();
        for graph in closure_graphs
            .iter()
            .filter(|graph| graph.source == *source && graph.target == *target)
        {
            if graph.edges.is_empty() {
                continue;
            }
            let pattern = polynomial_size_change_graph_justification_formula(pair, graph, width)?;
            let name = graph_names.get(&graph.key())?;
            initial_choices.push(format!("(and {name} {pattern})"));
        }
        if initial_choices.is_empty() {
            return None;
        }
        script.push_str(&format!("(assert {})\n", smt_or(initial_choices)));
    }

    let mut implications = 0usize;
    for first in &closure_graphs {
        check_smt_build(&script, deadline)?;
        let Some(first_name) = graph_names.get(&first.key()) else {
            return None;
        };
        for second in &closure_graphs {
            let Some(composed) = compose_size_change_graphs(first, second) else {
                continue;
            };
            let Some(second_name) = graph_names.get(&second.key()) else {
                return None;
            };
            let Some(composed_name) = graph_names.get(&composed.key()) else {
                return None;
            };
            script.push_str(&format!(
                "(assert (=> (and {first_name} {second_name}) {composed_name}))\n"
            ));
            implications += 1;
        }
    }
    for graph in &closure_graphs {
        check_smt_build(&script, deadline)?;
        if size_change_graph_is_bad_idempotent(graph) {
            let name = graph_names.get(&graph.key())?;
            script.push_str(&format!("(assert (not {name}))\n"));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    write_progress_event(
        "dp-sct-expensive",
        "encode-symbolic-closure",
        "linear-polynomial-mc",
        0,
        &format!(
            "closure_graphs={} composition_implications={implications}",
            closure_graphs.len()
        ),
    );
    Some(SymbolicSizeChangeClosureEncoding {
        script,
        closure_graphs,
        graph_names,
    })
}

pub(crate) fn enumerate_symbolic_size_change_graphs(
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<Vec<SizeChangeClosureGraph>> {
    let mut arities = BTreeMap::<Symbol, usize>::new();
    for pair in pairs {
        for term in [pair.lhs(), pair.rhs()] {
            let (symbol, args) = term_app_parts(term)?;
            match arities.entry(symbol.clone()) {
                std::collections::btree_map::Entry::Vacant(entry) => {
                    entry.insert(args.len());
                }
                std::collections::btree_map::Entry::Occupied(entry)
                    if *entry.get() == args.len() => {}
                std::collections::btree_map::Entry::Occupied(_) => return None,
            }
        }
    }
    let mut estimated_graphs = 0usize;
    for source_arity in arities.values() {
        for target_arity in arities.values() {
            let edge_slots = source_arity.checked_mul(*target_arity)?;
            estimated_graphs = estimated_graphs.checked_add(checked_usize_pow(3, edge_slots)?)?;
        }
    }
    if let Some(limit) = symbolic_sct_closure_graph_limit()
        && estimated_graphs > limit
    {
        write_progress_event(
            "dp-sct-expensive",
            "skip-symbolic-closure",
            "linear-polynomial-mc",
            0,
            &format!("closure_graphs={estimated_graphs} limit={limit}"),
        );
        return None;
    }
    let mut graphs = Vec::new();
    for (source, source_arity) in &arities {
        for (target, target_arity) in &arities {
            enumerate_symbolic_size_change_edge_patterns(
                source,
                *source_arity,
                target,
                *target_arity,
                deadline,
                &mut graphs,
            )?;
        }
    }
    Some(graphs)
}

pub(crate) fn symbolic_sct_closure_graph_limit() -> Option<usize> {
    match std::env::var("FERRUM_SYMBOLIC_SCT_MAX_CLOSURE_GRAPHS") {
        Ok(value) if value.trim().eq_ignore_ascii_case("none") => None,
        Ok(value) => value.trim().parse::<usize>().ok(),
        Err(_) => None,
    }
}

pub(crate) fn checked_usize_pow(base: usize, exponent: usize) -> Option<usize> {
    let mut result = 1usize;
    for _ in 0..exponent {
        result = result.checked_mul(base)?;
    }
    Some(result)
}

pub(crate) fn enumerate_symbolic_size_change_edge_patterns(
    source: &Symbol,
    source_arity: usize,
    target: &Symbol,
    target_arity: usize,
    deadline: Option<Instant>,
    graphs: &mut Vec<SizeChangeClosureGraph>,
) -> Option<()> {
    let positions = (1..=source_arity)
        .flat_map(|left| (1..=target_arity).map(move |right| (left, right)))
        .collect::<Vec<_>>();
    fn rec(
        index: usize,
        positions: &[(usize, usize)],
        source: &Symbol,
        source_arity: usize,
        target: &Symbol,
        target_arity: usize,
        deadline: Option<Instant>,
        edges: &mut BTreeMap<(usize, usize), bool>,
        graphs: &mut Vec<SizeChangeClosureGraph>,
    ) -> Option<()> {
        check_smt_build("", deadline)?;
        if index == positions.len() {
            graphs.push(SizeChangeClosureGraph {
                source: source.clone(),
                target: target.clone(),
                source_arity,
                target_arity,
                edges: edges.clone(),
            });
            return Some(());
        }
        let position = positions[index];
        rec(
            index + 1,
            positions,
            source,
            source_arity,
            target,
            target_arity,
            deadline,
            edges,
            graphs,
        )?;
        edges.insert(position, false);
        rec(
            index + 1,
            positions,
            source,
            source_arity,
            target,
            target_arity,
            deadline,
            edges,
            graphs,
        )?;
        edges.insert(position, true);
        rec(
            index + 1,
            positions,
            source,
            source_arity,
            target,
            target_arity,
            deadline,
            edges,
            graphs,
        )?;
        edges.remove(&position);
        Some(())
    }
    rec(
        0,
        &positions,
        source,
        source_arity,
        target,
        target_arity,
        deadline,
        &mut BTreeMap::new(),
        graphs,
    )
}

pub(crate) fn symbolic_size_change_graph_name(index: usize) -> String {
    format!("sct_closure_g_{index}")
}

pub(crate) fn polynomial_size_change_graph_justification_formula(
    pair: &DependencyPair,
    graph: &SizeChangeClosureGraph,
    width: usize,
) -> Option<String> {
    let (Some((_, lhs_args)), Some((_, rhs_args))) =
        (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
    else {
        return None;
    };
    if lhs_args.len() != graph.source_arity || rhs_args.len() != graph.target_arity {
        return None;
    }
    let mut parts = Vec::new();
    for ((left_position, right_position), strict) in &graph.edges {
        let left_arg = lhs_args.get(left_position.checked_sub(1)?)?;
        let right_arg = rhs_args.get(right_position.checked_sub(1)?)?;
        if *strict {
            parts.push(polynomial_bv_strict(left_arg, right_arg, width));
        } else {
            parts.push(polynomial_bv_weak_edge(left_arg, right_arg, width));
        }
    }
    (!parts.is_empty()).then(|| smt_and(parts))
}

pub(crate) fn selected_symbolic_size_change_graphs(
    pairs: &[DependencyPair],
    encoding: &SymbolicSizeChangeClosureEncoding,
    output: &str,
    interpretations: &LinearPolynomialInterpretations,
) -> Option<Vec<DpSizeChangeGraph>> {
    let bools = parse_smt_bool_values(output)?;
    let mut graphs = Vec::new();
    for pair in pairs {
        let (Some((source, lhs_args)), Some((target, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let selected = encoding
            .closure_graphs
            .iter()
            .filter(|graph| {
                graph.source == *source
                    && graph.target == *target
                    && graph.source_arity == lhs_args.len()
                    && graph.target_arity == rhs_args.len()
                    && !graph.edges.is_empty()
                    && encoding
                        .graph_names
                        .get(&graph.key())
                        .and_then(|name| bools.get(name))
                        .copied()
                        .unwrap_or(false)
                    && size_change_closure_graph_is_justified_by_polynomial(
                        pair,
                        graph,
                        interpretations,
                    )
            })
            .min_by_key(|graph| {
                (
                    graph.edges.len(),
                    graph.edges.values().filter(|strict| **strict).count(),
                )
            })?;
        graphs.push(DpSizeChangeGraph {
            pair: pair.clone(),
            edges: selected
                .edges
                .iter()
                .map(
                    |((left_position, right_position), strict)| DpSizeChangeEdge {
                        left_position: *left_position,
                        strict: *strict,
                        right_position: *right_position,
                    },
                )
                .collect(),
        });
    }
    Some(graphs)
}

pub(crate) fn size_change_closure_graph_is_justified_by_polynomial(
    pair: &DependencyPair,
    graph: &SizeChangeClosureGraph,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    let (Some((_, lhs_args)), Some((_, rhs_args))) =
        (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
    else {
        return false;
    };
    if lhs_args.len() != graph.source_arity || rhs_args.len() != graph.target_arity {
        return false;
    }
    graph
        .edges
        .iter()
        .all(|((left_position, right_position), strict)| {
            let Some(left_arg) = lhs_args.get(left_position.saturating_sub(1)) else {
                return false;
            };
            let Some(right_arg) = rhs_args.get(right_position.saturating_sub(1)) else {
                return false;
            };
            let left = interpret_polynomial(left_arg, interpretations);
            let right = interpret_polynomial(right_arg, interpretations);
            if *strict {
                left.strictly_gt(&right)
            } else {
                left.weakly_ge(&right)
            }
        })
}

pub(crate) fn smt_script_without_final_query(mut script: String) -> String {
    const FINAL_QUERY: &str = "(check-sat)\n(get-model)\n";
    if script.ends_with(FINAL_QUERY) {
        script.truncate(script.len() - FINAL_QUERY.len());
    }
    script
}

pub(crate) fn push_bv_polynomial_model_block(
    script: &mut String,
    interpretations: &LinearPolynomialInterpretations,
    arities: &BTreeMap<String, usize>,
    width: usize,
) -> Option<()> {
    let mut equalities = Vec::new();
    for (symbol, arity) in arities {
        let interpretation = interpretations.get(symbol)?;
        let constant = u128::try_from(interpretation.constant).ok()?;
        equalities.push(format!(
            "(= {} {})",
            smt_c(symbol),
            bv_literal(constant, width)
        ));
        for index in 0..*arity {
            let coefficient = u128::try_from(*interpretation.coefficients.get(index)?).ok()?;
            equalities.push(format!(
                "(= {} {})",
                smt_a(symbol, index),
                bv_literal(coefficient, width)
            ));
        }
    }
    script.push_str(&format!("(assert (not {}))\n", smt_and(equalities)));
    Some(())
}

pub(crate) fn bv_polynomial_model_block(
    interpretations: &LinearPolynomialInterpretations,
    arities: &BTreeMap<String, usize>,
    width: usize,
) -> Option<String> {
    let mut script = String::new();
    push_bv_polynomial_model_block(&mut script, interpretations, arities, width)?;
    Some(script)
}

pub(crate) fn polynomial_size_change_graph_pattern_cut(
    pairs: &[DependencyPair],
    graphs: &[DpSizeChangeGraph],
    width: usize,
) -> Option<String> {
    if pairs.len() != graphs.len() {
        return None;
    }
    let mut alternatives = Vec::new();
    for (pair, graph) in pairs.iter().zip(graphs) {
        if graph.pair != *pair {
            return None;
        }
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let strict_edges = graph
            .edges
            .iter()
            .filter(|edge| edge.strict)
            .map(|edge| (edge.left_position, edge.right_position))
            .collect::<BTreeSet<_>>();
        let weak_edges = graph
            .edges
            .iter()
            .map(|edge| (edge.left_position, edge.right_position))
            .collect::<BTreeSet<_>>();
        for (left_index, left_arg) in lhs_args.iter().enumerate() {
            for (right_index, right_arg) in rhs_args.iter().enumerate() {
                let position = (left_index + 1, right_index + 1);
                let weak = polynomial_bv_weak_edge(left_arg, right_arg, width);
                let strict = polynomial_bv_strict(left_arg, right_arg, width);
                if strict_edges.contains(&position) {
                    alternatives.push(format!("(not {strict})"));
                } else if weak_edges.contains(&position) {
                    alternatives.push(format!("(or (not {weak}) {strict})"));
                } else {
                    alternatives.push(weak);
                }
            }
        }
    }
    (!alternatives.is_empty()).then(|| format!("(assert {})\n", smt_or(alternatives)))
}

pub(crate) fn polynomial_bv_weak_edge(lhs: &Term, rhs: &Term, width: usize) -> String {
    let lhs = polynomial_bv_interpret(lhs, width);
    let rhs = polynomial_bv_interpret(rhs, width);
    polynomial_bv_weak_formula(&lhs, &rhs, width)
}

pub(crate) fn scnp_projection_symbols(pairs: &[DependencyPair]) -> Option<BTreeMap<String, usize>> {
    let mut symbols = BTreeMap::new();
    for pair in pairs {
        for term in [pair.lhs(), pair.rhs()] {
            let (symbol, args) = term_app_parts(term)?;
            symbols
                .entry(symbol.as_str().to_string())
                .and_modify(|arity| {
                    if *arity != args.len() {
                        *arity = usize::MAX;
                    }
                })
                .or_insert(args.len());
        }
    }
    symbols
        .values()
        .all(|arity| *arity != usize::MAX)
        .then_some(symbols)
}

pub(crate) fn scnp_projection_name(symbol: &str, position: usize) -> String {
    format!("scnp_sel_{}_{}", sanitize_smt_name(symbol), position)
}

pub(crate) fn parse_scnp_projection_model(
    output: &str,
    pairs: &[DependencyPair],
) -> Option<BTreeMap<String, usize>> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let bools = parse_smt_bool_values(output)?;
    let mut projections = BTreeMap::new();
    for (symbol, arity) in scnp_projection_symbols(pairs)? {
        let selected = (0..arity)
            .filter(|index| {
                bools
                    .get(&scnp_projection_name(&symbol, *index))
                    .copied()
                    .unwrap_or(false)
            })
            .collect::<Vec<_>>();
        let [position] = selected.as_slice() else {
            return None;
        };
        projections.insert(symbol, *position);
    }
    Some(projections)
}

pub(crate) fn parse_smt_bool_values(output: &str) -> Option<BTreeMap<String, bool>> {
    let normalized = output
        .replace('(', " ( ")
        .replace(')', " ) ")
        .replace('\n', " ");
    let tokens = normalized.split_whitespace().collect::<Vec<_>>();
    let mut values = BTreeMap::new();
    let mut index = 0usize;
    while index < tokens.len() {
        if index + 6 < tokens.len()
            && tokens[index] == "("
            && tokens[index + 1] == "define-fun"
            && tokens[index + 4] == ")"
            && tokens[index + 5] == "Bool"
        {
            match tokens[index + 6] {
                "true" => {
                    values.insert(tokens[index + 2].to_string(), true);
                    index += 8;
                    continue;
                }
                "false" => {
                    values.insert(tokens[index + 2].to_string(), false);
                    index += 8;
                    continue;
                }
                _ => {}
            }
        }
        if index + 3 < tokens.len() && tokens[index] == "(" && tokens[index + 1] == "(" {
            match tokens.get(index + 3).copied() {
                Some("true") => {
                    values.insert(tokens[index + 2].to_string(), true);
                    index += 5;
                    continue;
                }
                Some("false") => {
                    values.insert(tokens[index + 2].to_string(), false);
                    index += 5;
                    continue;
                }
                _ => {}
            }
        }
        if index + 3 < tokens.len() && tokens[index] == "(" && tokens.get(index + 3) == Some(&")") {
            match tokens.get(index + 2).copied() {
                Some("true") => {
                    values.insert(tokens[index + 1].to_string(), true);
                    index += 4;
                    continue;
                }
                Some("false") => {
                    values.insert(tokens[index + 1].to_string(), false);
                    index += 4;
                    continue;
                }
                _ => {}
            }
        }
        index += 1;
    }
    Some(values)
}

pub(crate) fn synthesize_matrix_size_change_proof(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dimension: usize,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    let interpretations = synthesize_matrix_for_size_change_with_sat(
        stats,
        pairs,
        usable,
        options,
        dimension,
        dependency_graph,
        deadline,
    )?;
    let strict_dimension = 1;
    let graphs = matrix_size_change_graphs(pairs, &interpretations, dimension, strict_dimension)?;
    cached_size_change_graphs_are_terminating_for_certificate(stats, &graphs, dependency_graph)?;
    Some((
        graphs,
        DpReductionPairProof::Matrix {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| (name.clone(), interpretation.clone()))
                .collect(),
            dimension,
            strict_dimension,
            backend: DpSearchBackend::Sat,
        },
    ))
}

pub(crate) fn synthesize_matrix_for_size_change_with_sat(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dimension: usize,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    let arities = arities_for_constraints(pairs, usable);
    if !matrix_sat_bounds_hold(&arities, options, dimension) {
        return None;
    }
    let strict_dimension = 1;
    let width = matrix_bv_width(pairs, usable, options, dimension)?;
    let encode_started = Instant::now();
    let script = matrix_size_change_bv_sat_script(
        pairs,
        usable,
        options,
        &arities,
        dimension,
        strict_dimension,
        width,
        deadline,
    )?;
    write_smt_encoding_event(
        "matrix-size-change",
        encode_started,
        &script,
        pairs,
        usable,
        format!("dimension={dimension} width={width}"),
    );
    let solver = options
        .smt_solver
        .as_deref()
        .or_else(|| command_exists("z3").then_some("z3"))
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let mut base = smt_script_without_final_query(script);
    for _ in 0..options.max_search_space.clamp(1, 64) {
        if current_thread_cancelled() || strategy_timed_out(deadline) { return None; }
        let stdout = run_matrix_smt_script(&format!("{base}(check-sat)\n(get-model)\n"), solver, deadline)?;
        let interpretations = parse_bv_matrix_model(&stdout, &arities, dimension)?;
        let valid = matrix_interpretations_are_well_formed(&interpretations, dimension)
            && usable.iter().all(|rule| {
                weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations, dimension)
            });
        if valid && matrix_size_change_graphs(pairs, &interpretations, dimension, strict_dimension)
            .is_some_and(|graphs| cached_size_change_graphs_are_terminating_for_certificate(
                stats, &graphs, dependency_graph,
            ).is_some()) {
            return Some(interpretations);
        }
        if valid {
            // A failed SCT closure is shared by every interpretation inducing
            // the same edge pattern. Cut that pattern, rather than repeatedly
            // finding different matrices with identical unsuccessful graphs.
            let mut changed_edges = Vec::new();
            for pair in pairs {
                let (_, lhs) = term_app_parts(pair.lhs())?;
                let (_, rhs) = term_app_parts(pair.rhs())?;
                for left in lhs {
                    for right in rhs {
                        for (predicate, holds) in [
                            (matrix_bv_weak_edge(left, right, dimension, width),
                             weakly_decreases_by_matrix(left, right, &interpretations, dimension)),
                            (matrix_bv_strict(left, right, dimension, strict_dimension, width),
                             strictly_decreases_by_matrix(left, right, &interpretations, dimension, strict_dimension)),
                        ] {
                            changed_edges.push(if holds { format!("(not {predicate})") } else { predicate });
                        }
                    }
                }
            }
            base.push_str(&format!("(assert {})\n", smt_or(changed_edges)));
            continue;
        }
        // Reject just this invalid interpretation; unlike a closure failure,
        // validity may depend on entries outside the compared arguments.
        let values = parse_bv_values(&stdout)?;
        let mut different = Vec::new();
        for (symbol, arity) in &arities {
            for row in 0..dimension {
                let name = matrix_bv_constant_name(symbol, row);
                let value = u128::try_from(*values.get(&name)?).ok()?;
                different.push(format!("(not (= {name} {}))", bv_literal(value, width)));
                for argument in 0..*arity {
                    for column in 0..dimension {
                        let name = matrix_bv_coefficient_name(symbol, argument, row, column);
                        let value = u128::try_from(*values.get(&name)?).ok()?;
                        different.push(format!("(not (= {name} {}))", bv_literal(value, width)));
                    }
                }
            }
        }
        base.push_str(&format!("(assert {})\n", smt_or(different)));
    }
    None
}

pub(crate) fn matrix_size_change_bv_sat_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    dimension: usize,
    strict_dimension: usize,
    width: usize,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_BV)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        for row in 0..dimension {
            push_bv_parameter_declaration(
                &mut script,
                &matrix_bv_constant_name(symbol, row),
                0,
                options.max_polynomial_constant,
                width,
            )?;
        }
        for argument in 0..*arity {
            for row in 0..dimension {
                for column in 0..dimension {
                    push_bv_parameter_declaration(
                        &mut script,
                        &matrix_bv_coefficient_name(symbol, argument, row, column),
                        0,
                        options.max_polynomial_coefficient,
                        width,
                    )?;
                }
            }
        }
    }
    for rule in usable {
        check_smt_build(&script, deadline)?;
        push_matrix_bv_weak(&mut script, rule.lhs(), rule.rhs(), dimension, width);
    }
    let mut any_strict_edge = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut pair_edges = Vec::new();
        for lhs_arg in lhs_args {
            for rhs_arg in rhs_args {
                pair_edges.push(matrix_bv_weak_edge(lhs_arg, rhs_arg, dimension, width));
                any_strict_edge.push(matrix_bv_strict(
                    lhs_arg,
                    rhs_arg,
                    dimension,
                    strict_dimension,
                    width,
                ));
            }
        }
        if pair_edges.is_empty() {
            return None;
        }
        script.push_str(&format!("(assert {})\n", smt_or(pair_edges)));
    }
    if any_strict_edge.is_empty() {
        return None;
    }
    script.push_str(&format!("(assert {})\n", smt_or(any_strict_edge)));
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn matrix_bv_weak_edge(
    lhs: &Term,
    rhs: &Term,
    dimension: usize,
    width: usize,
) -> String {
    let lhs = matrix_bv_interpret(lhs, dimension, width);
    let rhs = matrix_bv_interpret(rhs, dimension, width);
    matrix_bv_weak_formula(&lhs, &rhs, dimension, width)
}

pub(crate) fn synthesize_path_order_size_change_proof(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    let symbols = path_order_precedence(pairs, usable);
    if symbols.is_empty() || symbols.len() > options.max_symbols {
        return None;
    }
    let arities = argument_filter_symbols(pairs, usable);
    let filter_entries = filter_entries_by_symbol(&arities, deadline)?;
    let encode_started = Instant::now();
    let script = mixed_path_order_size_change_smt_script(
        pairs,
        usable,
        &symbols,
        &filter_entries,
        innermost_lhss,
        deadline,
    )?;
    write_smt_encoding_event(
        "path-order-mc",
        encode_started,
        &script,
        pairs,
        usable,
        format!("symbols={} filters={}", symbols.len(), filter_entries.len()),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    let (precedence, precedence_ranks, argument_filter, _) =
        parse_order_model(&stdout, &symbols, &filter_entries)?;
    let argument_filter = complete_argument_filter(pairs, usable, &argument_filter);
    if !path_order_q_compatibility_holds(innermost_lhss, &argument_filter) {
        return None;
    }
    let statuses = parse_path_order_status_model(&stdout, &symbols)?;
    let default_order = majority_path_order_status(&statuses);
    let statuses = complete_path_order_statuses(pairs, usable, &statuses, default_order);
    let precedence_rank_refs = precedence_rank_refs(&precedence_ranks);
    if usable.iter().any(|rule| {
        term_size(&filter_term(rule.rhs(), &argument_filter))
            > term_size(&filter_term(rule.lhs(), &argument_filter))
    }) || !usable.iter().all(|rule| {
        weakly_decreases_by_mixed_path_order(
            rule.lhs(),
            rule.rhs(),
            default_order,
            &statuses,
            &precedence_rank_refs,
            &argument_filter,
        )
    }) {
        return None;
    }
    let graphs = path_order_size_change_graphs(
        pairs,
        default_order,
        &statuses,
        &precedence_rank_refs,
        &argument_filter,
    )?;
    cached_size_change_graphs_are_terminating_for_certificate(stats, &graphs, dependency_graph)?;
    Some((
        graphs,
        DpReductionPairProof::PathOrder {
            order: default_order,
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
            backend: DpSearchBackend::PathOrder,
        },
    ))
}

pub(crate) fn synthesize_kbo_size_change_proof(
    stats: Option<&DpProofStats>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    dependency_graph: Option<&[Vec<usize>]>,
    deadline: Option<Instant>,
) -> Option<(Vec<DpSizeChangeGraph>, DpReductionPairProof)> {
    let symbols = symbols_for_constraints(pairs, usable);
    if symbols.is_empty() || symbols.len() > options.max_symbols || options.max_symbol_weight < 1 {
        return None;
    }
    let arities = argument_filter_symbols(pairs, usable);
    let filter_entries = filter_entries_by_symbol(&arities, deadline)?;
    let symbols = path_order_precedence(pairs, usable);
    let encode_started = Instant::now();
    let script = kbo_size_change_smt_script(
        pairs,
        usable,
        &symbols,
        &filter_entries,
        options.max_symbol_weight,
        innermost_lhss,
        deadline,
    )?;
    write_smt_encoding_event(
        "kbo-mc",
        encode_started,
        &script,
        pairs,
        usable,
        format!("symbols={} filters={}", symbols.len(), filter_entries.len()),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    let (precedence, precedence_ranks, argument_filter, weights) =
        parse_order_model(&stdout, &symbols, &filter_entries)?;
    let argument_filter = complete_argument_filter(pairs, usable, &argument_filter);
    if !path_order_q_compatibility_holds(innermost_lhss, &argument_filter) {
        return None;
    }
    if !kbo_weights_are_admissible(pairs, usable, &weights, &precedence_ranks, &argument_filter) {
        return None;
    }
    let precedence_rank_refs = precedence_rank_refs(&precedence_ranks);
    if !usable.iter().all(|rule| {
        weakly_decreases_by_kbo(
            rule.lhs(),
            rule.rhs(),
            &weights,
            &precedence_rank_refs,
            &argument_filter,
        )
    }) {
        return None;
    }
    let graphs = kbo_size_change_graphs(pairs, &weights, &precedence_rank_refs, &argument_filter)?;
    cached_size_change_graphs_are_terminating_for_certificate(stats, &graphs, dependency_graph)?;
    Some((
        graphs,
        DpReductionPairProof::Kbo {
            precedence,
            precedence_ranks,
            weights,
            argument_filter,
            backend: DpSearchBackend::Kbo,
        },
    ))
}

pub(crate) fn mixed_path_order_size_change_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = order_smt_prelude(symbols, filter_entries, None)?;
    push_path_order_status_prelude(&mut script, symbols);
    push_filter_q_compatibility(&mut script, filter_entries, innermost_lhss, deadline)?;
    let mut filtered_terms = FilteredTermAlternativeCache::new(filter_entries, deadline);
    let mut encoder = std::env::var_os("FERRUM_DIRECT_FILTER_PATH_ORDER")
        .map(|_| DpPathOrderSmtEncoder::new(None, deadline));
    for rule in usable {
        check_smt_build(&script, deadline)?;
        let formula = if let Some(encoder) = encoder.as_mut() {
            let formula = filtered_path_order_ge_formula_shared(
                rule.lhs(),
                rule.rhs(),
                &mut filtered_terms,
                encoder,
            )?;
            script.push_str(&encoder.take_definitions());
            formula
        } else {
            filtered_mixed_path_order_ge_formula_cached(
                rule.lhs(),
                rule.rhs(),
                &mut filtered_terms,
            )?
        };
        script.push_str("(assert ");
        script.push_str(&formula);
        script.push_str(")\n");
    }
    let mut any_strict_edge = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut pair_edges = Vec::new();
        for lhs_arg in lhs_args {
            for rhs_arg in rhs_args {
                if let Some(encoder) = encoder.as_mut() {
                    pair_edges.push(filtered_path_order_ge_formula_shared(
                        lhs_arg,
                        rhs_arg,
                        &mut filtered_terms,
                        encoder,
                    )?);
                    any_strict_edge.push(filtered_path_order_gt_formula_shared(
                        lhs_arg,
                        rhs_arg,
                        &mut filtered_terms,
                        encoder,
                    )?);
                    script.push_str(&encoder.take_definitions());
                    continue;
                }
                pair_edges.push(filtered_mixed_path_order_ge_formula_cached(
                    lhs_arg,
                    rhs_arg,
                    &mut filtered_terms,
                )?);
                any_strict_edge.push(filtered_mixed_path_order_gt_formula_cached(
                    lhs_arg,
                    rhs_arg,
                    &mut filtered_terms,
                )?);
            }
        }
        if pair_edges.is_empty() {
            return None;
        }
        script.push_str("(assert ");
        script.push_str(&smt_or(pair_edges));
        script.push_str(")\n");
    }
    if any_strict_edge.is_empty() {
        return None;
    }
    script.push_str("(assert ");
    script.push_str(&smt_or(any_strict_edge));
    script.push_str(")\n(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn kbo_size_change_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    max_weight: i64,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = order_smt_prelude(symbols, filter_entries, Some(max_weight))?;
    push_filter_q_compatibility(&mut script, filter_entries, innermost_lhss, deadline)?;
    push_kbo_admissibility(&mut script, symbols, filter_entries);
    let mut filtered_terms = FilteredTermAlternativeCache::new(filter_entries, deadline);
    let mut kbo_encoder = KboSmtEncoder::new(deadline);
    for rule in usable {
        check_smt_build(&script, deadline)?;
        let formula = filtered_kbo_ge_formula_cached(
            rule.lhs(),
            rule.rhs(),
            &mut filtered_terms,
            |left, right| kbo_encoder.ge(left, right),
        )?;
        script.push_str(&kbo_encoder.take_definitions());
        script.push_str("(assert ");
        script.push_str(&formula);
        script.push_str(")\n");
    }
    let mut any_strict_edge = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut pair_edges = Vec::new();
        for lhs_arg in lhs_args {
            for rhs_arg in rhs_args {
                pair_edges.push(filtered_kbo_ge_formula_cached(
                    lhs_arg,
                    rhs_arg,
                    &mut filtered_terms,
                    |left, right| kbo_encoder.ge(left, right),
                )?);
                any_strict_edge.push(filtered_kbo_gt_formula_cached(
                    lhs_arg,
                    rhs_arg,
                    &mut filtered_terms,
                    |left, right| kbo_encoder.gt(left, right),
                )?);
            }
        }
        if pair_edges.is_empty() {
            return None;
        }
        script.push_str(&kbo_encoder.take_definitions());
        script.push_str("(assert ");
        script.push_str(&smt_or(pair_edges));
        script.push_str(")\n");
    }
    if any_strict_edge.is_empty() {
        return None;
    }
    script.push_str(&kbo_encoder.take_definitions());
    script.push_str("(assert ");
    script.push_str(&smt_or(any_strict_edge));
    script.push_str(")\n(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn polynomial_size_change_graphs(
    pairs: &[DependencyPair],
    interpretations: &LinearPolynomialInterpretations,
) -> Option<Vec<DpSizeChangeGraph>> {
    let mut graphs = Vec::new();
    for pair in pairs {
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut edges = Vec::new();
        for (left_index, left_arg) in lhs_args.iter().enumerate() {
            for (right_index, right_arg) in rhs_args.iter().enumerate() {
                let left = interpret_polynomial(left_arg, interpretations);
                let right = interpret_polynomial(right_arg, interpretations);
                if left.strictly_gt(&right) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: true,
                        right_position: right_index + 1,
                    });
                } else if left.weakly_ge(&right) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: false,
                        right_position: right_index + 1,
                    });
                }
            }
        }
        if edges.is_empty() {
            return None;
        }
        graphs.push(DpSizeChangeGraph {
            pair: pair.clone(),
            edges,
        });
    }
    Some(graphs)
}

pub(crate) fn path_order_size_change_graphs(
    pairs: &[DependencyPair],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> Option<Vec<DpSizeChangeGraph>> {
    let mut graphs = Vec::new();
    for pair in pairs {
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut edges = Vec::new();
        for (left_index, left_arg) in lhs_args.iter().enumerate() {
            for (right_index, right_arg) in rhs_args.iter().enumerate() {
                if strictly_decreases_by_mixed_path_order(
                    left_arg,
                    right_arg,
                    default_order,
                    statuses,
                    precedence,
                    argument_filter,
                ) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: true,
                        right_position: right_index + 1,
                    });
                } else if weakly_decreases_by_mixed_path_order(
                    left_arg,
                    right_arg,
                    default_order,
                    statuses,
                    precedence,
                    argument_filter,
                ) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: false,
                        right_position: right_index + 1,
                    });
                }
            }
        }
        if edges.is_empty() {
            return None;
        }
        graphs.push(DpSizeChangeGraph {
            pair: pair.clone(),
            edges,
        });
    }
    Some(graphs)
}

pub(crate) fn kbo_size_change_graphs(
    pairs: &[DependencyPair],
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> Option<Vec<DpSizeChangeGraph>> {
    let mut graphs = Vec::new();
    for pair in pairs {
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut edges = Vec::new();
        for (left_index, left_arg) in lhs_args.iter().enumerate() {
            for (right_index, right_arg) in rhs_args.iter().enumerate() {
                if strictly_decreases_by_kbo(
                    left_arg,
                    right_arg,
                    weights,
                    precedence,
                    argument_filter,
                ) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: true,
                        right_position: right_index + 1,
                    });
                } else if weakly_decreases_by_kbo(
                    left_arg,
                    right_arg,
                    weights,
                    precedence,
                    argument_filter,
                ) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: false,
                        right_position: right_index + 1,
                    });
                }
            }
        }
        if edges.is_empty() {
            return None;
        }
        graphs.push(DpSizeChangeGraph {
            pair: pair.clone(),
            edges,
        });
    }
    Some(graphs)
}

pub(crate) fn matrix_size_change_graphs(
    pairs: &[DependencyPair],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
    strict_dimension: usize,
) -> Option<Vec<DpSizeChangeGraph>> {
    let mut graphs = Vec::new();
    for pair in pairs {
        let (Some((_, lhs_args)), Some((_, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return None;
        };
        let mut edges = Vec::new();
        for (left_index, left_arg) in lhs_args.iter().enumerate() {
            for (right_index, right_arg) in rhs_args.iter().enumerate() {
                if strictly_decreases_by_matrix(
                    left_arg,
                    right_arg,
                    interpretations,
                    dimension,
                    strict_dimension,
                ) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: true,
                        right_position: right_index + 1,
                    });
                } else if weakly_decreases_by_matrix(
                    left_arg,
                    right_arg,
                    interpretations,
                    dimension,
                ) {
                    edges.push(DpSizeChangeEdge {
                        left_position: left_index + 1,
                        strict: false,
                        right_position: right_index + 1,
                    });
                }
            }
        }
        if edges.is_empty() {
            return None;
        }
        graphs.push(DpSizeChangeGraph {
            pair: pair.clone(),
            edges,
        });
    }
    Some(graphs)
}

pub(crate) fn size_change_graph_for_pair(pair: &DependencyPair) -> Option<DpSizeChangeGraph> {
    let (Some((_, lhs_args)), Some((_, rhs_args))) =
        (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
    else {
        return None;
    };
    let mut edges = BTreeMap::<(usize, usize), bool>::new();
    for (left_index, left_arg) in lhs_args.iter().enumerate() {
        for (right_index, right_arg) in rhs_args.iter().enumerate() {
            let strict = if right_arg.is_proper_subterm_of(left_arg) {
                true
            } else if right_arg == left_arg {
                false
            } else {
                continue;
            };
            let key = (left_index + 1, right_index + 1);
            edges
                .entry(key)
                .and_modify(|existing| *existing |= strict)
                .or_insert(strict);
        }
    }
    if edges.is_empty() {
        return None;
    }
    Some(DpSizeChangeGraph {
        pair: pair.clone(),
        edges: edges
            .into_iter()
            .map(
                |((left_position, right_position), strict)| DpSizeChangeEdge {
                    left_position,
                    strict,
                    right_position,
                },
            )
            .collect(),
    })
}

pub(crate) fn size_change_closure_graph_for_pair(
    pair: &DependencyPair,
    graph: &DpSizeChangeGraph,
) -> Option<SizeChangeClosureGraph> {
    let (Some((source, lhs_args)), Some((target, rhs_args))) =
        (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
    else {
        return None;
    };
    Some(SizeChangeClosureGraph {
        source: source.clone(),
        target: target.clone(),
        source_arity: lhs_args.len(),
        target_arity: rhs_args.len(),
        edges: graph
            .edges
            .iter()
            .map(|edge| ((edge.left_position, edge.right_position), edge.strict))
            .collect(),
    })
}

pub(crate) fn size_change_graphs_are_terminating(graphs: &[DpSizeChangeGraph]) -> Option<()> {
    let closure = graphs
        .iter()
        .map(|graph| size_change_closure_graph_for_pair(&graph.pair, graph))
        .collect::<Option<Vec<_>>>()?;
    size_change_closure_is_terminating(closure).then_some(())
}

pub(crate) fn size_change_graphs_are_terminating_on_dependency_graph(
    graphs: &[DpSizeChangeGraph],
    dependency_graph: &[Vec<usize>],
) -> Option<()> {
    if graphs.len() != dependency_graph.len()
        || dependency_graph
            .iter()
            .flatten()
            .any(|target| *target >= graphs.len())
    {
        return None;
    }
    if strongly_connected_components(dependency_graph)
        .iter()
        .any(|component| !component_is_cyclic(component, dependency_graph))
    {
        return None;
    }
    let closure = graphs
        .iter()
        .enumerate()
        .map(|(index, graph)| {
            Some((
                index,
                index,
                size_change_closure_graph_for_pair(&graph.pair, graph)?,
            ))
        })
        .collect::<Option<Vec<_>>>()?;
    size_change_indexed_closure_is_terminating(closure, dependency_graph).then_some(())
}

pub(crate) fn cached_size_change_graphs_are_terminating_on_dependency_graph(
    stats: Option<&DpProofStats>,
    graphs: &[DpSizeChangeGraph],
    dependency_graph: &[Vec<usize>],
) -> Option<()> {
    cached_size_change_graphs_are_terminating_for_certificate(stats, graphs, Some(dependency_graph))
}

pub(crate) fn uncached_size_change_graphs_are_terminating_for_certificate(
    graphs: &[DpSizeChangeGraph],
    _dependency_graph: Option<&[Vec<usize>]>,
) -> bool {
    // CPF's size-change processor checks the supplied size-change graphs on
    // their own.  An enclosing dependency-graph proof does not become an
    // additional premise of that processor.  The indexed closure is useful
    // for search/ranking, but accepting an indexed-only result here emitted
    // positive CPFs that CeTA rejected (notably both `motivation.ari`
    // variants).
    size_change_graphs_are_terminating(graphs).is_some()
}

pub(crate) fn cached_size_change_graphs_are_terminating_for_certificate(
    stats: Option<&DpProofStats>,
    graphs: &[DpSizeChangeGraph],
    dependency_graph: Option<&[Vec<usize>]>,
) -> Option<()> {
    let key = DpSizeChangeClosureCacheKey {
        graphs: graphs.to_vec(),
        dependency_graph: dependency_graph.map(<[Vec<usize>]>::to_vec),
    };
    if let Some(stats) = stats
        && let Ok(cache) = stats.size_change_closure_cache.lock()
        && let Some(&terminating) = cache.get(&key)
    {
        write_progress_event(
            "dp-sct-cache",
            "hit",
            "closure",
            0,
            &format!(
                "graphs={} indexed={} terminating={}",
                graphs.len(),
                dependency_graph.is_some(),
                terminating
            ),
        );
        return terminating.then_some(());
    }

    let terminating =
        uncached_size_change_graphs_are_terminating_for_certificate(graphs, dependency_graph);
    if let Some(stats) = stats
        && let Ok(mut cache) = stats.size_change_closure_cache.lock()
        && !cache.contains_key(&key)
    {
        cache.insert(key, terminating);
    }
    terminating.then_some(())
}

pub(crate) fn size_change_indexed_closure_is_terminating(
    mut closure: Vec<(usize, usize, SizeChangeClosureGraph)>,
    dependency_graph: &[Vec<usize>],
) -> bool {
    let mut seen = BTreeSet::new();
    let mut index = 0;
    while index < closure.len() {
        if current_thread_cancelled() {
            return false;
        }
        let (first_pair, last_pair, graph) = &closure[index];
        let key = (*first_pair, *last_pair, graph.key());
        if !seen.insert(key) {
            closure.swap_remove(index);
            continue;
        }
        if dependency_graph[*last_pair].contains(first_pair)
            && size_change_graph_is_bad_idempotent(graph)
        {
            return false;
        }
        index += 1;
    }

    let mut left_index = 0;
    while left_index < closure.len() {
        if current_thread_cancelled() {
            return false;
        }
        let current_len = closure.len();
        for right_index in 0..current_len {
            if current_thread_cancelled() {
                return false;
            }
            let (first_pair, middle_pair, first) = closure[left_index].clone();
            let (second_pair, last_pair, second) = closure[right_index].clone();
            if !dependency_graph[middle_pair].contains(&second_pair) {
                continue;
            }
            let Some(composed) = compose_size_change_graphs(&first, &second) else {
                continue;
            };
            let key = (first_pair, last_pair, composed.key());
            if seen.contains(&key) {
                continue;
            }
            if dependency_graph[last_pair].contains(&first_pair)
                && size_change_graph_is_bad_idempotent(&composed)
            {
                return false;
            }
            seen.insert(key);
            closure.push((first_pair, last_pair, composed));
        }
        left_index += 1;
    }
    true
}

pub(crate) fn size_change_closure_is_terminating(mut closure: Vec<SizeChangeClosureGraph>) -> bool {
    let mut seen = BTreeSet::new();
    let mut index = 0;
    while index < closure.len() {
        if current_thread_cancelled() {
            return false;
        }
        let key = closure[index].key();
        if !seen.insert(key) {
            closure.swap_remove(index);
            continue;
        }
        if size_change_graph_is_bad_idempotent(&closure[index]) {
            return false;
        }
        index += 1;
    }

    let mut left_index = 0;
    while left_index < closure.len() {
        if current_thread_cancelled() {
            return false;
        }
        let current_len = closure.len();
        for right_index in 0..current_len {
            if current_thread_cancelled() {
                return false;
            }
            let left = closure[left_index].clone();
            let right = closure[right_index].clone();
            for (first, second) in [(&left, &right), (&right, &left)] {
                let Some(composed) = compose_size_change_graphs(first, second) else {
                    continue;
                };
                let key = composed.key();
                if seen.contains(&key) {
                    continue;
                }
                if size_change_graph_is_bad_idempotent(&composed) {
                    return false;
                }
                seen.insert(key);
                closure.push(composed);
            }
        }
        left_index += 1;
    }
    true
}

pub(crate) fn size_change_graph_is_bad_idempotent(graph: &SizeChangeClosureGraph) -> bool {
    graph.source == graph.target
        && size_change_graph_is_idempotent(graph)
        && !size_change_graph_has_strict_self_loop(graph)
}

pub(crate) fn size_change_graph_is_idempotent(graph: &SizeChangeClosureGraph) -> bool {
    compose_size_change_graphs(graph, graph).is_some_and(|composed| composed == *graph)
}

pub(crate) fn size_change_graph_has_strict_self_loop(graph: &SizeChangeClosureGraph) -> bool {
    (1..=graph.source_arity.min(graph.target_arity)).any(|position| {
        graph
            .edges
            .get(&(position, position))
            .copied()
            .unwrap_or(false)
    })
}

pub(crate) fn compose_size_change_graphs(
    first: &SizeChangeClosureGraph,
    second: &SizeChangeClosureGraph,
) -> Option<SizeChangeClosureGraph> {
    if first.target != second.source || first.target_arity != second.source_arity {
        return None;
    }
    let mut edges = BTreeMap::<(usize, usize), bool>::new();
    for ((left, middle), first_strict) in &first.edges {
        for ((second_middle, right), second_strict) in &second.edges {
            if middle != second_middle {
                continue;
            }
            let strict = *first_strict || *second_strict;
            edges
                .entry((*left, *right))
                .and_modify(|existing| *existing |= strict)
                .or_insert(strict);
        }
    }
    Some(SizeChangeClosureGraph {
        source: first.source.clone(),
        target: second.target.clone(),
        source_arity: first.source_arity,
        target_arity: second.target_arity,
        edges,
    })
}

pub(crate) fn term_app_parts(term: &Term) -> Option<(&Symbol, &[Term])> {
    match term {
        Term::Var(_) => None,
        Term::App { symbol, args } => Some((symbol, args)),
    }
}

#[cfg(test)]
mod frozen_recursive_subterm_tests {
    use super::*;

    fn list_residual_csr(and_positions: BTreeSet<usize>) -> CsrTrs {
        let variables = BTreeSet::from([
            Variable::new("x"),
            Variable::new("head"),
            Variable::new("tail"),
        ]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "isLNat",
                        vec![Term::app(
                            "cons",
                            vec![Term::var("head"), Term::var("tail")],
                        )],
                    ),
                    Term::app(
                        "and",
                        vec![
                            Term::app("isNatural", vec![Term::var("head")]),
                            Term::app("isLNat", vec![Term::var("tail")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("and", vec![Term::app("tt", Vec::new()), Term::var("x")]),
                    Term::var("x"),
                ),
            ],
        );
        CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("isLNat"), BTreeSet::new()),
                (Symbol::new("cons"), BTreeSet::from([0])),
                (Symbol::new("and"), and_positions),
                (Symbol::new("isNatural"), BTreeSet::from([0])),
                (Symbol::new("tt"), BTreeSet::new()),
            ])),
        )
        .expect("valid replacement map")
    }

    fn list_residual_pairs() -> Vec<DependencyPair> {
        vec![
            DependencyPair::new_for_test(
                Term::app("__CSR_U0", vec![Term::app("isLNat", vec![Term::var("x")])]),
                Term::app("isLNat#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "and#",
                    vec![
                        Term::app("tt", Vec::new()),
                        Term::app("isLNat", vec![Term::var("x")]),
                    ],
                ),
                Term::app("__CSR_U0", vec![Term::app("isLNat", vec![Term::var("x")])]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "isLNat#",
                    vec![Term::app(
                        "cons",
                        vec![Term::var("head"), Term::var("tail")],
                    )],
                ),
                Term::app(
                    "and#",
                    vec![
                        Term::app("isNatural", vec![Term::var("head")]),
                        Term::app("isLNat", vec![Term::var("tail")]),
                    ],
                ),
            ),
        ]
    }

    #[test]
    fn frozen_recursive_projection_closes_list_residual() {
        let csr = list_residual_csr(BTreeSet::from([0]));
        let pairs = list_residual_pairs();
        let (entries, strict) = synthesize_frozen_recursive_subterm_criterion(&csr, &pairs, None)
            .expect("recursive projection");
        let projection = entries
            .iter()
            .map(|entry| (entry.symbol.as_str(), entry.position))
            .collect::<BTreeMap<_, _>>();

        assert_eq!(strict, vec![2]);
        assert_eq!(projection.get("__CSR_U0"), Some(&0));
        assert_eq!(projection.get("isLNat#"), Some(&0));
        assert_eq!(projection.get("and#"), Some(&1));
        assert_eq!(projection.get("isLNat"), Some(&0));
    }

    #[test]
    fn frozen_recursive_projection_rejects_active_root_position() {
        let csr = list_residual_csr(BTreeSet::from([0, 1]));
        assert!(
            synthesize_frozen_recursive_subterm_criterion(&csr, &list_residual_pairs(), None)
                .is_none()
        );
    }

    #[test]
    fn frozen_recursive_projection_requires_the_inner_collapse() {
        let projection = BTreeMap::from([
            (Symbol::new("__CSR_U0"), 0),
            (Symbol::new("isLNat#"), 0),
            (Symbol::new("and#"), 1),
        ]);
        assert!(
            list_residual_pairs()
                .iter()
                .any(|pair| frozen_recursive_pair_comparison(pair, &projection).is_none())
        );
    }
}
