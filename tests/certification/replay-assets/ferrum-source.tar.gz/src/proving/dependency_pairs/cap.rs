use super::*;

pub(super) fn ceta_q_iedg_edge(
    _trs: &Trs,
    selected: &DependencyPair,
    successor: &DependencyPair,
    q_lhss: &[Term],
    reverse_base_rules: &[RewriteRule],
) -> bool {
    ceta_q_iedg_edge_with_usable_rules(selected, successor, q_lhss, reverse_base_rules, None)
}

pub(super) fn ceta_q_iedg_edge_with_usable_rules(
    selected: &DependencyPair,
    successor: &DependencyPair,
    q_lhss: &[Term],
    reverse_base_rules: &[RewriteRule],
    pair_usable_rules: Option<&[RewriteRule]>,
) -> bool {
    let selected_lhs_x = prefix_term_variables(selected.lhs(), "x");
    let selected_rhs_x = prefix_term_variables(selected.rhs(), "x");
    let successor_lhs_y = prefix_term_variables(successor.lhs(), "y");
    // A Q-redex already present in the successor pattern survives every
    // substitution, so it cannot occur as a Q-normal DP-chain element.
    if !term_is_q_normal(&successor_lhs_y, q_lhss) {
        return false;
    }
    let selected_rhs_y = prefix_term_variables(selected.rhs(), "y");
    let selected_lhs_y = prefix_term_variables(selected.lhs(), "y");
    let successor_lhs_x = prefix_term_variables(successor.lhs(), "x");
    let capped_selected_rhs = ceta_icap_q(
        reverse_base_rules,
        q_lhss,
        &[selected_lhs_x],
        &selected_rhs_x,
    );
    let mut edge_substitution = BTreeMap::new();
    if !unify_terms(
        &capped_selected_rhs,
        &successor_lhs_y,
        &mut edge_substitution,
    ) {
        return false;
    }
    if !term_is_q_normal(
        &apply_substitution(
            &prefix_term_variables(selected.lhs(), "x"),
            &edge_substitution,
        ),
        q_lhss,
    ) || !term_is_q_normal(
        &apply_substitution(&successor_lhs_y, &edge_substitution),
        q_lhss,
    ) {
        return false;
    }
    let computed_usable_rules;
    let pair_usable_rules = if let Some(pair_usable_rules) = pair_usable_rules {
        pair_usable_rules
    } else {
        computed_usable_rules =
            ceta_innermost_usable_rules_for_pair(reverse_base_rules, q_lhss, selected);
        &computed_usable_rules
    };
    let reversed_rules = reverse_rules(pair_usable_rules);
    ceta_q_iedg_reverse_check(
        selected,
        successor,
        q_lhss,
        &selected_rhs_y,
        &selected_lhs_y,
        &successor_lhs_x,
        &reversed_rules,
    )
}

/// Finish the reverse-CAP half of CeTA's Q-IEDG test using a rule set that
/// the caller has already reversed.  Dependency-graph construction applies
/// this test to many pair combinations under one fixed active rule context;
/// rebuilding the same reversed TRS for every candidate edge dominated large
/// generated Innermost problems.
pub(super) fn ceta_q_iedg_reverse_check(
    _selected: &DependencyPair,
    _successor: &DependencyPair,
    q_lhss: &[Term],
    selected_rhs_y: &Term,
    selected_lhs_y: &Term,
    successor_lhs_x: &Term,
    reversed_rules: &[RewriteRule],
) -> bool {
    let capped_successor_lhs = ceta_icap_empty_q(&reversed_rules, &[], true, &successor_lhs_x);
    let mut reverse_substitution = BTreeMap::new();
    if !unify_terms(
        &capped_successor_lhs,
        &selected_rhs_y,
        &mut reverse_substitution,
    ) {
        return false;
    }
    term_is_q_normal(
        &apply_substitution(&selected_lhs_y, &reverse_substitution),
        q_lhss,
    )
}

pub(super) fn ceta_q_iedg_edge_with_precomputed_reversed_usable_rules(
    selected: &DependencyPair,
    successor: &DependencyPair,
    q_lhss: &[Term],
    reverse_base_rules: &[RewriteRule],
    reversed_usable_rules: &[RewriteRule],
) -> bool {
    let source = ceta_q_iedg_source_context(selected, q_lhss, reverse_base_rules);
    let target = ceta_q_iedg_target_context(successor, q_lhss, reversed_usable_rules);
    ceta_q_iedg_edge_from_contexts(&source, &target, q_lhss)
}

#[derive(Clone, Debug)]
pub(super) struct CetaQIEDGSourceContext {
    selected_lhs_x: Term,
    selected_rhs_y: Term,
    selected_lhs_y: Term,
    capped_selected_rhs: Term,
}

#[derive(Clone, Debug)]
pub(super) struct CetaQIEDGTargetContext {
    successor_lhs_y: Term,
    capped_successor_lhs: Term,
    q_normal: bool,
}

pub(super) fn ceta_q_iedg_source_context(
    selected: &DependencyPair,
    q_lhss: &[Term],
    reverse_base_rules: &[RewriteRule],
) -> CetaQIEDGSourceContext {
    let selected_lhs_x = prefix_term_variables(selected.lhs(), "x");
    let selected_rhs_x = prefix_term_variables(selected.rhs(), "x");
    CetaQIEDGSourceContext {
        selected_rhs_y: prefix_term_variables(selected.rhs(), "y"),
        selected_lhs_y: prefix_term_variables(selected.lhs(), "y"),
        capped_selected_rhs: ceta_icap_q(
            reverse_base_rules,
            q_lhss,
            std::slice::from_ref(&selected_lhs_x),
            &selected_rhs_x,
        ),
        selected_lhs_x,
    }
}

pub(super) fn ceta_q_iedg_target_context(
    successor: &DependencyPair,
    q_lhss: &[Term],
    reversed_usable_rules: &[RewriteRule],
) -> CetaQIEDGTargetContext {
    let successor_lhs_y = prefix_term_variables(successor.lhs(), "y");
    let successor_lhs_x = prefix_term_variables(successor.lhs(), "x");
    CetaQIEDGTargetContext {
        q_normal: term_is_q_normal(&successor_lhs_y, q_lhss),
        capped_successor_lhs: ceta_icap_empty_q(reversed_usable_rules, &[], true, &successor_lhs_x),
        successor_lhs_y,
    }
}

pub(super) fn ceta_q_iedg_edge_from_contexts(
    source: &CetaQIEDGSourceContext,
    target: &CetaQIEDGTargetContext,
    q_lhss: &[Term],
) -> bool {
    if !target.q_normal {
        return false;
    }
    let mut edge_substitution = BTreeMap::new();
    if !unify_terms(
        &source.capped_selected_rhs,
        &target.successor_lhs_y,
        &mut edge_substitution,
    ) {
        return false;
    }
    if !term_is_q_normal(
        &apply_substitution(&source.selected_lhs_x, &edge_substitution),
        q_lhss,
    ) || !term_is_q_normal(
        &apply_substitution(&target.successor_lhs_y, &edge_substitution),
        q_lhss,
    ) {
        return false;
    }
    let mut reverse_substitution = BTreeMap::new();
    if !unify_terms(
        &target.capped_successor_lhs,
        &source.selected_rhs_y,
        &mut reverse_substitution,
    ) {
        return false;
    }
    term_is_q_normal(
        &apply_substitution(&source.selected_lhs_y, &reverse_substitution),
        q_lhss,
    )
}

pub(crate) fn ceta_innermost_usable_rules_for_pair(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    pair: &DependencyPair,
) -> Vec<RewriteRule> {
    ceta_innermost_usable_rules_for_pairs(rules, q_lhss, std::slice::from_ref(pair))
}

/// Union of CeTA's pair-local innermost usable-rule closures.
///
/// The closure is a monotone reachability fixed point.  Seeding one worklist
/// with every pair context is therefore exactly equivalent to computing a
/// fixed point per pair and taking their union, while shared rule-RHS
/// contexts are expanded only once.
pub(crate) fn ceta_innermost_usable_rules_for_pairs(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    if q_lhss.is_empty()
        || pairs
            .iter()
            .any(|pair| !pair.rhs().variables().is_subset(&pair.lhs().variables()))
    {
        return rules.to_vec();
    }
    let initial = pairs
        .iter()
        .map(|pair| (vec![pair.lhs().clone()], pair.rhs().clone()))
        .collect::<HashSet<_>>();
    ceta_innermost_usable_rules_for_contexts(rules, q_lhss, initial, None)
}

/// Check the innermost branch of CeTA's smart_usable_rules_checker_impl.
/// The caller must additionally establish normal-form substitutions (or the
/// alternative variable/minimality hypotheses). Filtering affects descent,
/// never root matching; all supplied U rules contribute closure obligations.
pub(crate) fn ceta_innermost_usable_rules_closed_with_filter(
    rules: &[RewriteRule], q_lhss: &[Term], pairs: &[DependencyPair],
    usable: &[RewriteRule], filter: &DpArgumentFilter,
) -> bool {
    if rules.iter().any(|r| term_is_q_normal(r.lhs(), q_lhss))
        || usable.iter().any(|r| !rules.contains(r))
    {
        return false;
    }
    let initial = pairs.iter()
        .map(|p| (vec![p.lhs().clone()], p.rhs().clone()))
        .chain(usable.iter().map(|r| (term_arguments(r.lhs()).to_vec(), r.rhs().clone())))
        .collect();
    ceta_innermost_usable_rules_for_contexts(rules, q_lhss, initial, Some(filter))
        .iter().all(|r| usable.contains(r))
}

pub(super) fn ceta_innermost_usable_rules_for_term(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    preserved: &[Term],
    term: &Term,
) -> Vec<RewriteRule> {
    ceta_innermost_usable_rules_for_contexts(
        rules,
        q_lhss,
        HashSet::from([(preserved.to_vec(), term.clone())]),
        None,
    )
}

fn ceta_innermost_usable_rules_for_contexts(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    initial_contexts: HashSet<(Vec<Term>, Term)>,
    argument_filter: Option<&DpArgumentFilter>,
) -> Vec<RewriteRule> {
    let mut rules_by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    let mut variable_lhs_rules = Vec::new();
    for (index, rule) in rules.iter().enumerate() {
        if let Some(root) = rule.lhs().root_symbol() {
            rules_by_root.entry(root.clone()).or_default().push(index);
        } else {
            variable_lhs_rules.push(index);
        }
    }
    let (q_by_root, variable_q_lhss) = index_lhss_by_root(q_lhss);
    let preserve_vars = rules
        .iter()
        .all(|rule| !term_is_q_normal_indexed(rule.lhs(), q_lhss, &q_by_root, &variable_q_lhss));
    let mut usable = BTreeSet::new();
    let mut contexts = initial_contexts.iter().cloned().collect::<Vec<_>>();
    let mut seen_contexts = initial_contexts;
    let mut expanded_rules = BTreeSet::new();
    let mut next_context = 0;
    while next_context < contexts.len() {
        let (preserved, term) = contexts[next_context].clone();
        next_context += 1;
        ceta_collect_innermost_usable_rules_indexed(
            rules,
            q_lhss,
            &preserved,
            &term,
            &mut usable,
            &rules_by_root,
            &variable_lhs_rules,
            preserve_vars,
            &q_by_root,
            &variable_q_lhss,
            argument_filter,
        );
        // Each admitted rule contributes its RHS context exactly once.  The
        // previous loop revisited every already admitted rule after every new
        // context and linearly rescanned the complete context vector.  That
        // was equivalent but cubic on large GM04 systems (1,158 pairs and
        // hundreds of rules), turning replay of a certified witness into a
        // minute-long validation.
        let newly_usable = usable
            .iter()
            .copied()
            .filter(|index| expanded_rules.insert(*index))
            .collect::<Vec<_>>();
        for rule_index in newly_usable {
            let rule = &rules[rule_index];
            let context = (term_arguments(rule.lhs()).to_vec(), rule.rhs().clone());
            if seen_contexts.insert(context.clone()) {
                contexts.push(context);
            }
        }
    }

    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

fn ceta_collect_innermost_usable_rules_indexed(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    preserved: &[Term],
    term: &Term,
    usable: &mut BTreeSet<usize>,
    rules_by_root: &BTreeMap<Symbol, Vec<usize>>,
    variable_lhs_rules: &[usize],
    preserve_vars: bool,
    q_by_root: &BTreeMap<Symbol, Vec<usize>>,
    variable_q_lhss: &[usize],
    argument_filter: Option<&DpArgumentFilter>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    for (index, argument) in args.iter().enumerate() {
        if argument_filter.and_then(|af| af.get(symbol.as_str())).is_some_and(|entry| match entry {
            DpArgumentFilterEntry::Collapsing(position) => *position != index,
            DpArgumentFilterEntry::NonCollapsing(positions) => !positions.contains(&index),
        }) {
            continue;
        }
        ceta_collect_innermost_usable_rules_indexed(
            rules,
            q_lhss,
            preserved,
            argument,
            usable,
            rules_by_root,
            variable_lhs_rules,
            preserve_vars,
            q_by_root,
            variable_q_lhss,
            argument_filter,
        );
    }

    let preserved_x = preserved
        .iter()
        .map(|term| prefix_term_variables(term, "x"))
        .collect::<Vec<_>>();
    let preserved_variables = preserved_x
        .iter()
        .flat_map(Term::variables)
        .collect::<BTreeSet<_>>();
    // Distinct capped positions are independent variables, also across
    // different arguments of this root.
    let mut cap_index = 0usize;
    let capped_args = args
        .iter()
        .map(|argument| {
            ceta_icap_q_inner_indexed(
                rules,
                q_lhss,
                &preserved_x,
                &preserved_variables,
                preserve_vars,
                &prefix_term_variables(argument, "x"),
                &mut cap_index,
                rules_by_root,
                variable_lhs_rules,
                q_by_root,
                variable_q_lhss,
            )
        })
        .collect();
    let capped_term = Term::app(symbol.as_str(), capped_args);

    for rule_index in rules_by_root
        .get(symbol)
        .into_iter()
        .flatten()
        .chain(variable_lhs_rules)
        .copied()
    {
        let rule = &rules[rule_index];
        let rule_lhs_y = prefix_term_variables(rule.lhs(), "y");
        let mut substitution = BTreeMap::new();
        if !unify_terms(&capped_term, &rule_lhs_y, &mut substitution) {
            continue;
        }
        let rule_arguments_are_normal = term_arguments(rule.lhs()).iter().all(|argument| {
            term_is_q_normal_indexed(
                &apply_substitution(&prefix_term_variables(argument, "y"), &substitution),
                q_lhss,
                q_by_root,
                variable_q_lhss,
            )
        });
        let preserved_terms_are_normal = preserved_x.iter().all(|term| {
            term_is_q_normal_indexed(
                &apply_substitution(term, &substitution),
                q_lhss,
                q_by_root,
                variable_q_lhss,
            )
        });
        if rule_arguments_are_normal && preserved_terms_are_normal {
            usable.insert(rule_index);
        }
    }
}

pub(super) fn ceta_icap_q(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    preserve_terms: &[Term],
    term: &Term,
) -> Term {
    let preserved_variables = preserve_terms
        .iter()
        .flat_map(Term::variables)
        .collect::<BTreeSet<_>>();
    let preserve_vars = rules
        .iter()
        .all(|rule| !term_is_q_normal(rule.lhs(), q_lhss));
    let (q_by_root, variable_q_lhss) = index_lhss_by_root(q_lhss);
    let mut rules_by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    let mut variable_lhs_rules = Vec::new();
    for (index, rule) in rules.iter().enumerate() {
        if let Some(root) = rule.lhs().root_symbol() {
            rules_by_root.entry(root.clone()).or_default().push(index);
        } else {
            variable_lhs_rules.push(index);
        }
    }
    let mut cap_index = 0usize;
    ceta_icap_q_inner_indexed(
        rules,
        q_lhss,
        preserve_terms,
        &preserved_variables,
        preserve_vars,
        term,
        &mut cap_index,
        &rules_by_root,
        &variable_lhs_rules,
        &q_by_root,
        &variable_q_lhss,
    )
}

fn ceta_icap_q_inner_indexed(
    rules: &[RewriteRule],
    q_lhss: &[Term],
    preserve_terms: &[Term],
    preserved_variables: &BTreeSet<Variable>,
    preserve_vars: bool,
    term: &Term,
    cap_index: &mut usize,
    rules_by_root: &BTreeMap<Symbol, Vec<usize>>,
    variable_lhs_rules: &[usize],
    q_by_root: &BTreeMap<Symbol, Vec<usize>>,
    variable_q_lhss: &[usize],
) -> Term {
    match term {
        Term::Var(variable) if preserve_vars && preserved_variables.contains(variable) => {
            term.clone()
        }
        Term::Var(_) => ceta_fresh_cap_variable(cap_index),
        Term::App { symbol, args } => {
            let capped = Term::app(
                symbol.as_str(),
                args.iter()
                    .map(|arg| {
                        ceta_icap_q_inner_indexed(
                            rules,
                            q_lhss,
                            preserve_terms,
                            preserved_variables,
                            preserve_vars,
                            arg,
                            cap_index,
                            rules_by_root,
                            variable_lhs_rules,
                            q_by_root,
                            variable_q_lhss,
                        )
                    })
                    .collect(),
            );
            if rules_by_root
                .get(symbol)
                .into_iter()
                .flatten()
                .chain(variable_lhs_rules)
                .copied()
                .any(|rule_index| {
                    let rule = &rules[rule_index];
                    let lhs = prefix_term_variables(rule.lhs(), "y");
                    let mut substitution = BTreeMap::new();
                    unify_terms(&capped, &lhs, &mut substitution)
                        && term_arguments(rule.lhs()).iter().all(|arg| {
                            term_is_q_normal_indexed(
                                &apply_substitution(
                                    &prefix_term_variables(arg, "y"),
                                    &substitution,
                                ),
                                q_lhss,
                                q_by_root,
                                variable_q_lhss,
                            )
                        })
                        && preserve_terms.iter().all(|term| {
                            term_is_q_normal_indexed(
                                &apply_substitution(term, &substitution),
                                q_lhss,
                                q_by_root,
                                variable_q_lhss,
                            )
                        })
                })
            {
                ceta_fresh_cap_variable(cap_index)
            } else {
                capped
            }
        }
    }
}

fn index_lhss_by_root(lhss: &[Term]) -> (BTreeMap<Symbol, Vec<usize>>, Vec<usize>) {
    let mut by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    let mut variable = Vec::new();
    for (index, lhs) in lhss.iter().enumerate() {
        if let Some(root) = lhs.root_symbol() {
            by_root.entry(root.clone()).or_default().push(index);
        } else {
            variable.push(index);
        }
    }
    (by_root, variable)
}

fn term_is_q_normal_indexed(
    term: &Term,
    q_lhss: &[Term],
    q_by_root: &BTreeMap<Symbol, Vec<usize>>,
    variable_q_lhss: &[usize],
) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .all(|(_, subterm)| {
            let rooted = subterm
                .root_symbol()
                .and_then(|root| q_by_root.get(root))
                .into_iter()
                .flatten();
            !rooted
                .chain(variable_q_lhss)
                .copied()
                .any(|index| pattern_matches_with_fresh_variables(&q_lhss[index], subterm))
        })
}

pub(crate) fn term_is_q_normal(term: &Term, q_lhss: &[Term]) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .all(|(_, subterm)| !term_is_guaranteed_q_redex(subterm, q_lhss))
}

pub(super) fn ceta_icap_empty_q(
    rules: &[RewriteRule],
    preserve_terms: &[Term],
    preserve_vars: bool,
    term: &Term,
) -> Term {
    let preserved_variables = preserve_terms
        .iter()
        .flat_map(Term::variables)
        .collect::<BTreeSet<_>>();
    let mut cap_index = 0usize;
    ceta_icap_empty_q_inner(
        rules,
        &preserved_variables,
        preserve_vars,
        term,
        &mut cap_index,
    )
}

pub(super) fn ceta_icap_empty_q_inner(
    rules: &[RewriteRule],
    preserved_variables: &BTreeSet<Variable>,
    preserve_vars: bool,
    term: &Term,
    cap_index: &mut usize,
) -> Term {
    match term {
        Term::Var(variable) if preserve_vars && preserved_variables.contains(variable) => {
            term.clone()
        }
        Term::Var(_) => ceta_fresh_cap_variable(cap_index),
        Term::App { symbol, args } => {
            let capped = Term::app(
                symbol.as_str(),
                args.iter()
                    .map(|arg| {
                        ceta_icap_empty_q_inner(
                            rules,
                            preserved_variables,
                            preserve_vars,
                            arg,
                            cap_index,
                        )
                    })
                    .collect(),
            );
            if rules.iter().any(|rule| {
                if rule.lhs().root_symbol().is_some_and(|root| root != symbol) {
                    return false;
                }
                let lhs = prefix_term_variables(rule.lhs(), "y");
                let mut substitution = BTreeMap::new();
                unify_terms(&capped, &lhs, &mut substitution)
            }) {
                ceta_fresh_cap_variable(cap_index)
            } else {
                capped
            }
        }
    }
}

pub(super) fn ceta_fresh_cap_variable(cap_index: &mut usize) -> Term {
    let variable = Term::var(format!("z{}", *cap_index));
    *cap_index += 1;
    variable
}

pub(super) fn reverse_rules(rules: &[RewriteRule]) -> Vec<RewriteRule> {
    rules
        .iter()
        .map(|rule| RewriteRule::new(rule.rhs().clone(), rule.lhs().clone()))
        .collect()
}

#[cfg(test)]
mod filtered_usable_tests {
    use super::*;

    #[test]
    fn q_filtered_closure_checks_roots_and_only_retained_arguments() {
        let x = Term::var("x");
        let g = |t| Term::app("g", vec![t]);
        let rule = RewriteRule::new(g(x.clone()), x.clone());
        let rules = vec![rule];
        let q = rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
        let p = |rhs| DependencyPair::new_for_test(Term::app("P", vec![x.clone()]), rhs);
        let af = BTreeMap::from([
            ("g".to_owned(), DpArgumentFilterEntry::Collapsing(0)),
            ("C".to_owned(), DpArgumentFilterEntry::NonCollapsing(vec![])),
        ]);
        assert!(!ceta_innermost_usable_rules_closed_with_filter(
            &rules, &q, &[p(g(x.clone()))], &[], &af));
        assert!(ceta_innermost_usable_rules_closed_with_filter(
            &rules, &q, &[p(Term::app("C", vec![g(x.clone())]))], &[], &af));
        assert!(!ceta_innermost_usable_rules_closed_with_filter(
            &rules, &[], &[], &[], &af));
    }

    #[test]
    fn q_filtered_closure_checks_even_unreachable_supplied_rules() {
        let x = Term::var("x");
        let g = Term::app("g", vec![x.clone()]);
        let rules = vec![RewriteRule::new(Term::app("f", vec![x.clone()]), g.clone()),
            RewriteRule::new(g, x)];
        let q = rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
        assert!(!ceta_innermost_usable_rules_closed_with_filter(
            &rules, &q, &[], &rules[..1], &BTreeMap::new()));
        assert!(ceta_innermost_usable_rules_closed_with_filter(
            &rules, &q, &[], &rules, &BTreeMap::new()));
    }

    #[test]
    fn q_usable_cap_positions_are_fresh_across_arguments() {
        let a = Term::app("a", vec![]);
        let b = Term::app("b", vec![]);
        let g = |x| Term::app("g", vec![x]);
        let rules = vec![
            RewriteRule::new(g(Term::var("x")), a.clone()),
            RewriteRule::new(Term::app("f", vec![a.clone(), b.clone()]), a.clone()),
        ];
        let q = rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
        let pair = DependencyPair::new_for_test(Term::app("P", vec![]),
            Term::app("f", vec![g(a), g(b)]));
        assert!(!ceta_innermost_usable_rules_closed_with_filter(
            &rules, &q, &[pair], &rules[..1], &BTreeMap::new()));
    }
}
