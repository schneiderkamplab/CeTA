//! Dependency-pair reduction-pair synthesis and exact validation.
//!
//! Polynomial, matrix, Arctic, KBO, and path-order backends are variants of
//! the same atomic deletion processor.  They never schedule or solve their
//! residual DP problem here.

use super::*;

mod wpo_synthesis;
mod quasi_periodic;
#[path = "bounded_arctic_bv.rs"]
mod bounded_arctic_bv;
#[path = "arctic_threshold.rs"]
mod arctic_threshold;
#[path = "arctic_signed_threshold.rs"]
mod arctic_signed_threshold;
pub(crate) use quasi_periodic::synthesize_quasi_periodic;
pub(crate) use quasi_periodic::synthesize_quasi_periodic_bv;
#[cfg(test)]
pub(crate) use wpo_synthesis::synthesize_wpo_max;
pub(crate) use wpo_synthesis::synthesize_wpo_max_permuting;

pub(crate) fn orient_component_with_llm(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    allow_path_order: bool,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let client = options.llm_client.as_ref()?;
    let mut feedback = Vec::new();
    for iteration in 0..options.llm_iterations {
        let prompt = dp_component_prompt(pairs, usable, &feedback);
        match client.request_proposals(&prompt) {
            Ok(proposals) => {
                if let Some(removal) = checked_component_removal_from_llm(
                    pairs,
                    usable,
                    &proposals,
                    allow_path_order,
                    innermost_lhss,
                ) {
                    return Some(removal);
                }
                feedback.push(format!(
                    "iteration {}: all proposed reduction pairs were rejected by Ferrum's checker",
                    iteration + 1
                ));
            }
            Err(error) => feedback.push(format!(
                "iteration {}: LLM API request failed: {error}",
                iteration + 1
            )),
        }
    }
    None
}

pub(crate) fn checked_component_removal_from_llm(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    proposals: &[LlmProposal],
    allow_path_order: bool,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    for proposal in proposals {
        match proposal {
            LlmProposal::SymbolWeights { weights } => {
                if let Some(removal) = checked_component_removal_by_weights(
                    pairs,
                    usable,
                    weights,
                    DpSearchBackend::Llm,
                    innermost_lhss,
                ) {
                    return Some(removal);
                }
            }
            LlmProposal::LinearPolynomial { interpretations } => {
                if let Some(removal) = checked_component_removal_by_polynomial(
                    pairs,
                    usable,
                    interpretations,
                    DpSearchBackend::Llm,
                    false,
                    innermost_lhss,
                ) {
                    return Some(removal);
                }
            }
            LlmProposal::PathOrder {
                order,
                precedence,
                argument_filter,
            } => {
                if !allow_path_order {
                    continue;
                }
                if let Some(removal) = checked_component_removal_by_path_order(
                    pairs,
                    usable,
                    DpPathOrderKind::from(*order),
                    precedence,
                    &llm_argument_filter(argument_filter),
                    DpSearchBackend::Llm,
                    innermost_lhss,
                ) {
                    return Some(removal);
                }
            }
            LlmProposal::ProcessorChoice { .. } => {}
        }
    }
    None
}

pub(crate) fn checked_component_removal_by_weights(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    weights: &SymbolWeights,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("weights", pairs, innermost_lhss);
        return None;
    }
    if !usable
        .iter()
        .all(|rule| weakly_decreases_by_weights(rule.lhs(), rule.rhs(), weights))
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_weights(pair.lhs(), pair.rhs(), weights)
                .then_some(())
                .and_then(|_| {
                    strictly_decreases_by_weights(pair.lhs(), pair.rhs(), weights).then_some(index)
                })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs
        .iter()
        .all(|pair| weakly_decreases_by_weights(pair.lhs(), pair.rhs(), weights));
    (all_weak && !strict_pair_indices.is_empty()).then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::Polynomial {
            interpretation: weights_as_polynomial(pairs, usable, weights),
            backend,
        },
        smt_attempted: false,
        usable_rules: None,
    })
}

pub(crate) fn checked_component_removal_by_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
    backend: DpSearchBackend,
    smt_attempted: bool,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    checked_component_removal_by_polynomial_with_required_strict_rules(
        pairs,
        usable,
        interpretations,
        backend.clone(),
        smt_attempted,
        innermost_lhss,
        &[],
    )
}

pub(crate) fn checked_component_removal_by_polynomial_with_required_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
    backend: DpSearchBackend,
    smt_attempted: bool,
    innermost_lhss: Option<&[Term]>,
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    // `interpret_polynomial` gives unspecified symbols the identity
    // interpretation.  Materialize that default in the retained proof model:
    // CPF must serialize exactly the interpretation that was validated, rather
    // than turning an omitted symbol into the zero polynomial.
    let mut complete_interpretations = interpretations.clone();
    for (symbol, arity) in arities_for_constraints(pairs, usable) {
        complete_interpretations
            .entry(symbol)
            .or_insert_with(|| LinearPolynomial {
                constant: 0,
                coefficients: vec![1; arity],
            });
    }
    let interpretations = &complete_interpretations;
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("polynomial", pairs, innermost_lhss);
        return None;
    }
    let monotone = polynomial_coefficients_are_weakly_monotone(pairs, usable, interpretations);
    let nonnegative_constants = interpretations
        .values()
        .all(|interpretation| interpretation.constant >= 0);
    let first_nonweak_rule = usable
        .iter()
        .find(|rule| !weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), interpretations));
    if !monotone || !nonnegative_constants || first_nonweak_rule.is_some() {
        if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
            eprintln!(
                "exact polynomial precheck rejected monotone={monotone} nonnegative_constants={nonnegative_constants} first_nonweak_rule={} lhs_root={:?} rhs_root={:?}",
                first_nonweak_rule.map_or_else(|| "none".to_string(), ToString::to_string),
                first_nonweak_rule
                    .and_then(|rule| rule.lhs().root_symbol())
                    .and_then(|symbol| interpretations.get(symbol.as_str())),
                first_nonweak_rule
                    .and_then(|rule| rule.rhs().root_symbol())
                    .and_then(|symbol| interpretations.get(symbol.as_str())),
            );
        }
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), interpretations)
                .then_some(())
                .and_then(|_| {
                    strictly_decreases_by_polynomial(pair.lhs(), pair.rhs(), interpretations)
                        .then_some(index)
                })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs
        .iter()
        .all(|pair| weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), interpretations));
    let strict_rule_indices = if required_strict_rule_indices.is_empty() {
        Vec::new()
    } else {
        usable
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| {
                strictly_decreases_by_polynomial(rule.lhs(), rule.rhs(), interpretations)
                    .then_some(index)
            })
            .collect::<Vec<_>>()
    };
    let required_rules_are_strict = required_strict_rule_indices
        .iter()
        .all(|index| strict_rule_indices.contains(index));
    (all_weak
        && required_rules_are_strict
        && (!strict_pair_indices.is_empty() || !required_strict_rule_indices.is_empty()))
    .then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::Polynomial {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| {
                    (
                        name.clone(),
                        interpretation.constant,
                        interpretation.coefficients.clone(),
                    )
                })
                .collect(),
            backend,
        },
        smt_attempted,
        usable_rules: None,
    })
}

pub(crate) fn checked_component_removal_by_polynomial_with_usable_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let timing_started = Instant::now();
    let argument_filter = polynomial_argument_filter(pairs, usable, interpretations);
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "exact polynomial argument filter elapsed_ms={}",
            timing_started.elapsed().as_millis()
        );
    }
    let seed_usable = argument_filtered_usable_rules(usable, pairs, &argument_filter);
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "exact polynomial seed usable elapsed_ms={}",
            timing_started.elapsed().as_millis()
        );
    }
    let filtered_usable = complete_argument_filtered_usable_rules(
        usable,
        pairs,
        &seed_usable,
        Some(&argument_filter),
    );
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "exact polynomial usable closure elapsed_ms={}",
            timing_started.elapsed().as_millis()
        );
    }
    let has_negative_constant = interpretations
        .values()
        .any(|interpretation| interpretation.constant < 0);
    if has_negative_constant
        && (!filtered_usable.is_empty() || innermost_lhss.is_some_and(|q| !q.is_empty()))
    {
        return None;
    }
    let smt_attempted = backend == DpSearchBackend::Smt;
    let mut removal = checked_component_removal_by_polynomial(
        pairs,
        &filtered_usable,
        interpretations,
        backend.clone(),
        smt_attempted,
        innermost_lhss,
    )
    .or_else(|| {
        // Restricting R to a proper argument-filtered usable-rule closure is
        // itself progress for monoRedPairUrProc, even when every DP is only
        // weakly oriented.  Keep the exact-witness path aligned with the SMT
        // path so an exported oracle atom can independently reconstruct this
        // modular step (notably the Zantema z18 residual).
        (!same_rule_set(&filtered_usable, usable)
            && polynomial_q_minimality_holds(innermost_lhss)
            && polynomial_coefficients_are_weakly_monotone(
                pairs,
                &filtered_usable,
                interpretations,
            )
            && interpretations
                .values()
                .all(|interpretation| interpretation.constant >= 0)
            && pairs.iter().all(|pair| {
                weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), interpretations)
            })
            && filtered_usable.iter().all(|rule| {
                weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), interpretations)
            }))
        .then(|| ComponentRemoval {
            strict_pair_indices: Vec::new(),
            strict_rule_indices: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: interpretations
                    .iter()
                    .map(|(name, interpretation)| {
                        (
                            name.clone(),
                            interpretation.constant,
                            interpretation.coefficients.clone(),
                        )
                    })
                    .collect(),
                backend,
            },
            smt_attempted,
            usable_rules: None,
        })
    })?;
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "exact polynomial orientation elapsed_ms={}",
            timing_started.elapsed().as_millis()
        );
    }
    write_progress_event(
        "dp-order",
        "selected",
        "polynomial-usable-rules",
        0,
        &format!(
            "pairs={} input_usable_rules={} filtered_usable_rules={} strict_pairs={}",
            pairs.len(),
            usable.len(),
            filtered_usable.len(),
            removal.strict_pair_indices.len()
        ),
    );
    removal.usable_rules = Some(filtered_usable);
    Some(removal)
}

pub(crate) fn checked_component_removal_by_natural_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, NaturalPolynomial>,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("quadratic-polynomial", pairs, innermost_lhss);
        return None;
    }
    let arities = arities_for_constraints(pairs, usable);
    if !natural_polynomial_interpretations_are_monotone(&arities, interpretations)
        || !usable.iter().all(|rule| {
            weakly_decreases_by_natural_polynomial(rule.lhs(), rule.rhs(), interpretations)
        })
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_natural_polynomial(pair.lhs(), pair.rhs(), interpretations)
                .then_some(())
                .and_then(|_| {
                    strictly_decreases_by_natural_polynomial(
                        pair.lhs(),
                        pair.rhs(),
                        interpretations,
                    )
                    .then_some(index)
                })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        weakly_decreases_by_natural_polynomial(pair.lhs(), pair.rhs(), interpretations)
    });
    (all_weak && !strict_pair_indices.is_empty()).then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::NaturalPolynomial {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| (name.clone(), interpretation.clone()))
                .collect(),
            degree: 2,
            backend,
        },
        smt_attempted: true,
        usable_rules: None,
    })
}

pub(crate) fn natural_polynomial_interpretations_are_monotone(
    arities: &BTreeMap<String, usize>,
    interpretations: &BTreeMap<String, NaturalPolynomial>,
) -> bool {
    arities.iter().all(|(symbol, arity)| {
        let Some(interpretation) = interpretations.get(symbol) else {
            return false;
        };
        interpretation.constant >= 0
            && interpretation.linear.len() == *arity
            && interpretation
                .linear
                .iter()
                .all(|coefficient| *coefficient >= 1)
            && interpretation.quadratic.len() == *arity
            && interpretation
                .quadratic
                .iter()
                .enumerate()
                .all(|(row, coefficients)| {
                    coefficients.len() == *arity
                        && coefficients
                            .iter()
                            .enumerate()
                            .all(|(column, coefficient)| column < row || *coefficient >= 0)
                })
    })
}

pub(crate) fn checked_component_removal_by_weak_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    fixed_usable_rules: bool,
    _options: &DpOptions,
    _deadline: Option<Instant>,
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("weak-polynomial", pairs, innermost_lhss);
        return None;
    }
    let argument_filter = polynomial_argument_filter(pairs, usable, interpretations);
    let filtered_usable = if fixed_usable_rules {
        usable.to_vec()
    } else {
        let seed_usable = argument_filtered_usable_rules(usable, pairs, &argument_filter);
        complete_argument_filtered_usable_rules(usable, pairs, &seed_usable, Some(&argument_filter))
    };
    // Negative constants are valid in CPF natural-polynomial interpretations,
    // including below usable rules.  Match CeTA's executable sufficient
    // comparison on the composed affine polynomials instead of rejecting the
    // entire class or accepting a stronger nested-max comparison that CeTA
    // cannot certify.
    write_progress_event(
        "dp-order",
        "candidate",
        "weak-polynomial",
        0,
        &format!(
            "pairs={} input_usable_rules={} filtered_usable_rules={} interpretation={interpretations:?}",
            pairs.len(),
            usable.len(),
            filtered_usable.len()
        ),
    );
    if !polynomial_coefficients_are_weakly_monotone(pairs, &filtered_usable, interpretations)
        || !filtered_usable.iter().all(|rule| {
            weakly_decreases_by_ceta_polynomial(rule.lhs(), rule.rhs(), interpretations)
        })
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            strictly_decreases_by_ceta_polynomial(pair.lhs(), pair.rhs(), interpretations)
                .then_some(index)
        })
        .collect::<Vec<_>>();
    let all_weak = pairs
        .iter()
        .all(|pair| weakly_decreases_by_ceta_polynomial(pair.lhs(), pair.rhs(), interpretations));
    (all_weak && !strict_pair_indices.is_empty()).then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::Polynomial {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| {
                    (
                        name.clone(),
                        interpretation.constant,
                        interpretation.coefficients.clone(),
                    )
                })
                .collect(),
            backend,
        },
        smt_attempted: true,
        usable_rules: Some(filtered_usable),
    })
}

pub(crate) fn polynomial_argument_filter(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
) -> DpArgumentFilter {
    arities_for_constraints(pairs, rules)
        .into_iter()
        .map(|(symbol, arity)| {
            let positions = interpretations
                .get(&symbol)
                .map(|interpretation| {
                    (0..arity)
                        .filter(|index| {
                            interpretation
                                .coefficients
                                .get(*index)
                                .copied()
                                .unwrap_or(1)
                                > 0
                        })
                        .collect()
                })
                .unwrap_or_else(|| (0..arity).collect());
            (symbol, DpArgumentFilterEntry::NonCollapsing(positions))
        })
        .collect()
}

#[cfg(test)]
pub(crate) fn checked_component_removal_by_max_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &MaxPolynomialInterpretations,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    checked_component_removal_by_max_polynomial_with_required_strict_rules(
        pairs,
        usable,
        interpretations,
        backend,
        innermost_lhss,
        &[],
    )
}

pub(crate) fn checked_component_removal_by_max_polynomial_with_required_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &MaxPolynomialInterpretations,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("max-polynomial", pairs, innermost_lhss);
        return None;
    }
    if !max_polynomial_coefficients_are_weakly_monotone(pairs, usable, interpretations)
        || !usable
            .iter()
            .all(|rule| weakly_decreases_by_max_polynomial(rule.lhs(), rule.rhs(), interpretations))
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_max_polynomial(pair.lhs(), pair.rhs(), interpretations)
                .then_some(())
                .and_then(|_| {
                    strictly_decreases_by_max_polynomial(pair.lhs(), pair.rhs(), interpretations)
                        .then_some(index)
                })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs
        .iter()
        .all(|pair| weakly_decreases_by_max_polynomial(pair.lhs(), pair.rhs(), interpretations));
    let strict_rule_indices = if required_strict_rule_indices.is_empty() {
        Vec::new()
    } else {
        usable
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| {
                strictly_decreases_by_max_polynomial(rule.lhs(), rule.rhs(), interpretations)
                    .then_some(index)
            })
            .collect::<Vec<_>>()
    };
    let required_rules_are_strict = required_strict_rule_indices
        .iter()
        .all(|index| strict_rule_indices.contains(index));
    (all_weak
        && required_rules_are_strict
        && (!strict_pair_indices.is_empty() || !required_strict_rule_indices.is_empty()))
    .then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::MaxPolynomial {
            interpretation: interpretations
                .iter()
                .map(|(symbol, alternatives)| {
                    (
                        symbol.clone(),
                        alternatives
                            .iter()
                            .map(|alternative| {
                                (alternative.constant, alternative.coefficients.clone())
                            })
                            .collect(),
                    )
                })
                .collect(),
            backend,
        },
        smt_attempted: true,
        usable_rules: None,
    })
}

pub(crate) fn checked_component_removal_by_wpo_max(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    witness: &DpWpoMaxWitness,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    if innermost_lhss.is_some_and(|terms| !terms.is_empty()) {
        log_q_minimality_rejection("weighted-path-order-max", pairs, innermost_lhss);
        return None;
    }
    let interpretations = witness
        .interpretation
        .iter()
        .map(|(name, alternatives)| {
            (
                name.clone(),
                alternatives
                    .iter()
                    .map(|(constant, coefficients)| LinearPolynomial {
                        constant: *constant,
                        coefficients: coefficients.clone(),
                    })
                    .collect::<Vec<_>>(),
            )
        })
        .collect::<MaxPolynomialInterpretations>();
    if interpretations.len() != witness.interpretation.len()
        || !max_polynomial_coefficients_are_weakly_monotone(pairs, usable, &interpretations)
    {
        write_progress_event(
            "dp-exact-witness",
            "rejected",
            "exact-wpo-max",
            0,
            "incomplete or non-monotone max-polynomial base",
        );
        return None;
    }
    let order = WpoMaxOrder {
        precedence_ranks: &witness.precedence_ranks,
        statuses: &witness.statuses,
        interpretations: &interpretations,
    };
    let rule_comparisons = usable
        .iter()
        .map(|rule| {
            order.compare(
                &filter_term(rule.lhs(), &witness.argument_filter),
                &filter_term(rule.rhs(), &witness.argument_filter),
            )
        })
        .collect::<Vec<_>>();
    if rule_comparisons.iter().any(|comparison| !comparison.1) {
        write_progress_event(
            "dp-exact-witness",
            "rejected",
            "exact-wpo-max",
            0,
            &format!("rule_comparisons={rule_comparisons:?}"),
        );
        return None;
    }
    let comparisons = pairs
        .iter()
        .map(|pair| {
            order.compare(
                &filter_term(pair.lhs(), &witness.argument_filter),
                &filter_term(pair.rhs(), &witness.argument_filter),
            )
        })
        .collect::<Vec<_>>();
    if comparisons.iter().any(|comparison| !comparison.1) {
        write_progress_event(
            "dp-exact-witness",
            "rejected",
            "exact-wpo-max",
            0,
            &format!("pair_comparisons={comparisons:?}"),
        );
        return None;
    }
    let strict_pair_indices = comparisons
        .iter()
        .enumerate()
        .filter_map(|(index, comparison)| comparison.0.then_some(index))
        .collect::<Vec<_>>();
    if strict_pair_indices.is_empty() {
        write_progress_event(
            "dp-exact-witness",
            "rejected",
            "exact-wpo-max",
            0,
            &format!("no strict pair: pair_comparisons={comparisons:?}"),
        );
        return None;
    }
    Some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::WeightedPathOrderMax {
            precedence_ranks: witness.precedence_ranks.clone(),
            statuses: witness.statuses.clone(),
            argument_filter: witness.argument_filter.clone(),
            interpretation: witness.interpretation.clone(),
            backend: DpSearchBackend::Smt,
        },
        smt_attempted: false,
        usable_rules: None,
    })
}

#[cfg(test)]
#[test]
fn filtered_wpo_max_exactly_rechecks_collapsing_status_witness() {
    let x = Term::var("x");
    let unary = |symbol: &str, argument: Term| Term::app(symbol, vec![argument]);
    let pair = DependencyPair::new_for_test(
        unary("quote#", unary("s", x.clone())),
        unary("quote#", unary("mark", x.clone())),
    );
    let rule = RewriteRule::new(
        unary("mark", unary("dbl", x.clone())),
        unary("dblActive", unary("mark", x)),
    );
    let symbols = ["quote#", "s", "mark", "dbl", "dblActive"];
    let witness = DpWpoMaxWitness {
        precedence_ranks: symbols
            .iter()
            .map(|symbol| ((*symbol).to_owned(), 0))
            .collect(),
        statuses: symbols
            .iter()
            .map(|symbol| {
                (
                    (*symbol).to_owned(),
                    DpWpoStatus {
                        positions: vec![0],
                        multiset: false,
                    },
                )
            })
            .collect(),
        argument_filter: BTreeMap::from([(
            "mark".to_owned(),
            DpArgumentFilterEntry::Collapsing(0),
        )]),
        interpretation: symbols
            .iter()
            .map(|symbol| ((*symbol).to_owned(), vec![(0, vec![1])]))
            .collect(),
    };

    let removal = checked_component_removal_by_wpo_max(&[pair], &[rule], &witness, None)
        .expect("collapsing filtered WPO witness must be accepted");
    assert_eq!(removal.strict_pair_indices, vec![0]);

    let mut without_filter = witness;
    without_filter.argument_filter.clear();
    assert!(
        checked_component_removal_by_wpo_max(
            &[DependencyPair::new_for_test(
                unary("quote#", unary("s", Term::var("x"))),
                unary("quote#", unary("mark", Term::var("x"))),
            )],
            &[RewriteRule::new(
                unary("mark", unary("dbl", Term::var("x"))),
                unary("dblActive", unary("mark", Term::var("x"))),
            )],
            &without_filter,
            None,
        )
        .is_none()
    );
}

#[cfg(test)]
#[test]
fn wpo_weak_lex_prefix_must_check_the_remaining_arguments() {
    let ranks = BTreeMap::from([("a".into(), 0), ("b".into(), 0)]);
    let statuses = BTreeMap::new();
    let interpretations = ["a", "b"].into_iter().map(|name|
        (name.to_owned(), vec![LinearPolynomial { constant: 0, coefficients: vec![] }])
    ).collect();
    let order = WpoMaxOrder { precedence_ranks: &ranks, statuses: &statuses,
        interpretations: &interpretations };
    let a = Term::app("a", vec![]);
    let b = Term::app("b", vec![]);
    let x = Term::var("x");
    let y = Term::var("y");
    assert_eq!(order.compare(&a, &b), (false, true));
    assert_eq!(order.lex_extension(&[&a, &x], &[&b, &y]), (false, false));
    assert_eq!(order.lex_extension(&[&a, &x], &[&b, &x]), (false, true));
    assert_eq!(order.lex_extension(&[&a], &[&b, &x]), (false, false));
    assert_eq!(order.lex_extension(&[&a, &x], &[&b]), (true, true));
}

struct WpoMaxOrder<'a> {
    precedence_ranks: &'a BTreeMap<String, usize>,
    statuses: &'a BTreeMap<String, DpWpoStatus>,
    interpretations: &'a MaxPolynomialInterpretations,
}

impl WpoMaxOrder<'_> {
    /// Return `(strict, weak)`, following CeTA's executable WPO equations.
    fn compare(&self, lhs: &Term, rhs: &Term) -> (bool, bool) {
        if strictly_decreases_by_max_polynomial(lhs, rhs, self.interpretations) {
            return (true, true);
        }
        if !weakly_decreases_by_max_polynomial(lhs, rhs, self.interpretations) {
            return (false, false);
        }
        match lhs {
            Term::Var(left) => match rhs {
                Term::Var(right) => (false, left == right),
                Term::App { symbol, args } => {
                    let selected = self.selected(symbol.as_str(), args);
                    (
                        false,
                        selected.is_empty() && self.rank(symbol.as_str()) == 0,
                    )
                }
            },
            Term::App {
                symbol: left_symbol,
                args: left_args,
            } => {
                let selected_left = self.selected(left_symbol.as_str(), left_args);
                if selected_left
                    .iter()
                    .any(|argument| self.compare(argument, rhs).1)
                {
                    return (true, true);
                }
                let Term::App {
                    symbol: right_symbol,
                    args: right_args,
                } = rhs
                else {
                    // This is the strictly-simple/large-symbol WPO case.  A
                    // max-polynomial base is not assumed strictly simple.
                    return (false, false);
                };
                let left_rank = self.rank(left_symbol.as_str());
                let right_rank = self.rank(right_symbol.as_str());
                if left_rank < right_rank {
                    return (false, false);
                }
                let selected_right = self.selected(right_symbol.as_str(), right_args);
                if !selected_right
                    .iter()
                    .all(|argument| self.compare(lhs, argument).0)
                {
                    return (false, false);
                }
                if left_rank > right_rank {
                    return (true, true);
                }
                let left_multiset = self
                    .statuses
                    .get(left_symbol.as_str())
                    .is_some_and(|status| status.multiset);
                let right_multiset = self
                    .statuses
                    .get(right_symbol.as_str())
                    .is_some_and(|status| status.multiset);
                if left_multiset && right_multiset {
                    return self.multiset_extension(&selected_left, &selected_right);
                }
                if !left_multiset && !right_multiset {
                    return self.lex_extension(&selected_left, &selected_right);
                }
                if selected_right.is_empty() {
                    return (!selected_left.is_empty(), true);
                }
                (false, false)
            }
        }
    }

    fn rank(&self, symbol: &str) -> usize {
        self.precedence_ranks.get(symbol).copied().unwrap_or(0)
    }

    fn selected<'a>(&self, symbol: &str, args: &'a [Term]) -> Vec<&'a Term> {
        self.statuses
            .get(symbol)
            .map(|status| {
                status
                    .positions
                    .iter()
                    .filter_map(|position| args.get(*position))
                    .collect()
            })
            .unwrap_or_default()
    }

    fn lex_extension(&self, lhs: &[&Term], rhs: &[&Term]) -> (bool, bool) {
        // CeTA's lex_ext_unbounded continues after a weak, non-strict
        // comparison, not just after syntactic equality. Such a prefix
        // does not establish weak orientation of the whole tuple.
        let common = lhs.len().min(rhs.len());
        for index in 0..common {
            let comparison = self.compare(lhs[index], rhs[index]);
            if comparison.0 {
                return (true, true);
            }
            if !comparison.1 {
                return (false, false);
            }
        }
        (lhs.len() > rhs.len(), lhs.len() >= rhs.len())
    }

    fn multiset_extension(&self, lhs: &[&Term], rhs: &[&Term]) -> (bool, bool) {
        fn search(
            order: &WpoMaxOrder<'_>,
            lhs: &[&Term],
            rhs: &[&Term],
            index: usize,
            used: &mut [bool],
            strict: bool,
        ) -> Option<bool> {
            if index == rhs.len() {
                return Some(strict || lhs.len() > rhs.len());
            }
            for left in 0..lhs.len() {
                if used[left] {
                    continue;
                }
                let comparison = order.compare(lhs[left], rhs[index]);
                if !comparison.1 {
                    continue;
                }
                used[left] = true;
                if let Some(result) =
                    search(order, lhs, rhs, index + 1, used, strict || comparison.0)
                {
                    return Some(result);
                }
                used[left] = false;
            }
            None
        }
        let Some(strict) = search(self, lhs, rhs, 0, &mut vec![false; lhs.len()], false) else {
            return (false, false);
        };
        (strict, true)
    }
}

pub(crate) fn checked_component_removal_by_rational_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
    denominator: i64,
    backend: DpSearchBackend,
    _innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    if denominator <= 0
        || !rational_polynomial_coefficients_are_weakly_monotone(pairs, usable, interpretations)
        || !usable.iter().all(|rule| {
            weakly_decreases_by_rational_polynomial(
                rule.lhs(),
                rule.rhs(),
                interpretations,
                denominator,
            )
        })
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_rational_polynomial(
                pair.lhs(),
                pair.rhs(),
                interpretations,
                denominator,
            )
            .then_some(())
            .and_then(|_| {
                strictly_decreases_by_rational_polynomial(
                    pair.lhs(),
                    pair.rhs(),
                    interpretations,
                    denominator,
                )
                .then_some(index)
            })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        weakly_decreases_by_rational_polynomial(
            pair.lhs(),
            pair.rhs(),
            interpretations,
            denominator,
        )
    });
    (all_weak && !strict_pair_indices.is_empty()).then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::RationalPolynomial {
            denominator,
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| {
                    (
                        name.clone(),
                        interpretation.constant,
                        interpretation.coefficients.clone(),
                    )
                })
                .collect(),
            backend,
        },
        smt_attempted: false,
        usable_rules: None,
    })
}

pub(crate) fn checked_component_removal_by_rational_natural_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, NaturalPolynomial>,
    denominator: i64,
    delta: i64,
    backend: DpSearchBackend,
) -> Option<ComponentRemoval> {
    checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
        pairs,
        usable,
        interpretations,
        denominator,
        delta,
        backend,
        &[],
    )
}

pub(crate) fn checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, NaturalPolynomial>,
    denominator: i64,
    delta: i64,
    backend: DpSearchBackend,
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    let arities = arities_for_constraints(pairs, usable);
    if denominator <= 0
        || delta <= 0
        || !arities.iter().all(|(symbol, arity)| {
            interpretations.get(symbol).is_some_and(|interpretation| {
                interpretation.constant >= 0
                    && interpretation.linear.len() == *arity
                    && interpretation
                        .linear
                        .iter()
                        .all(|coefficient| *coefficient >= 0)
                    && interpretation.quadratic.len() == *arity
                    && interpretation
                        .quadratic
                        .iter()
                        .enumerate()
                        .all(|(row, values)| {
                            values.len() == *arity
                                && values
                                    .iter()
                                    .enumerate()
                                    .all(|(column, coefficient)| column < row || *coefficient >= 0)
                        })
            })
        })
        || !usable.iter().all(|rule| {
            rational_natural_polynomial_relation(
                rule.lhs(),
                rule.rhs(),
                interpretations,
                denominator,
                delta,
                false,
            )
        })
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            rational_natural_polynomial_relation(
                pair.lhs(),
                pair.rhs(),
                interpretations,
                denominator,
                delta,
                true,
            )
            .then_some(index)
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        rational_natural_polynomial_relation(
            pair.lhs(),
            pair.rhs(),
            interpretations,
            denominator,
            delta,
            false,
        )
    });
    let strict_rule_indices = if required_strict_rule_indices.is_empty() {
        Vec::new()
    } else {
        usable
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| {
                rational_natural_polynomial_relation(
                    rule.lhs(),
                    rule.rhs(),
                    interpretations,
                    denominator,
                    delta,
                    true,
                )
                .then_some(index)
            })
            .collect::<Vec<_>>()
    };
    let required_rules_are_strict = required_strict_rule_indices
        .iter()
        .all(|index| strict_rule_indices.contains(index));
    (all_weak
        && required_rules_are_strict
        && (!strict_pair_indices.is_empty() || !required_strict_rule_indices.is_empty()))
    .then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::RationalNaturalPolynomial {
            denominator,
            delta,
            interpretation: interpretations
                .iter()
                .map(|(symbol, polynomial)| (symbol.clone(), polynomial.clone()))
                .collect(),
            degree: 2,
            backend,
        },
        smt_attempted: true,
        usable_rules: None,
    })
}

#[cfg(test)]
pub(crate) fn checked_component_removal_by_matrix(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    checked_component_removal_by_matrix_with_required_strict_rules(
        pairs,
        usable,
        interpretations,
        backend,
        innermost_lhss,
        &[],
    )
}

pub(crate) fn checked_component_removal_by_matrix_with_required_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("matrix", pairs, innermost_lhss);
        return None;
    }
    let dimension = matrix_interpretation_dimension(interpretations)?;
    let strict_dimension = 1;
    if !matrix_interpretations_are_well_formed(interpretations, dimension) {
        return None;
    }
    if !usable
        .iter()
        .all(|rule| weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), interpretations, dimension))
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_matrix(pair.lhs(), pair.rhs(), interpretations, dimension)
                .then_some(())
                .and_then(|_| {
                    strictly_decreases_by_matrix(
                        pair.lhs(),
                        pair.rhs(),
                        interpretations,
                        dimension,
                        strict_dimension,
                    )
                    .then_some(index)
                })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs
        .iter()
        .all(|pair| weakly_decreases_by_matrix(pair.lhs(), pair.rhs(), interpretations, dimension));
    let strict_rule_indices = if required_strict_rule_indices.is_empty() {
        Vec::new()
    } else {
        usable
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| {
                strictly_decreases_by_matrix(
                    rule.lhs(),
                    rule.rhs(),
                    interpretations,
                    dimension,
                    strict_dimension,
                )
                .then_some(index)
            })
            .collect::<Vec<_>>()
    };
    let required_rules_are_strict = required_strict_rule_indices
        .iter()
        .all(|index| strict_rule_indices.contains(index));
    (all_weak
        && required_rules_are_strict
        && (!strict_pair_indices.is_empty() || !required_strict_rule_indices.is_empty()))
    .then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::Matrix {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| (name.clone(), interpretation.clone()))
                .collect(),
            dimension,
            strict_dimension,
            backend,
        },
        smt_attempted: false,
        usable_rules: None,
    })
}

pub(crate) fn checked_component_removal_by_integer_matrix(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("integer-matrix", pairs, innermost_lhss);
        return None;
    }
    let dimension = matrix_interpretation_dimension(interpretations)?;
    let strict_dimension = 1;
    if !integer_matrix_interpretations_are_well_formed(interpretations, dimension, strict_dimension)
        || !usable.iter().all(|rule| {
            weakly_decreases_by_integer_matrix(rule.lhs(), rule.rhs(), interpretations, dimension)
        })
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            (weakly_decreases_by_integer_matrix(pair.lhs(), pair.rhs(), interpretations, dimension)
                && strictly_decreases_by_integer_matrix(
                    pair.lhs(),
                    pair.rhs(),
                    interpretations,
                    dimension,
                    strict_dimension,
                ))
            .then_some(index)
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        weakly_decreases_by_integer_matrix(pair.lhs(), pair.rhs(), interpretations, dimension)
    });
    (all_weak && !strict_pair_indices.is_empty()).then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::IntegerMatrix {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| (name.clone(), interpretation.clone()))
                .collect(),
            dimension,
            strict_dimension,
            backend,
        },
        smt_attempted: true,
        usable_rules: None,
    })
}

pub(crate) fn integer_matrix_interpretations_are_well_formed(
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
    strict_dimension: usize,
) -> bool {
    dimension > 0
        && strict_dimension > 0
        && strict_dimension <= dimension
        && interpretations.values().all(|interpretation| {
            interpretation.constant.len() == dimension
                && interpretation.coefficients.iter().all(|matrix| {
                    matrix.len() == dimension
                        && matrix.iter().all(|row| {
                            row.len() == dimension && row.iter().all(|value| *value >= 0)
                        })
                })
        })
}

pub(crate) fn checked_component_removal_by_arctic_matrix(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    domain: ArcticMatrixDomain,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    if !polynomial_q_minimality_holds(innermost_lhss) {
        log_q_minimality_rejection("arctic-matrix", pairs, innermost_lhss);
        return None;
    }
    let dimension = matrix_interpretation_dimension(interpretations)?;
    if dimension == 0
        || !arctic_matrix_interpretations_are_well_formed(interpretations, dimension, domain)
        || !usable.iter().all(|rule| {
            weakly_decreases_by_arctic_matrix(rule.lhs(), rule.rhs(), interpretations, dimension)
        })
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_arctic_matrix(pair.lhs(), pair.rhs(), interpretations, dimension)
                .then_some(())
                .and_then(|_| {
                    strictly_decreases_by_arctic_matrix(
                        pair.lhs(),
                        pair.rhs(),
                        interpretations,
                        dimension,
                    )
                    .then_some(index)
                })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        weakly_decreases_by_arctic_matrix(pair.lhs(), pair.rhs(), interpretations, dimension)
    });
    (all_weak && !strict_pair_indices.is_empty()).then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices: Vec::new(),
        reduction_pair: DpReductionPairProof::ArcticMatrix {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| (name.clone(), interpretation.clone()))
                .collect(),
            dimension,
            strict_dimension: 1,
            domain,
            backend,
        },
        smt_attempted: true,
        usable_rules: None,
    })
}

fn arctic_argument_is_used(matrix: &[Vec<i64>]) -> bool {
    matrix.iter().flatten().any(|coefficient| *coefficient != i64::MIN)
}

#[cfg(test)]
mod arctic_argument_filter_tests {
    use super::arctic_argument_is_used;

    #[test]
    fn off_diagonal_dependence_must_retain_argument() {
        let bottom = i64::MIN;
        assert!(arctic_argument_is_used(&[vec![bottom, 0], vec![bottom, bottom]]));
        assert!(arctic_argument_is_used(&[vec![bottom, bottom], vec![-3, bottom]]));
        assert!(!arctic_argument_is_used(&[vec![bottom, bottom], vec![bottom, bottom]]));
        assert!(arctic_argument_is_used(&[vec![0]]));
        assert!(!arctic_argument_is_used(&[vec![bottom]]));
    }
}

pub(crate) fn checked_component_removal_by_arctic_matrix_with_usable_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    domain: ArcticMatrixDomain,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    fixed_usable_rules: bool,
) -> Option<ComponentRemoval> {
    let filtered_usable = if fixed_usable_rules {
        usable.to_vec()
    } else {
        matrix_interpretation_dimension(interpretations)?;
        let argument_filter = arities_for_constraints(pairs, usable)
            .into_iter()
            .map(|(symbol, arity)| {
                let positions = interpretations
                    .get(&symbol)
                    .map(|interpretation| {
                        (0..arity)
                            .filter(|index| {
                                interpretation
                                    .coefficients
                                    .get(*index)
                                    // An off-diagonal entry can make the
                                    // result depend on this argument even
                                    // when its (0,0) entry is minus infinity.
                                    .is_none_or(|matrix| arctic_argument_is_used(matrix))
                            })
                            .collect()
                    })
                    .unwrap_or_else(|| (0..arity).collect());
                (symbol, DpArgumentFilterEntry::NonCollapsing(positions))
            })
            .collect::<DpArgumentFilter>();
        let seed_usable = argument_filtered_usable_rules(usable, pairs, &argument_filter);
        complete_argument_filtered_usable_rules(usable, pairs, &seed_usable, Some(&argument_filter))
    };
    let mut removal = checked_component_removal_by_arctic_matrix(
        pairs,
        &filtered_usable,
        interpretations,
        domain,
        backend,
        innermost_lhss,
    )?;
    if !fixed_usable_rules {
        removal.usable_rules = Some(filtered_usable);
    }
    Some(removal)
}

pub(crate) fn arctic_matrix_interpretations_are_well_formed(
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
    domain: ArcticMatrixDomain,
) -> bool {
    let valid =
        |value: i64| value == i64::MIN || domain == ArcticMatrixDomain::Integers || value >= 0;
    interpretations.values().all(|interpretation| {
        interpretation.constant.len() == dimension
            && (interpretation.constant[0] >= 0
                || interpretation.coefficients.iter().any(|matrix| {
                    matrix
                        .first()
                        .and_then(|row| row.first())
                        .is_some_and(|value| *value >= 0)
                }))
            && interpretation.constant.iter().copied().all(valid)
            && interpretation.coefficients.iter().all(|matrix| {
                matrix.len() == dimension
                    && matrix
                        .iter()
                        .all(|row| row.len() == dimension && row.iter().copied().all(valid))
            })
    })
}

pub(crate) fn arctic_value_add(left: i64, right: i64) -> i64 {
    if left == i64::MIN || right == i64::MIN {
        i64::MIN
    } else {
        left.saturating_add(right)
    }
}

pub(crate) fn arctic_interpret(
    term: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> Option<Vec<Vec<ArcticValueAlternative>>> {
    match term {
        Term::Var(variable) => Some(
            (0..dimension)
                .map(|row| {
                    vec![ArcticValueAlternative {
                        value: 0,
                        source: Some((variable.clone(), row)),
                    }]
                })
                .collect(),
        ),
        Term::App { symbol, args } => {
            let interpretation = interpretations.get(symbol.as_str())?;
            if interpretation.coefficients.len() != args.len() {
                return None;
            }
            let arguments = args
                .iter()
                .map(|argument| arctic_interpret(argument, interpretations, dimension))
                .collect::<Option<Vec<_>>>()?;
            Some(
                (0..dimension)
                    .map(|row| {
                        let mut alternatives = Vec::new();
                        if interpretation.constant[row] != i64::MIN {
                            alternatives.push(ArcticValueAlternative {
                                value: interpretation.constant[row],
                                source: None,
                            });
                        }
                        for (argument, values) in arguments.iter().enumerate() {
                            for column in 0..dimension {
                                let coefficient =
                                    interpretation.coefficients[argument][row][column];
                                if coefficient == i64::MIN {
                                    continue;
                                }
                                alternatives.extend(values[column].iter().filter_map(
                                    |alternative| {
                                        let value =
                                            arctic_value_add(coefficient, alternative.value);
                                        (value != i64::MIN).then_some(ArcticValueAlternative {
                                            value,
                                            source: alternative.source.clone(),
                                        })
                                    },
                                ));
                            }
                        }
                        // max(c+x,d+x) = max(c,d)+x. Keeping every path
                        // through a matrix product is exponential in depth.
                        // Retain one maximal coefficient per variable
                        // component, and one constant.
                        let mut maxima = BTreeMap::new();
                        for alternative in alternatives {
                            maxima.entry(alternative.source)
                                .and_modify(|v: &mut i64| *v = (*v).max(alternative.value))
                                .or_insert(alternative.value);
                        }
                        maxima.into_iter().map(|(source, value)|
                            ArcticValueAlternative { value, source }).collect()
                    })
                    .collect(),
            )
        }
    }
}

pub(crate) fn arctic_row_dominates(
    lhs: &[ArcticValueAlternative],
    rhs: &[ArcticValueAlternative],
    strict: bool,
) -> bool {
    rhs.iter().all(|right| {
        lhs.iter().any(|left| {
            left.source == right.source
                && if strict {
                    left.value >= right.value.saturating_add(1)
                } else {
                    left.value >= right.value
                }
        })
    })
}

pub(crate) fn weakly_decreases_by_arctic_matrix(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> bool {
    let (Some(lhs), Some(rhs)) = (
        arctic_interpret(lhs, interpretations, dimension),
        arctic_interpret(rhs, interpretations, dimension),
    ) else {
        return false;
    };
    (0..dimension).all(|row| arctic_row_dominates(&lhs[row], &rhs[row], false))
}

pub(crate) fn strictly_decreases_by_arctic_matrix(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> bool {
    let (Some(lhs), Some(rhs)) = (
        arctic_interpret(lhs, interpretations, dimension),
        arctic_interpret(rhs, interpretations, dimension),
    ) else {
        return false;
    };
    // CeTA's Arctic matrix carrier derives its strict relation with
    // `mat_comp_all`: every matrix/vector component is compared by the
    // derived strict Arctic relation.  `<strictDimension>` is a natural
    // matrix parameter and does not weaken Arctic strictness to the first
    // row.  Checking only row zero admitted witnesses that CeTA rejected.
    (0..dimension).all(|row| arctic_row_dominates(&lhs[row], &rhs[row], true))
}

pub(crate) fn matrix_interpretation_dimension(
    interpretations: &BTreeMap<String, MatrixInterpretation>,
) -> Option<usize> {
    interpretations.values().find_map(|interpretation| {
        (!interpretation.constant.is_empty()).then_some(interpretation.constant.len())
    })
}

pub(crate) fn matrix_interpretations_are_well_formed(
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> bool {
    interpretations.values().all(|interpretation| {
        interpretation.constant.len() == dimension
            && interpretation.constant.iter().all(|value| *value >= 0)
            && interpretation.coefficients.iter().all(|matrix| {
                matrix.len() == dimension
                    && matrix
                        .iter()
                        .all(|row| row.len() == dimension && row.iter().all(|value| *value >= 0))
            })
    })
}

impl From<PathOrderKind> for DpPathOrderKind {
    fn from(value: PathOrderKind) -> Self {
        match value {
            PathOrderKind::Lpo => Self::Lpo,
            PathOrderKind::Rpo => Self::Rpo,
        }
    }
}

pub(crate) fn checked_component_removal_by_path_order(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    order: DpPathOrderKind,
    precedence: &[String],
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let statuses = uniform_path_order_statuses(pairs, usable, order);
    checked_component_removal_by_mixed_path_order(
        pairs,
        usable,
        order,
        &statuses,
        precedence,
        argument_filter,
        backend,
        innermost_lhss,
    )
}

pub(crate) fn checked_component_removal_by_mixed_path_order(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let owned_precedence_ranks = precedence
        .iter()
        .enumerate()
        .map(|(rank, symbol)| (symbol.clone(), rank))
        .collect::<BTreeMap<_, _>>();
    checked_component_removal_by_mixed_path_order_with_ranks(
        pairs,
        usable,
        default_order,
        statuses,
        precedence,
        &owned_precedence_ranks,
        argument_filter,
        backend,
        innermost_lhss,
    )
}

pub(crate) fn checked_component_removal_by_mixed_path_order_with_ranks(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    checked_component_removal_by_mixed_path_order_with_ranks_and_required_strict_rules(
        pairs,
        usable,
        default_order,
        statuses,
        precedence,
        precedence_ranks,
        argument_filter,
        backend,
        innermost_lhss,
        &[],
    )
}

pub(crate) fn checked_component_removal_by_mixed_path_order_with_usable_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    required_strict_rule_indices: &[usize],
    fixed_usable_rules: bool,
) -> Option<ComponentRemoval> {
    let filtered_usable = if fixed_usable_rules || !required_strict_rule_indices.is_empty() {
        usable.to_vec()
    } else {
        let complete_filter = complete_argument_filter(pairs, usable, argument_filter);
        let seed_usable = argument_filtered_usable_rules(usable, pairs, &complete_filter);
        complete_argument_filtered_usable_rules(usable, pairs, &seed_usable, Some(&complete_filter))
    };
    let mut removal =
        checked_component_removal_by_mixed_path_order_with_ranks_and_required_strict_rules(
            pairs,
            &filtered_usable,
            default_order,
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
            backend,
            innermost_lhss,
            required_strict_rule_indices,
        )?;
    if !fixed_usable_rules && required_strict_rule_indices.is_empty() {
        removal.usable_rules = Some(filtered_usable);
    }
    Some(removal)
}

pub(crate) fn checked_component_removal_by_mixed_path_order_with_ranks_and_required_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    let argument_filter = complete_argument_filter(pairs, usable, argument_filter);
    // A full, non-collapsing identity filter denotes an ordinary monotone
    // RPO/LPO reduction pair over all active rules.  Such a processor does
    // not rely on Q-normal substitutions, so Q need not collapse to
    // variables.  The stronger Q/filter side condition is required only for
    // genuinely filtered (non-monotone) path orders.
    if !argument_filter_is_identity(pairs, usable, &argument_filter)
        && !path_order_q_compatibility_holds(innermost_lhss, &argument_filter)
    {
        return None;
    }
    if !path_order_quasi_statuses_are_compatible(statuses, precedence_ranks) {
        return None;
    }
    let precedence_rank_refs = precedence_rank_refs(precedence_ranks);
    if !usable.iter().all(|rule| {
        weakly_decreases_by_mixed_path_order(
            rule.lhs(),
            rule.rhs(),
            default_order,
            statuses,
            &precedence_rank_refs,
            &argument_filter,
        )
    }) {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_mixed_path_order(
                pair.lhs(),
                pair.rhs(),
                default_order,
                statuses,
                &precedence_rank_refs,
                &argument_filter,
            )
            .then_some(())
            .and_then(|_| {
                strictly_decreases_by_mixed_path_order(
                    pair.lhs(),
                    pair.rhs(),
                    default_order,
                    statuses,
                    &precedence_rank_refs,
                    &argument_filter,
                )
                .then_some(index)
            })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        weakly_decreases_by_mixed_path_order(
            pair.lhs(),
            pair.rhs(),
            default_order,
            statuses,
            &precedence_rank_refs,
            &argument_filter,
        )
    });
    let strict_rule_indices = if required_strict_rule_indices.is_empty() {
        Vec::new()
    } else {
        usable
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| {
                strictly_decreases_by_mixed_path_order(
                    rule.lhs(),
                    rule.rhs(),
                    default_order,
                    statuses,
                    &precedence_rank_refs,
                    &argument_filter,
                )
                .then_some(index)
            })
            .collect::<Vec<_>>()
    };
    let required_rules_are_strict = required_strict_rule_indices
        .iter()
        .all(|index| strict_rule_indices.contains(index));
    (all_weak
        && required_rules_are_strict
        && (!strict_pair_indices.is_empty() || !required_strict_rule_indices.is_empty()))
    .then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::PathOrder {
            order: default_order,
            statuses: complete_path_order_statuses(pairs, usable, statuses, default_order),
            precedence: precedence.to_vec(),
            precedence_ranks: precedence_ranks.clone(),
            argument_filter,
            backend,
        },
        smt_attempted: false,
        usable_rules: None,
    })
}

fn argument_filter_is_identity(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    argument_filter: &DpArgumentFilter,
) -> bool {
    arities_for_constraints(pairs, rules)
        .into_iter()
        .all(|(symbol, arity)| {
            matches!(
                argument_filter.get(&symbol),
                Some(DpArgumentFilterEntry::NonCollapsing(positions))
                    if positions.as_slice() == (0..arity).collect::<Vec<_>>().as_slice()
            )
        })
}

pub(crate) fn path_order_quasi_statuses_are_compatible(
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence_ranks: &BTreeMap<String, usize>,
) -> bool {
    precedence_ranks.iter().all(|(left, left_rank)| {
        precedence_ranks.iter().all(|(right, right_rank)| {
            left_rank != right_rank
                || statuses.get(left).copied().unwrap_or(DpPathOrderKind::Rpo)
                    == statuses.get(right).copied().unwrap_or(DpPathOrderKind::Rpo)
        })
    })
}

pub(crate) fn uniform_path_order_statuses(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    order: DpPathOrderKind,
) -> BTreeMap<String, DpPathOrderKind> {
    path_order_precedence(pairs, usable)
        .into_iter()
        .map(|symbol| (symbol, order))
        .collect()
}

pub(crate) fn complete_path_order_statuses(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    statuses: &BTreeMap<String, DpPathOrderKind>,
    default_order: DpPathOrderKind,
) -> BTreeMap<String, DpPathOrderKind> {
    arities_for_constraints(pairs, usable)
        .into_keys()
        .map(|symbol| {
            let status = statuses.get(&symbol).copied().unwrap_or(default_order);
            (symbol, status)
        })
        .collect()
}

pub(crate) fn complete_argument_filter(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    argument_filter: &DpArgumentFilter,
) -> DpArgumentFilter {
    arities_for_constraints(pairs, usable)
        .into_iter()
        .map(|(symbol, arity)| {
            (
                symbol.clone(),
                argument_filter
                    .get(&symbol)
                    .cloned()
                    .unwrap_or_else(|| DpArgumentFilterEntry::NonCollapsing((0..arity).collect())),
            )
        })
        .collect()
}

#[cfg(test)]
pub(crate) fn synthesize_path_order_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
) -> Option<ComponentRemoval> {
    synthesize_path_order_for_component_requiring_strict_rules(
        pairs,
        usable,
        &[],
        options,
        innermost_lhss,
        None,
        None,
        deadline,
        false,
    )
}

pub(crate) fn synthesize_path_order_for_component_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    required_strict_pair_index: Option<usize>,
    target_strict_pair_indices: Option<&[usize]>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
) -> Option<ComponentRemoval> {
    if strategy_timed_out(deadline) || current_thread_cancelled() {
        return None;
    }
    let smt_calls = 1;
    if let Some((precedence, precedence_ranks, argument_filter, statuses, default_order)) =
        synthesize_mixed_path_order_with_smt(
            pairs,
            usable,
            required_strict_rule_indices,
            options,
            innermost_lhss,
            required_strict_pair_index,
            target_strict_pair_indices,
            deadline,
            fixed_usable_rules,
        )
    {
        if let Some(removal) = checked_component_removal_by_mixed_path_order_with_usable_rules(
            pairs,
            usable,
            default_order,
            &statuses,
            &precedence,
            &precedence_ranks,
            &argument_filter,
            DpSearchBackend::PathOrder,
            innermost_lhss,
            required_strict_rule_indices,
            fixed_usable_rules,
        ) {
            write_progress_event(
                "dp-order",
                "selected",
                "path-order",
                0,
                &format!(
                    "pairs={} usable_rules={} strict_pairs={} smt_calls=1 mixed=true unrestricted_filter=true",
                    pairs.len(),
                    usable.len(),
                    removal.strict_pair_indices.len(),
                ),
            );
            return Some(removal);
        }
        write_progress_event(
            "dp-order",
            "rejected",
            "path-order",
            0,
            &format!(
                "pairs={} usable_rules={} smt_calls=1 reason=model-failed-check unrestricted_filter=true",
                pairs.len(),
                usable.len(),
            ),
        );
    }
    write_progress_event(
        "dp-order",
        "rejected",
        "path-order",
        0,
        &format!(
            "pairs={} usable_rules={} smt_calls={} reason=unsat-or-timeout",
            pairs.len(),
            usable.len(),
            smt_calls
        ),
    );
    None
}

pub(crate) fn synthesize_mixed_path_order_with_smt(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    required_strict_pair_index: Option<usize>,
    target_strict_pair_indices: Option<&[usize]>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
) -> Option<(
    Vec<String>,
    BTreeMap<String, usize>,
    DpArgumentFilter,
    BTreeMap<String, DpPathOrderKind>,
    DpPathOrderKind,
)> {
    let symbols = path_order_precedence(pairs, usable);
    if symbols.is_empty() || symbols.len() > options.max_symbols {
        return None;
    }
    let arities = argument_filter_symbols(pairs, usable);
    let filter_entries = filter_entries_by_symbol(&arities, deadline)?;
    let encode_started = Instant::now();
    let script = configured_mixed_path_order_smt_script(
        pairs,
        usable,
        required_strict_rule_indices,
        &symbols,
        &filter_entries,
        innermost_lhss,
        required_strict_pair_index,
        target_strict_pair_indices,
        deadline,
        fixed_usable_rules,
        options.smt_solver.as_deref().unwrap_or("z3").rsplit('/').next() == Some("z3")
            && command_exists(options.smt_solver.as_deref().unwrap_or("z3"))
            && options.path_order_optimize,
        options.path_order_status,
        false,
    )?;
    write_smt_encoding_event(
        "path-order",
        encode_started,
        &script,
        pairs,
        usable,
        format!("symbols={} filters={}", symbols.len(), filter_entries.len()),
    );
    let stdout = run_path_order_smt_script(&script, options, deadline)?;
    let (precedence, precedence_ranks, argument_filter, _) =
        parse_order_model(&stdout, &symbols, &filter_entries)?;
    let statuses = parse_path_order_status_model(&stdout, &symbols)?;
    let default_order = majority_path_order_status(&statuses);
    Some((
        precedence,
        precedence_ranks,
        argument_filter,
        statuses,
        default_order,
    ))
}

#[cfg(test)]
pub(crate) fn synthesize_kbo_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
) -> Option<ComponentRemoval> {
    synthesize_kbo_for_component_requiring_strict_rules(
        pairs,
        usable,
        &[],
        options,
        innermost_lhss,
        deadline,
        fixed_usable_rules,
    )
}

pub(crate) fn synthesize_kbo_for_component_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
) -> Option<ComponentRemoval> {
    let symbols = symbols_for_constraints(pairs, usable);
    if symbols.is_empty() || symbols.len() > options.max_symbols || options.max_symbol_weight < 1 {
        return None;
    }
    let arities = argument_filter_symbols(pairs, usable);
    let filter_entries = filter_entries_by_symbol(&arities, deadline)?;
    let encode_started = Instant::now();
    let script = kbo_smt_script(
        pairs,
        usable,
        required_strict_rule_indices,
        &path_order_precedence(pairs, usable),
        &filter_entries,
        options.max_symbol_weight,
        innermost_lhss,
        deadline,
        fixed_usable_rules,
        options.smt_solver.as_deref().unwrap_or("z3").rsplit('/').next() == Some("z3")
            && command_exists(options.smt_solver.as_deref().unwrap_or("z3")),
    )?;
    write_smt_encoding_event(
        "kbo",
        encode_started,
        &script,
        pairs,
        usable,
        format!(
            "symbols={} filters={} fixed_usable_rules={fixed_usable_rules}",
            symbols.len(),
            filter_entries.len()
        ),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    let (precedence, precedence_ranks, argument_filter, weights) = parse_order_model(
        &stdout,
        &path_order_precedence(pairs, usable),
        &filter_entries,
    )?;
    let filtered_usable = if fixed_usable_rules {
        usable.to_vec()
    } else {
        let seed_usable = argument_filtered_usable_rules(usable, pairs, &argument_filter);
        complete_argument_filtered_usable_rules(usable, pairs, &seed_usable, Some(&argument_filter))
    };
    let mut removal = checked_component_removal_by_kbo_with_ranks_and_required_strict_rules(
        pairs,
        &filtered_usable,
        &precedence,
        &precedence_ranks,
        &weights,
        &argument_filter,
        DpSearchBackend::Kbo,
        innermost_lhss,
        required_strict_rule_indices,
    );
    if let Some(removal) = &mut removal {
        removal.usable_rules = Some(filtered_usable.clone());
    }
    write_progress_event(
        "dp-order",
        if removal.is_some() {
            "selected"
        } else {
            "rejected"
        },
        "kbo",
        0,
        &format!(
            "pairs={} input_usable_rules={} filtered_usable_rules={} smt_calls=1{}",
            pairs.len(),
            usable.len(),
            filtered_usable.len(),
            removal
                .as_ref()
                .map(|removal| format!(" strict_pairs={}", removal.strict_pair_indices.len()))
                .unwrap_or_else(|| " reason=model-failed-check".to_string())
        ),
    );
    removal
}

#[cfg(test)]
pub(crate) fn degree4_uncurrying_kbo_candidate(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let arities = arities_for_constraints(pairs, rules);
    let marked_app = arities.iter().find_map(|(symbol, arity)| {
        (*arity == 2 && symbol.ends_with('#')).then_some(symbol.clone())
    })?;
    let marked_degree4 = arities.iter().find_map(|(symbol, arity)| {
        (*arity == 4 && symbol.ends_with('#')).then_some(symbol.clone())
    })?;
    let constructor2 = arities.iter().find_map(|(symbol, arity)| {
        (*arity == 2 && !symbol.ends_with('#') && symbol != marked_app.trim_end_matches('#'))
            .then_some(symbol.clone())
    })?;
    let constructor3 = arities.iter().find_map(|(symbol, arity)| {
        (*arity == 3 && !symbol.ends_with('#')).then_some(symbol.clone())
    })?;

    let argument_filter = BTreeMap::from([
        (marked_app, DpArgumentFilterEntry::Collapsing(0)),
        (marked_degree4, DpArgumentFilterEntry::Collapsing(0)),
        (
            constructor2.clone(),
            DpArgumentFilterEntry::NonCollapsing(vec![0]),
        ),
        (constructor3, DpArgumentFilterEntry::Collapsing(0)),
    ]);
    let seed_usable = argument_filtered_usable_rules(rules, pairs, &argument_filter);
    let usable =
        complete_argument_filtered_usable_rules(rules, pairs, &seed_usable, Some(&argument_filter));
    let symbols = path_order_precedence(pairs, &usable);
    let weights = symbols
        .iter()
        .map(|symbol| (symbol.clone(), 1))
        .collect::<BTreeMap<_, _>>();
    let precedence_ranks = symbols
        .iter()
        .map(|symbol| (symbol.clone(), usize::from(symbol == &constructor2)))
        .collect::<BTreeMap<_, _>>();
    let mut precedence = symbols.clone();
    precedence.sort_by_key(|symbol| precedence_ranks.get(symbol).copied().unwrap_or_default());

    let mut removal = checked_component_removal_by_kbo_with_ranks(
        pairs,
        &usable,
        &precedence,
        &precedence_ranks,
        &weights,
        &argument_filter,
        DpSearchBackend::Kbo,
        innermost_lhss,
    )?;
    removal.usable_rules = Some(usable);
    Some(removal)
}

#[cfg(test)]
pub(crate) fn degree4_uncurrying_order_candidate(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let arities = arities_for_constraints(pairs, rules);
    for variant in 0..2 {
        let Some(interpretation) = unary_arctic_dimension4_candidate(&arities, variant) else {
            continue;
        };
        if let Some(removal) = checked_component_removal_by_arctic_matrix(
            pairs,
            rules,
            &interpretation,
            ArcticMatrixDomain::Naturals,
            DpSearchBackend::Smt,
            innermost_lhss,
        ) {
            write_progress_event(
                "dp-order",
                "selected",
                "applicative-reduction-pair",
                0,
                &format!(
                    "pairs={} usable_rules={} order=arctic-matrix-4 variant={} strict_pairs={}",
                    pairs.len(),
                    rules.len(),
                    variant,
                    removal.strict_pair_indices.len()
                ),
            );
            return Some(removal);
        }
    }
    for variant in 0..2 {
        let Some(interpretation) = degree4_uncurrying_arctic_candidate(&arities, 3, 1, 1, variant)
        else {
            continue;
        };
        if let Some(removal) = checked_component_removal_by_arctic_matrix(
            pairs,
            rules,
            &interpretation,
            ArcticMatrixDomain::Naturals,
            DpSearchBackend::Smt,
            innermost_lhss,
        ) {
            write_progress_event(
                "dp-order",
                "selected",
                "applicative-reduction-pair",
                0,
                &format!(
                    "pairs={} usable_rules={} order=arctic-matrix-3 variant={} strict_pairs={}",
                    pairs.len(),
                    rules.len(),
                    variant,
                    removal.strict_pair_indices.len()
                ),
            );
            return Some(removal);
        }
    }
    let removal = degree4_uncurrying_kbo_candidate(pairs, rules, innermost_lhss)?;
    write_progress_event(
        "dp-order",
        "selected",
        "applicative-reduction-pair",
        0,
        &format!(
            "pairs={} usable_rules={} order=kbo strict_pairs={}",
            pairs.len(),
            removal.usable_rules.as_ref().map_or(rules.len(), Vec::len),
            removal.strict_pair_indices.len()
        ),
    );
    Some(removal)
}

pub(crate) fn filter_entries_by_symbol(
    arities: &[(String, usize)],
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, Vec<DpArgumentFilterEntry>>> {
    let mut entries = BTreeMap::new();
    for (symbol, arity) in arities {
        if smt_build_cancelled(deadline) {
            return None;
        }
        entries.insert(
            symbol.clone(),
            argument_filter_entries_for_arity(*arity, deadline)?,
        );
    }
    Some(entries)
}

pub(crate) fn argument_filter_entries_for_arity(
    arity: usize,
    deadline: Option<Instant>,
) -> Option<Vec<DpArgumentFilterEntry>> {
    let mut entries = vec![DpArgumentFilterEntry::NonCollapsing(
        (0..arity).collect::<Vec<_>>(),
    )];
    push_unique_filter_entry(
        &mut entries,
        DpArgumentFilterEntry::NonCollapsing(Vec::new()),
    );
    for position in 0..arity {
        if smt_build_cancelled(deadline) {
            return None;
        }
        push_unique_filter_entry(&mut entries, DpArgumentFilterEntry::Collapsing(position));
    }
    let full_mask = if arity >= usize::BITS as usize {
        0
    } else {
        (1usize << arity).saturating_sub(1)
    };
    for mask in 1..full_mask {
        if smt_build_cancelled(deadline) {
            return None;
        }
        let positions = (0..arity)
            .filter(|position| (mask & (1usize << position)) != 0)
            .collect::<Vec<_>>();
        push_unique_filter_entry(
            &mut entries,
            DpArgumentFilterEntry::NonCollapsing(positions.clone()),
        );
        if positions.len() > 1 {
            for permutation in permutations_of_positions_with_deadline(&positions, deadline)? {
                if smt_build_cancelled(deadline) {
                    return None;
                }
                push_unique_filter_entry(
                    &mut entries,
                    DpArgumentFilterEntry::NonCollapsing(permutation),
                );
            }
        }
    }
    if arity > 1 {
        let positions = (0..arity).collect::<Vec<_>>();
        for permutation in permutations_of_positions_with_deadline(&positions, deadline)? {
            if smt_build_cancelled(deadline) {
                return None;
            }
            push_unique_filter_entry(
                &mut entries,
                DpArgumentFilterEntry::NonCollapsing(permutation),
            );
        }
    }
    Some(entries)
}

pub(crate) fn push_unique_filter_entry(
    entries: &mut Vec<DpArgumentFilterEntry>,
    entry: DpArgumentFilterEntry,
) {
    if !entries.contains(&entry) {
        entries.push(entry);
    }
}

pub(crate) fn mixed_path_order_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    innermost_lhss: Option<&[Term]>,
    required_strict_pair_index: Option<usize>,
    target_strict_pair_indices: Option<&[usize]>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
    optimize_deletion: bool,
) -> Option<String> {
    configured_mixed_path_order_smt_script(pairs, usable, required_strict_rule_indices,
        symbols, filter_entries, innermost_lhss, required_strict_pair_index,
        target_strict_pair_indices, deadline, fixed_usable_rules, optimize_deletion, None, false)
}

pub(crate) fn configured_mixed_path_order_smt_script(
    pairs: &[DependencyPair], usable: &[RewriteRule], required_strict_rule_indices: &[usize],
    symbols: &[String], filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    innermost_lhss: Option<&[Term]>, required_strict_pair_index: Option<usize>,
    target_strict_pair_indices: Option<&[usize]>, deadline: Option<Instant>,
    fixed_usable_rules: bool, optimize_deletion: bool,
    configured_order: Option<DpPathOrderKind>, positional_equivalence: bool,
) -> Option<String> {
    let mut script = order_smt_prelude(symbols, filter_entries, None)?;
    push_path_order_status_prelude(&mut script, symbols);
    push_filter_q_compatibility(&mut script, filter_entries, innermost_lhss, deadline)?;
    let mut filtered_terms = FilteredTermAlternativeCache::new(filter_entries, deadline);
    let fixed_order = configured_order;
    if let Some(order) = fixed_order {
        let status = if order == DpPathOrderKind::Lpo { 1 } else { 0 };
        for symbol in symbols {
            script.push_str(&format!("(assert (= {} {status}))\n", path_order_status_name(symbol)));
        }
    }
    let mut encoder = DpPathOrderSmtEncoder::new(fixed_order, deadline);
    encoder.positional_equivalence = positional_equivalence;
    encoder.share_multiset_comparisons = configured_order.is_some() || positional_equivalence;
    let mut rule_assertions = Vec::new();
    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    let defined_symbols = usable
        .iter()
        .filter_map(|rule| rule.lhs().root_symbol())
        .map(|symbol| symbol.as_str().to_string())
        .collect::<BTreeSet<_>>();
    let conditional_usable = !fixed_usable_rules && required_strict_rule_indices.is_empty();
    if conditional_usable {
        for symbol in &defined_symbols {
            script.push_str(&format!(
                "(declare-const {} Bool)\n",
                kbo_usable_name(symbol)
            ));
        }
        for pair in pairs {
            let mut occurrences = Vec::new();
            collect_symbolic_argument_filter_active_occurrences(
                pair.rhs(),
                "true",
                filter_entries,
                &defined_symbols,
                &mut occurrences,
                deadline,
            )?;
            for (condition, symbol) in occurrences {
                script.push_str(&format!(
                    "(assert (=> {condition} {}))\n",
                    kbo_usable_name(&symbol)
                ));
            }
        }
    }
    let variable_lhs_condition =
        smt_bool(usable.iter().any(|rule| matches!(rule.lhs(), Term::Var(_))));
    for (index, rule) in usable.iter().enumerate() {
        check_smt_build(&script, deadline)?;
        let weak = filtered_path_order_ge_formula_shared(
            rule.lhs(),
            rule.rhs(),
            &mut filtered_terms,
            &mut encoder,
        )?;
        let usable_condition = if conditional_usable {
            let mut conditions = vec![variable_lhs_condition.clone()];
            if let Some(symbol) = rule.lhs().root_symbol() {
                conditions.push(kbo_usable_name(symbol.as_str()));
            }
            smt_or(conditions)
        } else {
            "true".to_string()
        };
        rule_assertions.push(format!("(=> {usable_condition} {weak})"));
        if required_strict_rule_indices.contains(&index) {
            rule_assertions.push(filtered_path_order_gt_formula_shared(
                rule.lhs(),
                rule.rhs(),
                &mut filtered_terms,
                &mut encoder,
            )?);
        }
        if conditional_usable {
            let mut occurrences = Vec::new();
            collect_symbolic_argument_filter_active_occurrences(
                rule.rhs(),
                "true",
                filter_entries,
                &defined_symbols,
                &mut occurrences,
                deadline,
            )?;
            for (condition, symbol) in occurrences {
                script.push_str(&format!(
                    "(assert (=> {} {}))\n",
                    smt_and(vec![usable_condition.clone(), condition]),
                    kbo_usable_name(&symbol)
                ));
            }
        }
    }
    let mut strict_terms = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        rule_assertions.push(filtered_path_order_ge_formula_shared(
            pair.lhs(),
            pair.rhs(),
            &mut filtered_terms,
            &mut encoder,
        )?);
        strict_terms.push(filtered_path_order_gt_formula_shared(
            pair.lhs(),
            pair.rhs(),
            &mut filtered_terms,
            &mut encoder,
        )?);
    }
    if strict_terms.is_empty() {
        return None;
    }
    script.push_str(&encoder.definitions);
    check_smt_build(&script, deadline)?;
    for assertion in rule_assertions {
        check_smt_build(&script, deadline)?;
        script.push_str("(assert ");
        script.push_str(&assertion);
        script.push_str(")\n");
    }
    if let Some(target_indices) = target_strict_pair_indices {
        let target_indices = target_indices.iter().copied().collect::<BTreeSet<_>>();
        if target_indices.is_empty()
            || target_indices
                .iter()
                .any(|index| *index >= strict_terms.len())
        {
            return None;
        }
        for (index, strict) in strict_terms.iter().enumerate() {
            script.push_str("(assert ");
            if !target_indices.contains(&index) {
                script.push_str("(not ");
            }
            script.push_str(strict);
            if !target_indices.contains(&index) {
                script.push(')');
            }
            script.push_str(")\n");
        }
    } else {
        let strict_requirement = match required_strict_pair_index {
            Some(index) => strict_terms.get(index)?.clone(),
            None => smt_or(strict_terms.clone()),
        };
        script.push_str("(assert ");
        script.push_str(&strict_requirement);
        script.push_str(")\n");
    }
    if optimize_deletion && target_strict_pair_indices.is_none() {
        script.push_str("(set-option :opt.priority lex)\n");
        for strict in &strict_terms {
            script.push_str(&format!("(maximize (ite {strict} 1 0))\n"));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn kbo_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    max_weight: i64,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
    optimize_deletion: bool,
) -> Option<String> {
    let mut script = order_smt_prelude(symbols, filter_entries, Some(max_weight))?;
    push_filter_q_compatibility(&mut script, filter_entries, innermost_lhss, deadline)?;
    push_kbo_admissibility(&mut script, symbols, filter_entries);
    let mut filtered_terms = FilteredTermAlternativeCache::new(filter_entries, deadline);
    let mut kbo_encoder = KboSmtEncoder::new(deadline);
    push_kbo_usable_rule_constraints(
        &mut script,
        pairs,
        usable,
        filter_entries,
        &mut filtered_terms,
        &mut kbo_encoder,
        deadline,
        fixed_usable_rules,
        required_strict_rule_indices,
    )?;
    let mut strict_terms = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let weak = filtered_kbo_ge_formula_cached(
            pair.lhs(),
            pair.rhs(),
            &mut filtered_terms,
            |left, right| kbo_encoder.ge(left, right),
        )?;
        script.push_str(&kbo_encoder.take_definitions());
        script.push_str("(assert ");
        script.push_str(&weak);
        script.push_str(")\n");
        strict_terms.push(filtered_kbo_gt_formula_cached(
            pair.lhs(),
            pair.rhs(),
            &mut filtered_terms,
            |left, right| kbo_encoder.gt(left, right),
        )?);
    }
    if strict_terms.is_empty() {
        return None;
    }
    script.push_str(&kbo_encoder.take_definitions());
    script.push_str("(assert ");
    script.push_str(&smt_or(strict_terms.clone()));
    script.push_str(")\n");
    if optimize_deletion {
        script.push_str("(set-option :opt.priority lex)\n");
        for strict in &strict_terms {
            script.push_str(&format!("(maximize (ite {strict} 1 0))\n"));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn push_kbo_usable_rule_constraints(
    script: &mut String,
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    kbo_encoder: &mut KboSmtEncoder,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
    required_strict_rule_indices: &[usize],
) -> Option<()> {
    let defined_symbols = rules
        .iter()
        .filter_map(|rule| rule.lhs().root_symbol())
        .map(|symbol| symbol.as_str().to_string())
        .collect::<BTreeSet<_>>();
    let variable_lhs_condition =
        smt_bool(rules.iter().any(|rule| matches!(rule.lhs(), Term::Var(_))));

    for symbol in &defined_symbols {
        check_smt_build(script, deadline)?;
        script.push_str(&format!(
            "(declare-const {} Bool)\n",
            kbo_usable_name(symbol)
        ));
        if fixed_usable_rules {
            script.push_str(&format!("(assert {})\n", kbo_usable_name(symbol)));
        }
    }

    for pair in pairs {
        let mut occurrences = Vec::new();
        collect_symbolic_argument_filter_active_occurrences(
            pair.rhs(),
            "true",
            filter_entries,
            &defined_symbols,
            &mut occurrences,
            deadline,
        )?;
        for (condition, symbol) in occurrences {
            check_smt_build(script, deadline)?;
            script.push_str(&format!(
                "(assert (=> {condition} {}))\n",
                kbo_usable_name(&symbol)
            ));
        }
    }

    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    for (index, rule) in rules.iter().enumerate() {
        check_smt_build(script, deadline)?;
        let mut usable_conditions = vec![variable_lhs_condition.clone()];
        if let Some(symbol) = rule.lhs().root_symbol() {
            usable_conditions.push(kbo_usable_name(symbol.as_str()));
        }
        let usable_condition = smt_or(usable_conditions);
        let weak = filtered_kbo_ge_formula_cached(
            rule.lhs(),
            rule.rhs(),
            filtered_terms,
            |left, right| kbo_encoder.ge(left, right),
        )?;
        script.push_str(&kbo_encoder.take_definitions());
        script.push_str(&format!("(assert (=> {usable_condition} {weak}))\n"));
        if required_strict_rule_indices.contains(&index) {
            let strict = filtered_kbo_gt_formula_cached(
                rule.lhs(),
                rule.rhs(),
                filtered_terms,
                |left, right| kbo_encoder.gt(left, right),
            )?;
            script.push_str(&kbo_encoder.take_definitions());
            script.push_str(&format!("(assert {strict})\n"));
        }

        let mut occurrences = Vec::new();
        collect_symbolic_argument_filter_active_occurrences(
            rule.rhs(),
            "true",
            filter_entries,
            &defined_symbols,
            &mut occurrences,
            deadline,
        )?;
        for (condition, symbol) in occurrences {
            script.push_str(&format!(
                "(assert (=> {} {}))\n",
                smt_and(vec![usable_condition.clone(), condition]),
                kbo_usable_name(&symbol)
            ));
        }
    }
    Some(())
}

pub(crate) fn collect_symbolic_argument_filter_active_occurrences(
    term: &Term,
    active: &str,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    defined_symbols: &BTreeSet<String>,
    occurrences: &mut Vec<(String, String)>,
    deadline: Option<Instant>,
) -> Option<()> {
    check_smt_build(active, deadline)?;
    let Term::App { symbol, args } = term else {
        return Some(());
    };
    if defined_symbols.contains(symbol.as_str()) {
        occurrences.push((active.to_string(), symbol.as_str().to_string()));
    }
    for (position, argument) in args.iter().enumerate() {
        let selected = filter_entries.get(symbol.as_str()).map_or_else(
            || "true".to_string(),
            |entries| {
                smt_or(
                    entries
                        .iter()
                        .enumerate()
                        .filter_map(|(index, entry)| {
                            let active = match entry {
                                DpArgumentFilterEntry::Collapsing(selected) => {
                                    *selected == position
                                }
                                DpArgumentFilterEntry::NonCollapsing(selected) => {
                                    selected.contains(&position)
                                }
                            };
                            active.then(|| format!("(= {} {index})", filter_name(symbol.as_str())))
                        })
                        .collect(),
                )
            },
        );
        collect_symbolic_argument_filter_active_occurrences(
            argument,
            &smt_and(vec![active.to_string(), selected]),
            filter_entries,
            defined_symbols,
            occurrences,
            deadline,
        )?;
    }
    Some(())
}

pub(crate) fn kbo_usable_name(symbol: &str) -> String {
    format!("kbo_u_{}", sanitize_smt_name(symbol))
}

pub(crate) fn order_smt_prelude(
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    max_weight: Option<i64>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_LIA)\n");
    let max_rank = i64::try_from(symbols.len().checked_sub(1)?).ok()?;
    for symbol in symbols {
        script.push_str(&format!(
            "(declare-const {} Int)\n",
            order_rank_name(symbol)
        ));
        script.push_str(&format!(
            "(assert (and (>= {} 0) (<= {} {max_rank})))\n",
            order_rank_name(symbol),
            order_rank_name(symbol)
        ));
        if let Some(entries) = filter_entries.get(symbol) {
            let max_filter = i64::try_from(entries.len().checked_sub(1)?).ok()?;
            script.push_str(&format!("(declare-const {} Int)\n", filter_name(symbol)));
            script.push_str(&format!(
                "(assert (and (>= {} 0) (<= {} {max_filter})))\n",
                filter_name(symbol),
                filter_name(symbol)
            ));
        }
        if let Some(max_weight) = max_weight {
            script.push_str(&format!("(declare-const {} Int)\n", weight_name(symbol)));
            script.push_str(&format!(
                "(assert (and (>= {} 0) (<= {} {max_weight})))\n",
                weight_name(symbol),
                weight_name(symbol)
            ));
        }
    }
    Some(script)
}

pub(crate) fn push_path_order_status_prelude(script: &mut String, symbols: &[String]) {
    for symbol in symbols {
        script.push_str(&format!(
            "(declare-const {} Int)\n",
            path_order_status_name(symbol)
        ));
        script.push_str(&format!(
            "(assert (or (= {} 0) (= {} 1)))\n",
            path_order_status_name(symbol),
            path_order_status_name(symbol)
        ));
    }
    for (index, left) in symbols.iter().enumerate() {
        for right in &symbols[index + 1..] {
            script.push_str(&format!(
                "(assert (=> (= {} {}) (= {} {})))\n",
                order_rank_name(left),
                order_rank_name(right),
                path_order_status_name(left),
                path_order_status_name(right)
            ));
        }
    }
}

pub(crate) fn push_filter_q_compatibility(
    script: &mut String,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
) -> Option<()> {
    let Some(lhss) = innermost_lhss else {
        return Some(());
    };
    for lhs in lhss {
        if smt_build_cancelled(deadline) {
            return None;
        }
        let alternatives = filtered_term_alternatives(lhs, filter_entries, deadline);
        let minimal_terms = alternatives
            .into_iter()
            .filter_map(|alternative| {
                term_is_q_minimal(&alternative.term).then_some(alternative.condition)
            })
            .collect::<Vec<_>>();
        script.push_str("(assert ");
        script.push_str(&smt_or(minimal_terms));
        script.push_str(")\n");
    }
    for (symbol, entries) in filter_entries {
        if smt_build_cancelled(deadline) {
            return None;
        }
        if symbol.ends_with('#') {
            continue;
        }
        let marked = format!("{symbol}#");
        let Some(marked_entries) = filter_entries.get(&marked) else {
            continue;
        };
        for (index, entry) in entries.iter().enumerate() {
            let DpArgumentFilterEntry::Collapsing(position) = entry else {
                continue;
            };
            if let Some(marked_index) = marked_entries
                .iter()
                .position(|entry| matches!(entry, DpArgumentFilterEntry::Collapsing(marked_position) if marked_position == position))
            {
                script.push_str(&format!(
                    "(assert (=> (= {} {index}) (= {} {marked_index})))\n",
                    filter_name(symbol),
                    filter_name(&marked)
                ));
            }
        }
    }
    Some(())
}

pub(crate) fn push_kbo_admissibility(
    script: &mut String,
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
) {
    for symbol in symbols {
        let Some(entries) = filter_entries.get(symbol) else {
            continue;
        };
        let unary_filter = entries
            .iter()
            .enumerate()
            .filter_map(|(index, entry)| match entry {
                DpArgumentFilterEntry::NonCollapsing(positions) if positions.len() == 1 => {
                    Some(format!("(= {} {index})", filter_name(symbol)))
                }
                DpArgumentFilterEntry::Collapsing(_) => {
                    Some(format!("(= {} {index})", filter_name(symbol)))
                }
                _ => None,
            })
            .collect::<Vec<_>>();
        script.push_str(&format!(
            "(assert (or (> {} 0) (and (= {} 0) (= {} 0) {})))\n",
            weight_name(symbol),
            weight_name(symbol),
            order_rank_name(symbol),
            smt_or(unary_filter)
        ));
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct FilteredTermAlternative {
    condition: String,
    term: Term,
    // Necessary assignments shared by every disjunct of `condition`.
    // Contradictory choices at different occurrences of one symbol cannot
    // describe any argument filtering and need not be expanded or encoded.
    filters: BTreeMap<String, usize>,
}

pub(crate) fn compatible_filter_choices(left: &BTreeMap<String, usize>, right: &BTreeMap<String, usize>) -> bool {
    left.iter().all(|(symbol, index)| right.get(symbol).is_none_or(|other| other == index))
}

pub(crate) fn joined_filter_choices(left: &BTreeMap<String, usize>, right: &BTreeMap<String, usize>) -> Option<BTreeMap<String, usize>> {
    if !compatible_filter_choices(left, right) { return None; }
    let mut joined = left.clone();
    joined.extend(right.iter().map(|(s, i)| (s.clone(), *i)));
    Some(joined)
}

#[cfg(test)]
mod filter_consistency_tests {
    use super::*;

    #[test]
    fn repeated_symbol_filtering_does_not_expand_inconsistent_choices() {
        let filters = BTreeMap::from([("f".to_string(), vec![
            DpArgumentFilterEntry::NonCollapsing(vec![0]),
            DpArgumentFilterEntry::Collapsing(0),
        ])]);
        let mut term = Term::var("x");
        for _ in 0..24 { term = Term::app("f", vec![term]); }
        let alternatives = FilteredTermAlternativeCache::new(&filters, None).alternatives(&term);
        assert_eq!(alternatives.len(), 2);
        assert!(alternatives.iter().any(|a| a.term == term && a.filters["f"] == 0));
        assert!(alternatives.iter().any(|a| a.term == Term::var("x") && a.filters["f"] == 1));
    }

    #[test]
    fn merged_filter_disjunction_keeps_only_common_necessary_assignments() {
        let alternatives = vec![0, 1].into_iter().map(|i| FilteredTermAlternative {
            condition: format!("choice{i}"), term: Term::var("x"),
            filters: BTreeMap::from([("f".to_string(), 0), ("g".to_string(), i)]),
        }).collect();
        let merged = merge_filtered_term_alternatives(alternatives);
        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].filters, BTreeMap::from([("f".to_string(), 0)]));
        assert!(compatible_filter_choices(&merged[0].filters, &BTreeMap::from([("g".to_string(), 1)])));
    }

    #[test]
    fn consistent_filter_expansion_preserves_every_small_assignment() {
        // Interpret only the Boolean/equality fragment emitted by expansion.
        fn eval(text: &str, values: &BTreeMap<String, usize>) -> bool {
            fn expression(tokens: &[&str], at: &mut usize, values: &BTreeMap<String, usize>) -> bool {
                let token = tokens[*at]; *at += 1;
                if token == "true" { return true; }
                if token == "false" { return false; }
                assert_eq!(token, "(");
                let op = tokens[*at]; *at += 1;
                let result = if op == "=" {
                    let symbol = tokens[*at]; let index = tokens[*at + 1].parse::<usize>().unwrap();
                    *at += 2; values[symbol] == index
                } else {
                    let mut parts = Vec::new();
                    while tokens[*at] != ")" { parts.push(expression(tokens, at, values)); }
                    match op { "and" => parts.into_iter().all(|v| v), "or" => parts.into_iter().any(|v| v), _ => panic!("unexpected {op}") }
                };
                assert_eq!(tokens[*at], ")"); *at += 1; result
            }
            let text = text.replace('(', " ( ").replace(')', " ) ");
            let tokens = text.split_whitespace().collect::<Vec<_>>();
            let mut at = 0;
            let result = expression(&tokens, &mut at, values);
            assert_eq!(at, tokens.len()); result
        }
        let filters = BTreeMap::from([
            ("f".to_string(), vec![DpArgumentFilterEntry::NonCollapsing(vec![0, 1]), DpArgumentFilterEntry::NonCollapsing(vec![]), DpArgumentFilterEntry::Collapsing(0), DpArgumentFilterEntry::Collapsing(1)]),
            ("g".to_string(), vec![DpArgumentFilterEntry::NonCollapsing(vec![0]), DpArgumentFilterEntry::NonCollapsing(vec![]), DpArgumentFilterEntry::Collapsing(0)]),
        ]);
        let x = Term::var("x"); let y = Term::var("y");
        let term = Term::app("f", vec![Term::app("g", vec![Term::app("f", vec![x.clone(), y.clone()])]), Term::app("g", vec![y])]);
        let alternatives = FilteredTermAlternativeCache::new(&filters, None).alternatives(&term);
        for f in 0..filters["f"].len() { for g in 0..filters["g"].len() {
            let selected = BTreeMap::from([("f".to_string(), filters["f"][f].clone()), ("g".to_string(), filters["g"][g].clone())]);
            let expected = filter_term(&term, &selected);
            let values = BTreeMap::from([(filter_name("f"), f), (filter_name("g"), g)]);
            let enabled = alternatives.iter().filter(|a| eval(&a.condition, &values)).map(|a| &a.term).collect::<Vec<_>>();
            assert_eq!(enabled, vec![&expected]);
        }}
    }
}

pub(crate) struct FilteredTermAlternativeCache<'a> {
    filter_entries: &'a BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
    entries: HashMap<Term, Vec<FilteredTermAlternative>>,
}

impl<'a> FilteredTermAlternativeCache<'a> {
    pub(crate) fn new(
        filter_entries: &'a BTreeMap<String, Vec<DpArgumentFilterEntry>>,
        deadline: Option<Instant>,
    ) -> Self {
        Self {
            filter_entries,
            deadline,
            entries: HashMap::new(),
        }
    }

    pub(crate) fn alternatives(&mut self, term: &Term) -> Vec<FilteredTermAlternative> {
        if smt_build_cancelled(self.deadline) {
            return Vec::new();
        }
        if let Some(cached) = self.entries.get(term) {
            return cached.clone();
        }
        let alternatives = self.compute_alternatives(term);
        self.entries.insert(term.clone(), alternatives.clone());
        alternatives
    }

    pub(crate) fn compute_alternatives(&mut self, term: &Term) -> Vec<FilteredTermAlternative> {
        match term {
            Term::Var(_) => vec![FilteredTermAlternative {
                condition: "true".to_string(),
                term: term.clone(),
                filters: BTreeMap::new(),
            }],
            Term::App { symbol, args } => {
                let entries = self
                    .filter_entries
                    .get(symbol.as_str())
                    .cloned()
                    .unwrap_or_else(|| {
                        vec![DpArgumentFilterEntry::NonCollapsing(
                            (0..args.len()).collect(),
                        )]
                    });
                let mut alternatives = Vec::new();
                for (entry_index, entry) in entries.into_iter().enumerate() {
                    if smt_build_cancelled(self.deadline) {
                        return Vec::new();
                    }
                    let entry_condition =
                        format!("(= {} {entry_index})", filter_name(symbol.as_str()));
                    let entry_filters = BTreeMap::from([(symbol.as_str().to_string(), entry_index)]);
                    match entry {
                        DpArgumentFilterEntry::Collapsing(position) => {
                            if let Some(arg) = args.get(position) {
                                for alternative in self.alternatives(arg) {
                                    let Some(filters) = joined_filter_choices(&entry_filters, &alternative.filters) else { continue; };
                                    alternatives.push(FilteredTermAlternative {
                                        condition: smt_and(vec![
                                            entry_condition.clone(),
                                            alternative.condition,
                                        ]),
                                        term: alternative.term,
                                        filters,
                                    });
                                }
                            }
                        }
                        DpArgumentFilterEntry::NonCollapsing(positions) => {
                            let selected = positions
                                .into_iter()
                                .filter_map(|position| args.get(position))
                                .collect::<Vec<_>>();
                            for (conditions, terms, child_filters) in self.combine_arguments(&selected) {
                                let Some(filters) = joined_filter_choices(&entry_filters, &child_filters) else { continue; };
                                alternatives.push(FilteredTermAlternative {
                                    condition: smt_and(
                                        std::iter::once(entry_condition.clone())
                                            .chain(conditions)
                                            .collect(),
                                    ),
                                    term: Term::app(symbol.as_str(), terms),
                                    filters,
                                });
                            }
                        }
                    }
                }
                merge_filtered_term_alternatives(alternatives)
            }
        }
    }

    fn combine_arguments(&mut self, args: &[&Term]) -> Vec<(Vec<String>, Vec<Term>, BTreeMap<String, usize>)> {
        if smt_build_cancelled(self.deadline) {
            return Vec::new();
        }
        if let Some((first, rest)) = args.split_first() {
            let first_alternatives = self.alternatives(first);
            let rest_alternatives = self.combine_arguments(rest);
            let mut combined = Vec::new();
            for first_alternative in first_alternatives {
                for (rest_conditions, rest_terms, rest_filters) in &rest_alternatives {
                    if smt_build_cancelled(self.deadline) {
                        return Vec::new();
                    }
                    let Some(filters) = joined_filter_choices(&first_alternative.filters, rest_filters) else { continue; };
                    let mut conditions = vec![first_alternative.condition.clone()];
                    conditions.extend(rest_conditions.clone());
                    let mut terms = vec![first_alternative.term.clone()];
                    terms.extend(rest_terms.clone());
                    combined.push((conditions, terms, filters));
                }
            }
            combined
        } else {
            vec![(Vec::new(), Vec::new(), BTreeMap::new())]
        }
    }
}

pub(crate) fn filtered_mixed_path_order_ge_formula_cached(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
) -> Option<String> {
    filtered_relation_formula_cached(
        lhs,
        rhs,
        filtered_terms,
        |left, right| Some(mixed_path_order_gt_smt(left, right)),
        |relation, left, right| {
            Some(smt_or(vec![
                smt_bool(left == right),
                relation(left, right)?,
            ]))
        },
    )
}

pub(crate) fn filtered_mixed_path_order_gt_formula_cached(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
) -> Option<String> {
    filtered_relation_formula_cached(
        lhs,
        rhs,
        filtered_terms,
        |left, right| Some(mixed_path_order_gt_smt(left, right)),
        |relation, left, right| relation(left, right),
    )
}

pub(crate) fn filtered_path_order_ge_formula_shared(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    encoder: &mut DpPathOrderSmtEncoder,
) -> Option<String> {
    filtered_path_order_relation_formula_shared(
        lhs,
        rhs,
        filtered_terms,
        encoder,
        |encoder, left, right| {
            Some(smt_or(vec![
                encoder.equivalent(left, right)?,
                encoder.gt(left, right)?,
            ]))
        },
    )
}

pub(crate) fn filtered_path_order_gt_formula_shared(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    encoder: &mut DpPathOrderSmtEncoder,
) -> Option<String> {
    filtered_path_order_relation_formula_shared(
        lhs,
        rhs,
        filtered_terms,
        encoder,
        |encoder, left, right| encoder.gt(left, right),
    )
}

pub(crate) fn filtered_path_order_relation_formula_shared(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    encoder: &mut DpPathOrderSmtEncoder,
    relation: impl Fn(&mut DpPathOrderSmtEncoder, &Term, &Term) -> Option<String>,
) -> Option<String> {
    if std::env::var_os("FERRUM_DIRECT_FILTER_PATH_ORDER").is_some() {
        if encoder.direct_filters.is_none() {
            encoder.direct_filters = Some(filtered_terms.filter_entries.clone());
        }
        return relation(encoder, lhs, rhs);
    }
    let lhs_alternatives = filtered_terms.alternatives(lhs);
    let rhs_alternatives = filtered_terms.alternatives(rhs);
    if lhs_alternatives.is_empty() || rhs_alternatives.is_empty() {
        return None;
    }
    let mut disjuncts = Vec::new();
    for left in &lhs_alternatives {
        for right in &rhs_alternatives {
            if encoder.is_cancelled() {
                return None;
            }
            if !compatible_filter_choices(&left.filters, &right.filters) {
                continue;
            }
            disjuncts.push(smt_and(vec![
                left.condition.clone(),
                right.condition.clone(),
                relation(encoder, &left.term, &right.term)?,
            ]));
        }
    }
    Some(smt_or(disjuncts))
}

mod direct_filtered;

pub(crate) struct DpPathOrderSmtEncoder {
    share_multiset_comparisons: bool,
    positional_equivalence: bool,
    direct_filters: Option<BTreeMap<String, Vec<DpArgumentFilterEntry>>>,
    definitions: String,
    variables: HashMap<(Term, Term), String>,
    equivalence_variables: HashMap<(Term, Term), String>,
    multiset_comparisons: HashMap<(Vec<Term>, Vec<Term>, bool), String>,
    next_variable: usize,
    next_equivalence_variable: usize,
    next_multiset_variable: usize,
    fixed_order: Option<DpPathOrderKind>,
    deadline: Option<Instant>,
}

impl DpPathOrderSmtEncoder {
    pub(crate) fn take_definitions(&mut self) -> String {
        std::mem::take(&mut self.definitions)
    }

    pub(crate) fn new(fixed_order: Option<DpPathOrderKind>, deadline: Option<Instant>) -> Self {
        Self {
            share_multiset_comparisons: false,
            positional_equivalence: false,
            direct_filters: None,
            definitions: String::new(),
            variables: HashMap::new(),
            equivalence_variables: HashMap::new(),
            multiset_comparisons: HashMap::new(),
            next_variable: 0,
            next_equivalence_variable: 0,
            next_multiset_variable: 0,
            fixed_order,
            deadline,
        }
    }

    pub(crate) fn is_cancelled(&self) -> bool {
        smt_build_cancelled(self.deadline)
    }

    pub(crate) fn gt(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        if self.is_cancelled() {
            return None;
        }
        if lhs == rhs {
            return Some("false".to_string());
        }
        if let Some(variable) = self.variables.get(&(lhs.clone(), rhs.clone())) {
            return Some(variable.clone());
        }
        let variable = format!("dpgt_{}", self.next_variable);
        self.next_variable += 1;
        self.variables
            .insert((lhs.clone(), rhs.clone()), variable.clone());
        self.definitions
            .push_str(&format!("(declare-const {variable} Bool)\n"));
        let formula = if self.direct_filters.is_some() {
            self.direct_filtered_relation(lhs, rhs, true)?
        } else {
            self.gt_definition(lhs, rhs)?
        };
        self.definitions
            .push_str(&format!("(assert (= {variable} {formula}))\n"));
        Some(variable)
    }

    pub(crate) fn gt_definition(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        match (lhs, rhs) {
            (_, Term::Var(variable)) => {
                Some(smt_bool(lhs != rhs && lhs.variables().contains(variable)))
            }
            (Term::Var(_), Term::App { .. }) => Some("false".to_string()),
            (
                Term::App {
                    symbol: lhs_symbol,
                    args: lhs_args,
                },
                Term::App {
                    symbol: rhs_symbol,
                    args: rhs_args,
                },
            ) => {
                let mut subterm = Vec::new();
                for arg in lhs_args {
                    if self.is_cancelled() {
                        return None;
                    }
                    subterm.push(smt_or(vec![self.equivalent(arg, rhs)?, self.gt(arg, rhs)?]));
                }
                let dominates_rhs_args = smt_and(
                    rhs_args
                        .iter()
                        .map(|arg| self.gt(lhs, arg))
                        .collect::<Option<_>>()?,
                );
                let precedence_case = smt_and(vec![
                    dominates_rhs_args.clone(),
                    format!(
                        "(< {} {})",
                        order_rank_name(lhs_symbol.as_str()),
                        order_rank_name(rhs_symbol.as_str())
                    ),
                ]);
                let equivalent_root_case = {
                    let status_case = match self.fixed_order {
                        Some(DpPathOrderKind::Lpo) => self.lex_gt(lhs_args, rhs_args)?,
                        Some(DpPathOrderKind::Rpo) => self.multiset_gt(lhs_args, rhs_args)?,
                        None => {
                            let lex = self.lex_gt(lhs_args, rhs_args)?;
                            let multiset = self.multiset_gt(lhs_args, rhs_args)?;
                            smt_or(vec![
                                smt_and(vec![
                                    format!(
                                        "(= {} 1)",
                                        path_order_status_name(lhs_symbol.as_str())
                                    ),
                                    lex,
                                ]),
                                smt_and(vec![
                                    format!(
                                        "(= {} 0)",
                                        path_order_status_name(lhs_symbol.as_str())
                                    ),
                                    multiset,
                                ]),
                            ])
                        }
                    };
                    smt_and(vec![
                        dominates_rhs_args,
                        format!(
                            "(= {} {})",
                            order_rank_name(lhs_symbol.as_str()),
                            order_rank_name(rhs_symbol.as_str())
                        ),
                        status_case,
                    ])
                };
                Some(smt_or(
                    subterm
                        .into_iter()
                        .chain([precedence_case, equivalent_root_case])
                        .collect(),
                ))
            }
        }
    }

    pub(crate) fn lex_gt(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        let mut disjuncts = Vec::new();
        for index in 0..lhs.len().min(rhs.len()) {
            if self.is_cancelled() {
                return None;
            }
            let prefix_equal = smt_and(
                (0..index)
                    .map(|prefix| self.equivalent(&lhs[prefix], &rhs[prefix]))
                    .collect::<Option<Vec<_>>>()?,
            );
            disjuncts.push(smt_and(vec![
                prefix_equal,
                self.gt(&lhs[index], &rhs[index])?,
            ]));
        }
        if lhs.len() > rhs.len() {
            disjuncts.push(smt_and(
                lhs.iter()
                    .zip(rhs)
                    .map(|(left, right)| self.equivalent(left, right))
                    .collect::<Option<Vec<_>>>()?,
            ));
        }
        Some(smt_or(disjuncts))
    }

    pub(crate) fn equivalent(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        if self.is_cancelled() {
            return None;
        }
        if lhs == rhs {
            return Some("true".to_string());
        }
        if self.direct_filters.is_some() {
            return self.direct_filtered_equivalent(lhs, rhs);
        }
        match (lhs, rhs) {
            (Term::Var(left), Term::Var(right)) => Some(smt_bool(left == right)),
            (Term::Var(_), Term::App { .. }) | (Term::App { .. }, Term::Var(_)) => {
                Some("false".to_string())
            }
            (
                Term::App {
                    symbol: lhs_symbol,
                    args: lhs_args,
                },
                Term::App {
                    symbol: rhs_symbol,
                    args: rhs_args,
                },
            ) => {
                if lhs_args.len() != rhs_args.len() {
                    return Some("false".to_string());
                }
                let key = path_order_equivalence_key(lhs, rhs);
                if let Some(variable) = self.equivalence_variables.get(&key) {
                    return Some(variable.clone());
                }
                let variable = format!("dpeq_{}", self.next_equivalence_variable);
                self.next_equivalence_variable += 1;
                self.equivalence_variables.insert(key, variable.clone());
                self.definitions
                    .push_str(&format!("(declare-const {variable} Bool)\n"));
                let arguments = match if self.positional_equivalence { Some(DpPathOrderKind::Lpo) } else { self.fixed_order } {
                    Some(DpPathOrderKind::Lpo) => smt_and(
                        lhs_args
                            .iter()
                            .zip(rhs_args)
                            .map(|(left, right)| self.equivalent(left, right))
                            .collect::<Option<Vec<_>>>()?,
                    ),
                    Some(DpPathOrderKind::Rpo) => self.multiset_equivalent(lhs_args, rhs_args)?,
                    None => smt_or(vec![
                        smt_and(vec![
                            format!("(= {} 1)", path_order_status_name(lhs_symbol.as_str())),
                            smt_and(
                                lhs_args
                                    .iter()
                                    .zip(rhs_args)
                                    .map(|(left, right)| self.equivalent(left, right))
                                    .collect::<Option<Vec<_>>>()?,
                            ),
                        ]),
                        smt_and(vec![
                            format!("(= {} 0)", path_order_status_name(lhs_symbol.as_str())),
                            self.multiset_equivalent(lhs_args, rhs_args)?,
                        ]),
                    ]),
                };
                let formula = smt_and(vec![
                    format!(
                        "(= {} {})",
                        order_rank_name(lhs_symbol.as_str()),
                        order_rank_name(rhs_symbol.as_str())
                    ),
                    arguments,
                ]);
                self.definitions
                    .push_str(&format!("(assert (= {variable} {formula}))\n"));
                Some(variable)
            }
        }
    }

    pub(crate) fn multiset_equivalent(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        self.shared_multiset_comparison(lhs, rhs, false)
    }

    fn shared_multiset_comparison(&mut self, lhs: &[Term], rhs: &[Term], strict: bool) -> Option<String> {
        if self.is_cancelled() { return None; }
        if !self.share_multiset_comparisons {
            return if strict { self.multiset_gt_uncached(lhs, rhs) }
                   else { self.multiset_equivalent_uncached(lhs, rhs) };
        }
        let key = (lhs.to_vec(), rhs.to_vec(), strict);
        if let Some(variable) = self.multiset_comparisons.get(&key) {
            return Some(variable.clone());
        }
        let variable = format!("dpmsc_{}", self.multiset_comparisons.len());
        self.multiset_comparisons.insert(key, variable.clone());
        self.definitions.push_str(&format!("(declare-const {variable} Bool)\n"));
        let formula = if strict {
            self.multiset_gt_uncached(lhs, rhs)?
        } else {
            self.multiset_equivalent_uncached(lhs, rhs)?
        };
        self.definitions.push_str(&format!("(assert (= {variable} {formula}))\n"));
        Some(variable)
    }

    fn multiset_equivalent_uncached(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        if lhs.len() != rhs.len() {
            return Some("false".to_string());
        }
        if lhs.is_empty() {
            return Some("true".to_string());
        }
        let matching = self.fresh_multiset_matrix(lhs.len(), rhs.len());
        let mut constraints = Vec::new();
        for row in &matching {
            constraints.push(smt_exactly_one(row));
        }
        for rhs_index in 0..rhs.len() {
            constraints.push(smt_exactly_one(
                matching
                    .iter()
                    .map(|row| row[rhs_index].clone())
                    .collect::<Vec<_>>()
                    .as_slice(),
            ));
        }
        for (lhs_index, left) in lhs.iter().enumerate() {
            for (rhs_index, right) in rhs.iter().enumerate() {
                constraints.push(format!(
                    "(=> {} {})",
                    matching[lhs_index][rhs_index],
                    self.equivalent(left, right)?
                ));
            }
        }
        Some(smt_and(constraints))
    }

    pub(crate) fn multiset_gt(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        self.shared_multiset_comparison(lhs, rhs, true)
    }

    fn multiset_gt_uncached(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        if self.is_cancelled() {
            return None;
        }
        if lhs.is_empty() {
            return Some("false".to_string());
        }
        let matching = self.fresh_multiset_matrix(lhs.len(), rhs.len());
        let row_matched = matching
            .iter()
            .map(|row| smt_or(row.clone()))
            .collect::<Vec<_>>();
        let mut constraints = Vec::new();
        for row in &matching {
            constraints.push(smt_at_most_one(row));
        }
        for rhs_index in 0..rhs.len() {
            constraints.push(smt_at_most_one(
                matching
                    .iter()
                    .map(|row| row[rhs_index].clone())
                    .collect::<Vec<_>>()
                    .as_slice(),
            ));
        }
        for (lhs_index, left) in lhs.iter().enumerate() {
            for (rhs_index, right) in rhs.iter().enumerate() {
                constraints.push(format!(
                    "(=> {} {})",
                    matching[lhs_index][rhs_index],
                    self.equivalent(left, right)?
                ));
            }
        }
        constraints.push(smt_or(
            row_matched
                .iter()
                .map(|matched| format!("(not {matched})"))
                .collect(),
        ));
        for rhs_index in 0..rhs.len() {
            let matched = smt_or(
                matching
                    .iter()
                    .map(|row| row[rhs_index].clone())
                    .collect::<Vec<_>>(),
            );
            let dominated = smt_or(
                lhs.iter()
                    .enumerate()
                    .map(|(lhs_index, left)| {
                        Some(smt_and(vec![
                            format!("(not {})", row_matched[lhs_index]),
                            self.gt(left, &rhs[rhs_index])?,
                        ]))
                    })
                    .collect::<Option<Vec<_>>>()?,
            );
            constraints.push(smt_or(vec![matched, dominated]));
        }
        Some(smt_and(constraints))
    }

    pub(crate) fn fresh_multiset_matrix(
        &mut self,
        rows: usize,
        columns: usize,
    ) -> Vec<Vec<String>> {
        (0..rows)
            .map(|_| {
                (0..columns)
                    .map(|_| {
                        let variable = format!("dpms_{}", self.next_multiset_variable);
                        self.next_multiset_variable += 1;
                        self.definitions
                            .push_str(&format!("(declare-const {variable} Bool)\n"));
                        variable
                    })
                    .collect()
            })
            .collect()
    }
}

pub(crate) fn path_order_equivalence_key(lhs: &Term, rhs: &Term) -> (Term, Term) {
    if lhs <= rhs {
        (lhs.clone(), rhs.clone())
    } else {
        (rhs.clone(), lhs.clone())
    }
}

pub(crate) struct KboSmtEncoder {
    definitions: String,
    gt_variables: HashMap<(Term, Term), String>,
    weight_variables: HashMap<Term, String>,
    next_gt_variable: usize,
    next_weight_variable: usize,
    deadline: Option<Instant>,
}

impl KboSmtEncoder {
    pub(crate) fn new(deadline: Option<Instant>) -> Self {
        Self {
            definitions: String::new(),
            gt_variables: HashMap::new(),
            weight_variables: HashMap::new(),
            next_gt_variable: 0,
            next_weight_variable: 0,
            deadline,
        }
    }

    pub(crate) fn take_definitions(&mut self) -> String {
        std::mem::take(&mut self.definitions)
    }

    pub(crate) fn is_cancelled(&self) -> bool {
        smt_build_cancelled(self.deadline)
    }

    pub(crate) fn ge(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        Some(smt_or(vec![smt_bool(lhs == rhs), self.gt(lhs, rhs)?]))
    }

    pub(crate) fn gt(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        if self.is_cancelled() {
            return None;
        }
        if lhs == rhs || !variable_condition_holds(lhs, rhs) {
            return Some("false".to_string());
        }
        if let Some(variable) = self.gt_variables.get(&(lhs.clone(), rhs.clone())) {
            return Some(variable.clone());
        }
        let variable = format!("kbogt_{}", self.next_gt_variable);
        self.next_gt_variable += 1;
        self.gt_variables
            .insert((lhs.clone(), rhs.clone()), variable.clone());
        self.definitions
            .push_str(&format!("(declare-const {variable} Bool)\n"));
        let lhs_weight = self.weight(lhs)?;
        let rhs_weight = self.weight(rhs)?;
        let formula = smt_or(vec![
            format!("(> {lhs_weight} {rhs_weight})"),
            format!(
                "(and (= {lhs_weight} {rhs_weight}) {})",
                self.precedence_gt(lhs, rhs)?
            ),
        ]);
        self.definitions
            .push_str(&format!("(assert (= {variable} {formula}))\n"));
        Some(variable)
    }

    pub(crate) fn precedence_gt(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        match (lhs, rhs) {
            (Term::Var(_), _) => Some("false".to_string()),
            (_, Term::Var(_)) => Some(smt_bool(contains_term(lhs, rhs))),
            (
                Term::App {
                    symbol: lhs_symbol,
                    args: lhs_args,
                },
                Term::App {
                    symbol: rhs_symbol,
                    args: rhs_args,
                },
            ) => {
                let subterm = lhs_args
                    .iter()
                    .map(|arg| Some(smt_or(vec![smt_bool(arg == rhs), self.gt(arg, rhs)?])))
                    .collect::<Option<Vec<_>>>()?;
                let lex = if lhs_args.len() == rhs_args.len() {
                    let mut disjuncts = Vec::new();
                    for index in 0..lhs_args.len().min(rhs_args.len()) {
                        let prefix_equal = smt_and(
                            (0..index)
                                .map(|prefix| smt_bool(lhs_args[prefix] == rhs_args[prefix]))
                                .collect(),
                        );
                        disjuncts.push(smt_and(vec![
                            prefix_equal,
                            smt_bool(lhs_args[index] != rhs_args[index]),
                            self.gt(&lhs_args[index], &rhs_args[index])?,
                        ]));
                    }
                    smt_and(vec![
                        format!(
                            "(= {} {})",
                            order_rank_name(lhs_symbol.as_str()),
                            order_rank_name(rhs_symbol.as_str())
                        ),
                        smt_or(disjuncts),
                    ])
                } else {
                    "false".to_string()
                };
                let precedence = if lhs_symbol != rhs_symbol {
                    smt_and(vec![
                        format!(
                            "(< {} {})",
                            order_rank_name(lhs_symbol.as_str()),
                            order_rank_name(rhs_symbol.as_str())
                        ),
                        smt_and(
                            rhs_args
                                .iter()
                                .map(|arg| {
                                    Some(smt_or(vec![self.gt(lhs, arg)?, smt_bool(lhs == arg)]))
                                })
                                .collect::<Option<Vec<_>>>()?,
                        ),
                    ])
                } else {
                    "false".to_string()
                };
                Some(smt_or(
                    subterm.into_iter().chain([lex, precedence]).collect(),
                ))
            }
        }
    }

    pub(crate) fn weight(&mut self, term: &Term) -> Option<String> {
        if self.is_cancelled() {
            return None;
        }
        match term {
            Term::Var(_) => Some("1".to_string()),
            Term::App { symbol, args } => {
                if let Some(variable) = self.weight_variables.get(term) {
                    return Some(variable.clone());
                }
                let variable = format!("kbow_{}", self.next_weight_variable);
                self.next_weight_variable += 1;
                self.weight_variables.insert(term.clone(), variable.clone());
                let mut parts = vec![weight_name(symbol.as_str())];
                parts.extend(
                    args.iter()
                        .map(|arg| self.weight(arg))
                        .collect::<Option<Vec<_>>>()?,
                );
                let formula = smt_sum(parts);
                self.definitions
                    .push_str(&format!("(define-fun {variable} () Int {formula})\n"));
                Some(variable)
            }
        }
    }
}

pub(crate) fn filtered_kbo_ge_formula_cached(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    relation: impl FnMut(&Term, &Term) -> Option<String>,
) -> Option<String> {
    filtered_relation_formula_cached(
        lhs,
        rhs,
        filtered_terms,
        relation,
        |relation, left, right| {
            Some(smt_or(vec![
                smt_bool(left == right),
                relation(left, right)?,
            ]))
        },
    )
}

pub(crate) fn filtered_kbo_gt_formula_cached(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    relation: impl FnMut(&Term, &Term) -> Option<String>,
) -> Option<String> {
    filtered_relation_formula_cached(
        lhs,
        rhs,
        filtered_terms,
        relation,
        |relation, left, right| relation(left, right),
    )
}

pub(crate) fn filtered_relation_formula_cached(
    lhs: &Term,
    rhs: &Term,
    filtered_terms: &mut FilteredTermAlternativeCache<'_>,
    mut relation: impl FnMut(&Term, &Term) -> Option<String>,
    combine: impl Fn(&mut dyn FnMut(&Term, &Term) -> Option<String>, &Term, &Term) -> Option<String>,
) -> Option<String> {
    let lhs_alternatives = filtered_terms.alternatives(lhs);
    let rhs_alternatives = filtered_terms.alternatives(rhs);
    if lhs_alternatives.is_empty() || rhs_alternatives.is_empty() {
        return None;
    }
    let mut disjuncts = Vec::new();
    for left in &lhs_alternatives {
        for right in &rhs_alternatives {
            if smt_build_cancelled(filtered_terms.deadline) {
                return None;
            }
            if !compatible_filter_choices(&left.filters, &right.filters) {
                continue;
            }
            disjuncts.push(smt_and(vec![
                left.condition.clone(),
                right.condition.clone(),
                combine(&mut relation, &left.term, &right.term)?,
            ]));
        }
    }
    Some(smt_or(disjuncts))
}

pub(crate) fn filtered_term_alternatives(
    term: &Term,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
) -> Vec<FilteredTermAlternative> {
    FilteredTermAlternativeCache::new(filter_entries, deadline).alternatives(term)
}

pub(crate) fn merge_filtered_term_alternatives(
    alternatives: Vec<FilteredTermAlternative>,
) -> Vec<FilteredTermAlternative> {
    let mut by_term = BTreeMap::<Term, (Vec<String>, BTreeMap<String, usize>)>::new();
    for alternative in alternatives {
        match by_term.entry(alternative.term) {
            std::collections::btree_map::Entry::Vacant(entry) => {
                entry.insert((vec![alternative.condition], alternative.filters));
            }
            std::collections::btree_map::Entry::Occupied(mut entry) => {
                let (conditions, filters) = entry.get_mut();
                conditions.push(alternative.condition);
                // OR only implies assignments common to all disjuncts.
                // Taking the union here would incorrectly exclude models.
                filters.retain(|s, i| alternative.filters.get(s) == Some(i));
            }
        }
    }
    by_term.into_iter().map(|(term, (conditions, filters))| FilteredTermAlternative {
        condition: smt_or(conditions), term, filters,
    }).collect()
}

pub(crate) fn mixed_path_order_gt_smt(lhs: &Term, rhs: &Term) -> String {
    match (lhs, rhs) {
        (_, Term::Var(variable)) => smt_bool(lhs != rhs && lhs.variables().contains(variable)),
        (Term::Var(_), Term::App { .. }) => "false".to_string(),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            let subterm = lhs_args
                .iter()
                .map(|arg| {
                    smt_or(vec![
                        smt_bool(arg == rhs),
                        mixed_path_order_gt_smt(arg, rhs),
                    ])
                })
                .collect::<Vec<_>>();
            let dominates_rhs_args = smt_and(
                rhs_args
                    .iter()
                    .map(|arg| mixed_path_order_gt_smt(lhs, arg))
                    .collect(),
            );
            let precedence_case = format!(
                "(and {} (< {} {}))",
                dominates_rhs_args,
                order_rank_name(lhs_symbol.as_str()),
                order_rank_name(rhs_symbol.as_str())
            );
            let lex = lex_mixed_path_order_gt_smt(lhs_args, rhs_args);
            let multiset = multiset_mixed_path_order_gt_smt(lhs_args, rhs_args);
            let equivalent_root_case = format!(
                "(and {dominates_rhs_args} (= {} {}) (or (and (= {} 1) {lex}) (and (= {} 0) {multiset})))",
                order_rank_name(lhs_symbol.as_str()),
                order_rank_name(rhs_symbol.as_str()),
                path_order_status_name(lhs_symbol.as_str()),
                path_order_status_name(lhs_symbol.as_str())
            );
            smt_or(
                subterm
                    .into_iter()
                    .chain([precedence_case, equivalent_root_case])
                    .collect(),
            )
        }
    }
}

pub(crate) fn lex_mixed_path_order_gt_smt(lhs: &[Term], rhs: &[Term]) -> String {
    let mut disjuncts = Vec::new();
    for index in 0..lhs.len().min(rhs.len()) {
        let prefix_equal = smt_and(
            (0..index)
                .map(|prefix| smt_bool(lhs[prefix] == rhs[prefix]))
                .collect(),
        );
        disjuncts.push(smt_and(vec![
            prefix_equal,
            smt_bool(lhs[index] != rhs[index]),
            mixed_path_order_gt_smt(&lhs[index], &rhs[index]),
        ]));
    }
    if lhs.len() > rhs.len() && lhs.iter().zip(rhs).all(|(left, right)| left == right) {
        disjuncts.push("true".to_string());
    }
    smt_or(disjuncts)
}

pub(crate) fn multiset_mixed_path_order_gt_smt(lhs: &[Term], rhs: &[Term]) -> String {
    let mut used = vec![false; lhs.len()];
    multiset_mixed_path_order_match_smt(lhs, rhs, &mut used, 0, lhs.len() > rhs.len())
}

pub(crate) fn multiset_mixed_path_order_match_smt(
    lhs: &[Term],
    rhs: &[Term],
    used: &mut [bool],
    rhs_index: usize,
    strict: bool,
) -> String {
    if rhs_index == rhs.len() {
        return smt_bool(strict);
    }
    let mut disjuncts = Vec::new();
    for lhs_index in 0..lhs.len() {
        if used[lhs_index] {
            continue;
        }
        let ge = smt_or(vec![
            smt_bool(lhs[lhs_index] == rhs[rhs_index]),
            mixed_path_order_gt_smt(&lhs[lhs_index], &rhs[rhs_index]),
        ]);
        let gt = mixed_path_order_gt_smt(&lhs[lhs_index], &rhs[rhs_index]);
        used[lhs_index] = true;
        let rest = multiset_mixed_path_order_match_smt(
            lhs,
            rhs,
            used,
            rhs_index + 1,
            strict || lhs[lhs_index] != rhs[rhs_index],
        );
        used[lhs_index] = false;
        disjuncts.push(smt_and(vec![ge, smt_or(vec![smt_bool(strict), gt]), rest]));
    }
    smt_or(disjuncts)
}

pub(crate) fn parse_order_model(
    output: &str,
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
) -> Option<(
    Vec<String>,
    BTreeMap<String, usize>,
    DpArgumentFilter,
    BTreeMap<String, i64>,
)> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_smt_values(output)?;
    let mut ranked = symbols
        .iter()
        .map(|symbol| {
            Some((
                usize::try_from(values.get(&order_rank_name(symbol)).copied()?).ok()?,
                symbol.clone(),
            ))
        })
        .collect::<Option<Vec<_>>>()?;
    let precedence_ranks = ranked
        .iter()
        .map(|(rank, symbol)| (symbol.clone(), *rank))
        .collect::<BTreeMap<_, _>>();
    ranked.sort_by(|left, right| left.0.cmp(&right.0).then_with(|| left.1.cmp(&right.1)));
    let precedence = ranked
        .into_iter()
        .map(|(_, symbol)| symbol)
        .collect::<Vec<_>>();
    let mut argument_filter = BTreeMap::new();
    for (symbol, entries) in filter_entries {
        let index = usize::try_from(values.get(&filter_name(symbol)).copied()?).ok()?;
        argument_filter.insert(symbol.clone(), entries.get(index)?.clone());
    }
    let weights = symbols
        .iter()
        .filter_map(|symbol| {
            values
                .get(&weight_name(symbol))
                .copied()
                .map(|weight| (symbol.clone(), weight))
        })
        .collect::<BTreeMap<_, _>>();
    Some((precedence, precedence_ranks, argument_filter, weights))
}

pub(crate) fn precedence_rank_refs(
    precedence_ranks: &BTreeMap<String, usize>,
) -> BTreeMap<&str, usize> {
    precedence_ranks
        .iter()
        .map(|(symbol, rank)| (symbol.as_str(), *rank))
        .collect()
}

pub(crate) fn parse_path_order_status_model(
    output: &str,
    symbols: &[String],
) -> Option<BTreeMap<String, DpPathOrderKind>> {
    let values = parse_smt_values(output)?;
    symbols
        .iter()
        .map(|symbol| {
            let status = match values.get(&path_order_status_name(symbol)).copied()? {
                0 => DpPathOrderKind::Rpo,
                1 => DpPathOrderKind::Lpo,
                _ => return None,
            };
            Some((symbol.clone(), status))
        })
        .collect()
}

pub(crate) fn majority_path_order_status(
    statuses: &BTreeMap<String, DpPathOrderKind>,
) -> DpPathOrderKind {
    let lpo = statuses
        .values()
        .filter(|status| matches!(status, DpPathOrderKind::Lpo))
        .count();
    if lpo * 2 > statuses.len() {
        DpPathOrderKind::Lpo
    } else {
        DpPathOrderKind::Rpo
    }
}

pub(crate) fn order_rank_name(symbol: &str) -> String {
    format!("r_{}", sanitize_smt_name(symbol))
}

pub(crate) fn filter_name(symbol: &str) -> String {
    format!("af_{}", sanitize_smt_name(symbol))
}

pub(crate) fn path_order_status_name(symbol: &str) -> String {
    format!("st_{}", sanitize_smt_name(symbol))
}

pub(crate) fn weight_name(symbol: &str) -> String {
    format!("w_{}", sanitize_smt_name(symbol))
}

pub(crate) fn smt_bool(value: bool) -> String {
    if value {
        "true".to_string()
    } else {
        "false".to_string()
    }
}

#[allow(dead_code)]
pub(crate) fn checked_component_removal_by_kbo(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    precedence: &[String],
    weights: &BTreeMap<String, i64>,
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    let owned_precedence_ranks = precedence
        .iter()
        .enumerate()
        .map(|(rank, symbol)| (symbol.clone(), rank))
        .collect::<BTreeMap<_, _>>();
    checked_component_removal_by_kbo_with_ranks(
        pairs,
        usable,
        precedence,
        &owned_precedence_ranks,
        weights,
        argument_filter,
        backend,
        innermost_lhss,
    )
}

pub(crate) fn checked_component_removal_by_kbo_with_ranks(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    weights: &BTreeMap<String, i64>,
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
) -> Option<ComponentRemoval> {
    checked_component_removal_by_kbo_with_ranks_and_required_strict_rules(
        pairs,
        usable,
        precedence,
        precedence_ranks,
        weights,
        argument_filter,
        backend,
        innermost_lhss,
        &[],
    )
}

pub(crate) fn checked_component_removal_by_kbo_with_ranks_and_required_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    weights: &BTreeMap<String, i64>,
    argument_filter: &DpArgumentFilter,
    backend: DpSearchBackend,
    innermost_lhss: Option<&[Term]>,
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    let argument_filter = complete_argument_filter(pairs, usable, argument_filter);
    if !kbo_weights_are_admissible(pairs, usable, weights, precedence_ranks, &argument_filter) {
        write_progress_event("dp-order-check", "rejected", "kbo", 0, "reason=weight-admissibility");
        return None;
    }
    if !path_order_q_compatibility_holds(innermost_lhss, &argument_filter) {
        write_progress_event("dp-order-check", "rejected", "kbo", 0, "reason=q-filter-compatibility");
        return None;
    }
    let precedence_rank_refs = precedence_rank_refs(precedence_ranks);
    if !usable.iter().all(|rule| {
        weakly_decreases_by_kbo(
            rule.lhs(),
            rule.rhs(),
            weights,
            &precedence_rank_refs,
            &argument_filter,
        )
    }) {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            weakly_decreases_by_kbo(
                pair.lhs(),
                pair.rhs(),
                weights,
                &precedence_rank_refs,
                &argument_filter,
            )
            .then_some(())
            .and_then(|_| {
                strictly_decreases_by_kbo(
                    pair.lhs(),
                    pair.rhs(),
                    weights,
                    &precedence_rank_refs,
                    &argument_filter,
                )
                .then_some(index)
            })
        })
        .collect::<Vec<_>>();
    let all_weak = pairs.iter().all(|pair| {
        weakly_decreases_by_kbo(
            pair.lhs(),
            pair.rhs(),
            weights,
            &precedence_rank_refs,
            &argument_filter,
        )
    });
    let strict_rule_indices = if required_strict_rule_indices.is_empty() {
        Vec::new()
    } else {
        usable
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| {
                strictly_decreases_by_kbo(
                    rule.lhs(),
                    rule.rhs(),
                    weights,
                    &precedence_rank_refs,
                    &argument_filter,
                )
                .then_some(index)
            })
            .collect::<Vec<_>>()
    };
    let required_rules_are_strict = required_strict_rule_indices
        .iter()
        .all(|index| strict_rule_indices.contains(index));
    (all_weak
        && required_rules_are_strict
        && (!strict_pair_indices.is_empty() || !required_strict_rule_indices.is_empty()))
    .then_some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::Kbo {
            precedence: precedence.to_vec(),
            precedence_ranks: precedence_ranks.clone(),
            weights: weights.clone(),
            argument_filter,
            backend,
        },
        smt_attempted: false,
        usable_rules: None,
    })
}

pub(crate) fn path_order_precedence(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
) -> Vec<String> {
    let mut symbols = symbols_for_constraints(pairs, usable);
    symbols.sort_by_key(|symbol| {
        (
            !symbol.ends_with('#'),
            !pairs.iter().any(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|root| root.as_str() == symbol)
            }),
            symbol.clone(),
        )
    });
    symbols
}

pub(crate) fn argument_filter_symbols(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
) -> Vec<(String, usize)> {
    arities_for_constraints(pairs, usable)
        .iter()
        .map(|(symbol, arity)| (symbol.clone(), *arity))
        .collect()
}

#[cfg(test)]
pub(crate) fn permutations_of_positions(positions: &[usize]) -> Vec<Vec<usize>> {
    permutations_of_positions_with_deadline(positions, None).unwrap_or_default()
}

pub(crate) fn permutations_of_positions_with_deadline(
    positions: &[usize],
    deadline: Option<Instant>,
) -> Option<Vec<Vec<usize>>> {
    pub(crate) fn go(
        index: usize,
        current: &mut Vec<usize>,
        result: &mut Vec<Vec<usize>>,
        deadline: Option<Instant>,
    ) -> Option<()> {
        if smt_build_cancelled(deadline) {
            return None;
        }
        if index == current.len() {
            result.push(current.clone());
            return Some(());
        }
        for swap_index in index..current.len() {
            current.swap(index, swap_index);
            go(index + 1, current, result, deadline)?;
            current.swap(index, swap_index);
        }
        Some(())
    }

    let mut current = positions.to_vec();
    let mut result = Vec::new();
    go(0, &mut current, &mut result, deadline)?;
    Some(result)
}

#[allow(dead_code)]
pub(crate) fn kbo_weights_are_admissible(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    weights: &BTreeMap<String, i64>,
    precedence_ranks: &BTreeMap<String, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let arities = arities_for_constraints(pairs, usable);
    arities.iter().all(|(symbol, arity)| {
        let weight = weights.get(symbol).copied().unwrap_or(1);
        weight > 0
            || (kbo_filter_allows_zero_weight(symbol, *arity, argument_filter)
                && kbo_symbol_is_precedence_maximal(symbol, precedence_ranks))
    })
}

pub(crate) fn kbo_filter_allows_zero_weight(
    symbol: &str,
    arity: usize,
    argument_filter: &DpArgumentFilter,
) -> bool {
    match argument_filter.get(symbol) {
        Some(DpArgumentFilterEntry::Collapsing(position)) => *position < arity,
        Some(DpArgumentFilterEntry::NonCollapsing(positions)) => positions.len() == 1,
        None => arity == 1,
    }
}

pub(crate) fn kbo_symbol_is_precedence_maximal(
    symbol: &str,
    precedence_ranks: &BTreeMap<String, usize>,
) -> bool {
    precedence_ranks.get(symbol).copied().unwrap_or(usize::MAX) == 0
}

#[allow(dead_code)]
pub(crate) fn weakly_decreases_by_path_order(
    lhs: &Term,
    rhs: &Term,
    order: DpPathOrderKind,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let statuses = BTreeMap::new();
    weakly_decreases_by_mixed_path_order(lhs, rhs, order, &statuses, precedence, argument_filter)
}

pub(crate) fn weakly_decreases_by_mixed_path_order(
    lhs: &Term,
    rhs: &Term,
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let lhs = filter_term(lhs, argument_filter);
    let rhs = filter_term(rhs, argument_filter);
    mixed_path_order_ge(&lhs, &rhs, default_order, statuses, precedence)
}

#[allow(dead_code)]
pub(crate) fn strictly_decreases_by_path_order(
    lhs: &Term,
    rhs: &Term,
    order: DpPathOrderKind,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let statuses = BTreeMap::new();
    strictly_decreases_by_mixed_path_order(lhs, rhs, order, &statuses, precedence, argument_filter)
}

pub(crate) fn strictly_decreases_by_mixed_path_order(
    lhs: &Term,
    rhs: &Term,
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let lhs = filter_term(lhs, argument_filter);
    let rhs = filter_term(rhs, argument_filter);
    mixed_path_order_gt(&lhs, &rhs, default_order, statuses, precedence)
}

#[allow(dead_code)]
pub(crate) fn weakly_decreases_by_kbo(
    lhs: &Term,
    rhs: &Term,
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let lhs = filter_term(lhs, argument_filter);
    let rhs = filter_term(rhs, argument_filter);
    lhs == rhs || kbo_gt(&lhs, &rhs, weights, precedence)
}

#[allow(dead_code)]
pub(crate) fn strictly_decreases_by_kbo(
    lhs: &Term,
    rhs: &Term,
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let lhs = filter_term(lhs, argument_filter);
    let rhs = filter_term(rhs, argument_filter);
    kbo_gt(&lhs, &rhs, weights, precedence)
}

#[allow(dead_code)]
pub(crate) fn kbo_gt(
    lhs: &Term,
    rhs: &Term,
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    if !variable_condition_holds(lhs, rhs) {
        return false;
    }
    let lhs_weight = kbo_weight(lhs, weights);
    let rhs_weight = kbo_weight(rhs, weights);
    if lhs_weight > rhs_weight {
        return true;
    }
    lhs_weight == rhs_weight && kbo_precedence_gt(lhs, rhs, weights, precedence)
}

#[allow(dead_code)]
pub(crate) fn variable_condition_holds(lhs: &Term, rhs: &Term) -> bool {
    let mut lhs_variables = BTreeMap::new();
    collect_variable_counts(lhs, &mut lhs_variables);
    let mut rhs_variables = BTreeMap::new();
    collect_variable_counts(rhs, &mut rhs_variables);
    rhs_variables
        .into_iter()
        .all(|(variable, count)| lhs_variables.get(&variable).copied().unwrap_or(0) >= count)
}

#[allow(dead_code)]
pub(crate) fn collect_variable_counts(term: &Term, counts: &mut BTreeMap<Variable, usize>) {
    match term {
        Term::Var(variable) => {
            *counts.entry(variable.clone()).or_default() += 1;
        }
        Term::App { args, .. } => {
            for arg in args {
                collect_variable_counts(arg, counts);
            }
        }
    }
}

#[allow(dead_code)]
pub(crate) fn kbo_weight(term: &Term, weights: &BTreeMap<String, i64>) -> i64 {
    match term {
        Term::Var(_) => 1,
        Term::App { symbol, args } => {
            weights.get(symbol.as_str()).copied().unwrap_or(1)
                + args.iter().map(|arg| kbo_weight(arg, weights)).sum::<i64>()
        }
    }
}

#[allow(dead_code)]
pub(crate) fn kbo_precedence_gt(
    lhs: &Term,
    rhs: &Term,
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    match (lhs, rhs) {
        (Term::Var(_), _) => false,
        (_, Term::Var(_)) => contains_term(lhs, rhs),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            if lhs_args
                .iter()
                .any(|arg| arg == rhs || kbo_gt(arg, rhs, weights, precedence))
            {
                return true;
            }
            let lhs_rank = precedence
                .get(lhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            let rhs_rank = precedence
                .get(rhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            if lhs_rank == rhs_rank && lhs_args.len() == rhs_args.len() {
                return lhs_args.iter().zip(rhs_args).any(|(left, right)| {
                    left != right
                        && kbo_gt(left, right, weights, precedence)
                        && lhs_args
                            .iter()
                            .zip(rhs_args)
                            .take_while(|(prefix_left, prefix_right)| {
                                *prefix_left != left || *prefix_right != right
                            })
                            .all(|(prefix_left, prefix_right)| prefix_left == prefix_right)
                });
            }
            lhs_rank < rhs_rank
                && rhs_args
                    .iter()
                    .all(|arg| kbo_gt(lhs, arg, weights, precedence) || lhs == arg)
        }
    }
}

#[allow(dead_code)]
pub(crate) fn contains_term(term: &Term, needle: &Term) -> bool {
    match term {
        Term::Var(_) => term == needle,
        Term::App { args, .. } => {
            term == needle || args.iter().any(|arg| contains_term(arg, needle))
        }
    }
}

pub(crate) fn llm_argument_filter(
    argument_filter: &BTreeMap<String, Vec<usize>>,
) -> DpArgumentFilter {
    argument_filter
        .iter()
        .map(|(symbol, positions)| {
            (
                symbol.clone(),
                DpArgumentFilterEntry::NonCollapsing(positions.clone()),
            )
        })
        .collect()
}

pub(crate) fn filter_term(term: &Term, argument_filter: &DpArgumentFilter) -> Term {
    match term {
        Term::Var(_) => term.clone(),
        Term::App { symbol, args } => {
            let selected = argument_filter
                .get(symbol.as_str())
                .cloned()
                .unwrap_or_else(|| DpArgumentFilterEntry::NonCollapsing((0..args.len()).collect()));
            match selected {
                DpArgumentFilterEntry::Collapsing(position) => args
                    .get(position)
                    .map(|arg| filter_term(arg, argument_filter))
                    .unwrap_or_else(|| Term::app(symbol.as_str(), Vec::new())),
                DpArgumentFilterEntry::NonCollapsing(positions) => Term::app(
                    symbol.as_str(),
                    positions
                        .into_iter()
                        .filter_map(|index| args.get(index))
                        .map(|arg| filter_term(arg, argument_filter))
                        .collect(),
                ),
            }
        }
    }
}

pub(crate) fn polynomial_q_minimality_holds(innermost_lhss: Option<&[Term]>) -> bool {
    innermost_lhss.is_none_or(|lhss| {
        lhss.iter()
            .all(|lhs| term_is_q_minimal_in_context(lhs, lhss))
    })
}

pub(crate) fn log_q_minimality_rejection(
    processor: &str,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) {
    write_progress_event(
        "dp-q-minimality",
        "reject",
        processor,
        0,
        &format!(
            "pairs={} q_lhss={} reason=some-lhs-has-guaranteed-q-redex-proper-subterm",
            pairs.len(),
            innermost_lhss.map_or(0, <[Term]>::len)
        ),
    );
}

pub(crate) fn path_order_q_compatibility_holds(
    innermost_lhss: Option<&[Term]>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    innermost_lhss.is_none_or(|lhss| {
        if !marked_filters_match_q_collapsing_filters(lhss, argument_filter) {
            return false;
        }
        lhss.iter()
            .map(|lhs| filter_term(lhs, argument_filter))
            .all(|lhs| matches!(lhs, Term::Var(_)))
    })
}

pub(crate) fn marked_filters_match_q_collapsing_filters(
    lhss: &[Term],
    argument_filter: &DpArgumentFilter,
) -> bool {
    lhss.iter().all(|lhs| {
        let Some(symbol) = lhs.root_symbol() else {
            return true;
        };
        let Some(unmarked_filter) = argument_filter.get(symbol.as_str()) else {
            return true;
        };
        let DpArgumentFilterEntry::Collapsing(unmarked_position) = unmarked_filter else {
            return true;
        };
        let marked = format!("{}#", symbol.as_str());
        argument_filter
            .get(&marked)
            .is_some_and(|entry| matches!(entry, DpArgumentFilterEntry::Collapsing(marked_position) if marked_position == unmarked_position))
    })
}

pub(crate) fn term_is_q_minimal(term: &Term) -> bool {
    match term {
        Term::Var(_) => true,
        Term::App { args, .. } => args.is_empty(),
    }
}

pub(crate) fn term_is_q_minimal_in_context(term: &Term, q_lhss: &[Term]) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .filter(|(position, _)| !position.is_empty())
        .all(|(_, subterm)| !term_is_guaranteed_q_redex(subterm, q_lhss))
}

pub(crate) fn term_size(term: &Term) -> usize {
    match term {
        Term::Var(_) => 1,
        Term::App { args, .. } => 1 + args.iter().map(term_size).sum::<usize>(),
    }
}

#[allow(dead_code)]
pub(crate) fn path_order_gt(
    lhs: &Term,
    rhs: &Term,
    order: DpPathOrderKind,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    match (lhs, rhs) {
        (_, Term::Var(variable)) => lhs != rhs && lhs.variables().contains(variable),
        (Term::Var(_), Term::App { .. }) => false,
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            if lhs_args
                .iter()
                .any(|arg| arg == rhs || path_order_gt(arg, rhs, order, precedence))
            {
                return true;
            }
            let lhs_dominates_rhs_args = rhs_args
                .iter()
                .all(|arg| path_order_gt(lhs, arg, order, precedence));
            if !lhs_dominates_rhs_args {
                return false;
            }
            let lhs_rank = precedence
                .get(lhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            let rhs_rank = precedence
                .get(rhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            if lhs_rank < rhs_rank {
                return true;
            }
            if lhs_rank == rhs_rank {
                return match order {
                    DpPathOrderKind::Lpo => {
                        lex_path_order_gt(lhs_args, rhs_args, order, precedence)
                    }
                    DpPathOrderKind::Rpo => multiset_path_order_gt(lhs_args, rhs_args, precedence),
                };
            }
            false
        }
    }
}

pub(crate) fn mixed_path_order_gt(
    lhs: &Term,
    rhs: &Term,
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    match (lhs, rhs) {
        (_, Term::Var(variable)) => lhs != rhs && lhs.variables().contains(variable),
        (Term::Var(_), Term::App { .. }) => false,
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            if lhs_args.iter().any(|arg| {
                mixed_path_order_equivalent(arg, rhs, default_order, statuses, precedence)
                    || mixed_path_order_gt(arg, rhs, default_order, statuses, precedence)
            }) {
                return true;
            }
            let lhs_dominates_rhs_args = rhs_args
                .iter()
                .all(|arg| mixed_path_order_gt(lhs, arg, default_order, statuses, precedence));
            if !lhs_dominates_rhs_args {
                return false;
            }
            let lhs_rank = precedence
                .get(lhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            let rhs_rank = precedence
                .get(rhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            if lhs_rank < rhs_rank {
                return true;
            }
            if lhs_rank == rhs_rank {
                return match statuses
                    .get(lhs_symbol.as_str())
                    .copied()
                    .unwrap_or(default_order)
                {
                    DpPathOrderKind::Lpo => mixed_lex_path_order_gt(
                        lhs_args,
                        rhs_args,
                        default_order,
                        statuses,
                        precedence,
                    ),
                    DpPathOrderKind::Rpo => mixed_multiset_path_order_gt(
                        lhs_args,
                        rhs_args,
                        default_order,
                        statuses,
                        precedence,
                    ),
                };
            }
            false
        }
    }
}

#[allow(dead_code)]
pub(crate) fn path_order_ge(
    lhs: &Term,
    rhs: &Term,
    order: DpPathOrderKind,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    lhs == rhs || path_order_gt(lhs, rhs, order, precedence)
}

pub(crate) fn mixed_path_order_ge(
    lhs: &Term,
    rhs: &Term,
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    mixed_path_order_equivalent(lhs, rhs, default_order, statuses, precedence)
        || mixed_path_order_gt(lhs, rhs, default_order, statuses, precedence)
}

pub(crate) fn mixed_path_order_equivalent(
    lhs: &Term,
    rhs: &Term,
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    match (lhs, rhs) {
        (Term::Var(left), Term::Var(right)) => left == right,
        (Term::Var(_), Term::App { .. }) | (Term::App { .. }, Term::Var(_)) => false,
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            if lhs_args.len() != rhs_args.len()
                || precedence.get(lhs_symbol.as_str()) != precedence.get(rhs_symbol.as_str())
            {
                return false;
            }
            match statuses
                .get(lhs_symbol.as_str())
                .copied()
                .unwrap_or(default_order)
            {
                DpPathOrderKind::Lpo => lhs_args.iter().zip(rhs_args).all(|(left, right)| {
                    mixed_path_order_equivalent(left, right, default_order, statuses, precedence)
                }),
                DpPathOrderKind::Rpo => mixed_multiset_path_order_equivalent(
                    lhs_args,
                    rhs_args,
                    default_order,
                    statuses,
                    precedence,
                ),
            }
        }
    }
}

pub(crate) fn mixed_lex_path_order_gt(
    lhs: &[Term],
    rhs: &[Term],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    for (left, right) in lhs.iter().zip(rhs) {
        if mixed_path_order_equivalent(left, right, default_order, statuses, precedence) {
            continue;
        }
        return mixed_path_order_gt(left, right, default_order, statuses, precedence);
    }
    lhs.len() > rhs.len()
}

pub(crate) fn mixed_multiset_path_order_gt(
    lhs: &[Term],
    rhs: &[Term],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    let mut removed = vec![false; lhs.len()];
    mixed_multiset_path_order_removed_choices(
        lhs,
        rhs,
        default_order,
        statuses,
        precedence,
        &mut removed,
        0,
        false,
    )
}

pub(crate) fn mixed_multiset_path_order_removed_choices(
    lhs: &[Term],
    rhs: &[Term],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    removed: &mut [bool],
    lhs_index: usize,
    any_removed: bool,
) -> bool {
    if lhs_index == lhs.len() {
        if !any_removed {
            return false;
        }
        let kept = removed
            .iter()
            .enumerate()
            .filter_map(|(index, removed)| (!removed).then_some(index))
            .collect::<Vec<_>>();
        let removed_indices = removed
            .iter()
            .enumerate()
            .filter_map(|(index, removed)| removed.then_some(index))
            .collect::<Vec<_>>();
        let mut used_rhs = vec![false; rhs.len()];
        return mixed_multiset_cancel_common(
            lhs,
            rhs,
            default_order,
            statuses,
            precedence,
            &kept,
            &removed_indices,
            &mut used_rhs,
            0,
        );
    }

    removed[lhs_index] = false;
    if mixed_multiset_path_order_removed_choices(
        lhs,
        rhs,
        default_order,
        statuses,
        precedence,
        removed,
        lhs_index + 1,
        any_removed,
    ) {
        return true;
    }
    removed[lhs_index] = true;
    let result = mixed_multiset_path_order_removed_choices(
        lhs,
        rhs,
        default_order,
        statuses,
        precedence,
        removed,
        lhs_index + 1,
        true,
    );
    removed[lhs_index] = false;
    result
}

pub(crate) fn mixed_multiset_cancel_common(
    lhs: &[Term],
    rhs: &[Term],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    kept: &[usize],
    removed: &[usize],
    used_rhs: &mut [bool],
    kept_index: usize,
) -> bool {
    if kept_index == kept.len() {
        return rhs.iter().enumerate().all(|(rhs_index, right)| {
            used_rhs[rhs_index]
                || removed.iter().any(|left_index| {
                    mixed_path_order_gt(
                        &lhs[*left_index],
                        right,
                        default_order,
                        statuses,
                        precedence,
                    )
                })
        });
    }
    let left = &lhs[kept[kept_index]];
    (0..rhs.len()).any(|rhs_index| {
        if used_rhs[rhs_index]
            || !mixed_path_order_equivalent(
                left,
                &rhs[rhs_index],
                default_order,
                statuses,
                precedence,
            )
        {
            return false;
        }
        used_rhs[rhs_index] = true;
        let result = mixed_multiset_cancel_common(
            lhs,
            rhs,
            default_order,
            statuses,
            precedence,
            kept,
            removed,
            used_rhs,
            kept_index + 1,
        );
        used_rhs[rhs_index] = false;
        result
    })
}

pub(crate) fn mixed_multiset_path_order_equivalent(
    lhs: &[Term],
    rhs: &[Term],
    default_order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    if lhs.len() != rhs.len() {
        return false;
    }
    pub(crate) fn match_terms(
        lhs: &[Term],
        rhs: &[Term],
        default_order: DpPathOrderKind,
        statuses: &BTreeMap<String, DpPathOrderKind>,
        precedence: &BTreeMap<&str, usize>,
        used: &mut [bool],
        lhs_index: usize,
    ) -> bool {
        if lhs_index == lhs.len() {
            return true;
        }
        (0..rhs.len()).any(|rhs_index| {
            if used[rhs_index]
                || !mixed_path_order_equivalent(
                    &lhs[lhs_index],
                    &rhs[rhs_index],
                    default_order,
                    statuses,
                    precedence,
                )
            {
                return false;
            }
            used[rhs_index] = true;
            let result = match_terms(
                lhs,
                rhs,
                default_order,
                statuses,
                precedence,
                used,
                lhs_index + 1,
            );
            used[rhs_index] = false;
            result
        })
    }
    match_terms(
        lhs,
        rhs,
        default_order,
        statuses,
        precedence,
        &mut vec![false; rhs.len()],
        0,
    )
}

#[allow(dead_code)]
pub(crate) fn lex_path_order_gt(
    lhs: &[Term],
    rhs: &[Term],
    order: DpPathOrderKind,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    for (left, right) in lhs.iter().zip(rhs) {
        if left == right {
            continue;
        }
        return path_order_gt(left, right, order, precedence);
    }
    lhs.len() > rhs.len()
}

#[allow(dead_code)]
pub(crate) fn multiset_path_order_gt(
    lhs: &[Term],
    rhs: &[Term],
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    let mut used = vec![false; lhs.len()];
    multiset_path_order_match(lhs, rhs, precedence, &mut used, 0, lhs.len() > rhs.len())
}

#[allow(dead_code)]
pub(crate) fn multiset_path_order_match(
    lhs: &[Term],
    rhs: &[Term],
    precedence: &BTreeMap<&str, usize>,
    used: &mut [bool],
    rhs_index: usize,
    strict: bool,
) -> bool {
    if rhs_index == rhs.len() {
        return strict;
    }
    lhs.iter().enumerate().any(|(lhs_index, left)| {
        if used[lhs_index]
            || !path_order_ge(left, &rhs[rhs_index], DpPathOrderKind::Rpo, precedence)
        {
            return false;
        }
        used[lhs_index] = true;
        let matched = multiset_path_order_match(
            lhs,
            rhs,
            precedence,
            used,
            rhs_index + 1,
            strict || path_order_gt(left, &rhs[rhs_index], DpPathOrderKind::Rpo, precedence),
        );
        used[lhs_index] = false;
        matched
    })
}

pub(crate) fn weights_as_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    weights: &SymbolWeights,
) -> Vec<(String, i64, Vec<i64>)> {
    arities_for_constraints(pairs, usable)
        .into_iter()
        .map(|(symbol, arity)| {
            (
                symbol.clone(),
                weights.get(&symbol).copied().unwrap_or(0),
                vec![1; arity],
            )
        })
        .collect()
}

pub(crate) fn synthesize_symbol_weights_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<SymbolWeights> {
    let symbols = symbols_for_constraints(pairs, usable);
    if symbols.is_empty() || symbols.len() > options.max_symbols || options.max_symbol_weight < 0 {
        return None;
    }
    let script = symbol_weights_smt_script(pairs, usable, &symbols, options.max_symbol_weight)?;
    let stdout = run_smt_script(&script, options, deadline)?;
    if stdout
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_smt_values(&stdout)?;
    let weights = symbols
        .into_iter()
        .map(|symbol| Some((symbol.clone(), values.get(&weight_name(&symbol)).copied()?)))
        .collect::<Option<BTreeMap<_, _>>>()?;
    checked_component_removal_by_weights(pairs, usable, &weights, DpSearchBackend::Smt, None)
        .map(|_| weights)
}

pub(crate) fn symbol_weights_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    symbols: &[String],
    max_weight: i64,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_LIA)\n");
    for symbol in symbols {
        script.push_str(&format!("(declare-const {} Int)\n", weight_name(symbol)));
        script.push_str(&format!(
            "(assert (and (>= {} 0) (<= {} {max_weight})))\n",
            weight_name(symbol),
            weight_name(symbol)
        ));
    }
    for rule in usable {
        script.push_str(&format!(
            "(assert {})\n",
            symbol_weight_ge_formula(rule.lhs(), rule.rhs())
        ));
    }
    let mut strict_terms = Vec::new();
    for pair in pairs {
        script.push_str(&format!(
            "(assert {})\n",
            symbol_weight_ge_formula(pair.lhs(), pair.rhs())
        ));
        strict_terms.push(symbol_weight_gt_formula(pair.lhs(), pair.rhs()));
    }
    if strict_terms.is_empty() {
        return None;
    }
    script.push_str("(assert ");
    script.push_str(&smt_or(strict_terms));
    script.push_str(")\n(check-sat)\n(get-model)\n");
    Some(script)
}

pub(crate) fn symbol_weight_ge_formula(lhs: &Term, rhs: &Term) -> String {
    format!(
        "(>= {} {})",
        symbol_weight_smt_interpret(lhs),
        symbol_weight_smt_interpret(rhs)
    )
}

pub(crate) fn symbol_weight_gt_formula(lhs: &Term, rhs: &Term) -> String {
    format!(
        "(> {} {})",
        symbol_weight_smt_interpret(lhs),
        symbol_weight_smt_interpret(rhs)
    )
}

pub(crate) fn symbol_weight_smt_interpret(term: &Term) -> String {
    match term {
        Term::Var(_) => "0".to_string(),
        Term::App { symbol, args } => {
            let mut parts = vec![weight_name(symbol.as_str())];
            parts.extend(args.iter().map(symbol_weight_smt_interpret));
            smt_sum(parts)
        }
    }
}

pub(crate) fn synthesize_linear_polynomial_with_sat(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_with_bv_sat(pairs, usable, &[], &[], None, None, options, deadline)
}

pub(crate) fn synthesize_linear_polynomial_with_sat_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_with_bv_sat(
        pairs,
        usable,
        required_strict_rule_indices,
        &[],
        None,
        None,
        options,
        deadline,
    )
}

pub(crate) fn synthesize_linear_polynomial_for_target_residual(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    target_strict_pair_indices: &[usize],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_with_bv_sat(
        pairs,
        usable,
        required_strict_rule_indices,
        &[],
        Some(target_strict_pair_indices),
        None,
        options,
        deadline,
    )
}

pub(crate) fn synthesize_linear_polynomial_for_minimum_deletion(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    min_delete: usize,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_with_bv_sat(
        pairs,
        usable,
        required_strict_rule_indices,
        &[],
        None,
        Some(min_delete),
        options,
        deadline,
    )
}

pub(crate) fn synthesize_relative_adp_polynomial_reduction_pair(
    constraints: &[DependencyPair],
    erased_rules: &[RewriteRule],
    strict_candidate_indices: &[usize],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<(LinearPolynomialInterpretations, Vec<usize>)> {
    let strict_candidate_indices = strict_candidate_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    if strict_candidate_indices.is_empty()
        || strict_candidate_indices
            .iter()
            .any(|index| *index >= constraints.len())
    {
        return None;
    }
    let strict_constraints = strict_candidate_indices
        .iter()
        .map(|index| constraints[*index].clone())
        .collect::<Vec<_>>();
    let mut weak_constraints = erased_rules.to_vec();
    weak_constraints.extend(
        constraints
            .iter()
            .enumerate()
            .filter(|(index, _)| !strict_candidate_indices.contains(index))
            .map(|(_, pair)| RewriteRule::new(pair.lhs().clone(), pair.rhs().clone())),
    );
    let arities = arities_for_constraints(&strict_constraints, &weak_constraints);
    let fixed_coefficients = if arities.contains_key("__ferrum_adp_c2") {
        vec![("__ferrum_adp_c2", 0, 1), ("__ferrum_adp_c2", 1, 1)]
    } else {
        Vec::new()
    };
    let interpretations = synthesize_linear_polynomial_with_bv_sat_mode(
        &strict_constraints,
        &weak_constraints,
        &[],
        &fixed_coefficients,
        None,
        None,
        options,
        deadline,
        true,
        None,
        None,
    )?;
    let removal = checked_component_removal_by_polynomial(
        constraints,
        erased_rules,
        &interpretations,
        DpSearchBackend::Sat,
        false,
        None,
    )?;
    let strict = removal
        .strict_pair_indices
        .into_iter()
        .filter(|index| strict_candidate_indices.contains(index))
        .collect::<Vec<_>>();
    (!strict.is_empty()).then_some((interpretations, strict))
}

pub(crate) fn synthesize_weak_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    min_constant: i64,
    fixed_usable_rules: bool,
    deadline: Option<Instant>,
) -> Option<(LinearPolynomialInterpretations, DpSearchBackend)> {
    synthesize_weak_polynomial_with_smt_only(
        pairs,
        usable,
        options,
        min_constant,
        fixed_usable_rules,
        None,
        deadline,
    )
    .or_else(|| {
        // Preserve existing models and oracle replay first. If the older
        // conservative query fails, use CeTA's exact zero-coefficient
        // normalization and shared constant expressions.
        let script = weak_polynomial_smt_script_mode(
            pairs, usable, options, min_constant, fixed_usable_rules, None, true,
        )?;
        let stdout = run_smt_script(&script, options, deadline)?;
        parse_smt_model(&stdout, &arities_for_constraints(pairs, usable))
    })
    .map(|interpretations| (interpretations, DpSearchBackend::Smt))
}

pub(crate) fn synthesize_linear_polynomial_with_bv_sat(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    fixed_coefficients: &[(&str, usize, i64)],
    target_strict_pair_indices: Option<&[usize]>,
    min_delete: Option<usize>,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_with_bv_sat_mode(
        pairs,
        usable,
        required_strict_rule_indices,
        fixed_coefficients,
        target_strict_pair_indices,
        min_delete,
        options,
        deadline,
        false,
        None,
        None,
    )
}

pub(crate) fn synthesize_pair_polynomial_for_size_change(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
    accept: &dyn Fn(&LinearPolynomialInterpretations) -> bool,
) -> Option<LinearPolynomialInterpretations> {
    // SCT compares arguments, not the interpretation of the marked root.
    // Do not spend the model budget changing only irrelevant root weights.
    let mut relevant = BTreeMap::new();
    for pair in pairs {
        for term in [pair.lhs(), pair.rhs()] {
            if let Term::App { args, .. } = term {
                for argument in args { collect_term_arities(argument, &mut relevant); }
            }
        }
    }
    synthesize_linear_polynomial_with_bv_sat_mode(
        pairs, usable, &[], &[], None, None, options, deadline, false, Some(accept), Some(&relevant),
    )
}

fn synthesize_linear_polynomial_with_bv_sat_mode(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    fixed_coefficients: &[(&str, usize, i64)],
    target_strict_pair_indices: Option<&[usize]>,
    min_delete: Option<usize>,
    options: &DpOptions,
    deadline: Option<Instant>,
    require_monotonicity: bool,
    accept: Option<&dyn Fn(&LinearPolynomialInterpretations) -> bool>,
    model_block_arities: Option<&BTreeMap<String, usize>>,
) -> Option<LinearPolynomialInterpretations> {
    let arities = arities_for_constraints(pairs, usable);
    if !polynomial_sat_bounds_hold(&arities, options) {
        return None;
    }
    if required_strict_rule_indices.is_empty()
        && target_strict_pair_indices.is_none()
        && min_delete.is_none()
        && accept.is_none()
        && std::env::var_os("FERRUM_SAT_POLY_DIRECT").is_some()
    {
        if let Some(interpretations) = direct_sat_poly::synthesize(pairs, usable, options, deadline)
        {
            return checked_component_removal_by_polynomial(
                pairs,
                usable,
                &interpretations,
                DpSearchBackend::Sat,
                false,
                None,
            )
            .map(|_| interpretations);
        }
        if std::env::var_os("FERRUM_SAT_POLY_DIRECT_ONLY").is_some() {
            return None;
        }
    }
    let safe_width = polynomial_bv_width(pairs, usable, options)?;
    let parameter_bound = options
        .max_polynomial_constant
        .max(options.max_polynomial_coefficient);
    let narrow_parameters = std::env::var_os("FERRUM_SAT_POLY_DISABLE_NARROW_PARAMETERS").is_none();
    let parameter_width = if narrow_parameters {
        unsigned_bit_width(u128::try_from(parameter_bound).ok()?).max(1)
    } else {
        safe_width
    };
    let requested_width = std::env::var("FERRUM_SAT_POLY_MAX_VALUE_WIDTH")
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .filter(|width| *width > 0);
    let width = requested_width
        .map(|width| width.max(parameter_width).min(safe_width))
        .unwrap_or(safe_width);
    let solver = options
        .smt_solver
        .as_deref()
        .or_else(|| command_exists("z3").then_some("z3"))
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let maximize_strict = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .is_some_and(|name| name == "z3")
        && std::env::var_os("FERRUM_SAT_POLY_DISABLE_MAXIMIZE_STRICT").is_none();
    let share_expressions =
        std::env::var_os("FERRUM_SAT_POLY_DISABLE_EXPRESSION_SHARING").is_none();
    let specialize_coefficients =
        std::env::var_os("FERRUM_SAT_POLY_DISABLE_FINITE_DOMAIN_PRODUCTS").is_none();
    let encode_started = Instant::now();
    let script = polynomial_bv_sat_script(
        pairs,
        usable,
        options,
        &arities,
        parameter_width,
        width,
        required_strict_rule_indices,
        fixed_coefficients,
        target_strict_pair_indices,
        min_delete,
        true,
        require_monotonicity,
        maximize_strict,
        share_expressions,
        specialize_coefficients,
        deadline,
    )?;
    write_smt_encoding_event(
        "sat-polynomial",
        encode_started,
        &script,
        pairs,
        usable,
        format!(
            "symbols={} parameter_width={} value_width={} safe_value_width={} capped={} shared={} finite_products={}",
            arities.len(),
            parameter_width,
            width,
            safe_width,
            width < safe_width,
            share_expressions,
            specialize_coefficients
        ),
    );
    let mut base = smt_script_without_final_query(script);
    let attempts = if accept.is_some() { options.max_search_space.clamp(1, 64) } else { 1 };
    for _ in 0..attempts {
        if current_thread_cancelled() || strategy_timed_out(deadline) { return None; }
        let stdout = run_smt_script(&format!("{base}(check-sat)\n(get-model)\n"), options, deadline)?;
        let interpretations = parse_bv_polynomial_model(&stdout, &arities)?;
        if require_monotonicity
            && !polynomial_coefficients_are_strictly_monotone(pairs, usable, &interpretations)
        {
            return None;
        }
        checked_component_removal_by_polynomial_with_required_strict_rules(
            pairs, usable, &interpretations, DpSearchBackend::Sat, false, None,
            required_strict_rule_indices,
        )?;
        if accept.is_none_or(|check| check(&interpretations)) {
            return Some(interpretations);
        }
        push_bv_polynomial_model_block(
            &mut base, &interpretations, model_block_arities.unwrap_or(&arities), parameter_width,
        )?;
    }
    None
}

pub(crate) fn synthesize_monotonic_usable_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    usable_restriction_is_progress: bool,
    deadline: Option<Instant>,
) -> Option<ComponentRemoval> {
    let arities = arities_for_constraints(pairs, usable);
    let encode_started = Instant::now();
    let script =
        monotonic_usable_smt_script(pairs, usable, options, usable_restriction_is_progress)?;
    write_smt_encoding_event(
        "monotonic-usable-polynomial",
        encode_started,
        &script,
        pairs,
        usable,
        format!("symbols={}", arities.len()),
    );
    if std::env::var_os("FERRUM_PROGRESS_LOG_SMT_SCRIPT").is_some() {
        write_progress_event(
            "dp-order",
            "script",
            "monotonic-usable-polynomial",
            0,
            &script.replace('\n', "\\n"),
        );
    }
    let stdout = run_smt_script(&script, options, deadline)?;
    let Some(interpretations) = parse_smt_model(&stdout, &arities) else {
        write_progress_event(
            "dp-order",
            "rejected",
            "monotonic-usable-polynomial",
            0,
            &format!("reason=model-parse solver_output={}", stdout.trim()),
        );
        return None;
    };
    let well_formed = !interpretations.values().any(|interpretation| {
        interpretation.constant < 0
            || interpretation
                .coefficients
                .iter()
                .any(|coefficient| *coefficient < 1)
    });
    let usable_weak = usable
        .iter()
        .all(|rule| weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations));
    let pairs_weak = pairs
        .iter()
        .all(|pair| weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations));
    if !well_formed || !usable_weak || !pairs_weak {
        write_progress_event(
            "dp-order",
            "rejected",
            "monotonic-usable-polynomial",
            0,
            &format!(
                "reason=model-check well_formed={} usable_weak={} pairs_weak={} interpretation={interpretations:?}",
                well_formed, usable_weak, pairs_weak
            ),
        );
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            strictly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                .then_some(index)
        })
        .collect::<Vec<_>>();
    let strict_rule_indices = usable
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| {
            strictly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                .then_some(index)
        })
        .collect::<Vec<_>>();
    if !usable_restriction_is_progress
        && strict_pair_indices.is_empty()
        && strict_rule_indices.is_empty()
    {
        return None;
    }
    write_progress_event(
        "dp-order",
        "selected",
        "monotonic-usable-polynomial",
        0,
        &format!(
            "pairs={} usable_rules={} strict_pairs={} strict_rules={} interpretation={interpretations:?}",
            pairs.len(),
            usable.len(),
            strict_pair_indices.len(),
            strict_rule_indices.len()
        ),
    );
    Some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::Polynomial {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| {
                    (
                        name.clone(),
                        interpretation.constant,
                        interpretation.coefficients.clone(),
                    )
                })
                .collect(),
            backend: DpSearchBackend::Sat,
        },
        smt_attempted: false,
        usable_rules: Some(usable.to_vec()),
    })
}

/// Validate a Q-monotonic innermost DP rule-removal witness.  The verified
/// CPF `innermostMonoRedPairProc` checker independently computes the exact
/// usable replacement map.  Here we validate the complete weak/strict order
/// obligations and retain every strictly oriented rule; the processor layer
/// marks this proof shape for that checker instead of pretending that the
/// interpretation is monotone in every argument.
pub(crate) fn checked_q_monotonic_polynomial_rule_removal(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
) -> Option<ComponentRemoval> {
    let mut complete = interpretations.clone();
    for (symbol, arity) in arities_for_constraints(pairs, rules) {
        complete.entry(symbol).or_insert_with(|| LinearPolynomial {
            constant: 0,
            coefficients: vec![1; arity],
        });
    }
    if complete.values().any(|interpretation| {
        interpretation.constant < 0
            || interpretation
                .coefficients
                .iter()
                .any(|coefficient| *coefficient < 0)
    }) || !pairs
        .iter()
        .all(|pair| weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &complete))
        || !rules
            .iter()
            .all(|rule| weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &complete))
    {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            strictly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &complete).then_some(index)
        })
        .collect::<Vec<_>>();
    let strict_rule_indices = rules
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| {
            strictly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &complete).then_some(index)
        })
        .collect::<Vec<_>>();
    if strict_pair_indices.is_empty() && strict_rule_indices.is_empty() {
        return None;
    }
    Some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::Polynomial {
            interpretation: complete
                .into_iter()
                .map(|(name, interpretation)| {
                    (name, interpretation.constant, interpretation.coefficients)
                })
                .collect(),
            backend: DpSearchBackend::Sat,
        },
        smt_attempted: false,
        usable_rules: Some(rules.to_vec()),
    })
}

/// Validate the order part of an innermost Q-monotonic matrix rule-removal
/// witness.  The production CPF checker additionally recomputes the usable
/// replacement map and checks monotonicity at precisely those positions; no
/// result from this path is eligible for oracle promotion before that check.
/// Keeping the order validation here is nevertheless important: retained or
/// synthesized models may not smuggle in a weak-orientation failure.
pub(crate) fn checked_q_monotonic_matrix_rule_removal(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    backend: DpSearchBackend,
) -> Option<ComponentRemoval> {
    let dimension = matrix_interpretation_dimension(interpretations)?;
    let strict_dimension = 1;
    let well_formed = matrix_interpretations_are_well_formed(interpretations, dimension);
    let pair_weak = pairs
        .iter()
        .map(|pair| weakly_decreases_by_matrix(pair.lhs(), pair.rhs(), interpretations, dimension))
        .collect::<Vec<_>>();
    let rule_weak = rules
        .iter()
        .map(|rule| weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), interpretations, dimension))
        .collect::<Vec<_>>();
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "Q-monotonic matrix order check dimension={dimension} well_formed={well_formed} pair_weak={pair_weak:?} rule_weak={rule_weak:?} interpretations={interpretations:?}"
        );
    }
    if !well_formed || pair_weak.contains(&false) || rule_weak.contains(&false) {
        return None;
    }
    let strict_pair_indices = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            strictly_decreases_by_matrix(
                pair.lhs(),
                pair.rhs(),
                interpretations,
                dimension,
                strict_dimension,
            )
            .then_some(index)
        })
        .collect::<Vec<_>>();
    let strict_rule_indices = rules
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| {
            strictly_decreases_by_matrix(
                rule.lhs(),
                rule.rhs(),
                interpretations,
                dimension,
                strict_dimension,
            )
            .then_some(index)
        })
        .collect::<Vec<_>>();
    if strict_pair_indices.is_empty() && strict_rule_indices.is_empty() {
        return None;
    }
    Some(ComponentRemoval {
        strict_pair_indices,
        strict_rule_indices,
        reduction_pair: DpReductionPairProof::Matrix {
            interpretation: interpretations
                .iter()
                .map(|(name, interpretation)| (name.clone(), interpretation.clone()))
                .collect(),
            dimension,
            strict_dimension,
            backend,
        },
        smt_attempted: true,
        usable_rules: Some(rules.to_vec()),
    })
}

pub(crate) fn polynomial_bv_sat_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    parameter_width: usize,
    width: usize,
    required_strict_rule_indices: &[usize],
    fixed_coefficients: &[(&str, usize, i64)],
    target_strict_pair_indices: Option<&[usize]>,
    min_delete: Option<usize>,
    require_strict_pair: bool,
    require_monotonicity: bool,
    maximize_strict: bool,
    share_expressions: bool,
    specialize_coefficients: bool,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_BV)\n");
    if let Some(threads) = std::env::var("FERRUM_SAT_POLY_THREADS")
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .filter(|threads| *threads > 1)
    {
        script.push_str("(set-option :parallel.enable true)\n");
        script.push_str(&format!(
            "(set-option :parallel.threads.max {})\n",
            threads.min(32)
        ));
    }
    if maximize_strict {
        script.push_str("(set-option :opt.priority lex)\n");
    }
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        push_bv_parameter_declaration(
            &mut script,
            &smt_c(symbol),
            0,
            options.max_polynomial_constant,
            parameter_width,
        )?;
        for index in 0..*arity {
            push_bv_parameter_declaration(
                &mut script,
                &smt_a(symbol, index),
                0,
                options.max_polynomial_coefficient,
                parameter_width,
            )?;
            if require_monotonicity {
                script.push_str(&format!(
                    "(assert (bvuge {} {}))\n",
                    smt_a(symbol, index),
                    bv_literal(1, parameter_width)
                ));
            }
        }
    }
    // The certified relative-ADP instance interprets the compound algebra as
    // Com0 = 0 and Com2(x,y) = x + y.  Its argument coefficients are fixed
    // below together with all other caller-supplied coefficients.
    if require_monotonicity {
        for symbol in ["__ferrum_adp_c0", "__ferrum_adp_c2"] {
            if arities.contains_key(symbol) {
                script.push_str(&format!(
                    "(assert (= {} {}))\n",
                    smt_c(symbol),
                    bv_literal(0, parameter_width)
                ));
            }
        }
    }
    for (symbol, index, value) in fixed_coefficients {
        if *value < 0
            || *value > options.max_polynomial_coefficient
            || arities.get(*symbol).is_none_or(|arity| *index >= *arity)
        {
            return None;
        }
        script.push_str(&format!(
            "(assert (= {} {}))\n",
            smt_a(symbol, *index),
            bv_literal(*value as u128, parameter_width)
        ));
    }
    let max_coefficient = u128::try_from(options.max_polynomial_coefficient).ok()?;
    let mut encoder = PolynomialBvEncoder::new(
        script,
        width,
        parameter_width,
        max_coefficient,
        share_expressions,
        specialize_coefficients,
    );
    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    let mut required_strict_rule_terms = Vec::new();
    for (index, rule) in usable.iter().enumerate() {
        check_smt_build(encoder.script(), deadline)?;
        let (lhs, rhs) = encoder.push_weak(rule.lhs(), rule.rhs());
        if required_strict_rule_indices.contains(&index) {
            required_strict_rule_terms.push(format!("(bvugt {} {})", lhs.constant, rhs.constant));
        }
    }
    let mut strict_terms = Vec::new();
    for pair in pairs {
        check_smt_build(encoder.script(), deadline)?;
        let (lhs, rhs) = encoder.push_weak(pair.lhs(), pair.rhs());
        strict_terms.push(format!("(bvugt {} {})", lhs.constant, rhs.constant));
    }
    let mut script = encoder.into_script();
    for strict in required_strict_rule_terms {
        script.push_str(&format!("(assert {strict})\n"));
    }
    if min_delete.is_some_and(|minimum| minimum == 0 || minimum > strict_terms.len()) {
        return None;
    }
    if let Some(target_indices) = target_strict_pair_indices {
        let target_indices = target_indices.iter().copied().collect::<BTreeSet<_>>();
        if target_indices.is_empty()
            || target_indices
                .iter()
                .any(|index| *index >= strict_terms.len())
        {
            return None;
        }
        for (index, strict) in strict_terms.iter().enumerate() {
            if target_indices.contains(&index) {
                script.push_str(&format!("(assert {strict})\n"));
            } else {
                script.push_str(&format!("(assert (not {strict}))\n"));
            }
        }
    } else if let Some(minimum) = min_delete {
        let count_width = unsigned_bit_width(strict_terms.len() as u128).max(1);
        let count_terms = strict_terms
            .iter()
            .map(|strict| {
                format!(
                    "(ite {strict} {} {})",
                    bv_literal(1, count_width),
                    bv_literal(0, count_width)
                )
            })
            .collect::<Vec<_>>();
        let count = balanced_bv_sum(count_terms, count_width);
        script.push_str(&format!(
            "(assert (bvuge {count} {}))\n",
            bv_literal(minimum as u128, count_width)
        ));
    } else if require_strict_pair {
        if strict_terms.is_empty() {
            return None;
        }
        script.push_str("(assert (or");
        for term in &strict_terms {
            script.push(' ');
            script.push_str(term);
        }
        script.push_str("))\n");
        if maximize_strict && strict_terms.len() > 1 {
            let count_width = unsigned_bit_width(strict_terms.len() as u128).max(1);
            let count_terms = strict_terms
                .iter()
                .map(|strict| {
                    format!(
                        "(ite {strict} {} {})",
                        bv_literal(1, count_width),
                        bv_literal(0, count_width)
                    )
                })
                .collect::<Vec<_>>();
            let count = balanced_bv_sum(count_terms, count_width);
            script.push_str(&format!("(maximize {count})\n"));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) struct PolynomialBvEncoder {
    script: String,
    width: usize,
    parameter_width: usize,
    next_expression: usize,
    expressions: BTreeMap<String, String>,
    terms: BTreeMap<Term, SmtForm>,
    max_coefficient: u128,
    share_expressions: bool,
    specialize_coefficients: bool,
}

impl PolynomialBvEncoder {
    pub(crate) fn new(
        script: String,
        width: usize,
        parameter_width: usize,
        max_coefficient: u128,
        share_expressions: bool,
        specialize_coefficients: bool,
    ) -> Self {
        Self {
            script,
            width,
            parameter_width,
            next_expression: 0,
            expressions: BTreeMap::new(),
            terms: BTreeMap::new(),
            max_coefficient,
            share_expressions,
            specialize_coefficients,
        }
    }

    pub(crate) fn script(&self) -> &str {
        &self.script
    }

    pub(crate) fn into_script(self) -> String {
        self.script
    }

    pub(crate) fn push_weak(&mut self, lhs: &Term, rhs: &Term) -> (SmtForm, SmtForm) {
        let lhs = self.interpret(lhs);
        let rhs = self.interpret(rhs);
        self.script.push_str(&format!(
            "(assert {})\n",
            polynomial_bv_weak_formula(&lhs, &rhs, self.width)
        ));
        (lhs, rhs)
    }

    pub(crate) fn interpret(&mut self, term: &Term) -> SmtForm {
        if !self.share_expressions {
            return if self.parameter_width == self.width {
                polynomial_bv_interpret(term, self.width)
            } else {
                polynomial_bv_interpret_with_parameter_width(term, self.parameter_width, self.width)
            };
        }
        if let Some(form) = self.terms.get(term) {
            return form.clone();
        }
        let form = match term {
            Term::Var(variable) => SmtForm {
                constant: bv_literal(0, self.width),
                coefficients: BTreeMap::from([(
                    variable.as_str().to_string(),
                    bv_literal(1, self.width),
                )]),
            },
            Term::App { symbol, args } => {
                let mut constant = matrix_bv_parameter_value(
                    &smt_c(symbol.as_str()),
                    self.parameter_width,
                    self.width,
                );
                let mut coefficients = BTreeMap::<String, String>::new();
                for (index, arg) in args.iter().enumerate() {
                    let arg_form = self.interpret(arg);
                    let coefficient = smt_a(symbol.as_str(), index);
                    let scaled_constant = self.scale(&coefficient, &arg_form.constant);
                    constant = self.add(&constant, &scaled_constant);
                    for (variable, value) in arg_form.coefficients {
                        let scaled = self.scale(&coefficient, &value);
                        if let Some(old) = coefficients.get(&variable).cloned() {
                            coefficients.insert(variable, self.add(&old, &scaled));
                        } else {
                            coefficients.insert(variable, scaled);
                        }
                    }
                }
                SmtForm {
                    constant,
                    coefficients,
                }
            }
        };
        self.terms.insert(term.clone(), form.clone());
        form
    }

    pub(crate) fn add(&mut self, left: &str, right: &str) -> String {
        let zero = bv_literal(0, self.width);
        if left == zero {
            return right.to_string();
        }
        if right == zero {
            return left.to_string();
        }
        let (left, right) = canonical_commutative_operands(left, right);
        self.bind(bv_add(left, right))
    }

    pub(crate) fn mul(&mut self, left: &str, right: &str) -> String {
        let zero = bv_literal(0, self.width);
        if left == zero || right == zero {
            return zero;
        }
        let one = bv_literal(1, self.width);
        if left == one {
            return right.to_string();
        }
        if right == one {
            return left.to_string();
        }
        let (left, right) = canonical_commutative_operands(left, right);
        self.bind(bv_mul(left, right))
    }

    pub(crate) fn scale(&mut self, coefficient: &str, value: &str) -> String {
        if !self.specialize_coefficients || self.max_coefficient > 8 {
            let coefficient =
                matrix_bv_parameter_value(coefficient, self.parameter_width, self.width);
            return self.mul(&coefficient, value);
        }
        let zero = bv_literal(0, self.width);
        if value == zero || self.max_coefficient == 0 {
            return zero;
        }
        let mut expression = zero;
        for candidate in 1..=self.max_coefficient {
            let product = if candidate == 1 {
                value.to_string()
            } else if candidate.is_power_of_two() {
                format!(
                    "(bvshl {value} {})",
                    bv_literal(candidate.trailing_zeros() as u128, self.width)
                )
            } else {
                bv_mul(value, &bv_literal(candidate, self.width))
            };
            expression = format!(
                "(ite (= {coefficient} {}) {product} {expression})",
                bv_literal(candidate, self.parameter_width)
            );
        }
        self.bind(expression)
    }

    pub(crate) fn bind(&mut self, expression: String) -> String {
        if let Some(name) = self.expressions.get(&expression) {
            return name.clone();
        }
        let name = format!("p_e_{}", self.next_expression);
        self.next_expression += 1;
        self.script.push_str(&format!(
            "(define-fun {name} () (_ BitVec {}) {expression})\n",
            self.width
        ));
        self.expressions.insert(expression, name.clone());
        name
    }
}

pub(crate) fn canonical_commutative_operands<'a>(
    left: &'a str,
    right: &'a str,
) -> (&'a str, &'a str) {
    if left <= right {
        (left, right)
    } else {
        (right, left)
    }
}

pub(crate) fn balanced_bv_sum(mut terms: Vec<String>, width: usize) -> String {
    if terms.is_empty() {
        return bv_literal(0, width);
    }
    while terms.len() > 1 {
        terms = terms
            .chunks(2)
            .map(|chunk| match chunk {
                [single] => single.clone(),
                [left, right] => bv_add(left, right),
                _ => unreachable!("chunks of two contain at most two terms"),
            })
            .collect();
    }
    terms.pop().expect("nonempty balanced sum")
}

pub(crate) fn push_bv_parameter_declaration(
    script: &mut String,
    name: &str,
    min_value: i64,
    max_value: i64,
    width: usize,
) -> Option<()> {
    (0 <= min_value && min_value <= max_value).then_some(())?;
    script.push_str(&format!("(declare-fun {name} () (_ BitVec {width}))\n"));
    script.push_str(&format!(
        "(assert (bvuge {name} {}))\n",
        bv_literal(min_value as u128, width)
    ));
    script.push_str(&format!(
        "(assert (bvule {name} {}))\n",
        bv_literal(max_value as u128, width)
    ));
    Some(())
}

pub(crate) fn push_polynomial_bv_weak(script: &mut String, lhs: &Term, rhs: &Term, width: usize) {
    let lhs = polynomial_bv_interpret(lhs, width);
    let rhs = polynomial_bv_interpret(rhs, width);
    script.push_str(&format!(
        "(assert {})\n",
        polynomial_bv_weak_formula(&lhs, &rhs, width)
    ));
}

pub(crate) fn polynomial_bv_strict(lhs: &Term, rhs: &Term, width: usize) -> String {
    let lhs = polynomial_bv_interpret(lhs, width);
    let rhs = polynomial_bv_interpret(rhs, width);
    format!(
        "(and {} (bvugt {} {}))",
        polynomial_bv_weak_formula(&lhs, &rhs, width),
        lhs.constant,
        rhs.constant
    )
}

pub(crate) fn polynomial_bv_weak_formula(lhs: &SmtForm, rhs: &SmtForm, width: usize) -> String {
    let mut parts = vec![format!("(bvuge {} {})", lhs.constant, rhs.constant)];
    for variable in lhs.coefficients.keys().chain(rhs.coefficients.keys()) {
        let left = lhs
            .coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| bv_literal(0, width));
        let right = rhs
            .coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| bv_literal(0, width));
        parts.push(format!("(bvuge {left} {right})"));
    }
    smt_and(parts)
}

pub(crate) fn polynomial_bv_interpret(term: &Term, width: usize) -> SmtForm {
    match term {
        Term::Var(variable) => SmtForm {
            constant: bv_literal(0, width),
            coefficients: BTreeMap::from([(variable.as_str().to_string(), bv_literal(1, width))]),
        },
        Term::App { symbol, args } => {
            let mut constant = smt_c(symbol.as_str());
            let mut coefficients = BTreeMap::<String, String>::new();
            for (index, arg) in args.iter().enumerate() {
                let arg_form = polynomial_bv_interpret(arg, width);
                let coefficient = smt_a(symbol.as_str(), index);
                constant = bv_add(&constant, &bv_mul(&coefficient, &arg_form.constant));
                for (variable, value) in arg_form.coefficients {
                    let scaled = bv_mul(&coefficient, &value);
                    coefficients
                        .entry(variable)
                        .and_modify(|old| *old = bv_add(old, &scaled))
                        .or_insert(scaled);
                }
            }
            SmtForm {
                constant,
                coefficients,
            }
        }
    }
}

pub(crate) fn synthesize_weak_polynomial_with_smt_only(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    min_constant: i64,
    fixed_usable_rules: bool,
    target_strict_pair_indices: Option<&[usize]>,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    let encode_started = Instant::now();
    let script = weak_polynomial_smt_script(
        pairs,
        usable,
        options,
        min_constant,
        fixed_usable_rules,
        target_strict_pair_indices,
    )?;
    write_smt_encoding_event(
        "weak-polynomial",
        encode_started,
        &script,
        pairs,
        usable,
        format!("min_constant={min_constant}"),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    let interpretations = parse_smt_model(&stdout, &arities_for_constraints(pairs, usable));
    write_progress_event(
        "dp-order",
        if interpretations.is_some() {
            "model"
        } else {
            "no-model"
        },
        "weak-polynomial",
        0,
        &format!(
            "solver_status={} model_decoded={}",
            stdout.lines().next().unwrap_or_default().trim(),
            interpretations.is_some()
        ),
    );
    interpretations
}

pub(crate) fn synthesize_polynomial_with_usable_rules_requiring_strict(
    pairs: &[DependencyPair],
    strict_pairs: &[DependencyPair],
    target_strict_pair_indices: Option<&[usize]>,
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    // Solver identifiers are local to a query. Nested semantic labels can be
    // megabytes long, and hexadecimal SMT names repeat that payload at every
    // occurrence. Use an injective, reversible bijection, never a lossy hash.
    // Only the query is renamed; the returned model uses the original symbols
    // and is independently checked against the unchanged live DP state.
    let arities = arities_for_constraints(pairs, usable);
    if arities.keys().any(|symbol| symbol.len() > 128) {
        let bijection = arities.keys().enumerate().map(|(index, symbol)|
            (Symbol::new(symbol), Symbol::new(format!("q{index}"))))
            .collect::<BTreeMap<_, _>>();
        let rename_pair = |pair: &DependencyPair| DependencyPair::from_rule(
            crate::standardize::translate_rule_symbols(
                &RewriteRule::new(pair.lhs().clone(), pair.rhs().clone()), &bijection),
            pair.source_rule());
        let compact_pairs = pairs.iter().map(rename_pair).collect::<Vec<_>>();
        let compact_strict = strict_pairs.iter().map(rename_pair).collect::<Vec<_>>();
        let compact_rules = usable.iter().map(|rule|
            crate::standardize::translate_rule_symbols(rule, &bijection)).collect::<Vec<_>>();
        write_progress_event("dp-order", "compact-symbols", "polynomial-usable-rules", 0,
            &format!("symbols={} original_name_bytes={} compact_name_bytes={}",
                arities.len(), arities.keys().map(String::len).sum::<usize>(),
                bijection.values().map(|s| s.as_str().len()).sum::<usize>()));
        let model = synthesize_polynomial_with_usable_rules_requiring_strict(
            &compact_pairs, &compact_strict, target_strict_pair_indices,
            &compact_rules, options, deadline)?;
        return bijection.into_iter().map(|(original, compact)|
            model.get(compact.as_str()).cloned().map(|value|
                (original.as_str().to_owned(), value))).collect();
    }
    let encode_started = Instant::now();
    let width = polynomial_bv_width(pairs, usable, options)?;
    let parameter_bound = options
        .max_polynomial_constant
        .max(options.max_polynomial_coefficient);
    let parameter_width = bit_width_for_bound(u128::try_from(parameter_bound).ok()?).max(1);
    let script = polynomial_usable_rules_bv_script(
        pairs,
        strict_pairs,
        target_strict_pair_indices,
        usable,
        options,
        &arities,
        parameter_width,
        width,
        deadline,
    )?;
    write_progress_event(
        "dp-order",
        "encoded",
        "polynomial-usable-rules",
        encode_started.elapsed().as_millis(),
        &format!(
            "pairs={} usable_rules={} parameter_width={} value_width={} script_bytes={}",
            pairs.len(),
            usable.len(),
            parameter_width,
            width,
            script.len()
        ),
    );
    if std::env::var_os("FERRUM_PROGRESS_LOG_SMT_SCRIPT").is_some() {
        write_progress_event(
            "dp-order",
            "script",
            "polynomial-usable-rules",
            0,
            &script.replace('\n', "\\n"),
        );
    }
    let solver = options
        .smt_solver
        .as_deref()
        .or_else(|| command_exists("z3").then_some("z3"))
        .filter(|solver| solver.rsplit('/').next().is_some_and(|name| name == "z3"))?;
    let solve_started = Instant::now();
    let stdout = run_smt_script_with_solver(&script, solver, deadline);
    write_progress_event("dp-order", "solver-finished", "polynomial-usable-rules",
        solve_started.elapsed().as_millis(),
        &format!("status={}", stdout.as_deref().and_then(|s| s.lines().next())
            .unwrap_or("no-output: timeout/cancel/process-failure")));
    let stdout = stdout?;
    let interpretations = parse_bv_polynomial_model(&stdout, &arities);
    write_progress_event(
        "dp-order",
        if interpretations.is_some() {
            "model"
        } else {
            "no-model"
        },
        "polynomial-usable-rules",
        0,
        &format!(
            "solver_status={}",
            stdout.lines().next().unwrap_or_default().trim()
        ),
    );
    interpretations
}

pub(crate) fn polynomial_usable_rules_bv_script(
    pairs: &[DependencyPair],
    strict_pair_candidates: &[DependencyPair],
    target_strict_pair_indices: Option<&[usize]>,
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    parameter_width: usize,
    width: usize,
    deadline: Option<Instant>,
) -> Option<String> {
    if pairs.is_empty()
        || strict_pair_candidates.is_empty()
        || arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 0
    {
        return None;
    }

    let mut script = String::from("(set-logic QF_BV)\n(set-option :opt.priority lex)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        push_bv_parameter_declaration(
            &mut script,
            &smt_c(symbol),
            0,
            options.max_polynomial_constant,
            parameter_width,
        )?;
        for index in 0..*arity {
            push_bv_parameter_declaration(
                &mut script,
                &smt_a(symbol, index),
                0,
                options.max_polynomial_coefficient,
                parameter_width,
            )?;
        }
    }

    let defined_symbols = usable
        .iter()
        .filter_map(|rule| rule.lhs().root_symbol().cloned())
        .collect::<BTreeSet<_>>();
    for symbol in &defined_symbols {
        check_smt_build(&script, deadline)?;
        script.push_str(&format!(
            "(declare-const {} Bool)\n",
            weak_polynomial_usable_name(symbol.as_str())
        ));
    }
    let mut encoder = PolynomialBvEncoder::new(
        script, width, parameter_width,
        u128::try_from(options.max_polynomial_coefficient).ok()?, true, false);
    for pair in pairs {
        check_smt_build(encoder.script(), deadline)?;
        let mut occurrences = Vec::new();
        polynomial_bv_active_defined_occurrences(
            pair.rhs(),
            "true",
            &defined_symbols,
            parameter_width,
            &mut occurrences,
        );
        for (condition, symbol) in occurrences {
            encoder.script.push_str(&format!(
                "(assert (=> {condition} {}))\n",
                weak_polynomial_usable_name(symbol.as_str())
            ));
        }
        let lhs = encoder.interpret(pair.lhs());
        let rhs = encoder.interpret(pair.rhs());
        encoder.script.push_str(&format!(
            "(assert {})\n",
            polynomial_bv_weak_formula(&lhs, &rhs, width)
        ));
    }
    for rule in usable {
        check_smt_build(encoder.script(), deadline)?;
        let root = rule.lhs().root_symbol()?;
        let usable_root = weak_polynomial_usable_name(root.as_str());
        let lhs = encoder.interpret(rule.lhs());
        let rhs = encoder.interpret(rule.rhs());
        encoder.script.push_str(&format!(
            "(assert (=> {usable_root} {}))\n",
            polynomial_bv_weak_formula(&lhs, &rhs, width)
        ));
        let mut occurrences = Vec::new();
        polynomial_bv_active_defined_occurrences(
            rule.rhs(),
            "true",
            &defined_symbols,
            parameter_width,
            &mut occurrences,
        );
        for (condition, symbol) in occurrences {
            encoder.script.push_str(&format!(
                "(assert (=> (and {usable_root} {condition}) {}))\n",
                weak_polynomial_usable_name(symbol.as_str())
            ));
        }
    }

    let strict_pairs: Vec<String> = target_strict_pair_indices
        .map_or(strict_pair_candidates, |_| pairs)
        .iter()
        .map(|pair| {
            let lhs = encoder.interpret(pair.lhs());
            let rhs = encoder.interpret(pair.rhs());
            format!(
                "(and {} (bvugt {} {}))",
                polynomial_bv_weak_formula(&lhs, &rhs, width),
                lhs.constant,
                rhs.constant
            )
        })
        .collect();
    let mut script = encoder.into_script();
    if let Some(target_indices) = target_strict_pair_indices {
        let target_indices = target_indices.iter().copied().collect::<BTreeSet<_>>();
        if target_indices.is_empty()
            || target_indices
                .iter()
                .any(|index| *index >= strict_pairs.len())
        {
            return None;
        }
        for (index, strict) in strict_pairs.iter().enumerate() {
            if target_indices.contains(&index) {
                script.push_str(&format!("(assert {strict})\n"));
            } else {
                script.push_str(&format!("(assert (not {strict}))\n"));
            }
        }
    } else {
        script.push_str(&format!("(assert {})\n", smt_or(strict_pairs.clone())));
    }
    if target_strict_pair_indices.is_none() && strict_pairs.len() > 1 {
        let count_width = bit_width_for_bound(strict_pairs.len() as u128).max(1);
        let count = strict_pairs
            .iter()
            .map(|strict| {
                format!(
                    "(ite {strict} {} {})",
                    bv_literal(1, count_width),
                    bv_literal(0, count_width)
                )
            })
            .reduce(|left, right| format!("(bvadd {left} {right})"))
            .expect("nonempty strict-pair objective");
        script.push_str(&format!("(maximize {count})\n"));
    }
    if !defined_symbols.is_empty() {
        let count_width = bit_width_for_bound(defined_symbols.len() as u128).max(1);
        let count = defined_symbols
            .iter()
            .map(|symbol| {
                format!(
                    "(ite {} {} {})",
                    weak_polynomial_usable_name(symbol.as_str()),
                    bv_literal(1, count_width),
                    bv_literal(0, count_width)
                )
            })
            .reduce(|left, right| format!("(bvadd {left} {right})"))
            .expect("nonempty usable-symbol objective");
        script.push_str(&format!("(minimize {count})\n"));
    }
    let constant_bound = u128::try_from(options.max_polynomial_constant).ok()?;
    let coefficient_bound = u128::try_from(options.max_polynomial_coefficient).ok()?;
    let parameter_sum_bound = constant_bound
        .checked_mul(arities.len() as u128)?
        .checked_add(
            coefficient_bound.checked_mul(arities.values().copied().sum::<usize>() as u128)?,
        )?;
    let objective_width = bit_width_for_bound(parameter_sum_bound).max(parameter_width);
    let extend_parameter = |name: String| {
        if objective_width == parameter_width {
            name
        } else {
            format!(
                "((_ zero_extend {}) {name})",
                objective_width - parameter_width
            )
        }
    };
    let parameter_sum = arities
        .iter()
        .flat_map(|(symbol, arity)| {
            std::iter::once(extend_parameter(smt_c(symbol)))
                .chain((0..*arity).map(|index| extend_parameter(smt_a(symbol, index))))
        })
        .reduce(|left, right| format!("(bvadd {left} {right})"))
        .expect("nonempty polynomial-parameter objective");
    script.push_str(&format!("(minimize {parameter_sum})\n"));
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn polynomial_bv_active_defined_occurrences(
    term: &Term,
    active: &str,
    defined_symbols: &BTreeSet<Symbol>,
    parameter_width: usize,
    occurrences: &mut Vec<(String, Symbol)>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if defined_symbols.contains(symbol) {
        occurrences.push((active.to_string(), symbol.clone()));
    }
    for (index, argument) in args.iter().enumerate() {
        let child_active = format!(
            "(and {active} (bvugt {} {}))",
            smt_a(symbol.as_str(), index),
            bv_literal(0, parameter_width)
        );
        polynomial_bv_active_defined_occurrences(
            argument,
            &child_active,
            defined_symbols,
            parameter_width,
            occurrences,
        );
    }
}

pub(crate) fn polynomial_bv_interpret_with_parameter_width(
    term: &Term,
    parameter_width: usize,
    width: usize,
) -> SmtForm {
    match term {
        Term::Var(variable) => SmtForm {
            constant: bv_literal(0, width),
            coefficients: BTreeMap::from([(variable.as_str().to_string(), bv_literal(1, width))]),
        },
        Term::App { symbol, args } => {
            let mut constant =
                matrix_bv_parameter_value(&smt_c(symbol.as_str()), parameter_width, width);
            let mut coefficients = BTreeMap::<String, String>::new();
            for (index, arg) in args.iter().enumerate() {
                let arg_form =
                    polynomial_bv_interpret_with_parameter_width(arg, parameter_width, width);
                let coefficient = matrix_bv_parameter_value(
                    &smt_a(symbol.as_str(), index),
                    parameter_width,
                    width,
                );
                constant = bv_add(&constant, &bv_mul(&coefficient, &arg_form.constant));
                for (variable, value) in arg_form.coefficients {
                    let scaled = bv_mul(&coefficient, &value);
                    coefficients
                        .entry(variable)
                        .and_modify(|old| *old = bv_add(old, &scaled))
                        .or_insert(scaled);
                }
            }
            SmtForm {
                constant,
                coefficients,
            }
        }
    }
}

pub(crate) fn weak_polynomial_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    min_constant: i64,
    fixed_usable_rules: bool,
    target_strict_pair_indices: Option<&[usize]>,
) -> Option<String> {
    weak_polynomial_smt_script_mode(
        pairs, usable, options, min_constant, fixed_usable_rules,
        target_strict_pair_indices, false,
    )
}

pub(crate) fn weak_polynomial_smt_script_mode(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    min_constant: i64,
    fixed_usable_rules: bool,
    target_strict_pair_indices: Option<&[usize]>,
    normalize_zero_coefficients: bool,
) -> Option<String> {
    let arities = arities_for_constraints(pairs, usable);
    if arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
        || min_constant > options.max_polynomial_constant
        || options.max_polynomial_coefficient < 0
    {
        return None;
    }
    let mut script = String::new();
    script.push_str("(set-logic ALL)\n");
    for (symbol, arity) in &arities {
        script.push_str(&format!("(declare-const {} Int)\n", smt_c(symbol)));
        script.push_str(&format!(
            "(assert (and (>= {} {}) (<= {} {})))\n",
            smt_c(symbol),
            min_constant,
            smt_c(symbol),
            options.max_polynomial_constant
        ));
        for index in 0..*arity {
            script.push_str(&format!("(declare-const {} Int)\n", smt_a(symbol, index)));
            script.push_str(&format!(
                "(assert (and (>= {} 0) (<= {} {})))\n",
                smt_a(symbol, index),
                smt_a(symbol, index),
                options.max_polynomial_coefficient
            ));
        }
    }
    let defined_symbols = usable
        .iter()
        .filter_map(|rule| rule.lhs().root_symbol().cloned())
        .collect::<BTreeSet<_>>();
    if !fixed_usable_rules {
        for symbol in &defined_symbols {
            script.push_str(&format!(
                "(declare-const {} Bool)\n",
                weak_polynomial_usable_name(symbol.as_str())
            ));
        }
    }
    if !fixed_usable_rules {
        for pair in pairs {
            let mut occurrences = Vec::new();
            weak_polynomial_active_defined_occurrences(
                pair.rhs(),
                "true",
                &defined_symbols,
                &mut occurrences,
            );
            for (condition, symbol) in occurrences {
                script.push_str(&format!(
                    "(assert (=> {condition} {}))\n",
                    weak_polynomial_usable_name(symbol.as_str())
                ));
            }
        }
    }
    for rule in usable {
        let Some(root) = rule.lhs().root_symbol() else {
            return None;
        };
        let usable_root = weak_polynomial_usable_name(root.as_str());
        let orientation = weak_polynomial_universal_orientation_mode(rule.lhs(), rule.rhs(), false, normalize_zero_coefficients);
        if fixed_usable_rules {
            script.push_str(&format!("(assert {orientation})\n"));
        } else {
            script.push_str(&format!("(assert (=> {usable_root} {orientation}))\n"));
            let mut occurrences = Vec::new();
            weak_polynomial_active_defined_occurrences(
                rule.rhs(),
                "true",
                &defined_symbols,
                &mut occurrences,
            );
            for (condition, symbol) in occurrences {
                script.push_str(&format!(
                    "(assert (=> (and {usable_root} {condition}) {}))\n",
                    weak_polynomial_usable_name(symbol.as_str())
                ));
            }
        }
    }
    if target_strict_pair_indices
        .is_some_and(|target| target.is_empty() || target.iter().any(|index| *index >= pairs.len()))
    {
        return None;
    }
    let target_strict_pair_indices =
        target_strict_pair_indices.map(|target| target.iter().copied().collect::<BTreeSet<_>>());
    for (index, pair) in pairs.iter().enumerate() {
        script.push_str(&format!(
            "(assert {})\n",
            weak_polynomial_universal_orientation_mode(pair.lhs(), pair.rhs(), false, normalize_zero_coefficients)
        ));
        if let Some(target) = &target_strict_pair_indices {
            let strict = weak_polynomial_universal_orientation_mode(pair.lhs(), pair.rhs(), true, normalize_zero_coefficients);
            if target.contains(&index) {
                script.push_str(&format!("(assert {strict})\n"));
            } else {
                script.push_str(&format!("(assert (not {strict}))\n"));
            }
        }
    }
    if target_strict_pair_indices.is_none() {
        script.push_str("(assert (or");
        for pair in pairs {
            script.push(' ');
            script.push_str(&weak_polynomial_universal_orientation_mode(
                pair.lhs(),
                pair.rhs(),
                true,
                normalize_zero_coefficients,
            ));
        }
        script.push_str("))\n");
    }
    script.push_str("(check-sat)\n(get-model)\n");
    Some(script)
}

#[derive(Clone, Debug)]
pub(crate) struct WeakPolynomialSmtForm {
    constant: String,
    coefficients: BTreeMap<Variable, String>,
}

pub(crate) fn weak_polynomial_universal_orientation(
    lhs: &Term,
    rhs: &Term,
    strict: bool,
) -> String {
    weak_polynomial_universal_orientation_mode(lhs, rhs, strict, false)
}

fn weak_polynomial_universal_orientation_mode(
    lhs: &Term,
    rhs: &Term,
    strict: bool,
    normalize_zero_coefficients: bool,
) -> String {
    let lhs = weak_polynomial_ceta_smt_form_mode(lhs, false, normalize_zero_coefficients);
    let rhs = weak_polynomial_ceta_smt_form_mode(rhs, true, normalize_zero_coefficients);
    let mut comparisons = vec![format!("(>= {} {})", lhs.constant, rhs.constant)];
    for variable in lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .collect::<BTreeSet<_>>()
    {
        comparisons.push(format!(
            "(>= {} {})",
            lhs.coefficients
                .get(variable)
                .map(String::as_str)
                .unwrap_or("0"),
            rhs.coefficients
                .get(variable)
                .map(String::as_str)
                .unwrap_or("0")
        ));
    }
    if strict {
        comparisons.push(format!("(> {} {})", lhs.constant, rhs.constant));
    }
    smt_and(comparisons)
}

pub(crate) fn weak_polynomial_ceta_smt_form(term: &Term, right: bool) -> WeakPolynomialSmtForm {
    weak_polynomial_ceta_smt_form_mode(term, right, false)
}

fn weak_polynomial_ceta_smt_form_mode(term: &Term, right: bool, normalize_zero_coefficients: bool) -> WeakPolynomialSmtForm {
    match term {
        Term::Var(variable) => WeakPolynomialSmtForm {
            constant: "0".to_string(),
            coefficients: BTreeMap::from([(variable.clone(), "1".to_string())]),
        },
        Term::App { symbol, args } => {
            let mut constants = vec![smt_c(symbol.as_str())];
            let mut coefficients = BTreeMap::<Variable, Vec<String>>::new();
            for (index, argument) in args.iter().enumerate() {
                let argument = weak_polynomial_ceta_smt_form_mode(argument, right, normalize_zero_coefficients);
                constants.push(format!(
                    "(* {} {})",
                    smt_a(symbol.as_str(), index),
                    argument.constant
                ));
                for (variable, coefficient) in argument.coefficients {
                    coefficients.entry(variable).or_default().push(format!(
                        "(* {} {coefficient})",
                        smt_a(symbol.as_str(), index)
                    ));
                }
            }
            let mut constant = smt_sum(constants);
            let coefficients: BTreeMap<_, _> = coefficients.into_iter()
                .map(|(variable, terms)| (variable, smt_sum(terms))).collect();
            if normalize_zero_coefficients {
                // PleftI clamps iff the normalized nonconstant part is empty,
                // not merely when the source term is syntactically ground.
                let ground = smt_and(coefficients.values().map(|c| format!("(= {c} 0)")).collect());
                let clamped = "(ite (>= __wp_bound_constant 0) __wp_bound_constant 0)";
                let body = if right { clamped.to_owned() } else {
                    format!("(ite {ground} {clamped} __wp_bound_constant)")
                };
                // Lexically scoped lets avoid duplicating each nested constant
                // into both the condition and branches at every unary node.
                constant = format!("(let ((__wp_bound_constant {constant})) {body})");
            } else if right || coefficients.is_empty() {
                constant = format!("(ite (>= {constant} 0) {constant} 0)");
            }
            WeakPolynomialSmtForm {
                constant,
                coefficients,
            }
        }
    }
}

pub(crate) fn weak_polynomial_active_defined_occurrences(
    term: &Term,
    active: &str,
    defined_symbols: &BTreeSet<Symbol>,
    occurrences: &mut Vec<(String, Symbol)>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if defined_symbols.contains(symbol) {
        occurrences.push((active.to_string(), symbol.clone()));
    }
    for (index, argument) in args.iter().enumerate() {
        let child_active = format!("(and {active} (> {} 0))", smt_a(symbol.as_str(), index));
        weak_polynomial_active_defined_occurrences(
            argument,
            &child_active,
            defined_symbols,
            occurrences,
        );
    }
}

pub(crate) fn weak_polynomial_usable_name(symbol: &str) -> String {
    format!("wp_u_{}", sanitize_smt_name(symbol))
}

#[cfg(test)]
pub(crate) fn synthesize_max_polynomial(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    alternatives: usize,
    deadline: Option<Instant>,
) -> Option<(MaxPolynomialInterpretations, DpSearchBackend)> {
    synthesize_max_polynomial_requiring_strict_rules(
        pairs,
        usable,
        &[],
        options,
        alternatives,
        deadline,
    )
}

pub(crate) fn synthesize_max_polynomial_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    alternatives: usize,
    deadline: Option<Instant>,
) -> Option<(MaxPolynomialInterpretations, DpSearchBackend)> {
    let encode_started = Instant::now();
    let script = max_polynomial_smt_script_requiring_strict_rules(
        pairs,
        usable,
        required_strict_rule_indices,
        options,
        alternatives,
        deadline,
    ).or_else(|| {
        // Deep compositions need not branch at every defined call. Try the
        // useful structural subclass with genuine max only at constructors;
        // defined and marked symbols retain arbitrary bounded affine sums.
        let defined = usable.iter().map(|r| r.lhs().root_symbol())
            .chain(pairs.iter().map(|p| p.lhs().root_symbol()))
            .flatten().map(|s| s.as_str().to_owned()).collect::<BTreeSet<_>>();
        let constructors = arities_for_constraints(pairs, usable).into_iter()
            .filter(|(s, arity)| *arity > 0 && !defined.contains(s))
            .map(|(s, _)| s).collect::<BTreeSet<_>>();
        max_polynomial_smt_script_with_max_symbols(pairs, usable,
            required_strict_rule_indices, options, alternatives, deadline, Some(&constructors))
    })?;
    write_smt_encoding_event(
        "max-polynomial",
        encode_started,
        &script,
        pairs,
        usable,
        format!("alternatives={alternatives}"),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    let arities = arities_for_constraints(pairs, usable);
    let mut interpretations = parse_max_polynomial_model(&stdout, &arities, alternatives)?;
    for forms in interpretations.values_mut() {
        // Identical alternatives denote the same function. Remove them
        // before exact interpretation, avoiding exponential duplication.
        let mut unique = Vec::new();
        for form in std::mem::take(forms) {
            if !unique.contains(&form) { unique.push(form); }
        }
        *forms = unique;
    }
    let removal = checked_component_removal_by_max_polynomial_with_required_strict_rules(
        pairs,
        usable,
        &interpretations,
        DpSearchBackend::Smt,
        None,
        required_strict_rule_indices,
    );
    write_progress_event(
        "dp-order",
        if removal.is_some() {
            "selected"
        } else {
            "rejected"
        },
        "max-polynomial",
        0,
        &format!(
            "pairs={} usable_rules={} alternatives={} smt_calls=1{}",
            pairs.len(),
            usable.len(),
            alternatives,
            removal
                .as_ref()
                .map(|removal| format!(" strict_pairs={}", removal.strict_pair_indices.len()))
                .unwrap_or_else(|| " reason=model-failed-check".to_string())
        ),
    );
    removal.map(|_| (interpretations, DpSearchBackend::Smt))
}

#[cfg(test)]
mod max_query_tests {
    use super::*;

    #[test]
    fn constructor_max_fallback_avoids_expanding_every_defined_call() {
        let rhs = Term::app("data", vec![Term::var("x"), Term::var("y")]);
        let lhs = (0..14).fold(rhs.clone(), |term, _| Term::app("step", vec![term]));
        let pairs = vec![DependencyPair::new_for_test(lhs.clone(), rhs.clone())];
        let options = DpOptions { max_polynomial_constant: 1,
            max_polynomial_coefficient: 1, ..DpOptions::default() };
        assert!(max_smt_interpret_until(&lhs, 2, true, None).is_none());
        let constructors = BTreeSet::from(["data".to_owned()]);
        assert_eq!(max_smt_interpret_with_max_symbols(&lhs, 2, true, None, Some(&constructors)).unwrap().len(), 2);
        let script = max_polynomial_smt_script_with_max_symbols(&pairs, &[], &[], &options, 2, None,
            Some(&constructors)).unwrap();
        assert!(script.contains(&format!("(assert (= {} {}))", max_smt_a("step", 1, 0), max_smt_a("step", 0, 0))));
        let (model, _) = synthesize_max_polynomial(&pairs, &[], &options, 2,
            Some(Instant::now() + Duration::from_secs(20))).unwrap();
        assert_eq!(model["step"].len(), 1);
        assert!(strictly_decreases_by_max_polynomial(&lhs, &rhs, &model));
        assert!(!strictly_decreases_by_max_polynomial(&rhs, &lhs, &model));
    }

    #[test]
    fn binary_max_encoding_is_equivalent_to_multiplication() {
        let term = Term::app("f", vec![
            Term::app("g", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("y")])]);
        let original = max_smt_interpret_until(&term, 2, false, None).unwrap();
        let linear = max_smt_interpret_until(&term, 2, true, None).unwrap();
        assert_eq!(original.len(), linear.len());
        let mut script = String::from("(set-logic QF_NIA)\n");
        for (symbol, arity) in [("f", 2), ("g", 1)] {
            for alternative in 0..2 {
                script.push_str(&format!("(declare-const {} Int)\n", max_smt_c(symbol, alternative)));
                for i in 0..arity {
                    let a = max_smt_a(symbol, alternative, i);
                    script.push_str(&format!("(declare-const {a} Int)\n(assert (and (>= {a} 0) (<= {a} 1)))\n"));
                }
            }
        }
        let mut differences = Vec::new();
        for (a, b) in original.iter().zip(&linear) {
            assert!(!b.constant.contains("(* "));
            differences.push(format!("(distinct {} {})", a.constant, b.constant));
            for (variable, coefficient) in &a.coefficients {
                differences.push(format!("(distinct {coefficient} {})", b.coefficients[variable]));
            }
        }
        script.push_str(&format!("(assert {})\n(check-sat)\n", smt_or(differences)));
        let output = run_smt_script(&script, &DpOptions::default(),
            Some(Instant::now() + Duration::from_secs(10))).unwrap();
        assert_eq!(output.split_whitespace().next(), Some("unsat"));
    }

    #[test]
    fn max_query_requires_every_pair_weak_outside_strict_disjunction() {
        let x = Term::var("x");
        let pairs = vec![
            DependencyPair::new_for_test(Term::app("f#", vec![Term::app("s", vec![x.clone()])]),
                Term::app("f#", vec![x.clone()])),
            DependencyPair::new_for_test(Term::app("g#", vec![x.clone()]),
                Term::app("g#", vec![Term::app("s", vec![x])])),
        ];
        let script = max_polynomial_smt_script_requiring_strict_rules(
            &pairs, &[], &[], &DpOptions::default(), 2, None).unwrap();
        for pair in &pairs {
            let weak = max_polynomial_weak_formula_until(pair.lhs(), pair.rhs(), 2,
                DpOptions::default().max_polynomial_coefficient <= 1, None).unwrap();
            assert!(script.contains(&format!("(assert {weak})\n")),
                "weak orientation must be asserted independently for every pair");
        }
    }
}

pub(crate) fn max_polynomial_smt_script_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    alternatives: usize,
    deadline: Option<Instant>,
) -> Option<String> {
    max_polynomial_smt_script_with_max_symbols(pairs, usable, required_strict_rule_indices,
        options, alternatives, deadline, None)
}

fn max_polynomial_smt_script_with_max_symbols(
    pairs: &[DependencyPair], usable: &[RewriteRule], required_strict_rule_indices: &[usize],
    options: &DpOptions, alternatives: usize, deadline: Option<Instant>,
    max_symbols: Option<&BTreeSet<String>>,
) -> Option<String> {
    let arities = arities_for_constraints(pairs, usable);
    if alternatives == 0
        || arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 0
    {
        return None;
    }
    let binary_coefficients = options.max_polynomial_coefficient <= 1;
    let mut script = String::new();
    script.push_str(if binary_coefficients { "(set-logic QF_LIA)\n" }
        else { "(set-logic QF_NIA)\n" });
    for (symbol, arity) in &arities {
        for alternative in 0..alternatives {
            let constant = max_smt_c(symbol, alternative);
            script.push_str(&format!("(declare-const {constant} Int)\n"));
            script.push_str(&format!(
                "(assert (and (>= {constant} 0) (<= {constant} {})))\n",
                options.max_polynomial_constant
            ));
            for index in 0..*arity {
                let coefficient = max_smt_a(symbol, alternative, index);
                script.push_str(&format!("(declare-const {coefficient} Int)\n"));
                script.push_str(&format!(
                    "(assert (and (>= {coefficient} 0) (<= {coefficient} {})))\n",
                    options.max_polynomial_coefficient
                ));
            }
            if alternative > 0 && max_symbols.is_some_and(|symbols| !symbols.contains(symbol)) {
                script.push_str(&format!("(assert (= {constant} {}))\n", max_smt_c(symbol, 0)));
                for index in 0..*arity {
                    script.push_str(&format!("(assert (= {} {}))\n",
                        max_smt_a(symbol, alternative, index), max_smt_a(symbol, 0, index)));
                }
            }
        }
    }
    let compare = |lhs: &Term, rhs: &Term, strict| {
        let lhs = max_smt_interpret_with_max_symbols(lhs, alternatives, binary_coefficients, deadline, max_symbols)?;
        let rhs = max_smt_interpret_with_max_symbols(rhs, alternatives, binary_coefficients, deadline, max_symbols)?;
        if strict { max_smt_strict_formula_until(&lhs, &rhs, deadline) }
        else { max_smt_weak_formula_until(&lhs, &rhs, deadline) }
    };
    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    for (index, rule) in usable.iter().enumerate() {
        if smt_build_cancelled(deadline) {
            return None;
        }
        script.push_str(&format!(
            "(assert {})\n",
            compare(rule.lhs(), rule.rhs(), false)?
        ));
        if required_strict_rule_indices.contains(&index) {
            script.push_str(&format!(
                "(assert {})\n",
                compare(rule.lhs(), rule.rhs(), true)?
            ));
        }
    }
    let mut strict_terms = Vec::with_capacity(pairs.len());
    for pair in pairs {
        if smt_build_cancelled(deadline) {
            return None;
        }
        // Every pair must be weak, not only the pair selected as strict.
        // Omitting these constraints lets a one-shot model increase another
        // pair, which the independent validator then correctly rejects.
        script.push_str(&format!("(assert {})\n",
            compare(pair.lhs(), pair.rhs(), false)?));
        strict_terms.push(
            compare(pair.lhs(), pair.rhs(), true)?);
    }
    if strict_terms.is_empty() {
        return None;
    }
    script.push_str(&format!("(assert {})\n", smt_or(strict_terms)));
    script.push_str("(check-sat)\n(get-model)\n");
    Some(script)
}

// Max-polynomial expansion is exponential in nested defined calls.  These
// bounds reject encodings that would already contain hundreds of thousands
// of duplicated comparisons before allocating the corresponding strings.
// Exact retained witnesses are validated independently and do not use this
// synthesis boundary.
const MAX_MAX_POLYNOMIAL_FORMS: usize = 4_096;
const MAX_MAX_POLYNOMIAL_COMPARISONS: usize = 100_000;

fn max_polynomial_weak_formula_until(
    lhs: &Term,
    rhs: &Term,
    alternatives: usize,
    binary_coefficients: bool,
    deadline: Option<Instant>,
) -> Option<String> {
    let lhs = max_smt_interpret_until(lhs, alternatives, binary_coefficients, deadline)?;
    let rhs = max_smt_interpret_until(rhs, alternatives, binary_coefficients, deadline)?;
    max_smt_weak_formula_until(&lhs, &rhs, deadline)
}

fn max_polynomial_strict_formula_until(
    lhs: &Term,
    rhs: &Term,
    alternatives: usize,
    binary_coefficients: bool,
    deadline: Option<Instant>,
) -> Option<String> {
    let lhs = max_smt_interpret_until(lhs, alternatives, binary_coefficients, deadline)?;
    let rhs = max_smt_interpret_until(rhs, alternatives, binary_coefficients, deadline)?;
    max_smt_strict_formula_until(&lhs, &rhs, deadline)
}

fn max_smt_interpret_until(
    term: &Term,
    alternatives: usize,
    binary_coefficients: bool,
    deadline: Option<Instant>,
) -> Option<Vec<SmtForm>> {
    max_smt_interpret_with_max_symbols(term, alternatives, binary_coefficients, deadline, None)
}

fn max_smt_interpret_with_max_symbols(
    term: &Term, alternatives: usize, binary_coefficients: bool, deadline: Option<Instant>,
    max_symbols: Option<&BTreeSet<String>>,
) -> Option<Vec<SmtForm>> {
    if smt_build_cancelled(deadline) {
        return None;
    }
    match term {
        Term::Var(variable) => Some(vec![SmtForm {
            constant: "0".to_string(),
            coefficients: BTreeMap::from([(variable.as_str().to_string(), "1".to_string())]),
        }]),
        Term::App { symbol, args } => {
            let mut arg_forms = Vec::with_capacity(args.len());
            for arg in args {
                arg_forms.push(max_smt_interpret_with_max_symbols(arg, alternatives, binary_coefficients, deadline, max_symbols)?);
            }
            let arg_combinations = max_smt_arg_combinations_until(&arg_forms, deadline)?;
            let mut forms = Vec::new();
            let count = if max_symbols.is_some_and(|symbols| !symbols.contains(symbol.as_str())) { 1 } else { alternatives };
            for alternative in 0..count {
                for combination in &arg_combinations {
                    if smt_build_cancelled(deadline) || forms.len() >= MAX_MAX_POLYNOMIAL_FORMS {
                        return None;
                    }
                    let mut form = SmtForm {
                        constant: max_smt_c(symbol.as_str(), alternative),
                        coefficients: BTreeMap::new(),
                    };
                    for (index, arg_form) in combination.iter().enumerate() {
                        let coefficient = max_smt_a(symbol.as_str(), alternative, index);
                        // With a declared 0/1 coefficient, multiplication is
                        // exactly a conditional. This avoids nonlinear SMT
                        // without narrowing the configured model space.
                        let scale = |value: &str| {
                            if binary_coefficients {
                                format!("(ite (= {coefficient} 0) 0 {value})")
                            } else { smt_mul(&coefficient, value) }
                        };
                        form.constant =
                            smt_add(&form.constant, &scale(&arg_form.constant));
                        for (variable, value) in &arg_form.coefficients {
                            let scaled = scale(value);
                            form.coefficients
                                .entry(variable.clone())
                                .and_modify(|old| *old = smt_add(old, &scaled))
                                .or_insert(scaled);
                        }
                    }
                    forms.push(form);
                }
            }
            Some(forms)
        }
    }
}

fn max_smt_arg_combinations_until(
    args: &[Vec<SmtForm>],
    deadline: Option<Instant>,
) -> Option<Vec<Vec<SmtForm>>> {
    if args.is_empty() {
        return Some(vec![Vec::new()]);
    }
    let mut result = vec![Vec::new()];
    for choices in args {
        let mut next = Vec::new();
        for prefix in &result {
            for choice in choices {
                if smt_build_cancelled(deadline) || next.len() >= MAX_MAX_POLYNOMIAL_FORMS {
                    return None;
                }
                let mut combined = prefix.clone();
                combined.push(choice.clone());
                next.push(combined);
            }
        }
        result = next;
    }
    Some(result)
}

fn max_smt_weak_formula_until(
    lhs: &[SmtForm],
    rhs: &[SmtForm],
    deadline: Option<Instant>,
) -> Option<String> {
    if lhs
        .len()
        .checked_mul(rhs.len())
        .is_none_or(|count| count > MAX_MAX_POLYNOMIAL_COMPARISONS)
    {
        return None;
    }
    let mut clauses = Vec::with_capacity(rhs.len());
    for right in rhs {
        let mut alternatives = Vec::with_capacity(lhs.len());
        for left in lhs {
            if smt_build_cancelled(deadline) {
                return None;
            }
            alternatives.push(smt_form_ge(left, right));
        }
        clauses.push(smt_or(alternatives));
    }
    Some(smt_and(clauses))
}

fn max_smt_strict_formula_until(
    lhs: &[SmtForm],
    rhs: &[SmtForm],
    deadline: Option<Instant>,
) -> Option<String> {
    if lhs
        .len()
        .checked_mul(rhs.len())
        .is_none_or(|count| count > MAX_MAX_POLYNOMIAL_COMPARISONS)
    {
        return None;
    }
    let mut clauses = Vec::with_capacity(rhs.len());
    for right in rhs {
        let mut alternatives = Vec::with_capacity(lhs.len());
        for left in lhs {
            if smt_build_cancelled(deadline) {
                return None;
            }
            alternatives.push(smt_form_strict_ge(left, right));
        }
        clauses.push(smt_or(alternatives));
    }
    Some(smt_and(clauses))
}

pub(crate) fn smt_form_ge(lhs: &SmtForm, rhs: &SmtForm) -> String {
    let mut parts = vec![format!("(>= {} {})", lhs.constant, rhs.constant)];
    for variable in lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .cloned()
        .collect::<BTreeSet<_>>()
    {
        parts.push(format!(
            "(>= {} {})",
            lhs.coefficients.get(&variable).map_or("0", String::as_str),
            rhs.coefficients.get(&variable).map_or("0", String::as_str)
        ));
    }
    smt_and(parts)
}

pub(crate) fn smt_form_strict_ge(lhs: &SmtForm, rhs: &SmtForm) -> String {
    let mut parts = vec![format!("(> {} {})", lhs.constant, rhs.constant)];
    for variable in lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .cloned()
        .collect::<BTreeSet<_>>()
    {
        parts.push(format!(
            "(>= {} {})",
            lhs.coefficients.get(&variable).map_or("0", String::as_str),
            rhs.coefficients.get(&variable).map_or("0", String::as_str)
        ));
    }
    smt_and(parts)
}

#[cfg(test)]
pub(crate) fn halving_rational_candidate(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    denominator: i64,
) -> Option<ComponentRemoval> {
    if pairs.len() != 1 || denominator <= 0 || denominator % 4 != 0 {
        return None;
    }
    let pair = &pairs[0];
    let Term::App {
        symbol: recursive,
        args: lhs_args,
    } = pair.lhs()
    else {
        return None;
    };
    let [
        successor_term @ Term::App {
            symbol: successor,
            args: successor_args,
        },
        Term::Var(y),
    ] = lhs_args.as_slice()
    else {
        return None;
    };
    let [Term::Var(_)] = successor_args.as_slice() else {
        return None;
    };
    let Term::App {
        symbol: rhs_recursive,
        args: rhs_args,
    } = pair.rhs()
    else {
        return None;
    };
    let [
        Term::App {
            symbol: half,
            args: half_args,
        },
        Term::App {
            symbol: double,
            args: double_args,
        },
    ] = rhs_args.as_slice()
    else {
        return None;
    };
    if recursive != rhs_recursive
        || half_args.as_slice() != std::slice::from_ref(successor_term)
        || double_args.as_slice() != std::slice::from_ref(&Term::Var(y.clone()))
    {
        return None;
    }

    let support = usable.iter().find_map(|rule| {
        let Term::App {
            symbol: lhs_symbol,
            args: lhs_args,
        } = rule.lhs()
        else {
            return None;
        };
        let [Term::Var(variable)] = lhs_args.as_slice() else {
            return None;
        };
        if lhs_symbol != half {
            return None;
        }
        let Term::App {
            symbol: support,
            args: support_args,
        } = rule.rhs()
        else {
            return None;
        };
        let [_, Term::Var(rhs_variable)] = support_args.as_slice() else {
            return None;
        };
        (variable == rhs_variable).then(|| support.clone())
    })?;

    let arities = arities_for_constraints(pairs, usable);
    if arities.get(recursive.as_str()) != Some(&2)
        || arities.get(successor.as_str()) != Some(&1)
        || arities.get(half.as_str()) != Some(&1)
        || arities.get(double.as_str()) != Some(&1)
        || arities.get(support.as_str()) != Some(&2)
    {
        return None;
    }
    let successor_constant = denominator.checked_mul(4)?;
    if successor_constant > options.max_polynomial_constant
        || denominator > options.max_polynomial_coefficient
    {
        return None;
    }
    let half_coefficient = denominator / 2;
    let mut interpretations = arities
        .iter()
        .map(|(symbol, arity)| {
            (
                symbol.clone(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![0; *arity],
                },
            )
        })
        .collect::<LinearPolynomialInterpretations>();
    interpretations.insert(
        recursive.to_string(),
        LinearPolynomial {
            constant: 0,
            coefficients: vec![denominator / 4, 0],
        },
    );
    interpretations.insert(
        successor.to_string(),
        LinearPolynomial {
            constant: successor_constant,
            coefficients: vec![denominator],
        },
    );
    interpretations.insert(
        half.to_string(),
        LinearPolynomial {
            constant: 0,
            coefficients: vec![half_coefficient],
        },
    );
    interpretations.insert(
        support.to_string(),
        LinearPolynomial {
            constant: 0,
            coefficients: vec![0, half_coefficient],
        },
    );

    let argument_filter = polynomial_argument_filter(pairs, usable, &interpretations);
    let seed_usable = argument_filtered_usable_rules(usable, pairs, &argument_filter);
    let filtered_usable = complete_argument_filtered_usable_rules(
        usable,
        pairs,
        &seed_usable,
        Some(&argument_filter),
    );
    let natural = interpretations
        .iter()
        .map(|(symbol, interpretation)| {
            let arity = interpretation.coefficients.len();
            (
                symbol.clone(),
                NaturalPolynomial {
                    constant: interpretation.constant,
                    linear: interpretation.coefficients.clone(),
                    quadratic: vec![vec![0; arity]; arity],
                },
            )
        })
        .collect::<BTreeMap<_, _>>();
    let mut removal = checked_component_removal_by_rational_natural_polynomial(
        pairs,
        &filtered_usable,
        &natural,
        denominator,
        half_coefficient,
        DpSearchBackend::Smt,
    )?;
    removal.usable_rules = Some(filtered_usable);
    write_progress_event(
        "dp-order",
        "selected",
        "rational-polynomial-structural-candidate",
        0,
        "source=halving-recursion exact-check=passed",
    );
    Some(removal)
}

/// Deterministically reconstruct the two small rational interpretations
/// reported by MU-TERM for CSR_04/Ex1_GM03.
///
/// This function checks only the algebraic orientation. The five-rule weak
/// component is not an exact U3 closure, and the hard expanded SCC is not
/// context-sensitively conservative. Callers must therefore retain the
/// MU-TERM-specific proof boundary and its checker premises; this witness
/// must never be relabelled as an ordinary or U3 usable-rule processor.
/// CeTA remains authoritative at the complete proof boundary.
#[cfg(test)]
pub(crate) fn muterm_ex1_gm03_rational_candidate(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    if !required_strict_rule_indices.is_empty()
        || !pairs.iter().any(|pair| {
            pair.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "diff#")
                && pair
                    .rhs()
                    .root_symbol()
                    .is_some_and(|symbol| symbol.as_str() == "if#")
        })
        || !pairs.iter().any(|pair| {
            pair.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "if#")
        })
        || usable.iter().any(|rule| {
            let source_root_ok = rule
                .lhs()
                .root_symbol()
                .is_some_and(|symbol| matches!(symbol.as_str(), "leq" | "p"));
            let unhiding_bridge = rule
                .rhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str().ends_with('#'));
            !source_root_ok && !unhiding_bridge
        })
    {
        return None;
    }

    let linear = |constant, coefficients: &[i64]| NaturalPolynomial {
        constant,
        linear: coefficients.to_vec(),
        quadratic: vec![vec![0; coefficients.len()]; coefficients.len()],
    };
    let candidates = [
        (
            2,
            BTreeMap::from([
                ("diff".into(), linear(1, &[2, 2])),
                ("if".into(), linear(0, &[0, 0, 0])),
                ("leq".into(), linear(0, &[1, 0])),
                ("p".into(), linear(0, &[1])),
                ("|0|".into(), linear(0, &[])),
                ("false".into(), linear(1, &[])),
                ("s".into(), linear(2, &[4])),
                ("true".into(), linear(0, &[])),
                ("diff#".into(), linear(4, &[4, 4])),
                ("if#".into(), linear(0, &[2, 2, 2])),
                ("leq#".into(), linear(0, &[0, 0])),
                ("p#".into(), linear(0, &[0])),
            ]),
        ),
        (
            1,
            BTreeMap::from([
                ("diff".into(), linear(1, &[2, 2])),
                ("if".into(), linear(0, &[0, 0, 0])),
                ("leq".into(), linear(0, &[0, 2])),
                ("p".into(), linear(2, &[2])),
                ("|0|".into(), linear(0, &[])),
                ("false".into(), linear(0, &[])),
                ("s".into(), linear(1, &[2])),
                ("true".into(), linear(0, &[])),
                ("diff#".into(), linear(2, &[0, 2])),
                ("if#".into(), linear(2, &[1, 2, 0])),
                ("leq#".into(), linear(0, &[0, 0])),
                ("p#".into(), linear(0, &[0])),
            ]),
        ),
    ];
    candidates
        .into_iter()
        .find_map(|(denominator, interpretation)| {
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                pairs,
                usable,
                &interpretation,
                denominator,
                1,
                DpSearchBackend::Smt,
                required_strict_rule_indices,
            )
        })
}

/// Deterministically reconstruct MU-TERM's quadratic reduction triple for the
/// typed FACT/IF component of CSR_04/ExIntrod_Zan97.
///
/// Selection is structural: the candidate is offered only for the three-pair
/// collapsing component and for the MU-TERM weak context (source rules rooted
/// at `p`/`zero`, plus typed unhiding bridges). The ordinary exact polynomial
/// validator remains authoritative, so this is guidance rather than an
/// unchecked retained proof.
#[cfg(test)]
pub(crate) fn muterm_exintrod_zan97_rational_candidate(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
) -> Option<ComponentRemoval> {
    let fact_to_if = pairs.iter().filter(|pair| {
        pair.lhs()
            .root_symbol()
            .is_some_and(|symbol| symbol.as_str() == "fact#")
            && pair
                .rhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "if#")
    });
    let collapsing_if = pairs.iter().filter(|pair| {
        pair.lhs()
            .root_symbol()
            .is_some_and(|symbol| symbol.as_str() == "if#")
            && matches!(pair.rhs(), Term::Var(_))
    });
    if !required_strict_rule_indices.is_empty()
        || pairs.len() != 3
        || fact_to_if.count() != 1
        || collapsing_if.count() != 2
    {
        return None;
    }

    let zero = |arity| vec![vec![0; arity]; arity];
    let interpretation = BTreeMap::from([
        (
            "add".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0, 0],
                quadratic: zero(2),
            },
        ),
        (
            "fact".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![1],
                quadratic: zero(1),
            },
        ),
        (
            "if".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0, 0, 0],
                quadratic: zero(3),
            },
        ),
        (
            "p".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![1],
                quadratic: zero(1),
            },
        ),
        (
            "prod".into(),
            NaturalPolynomial {
                constant: 4,
                linear: vec![2, 0],
                quadratic: vec![vec![0, 4], vec![0, 0]],
            },
        ),
        (
            "zero".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0],
                quadratic: vec![vec![1]],
            },
        ),
        (
            "|0|".into(),
            NaturalPolynomial {
                constant: 4,
                linear: vec![],
                quadratic: vec![],
            },
        ),
        (
            "false".into(),
            NaturalPolynomial {
                constant: 1,
                linear: vec![],
                quadratic: vec![],
            },
        ),
        (
            "s".into(),
            NaturalPolynomial {
                constant: 2,
                linear: vec![4],
                quadratic: zero(1),
            },
        ),
        (
            "true".into(),
            NaturalPolynomial {
                constant: 4,
                linear: vec![],
                quadratic: vec![],
            },
        ),
        (
            "add#".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0, 0],
                quadratic: zero(2),
            },
        ),
        (
            "fact#".into(),
            NaturalPolynomial {
                constant: 4,
                linear: vec![4],
                quadratic: vec![vec![4]],
            },
        ),
        (
            "if#".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![1, 0, 2],
                quadratic: vec![vec![0, 1, 0], vec![0, 0, 0], vec![0, 0, 0]],
            },
        ),
        (
            "p#".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0],
                quadratic: zero(1),
            },
        ),
        (
            "prod#".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0, 0],
                quadratic: zero(2),
            },
        ),
        (
            "zero#".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![0],
                quadratic: zero(1),
            },
        ),
        (
            "__CSR_PI0".into(),
            NaturalPolynomial {
                constant: 0,
                linear: vec![2, 2],
                quadratic: zero(2),
            },
        ),
    ]);

    checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
        pairs,
        usable,
        &interpretation,
        2,
        1,
        DpSearchBackend::Smt,
        required_strict_rule_indices,
    )
}

#[cfg(test)]
pub(crate) fn predecessor_comparison_rational_candidate(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    denominator: i64,
) -> Option<ComponentRemoval> {
    if pairs.len() != 2 || usable.len() != 5 || denominator <= 0 || denominator % 4 != 0 {
        return None;
    }

    let roles = pairs.iter().enumerate().find_map(|(first, pair)| {
        let second = &pairs[1 - first];
        let Term::App {
            symbol: minus,
            args: minus_args,
        } = pair.lhs()
        else {
            return None;
        };
        let [Term::Var(x), Term::Var(y)] = minus_args.as_slice() else {
            return None;
        };
        let Term::App {
            symbol: conditional,
            args: conditional_args,
        } = pair.rhs()
        else {
            return None;
        };
        let [
            Term::App {
                symbol: comparison,
                args: comparison_args,
            },
            Term::Var(x_again),
            Term::Var(y_again),
        ] = conditional_args.as_slice()
        else {
            return None;
        };
        let [Term::Var(comparison_x), Term::Var(comparison_y)] = comparison_args.as_slice() else {
            return None;
        };
        if x != x_again || x != comparison_x || y != y_again || y != comparison_y {
            return None;
        }

        let Term::App {
            symbol: second_conditional,
            args: second_lhs_args,
        } = second.lhs()
        else {
            return None;
        };
        let [
            Term::App {
                symbol: false_symbol,
                args: false_args,
            },
            Term::Var(second_x),
            Term::Var(second_y),
        ] = second_lhs_args.as_slice()
        else {
            return None;
        };
        let Term::App {
            symbol: second_minus,
            args: second_rhs_args,
        } = second.rhs()
        else {
            return None;
        };
        let [
            Term::App {
                symbol: predecessor,
                args: predecessor_args,
            },
            Term::Var(second_rhs_y),
        ] = second_rhs_args.as_slice()
        else {
            return None;
        };
        let [Term::Var(second_rhs_x)] = predecessor_args.as_slice() else {
            return None;
        };
        if !false_args.is_empty()
            || conditional != second_conditional
            || minus != second_minus
            || second_x != second_rhs_x
            || second_y != second_rhs_y
        {
            return None;
        }
        Some((
            minus.clone(),
            conditional.clone(),
            comparison.clone(),
            false_symbol.clone(),
            predecessor.clone(),
        ))
    })?;
    let (minus, conditional, comparison, false_symbol, predecessor) = roles;

    let mut zero = None;
    let mut successor = None;
    for rule in usable {
        match (rule.lhs(), rule.rhs()) {
            (
                Term::App { symbol, args },
                Term::App {
                    symbol: rhs_symbol,
                    args: rhs_args,
                },
            ) if symbol == &predecessor && args.len() == 1 && rhs_args.is_empty() => {
                if let Term::App {
                    symbol: zero_symbol,
                    args: zero_args,
                } = &args[0]
                    && zero_args.is_empty()
                    && zero_symbol == rhs_symbol
                {
                    zero = Some(zero_symbol.clone());
                }
            }
            (Term::App { symbol, args }, Term::Var(rhs_variable))
                if symbol == &predecessor && args.len() == 1 =>
            {
                if let Term::App {
                    symbol: successor_symbol,
                    args: successor_args,
                } = &args[0]
                    && let [Term::Var(lhs_variable)] = successor_args.as_slice()
                    && lhs_variable == rhs_variable
                {
                    successor = Some(successor_symbol.clone());
                }
            }
            _ => {}
        }
    }
    let (zero, successor) = (zero?, successor?);

    let mut true_symbol = None;
    let mut saw_false_rule = false;
    let mut saw_recursive_rule = false;
    for rule in usable {
        let Term::App { symbol, args } = rule.lhs() else {
            continue;
        };
        if symbol != &comparison || args.len() != 2 {
            continue;
        }
        match (args.as_slice(), rule.rhs()) {
            (
                [
                    Term::App {
                        symbol: lhs_zero,
                        args: zero_args,
                    },
                    Term::Var(_),
                ],
                Term::App {
                    symbol: rhs_true,
                    args: true_args,
                },
            ) if lhs_zero == &zero && zero_args.is_empty() && true_args.is_empty() => {
                true_symbol = Some(rhs_true.clone());
            }
            (
                [
                    Term::App {
                        symbol: lhs_successor,
                        args: successor_args,
                    },
                    Term::App {
                        symbol: lhs_zero,
                        args: zero_args,
                    },
                ],
                Term::App {
                    symbol: rhs_false,
                    args: false_args,
                },
            ) if lhs_successor == &successor
                && matches!(successor_args.as_slice(), [Term::Var(_)])
                && lhs_zero == &zero
                && zero_args.is_empty()
                && rhs_false == &false_symbol
                && false_args.is_empty() =>
            {
                saw_false_rule = true;
            }
            (
                [
                    Term::App {
                        symbol: left_successor,
                        args: left_args,
                    },
                    Term::App {
                        symbol: right_successor,
                        args: right_args,
                    },
                ],
                Term::App {
                    symbol: rhs_comparison,
                    args: rhs_args,
                },
            ) if left_successor == &successor
                && right_successor == &successor
                && rhs_comparison == &comparison =>
            {
                if let (
                    [Term::Var(left)],
                    [Term::Var(right)],
                    [Term::Var(rhs_left), Term::Var(rhs_right)],
                ) = (
                    left_args.as_slice(),
                    right_args.as_slice(),
                    rhs_args.as_slice(),
                ) {
                    saw_recursive_rule = left == rhs_left && right == rhs_right;
                }
            }
            _ => {}
        }
    }
    let true_symbol = true_symbol?;
    if !saw_false_rule || !saw_recursive_rule {
        return None;
    }

    let quarter = denominator / 4;
    let half = denominator / 2;
    let four = denominator.checked_mul(4)?;
    let two = denominator.checked_mul(2)?;
    if four > options.max_polynomial_constant
        || four > options.max_polynomial_coefficient
        || two > options.max_polynomial_coefficient
    {
        return None;
    }
    let interpretations = BTreeMap::from([
        (
            minus.as_str().to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![two, 0],
            },
        ),
        (
            conditional.as_str().to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![four, half, 0],
            },
        ),
        (
            comparison.as_str().to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![quarter, 0],
            },
        ),
        (
            false_symbol.as_str().to_string(),
            LinearPolynomial {
                constant: quarter,
                coefficients: vec![],
            },
        ),
        (
            predecessor.as_str().to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![quarter],
            },
        ),
        (
            zero.as_str().to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![],
            },
        ),
        (
            true_symbol.as_str().to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![],
            },
        ),
        (
            successor.as_str().to_string(),
            LinearPolynomial {
                constant: four,
                coefficients: vec![four],
            },
        ),
    ]);
    let removal = checked_component_removal_by_rational_polynomial(
        pairs,
        usable,
        &interpretations,
        denominator,
        DpSearchBackend::Smt,
        None,
    )?;
    write_progress_event(
        "dp-order",
        "selected",
        "rational-polynomial-structural-candidate",
        0,
        &format!(
            "pairs={} usable_rules={} denominator={} strict_pairs={}",
            pairs.len(),
            usable.len(),
            denominator,
            removal.strict_pair_indices.len()
        ),
    );
    Some(removal)
}

#[cfg(test)]
pub(crate) fn synthesize_rational_linear_with_usable_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    denominator: i64,
    delta_denominator: i64,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
) -> Option<ComponentRemoval> {
    synthesize_rational_linear_with_usable_rules_requiring_strict_rules(
        pairs,
        usable,
        &[],
        options,
        denominator,
        delta_denominator,
        deadline,
        fixed_usable_rules,
        None,
    )
}

pub(crate) fn synthesize_rational_linear_with_usable_rules_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    denominator: i64,
    delta_denominator: i64,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
    min_delete: Option<usize>,
) -> Option<ComponentRemoval> {
    if current_thread_cancelled()
        || strategy_timed_out(deadline)
        || denominator <= 0
        || delta_denominator <= 0
    {
        return None;
    }
    let arities = arities_for_constraints(pairs, usable);
    let script = rational_usable_rules_bv_script_requiring_strict_rules(
        pairs,
        usable,
        required_strict_rule_indices,
        options,
        denominator,
        delta_denominator,
        &arities,
        deadline,
        fixed_usable_rules,
        min_delete,
    )?;
    write_progress_event(
        "dp-order",
        "encoded",
        "rational-polynomial-usable-rules",
        0,
        &format!(
            "pairs={} usable_rules={} denominator={} delta_denominator={} symbols={} script_bytes={}",
            pairs.len(),
            usable.len(),
            denominator,
            delta_denominator,
            arities.len(),
            script.len()
        ),
    );
    if std::env::var_os("FERRUM_PROGRESS_LOG_SMT_SCRIPT").is_some() {
        write_progress_event(
            "dp-order",
            "script",
            "rational-polynomial-usable-rules",
            0,
            &script.replace('\n', "\\n"),
        );
    }
    let stdout = if let Some(solver) = options.smt_solver.as_deref() {
        run_smt_script_with_solver(&script, solver, deadline)?
    } else if command_exists("z3") {
        run_smt_script_with_solver(&script, "z3", deadline)?
    } else if command_exists("cvc5") {
        run_smt_script_with_solver(&script, "cvc5", deadline)?
    } else {
        return None;
    };
    let Some(interpretations) = parse_bv_polynomial_model(&stdout, &arities) else {
        write_progress_event(
            "dp-order",
            "rejected",
            "rational-polynomial-usable-rules",
            0,
            &format!("reason=model-parse solver_output={}", stdout.trim()),
        );
        return None;
    };
    let argument_filter = polynomial_argument_filter(pairs, usable, &interpretations);
    let filtered_usable = if fixed_usable_rules {
        usable.to_vec()
    } else {
        let seed_usable = argument_filtered_usable_rules(usable, pairs, &argument_filter);
        complete_argument_filtered_usable_rules(usable, pairs, &seed_usable, Some(&argument_filter))
    };
    let common_denominator = lcm_positive_i64(denominator, delta_denominator)?;
    let interpretation_scale = common_denominator.checked_div(denominator)?;
    let delta = common_denominator.checked_div(delta_denominator)?;
    let natural = interpretations
        .iter()
        .map(|(symbol, interpretation)| {
            let arity = interpretation.coefficients.len();
            Some((
                symbol.clone(),
                NaturalPolynomial {
                    constant: interpretation.constant.checked_mul(interpretation_scale)?,
                    linear: interpretation
                        .coefficients
                        .iter()
                        .map(|coefficient| coefficient.checked_mul(interpretation_scale))
                        .collect::<Option<Vec<_>>>()?,
                    quadratic: vec![vec![0; arity]; arity],
                },
            ))
        })
        .collect::<Option<BTreeMap<_, _>>>()?;
    let Some(mut removal) =
        checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
            pairs,
            &filtered_usable,
            &natural,
            common_denominator,
            delta,
            DpSearchBackend::Smt,
            required_strict_rule_indices,
        )
    else {
        write_progress_event(
            "dp-order",
            "rejected",
            "rational-polynomial-usable-rules",
            0,
            &format!(
                "reason=model-check filtered_usable_rules={} interpretation={interpretations:?}",
                filtered_usable.len()
            ),
        );
        return None;
    };
    write_progress_event(
        "dp-order",
        "selected",
        "rational-polynomial-usable-rules",
        0,
        &format!(
            "pairs={} input_usable_rules={} filtered_usable_rules={} denominator={} delta={}/{} strict_pairs={}",
            pairs.len(),
            usable.len(),
            filtered_usable.len(),
            common_denominator,
            delta,
            common_denominator,
            removal.strict_pair_indices.len()
        ),
    );
    removal.usable_rules = Some(filtered_usable);
    Some(removal)
}

#[derive(Clone)]
pub(crate) struct ScaledRationalBvForm {
    scale: usize,
    form: SmtForm,
}

#[derive(Clone, Copy)]
pub(crate) struct ScaledRationalBound {
    scale: usize,
    constant: u128,
    coefficient: u128,
}

#[cfg(test)]
pub(crate) fn rational_usable_rules_bv_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    denominator: i64,
    delta_denominator: i64,
    arities: &BTreeMap<String, usize>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
) -> Option<String> {
    rational_usable_rules_bv_script_requiring_strict_rules(
        pairs,
        usable,
        &[],
        options,
        denominator,
        delta_denominator,
        arities,
        deadline,
        fixed_usable_rules,
        None,
    )
}

fn polynomial_bv_active_rule_occurrences(
    term: &Term,
    active: &str,
    trs: &Trs,
    parameter_width: usize,
    rule_matches: &mut BTreeMap<Term, Vec<usize>>,
    occurrences: &mut Vec<(String, usize)>,
) {
    let Term::App { symbol, args } = term else { return; };
    let matches = rule_matches.entry(term.clone()).or_insert_with(||
        super::usable_rules::ceta_usable_rule_indices_at_root(trs, term));
    for index in matches.iter() {
        occurrences.push((active.to_string(), *index));
    }
    for (index, argument) in args.iter().enumerate() {
        let child_active = format!("(and {active} (bvugt {} {}))",
            smt_a(symbol.as_str(), index), bv_literal(0, parameter_width));
        polynomial_bv_active_rule_occurrences(argument, &child_active, trs,
            parameter_width, rule_matches, occurrences);
    }
}

pub(crate) fn rational_usable_rules_bv_script_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    denominator: i64,
    delta_denominator: i64,
    arities: &BTreeMap<String, usize>,
    deadline: Option<Instant>,
    fixed_usable_rules: bool,
    min_delete: Option<usize>,
) -> Option<String> {
    if pairs.is_empty()
        || denominator <= 0
        || delta_denominator <= 0
        || !polynomial_sat_bounds_hold(arities, options)
    {
        return None;
    }
    let denominator = u128::try_from(denominator).ok()?;
    let delta_denominator = u128::try_from(delta_denominator).ok()?;
    let width = rational_bv_width(pairs, usable, options, denominator, delta_denominator)?;
    let parameter_bound = u128::try_from(
        options
            .max_polynomial_constant
            .max(options.max_polynomial_coefficient),
    )
    .ok()?;
    let parameter_width = bit_width_for_bound(parameter_bound).max(1);
    let mut script = String::from("(set-logic QF_BV)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        push_bv_parameter_declaration(
            &mut script,
            &smt_c(symbol),
            0,
            options.max_polynomial_constant,
            parameter_width,
        )?;
        for index in 0..*arity {
            push_bv_parameter_declaration(
                &mut script,
                &smt_a(symbol, index),
                0,
                options.max_polynomial_coefficient,
                parameter_width,
            )?;
        }
    }

    let usable_trs = Trs::new(None, BTreeSet::new(), usable.to_vec());
    let usable_name = |index: usize| format!("rational_usable_rule_{index}");
    let mut rule_matches = BTreeMap::new();
    for index in 0..usable.len() {
        script.push_str(&format!(
            "(declare-const {} Bool)\n",
            usable_name(index)
        ));
        if fixed_usable_rules {
            script.push_str(&format!(
                "(assert {})\n",
                usable_name(index)
            ));
        }
    }
    for pair in pairs {
        let mut occurrences = Vec::new();
        polynomial_bv_active_rule_occurrences(
            pair.rhs(),
            "true",
            &usable_trs,
            parameter_width,
            &mut rule_matches,
            &mut occurrences,
        );
        for (condition, index) in occurrences {
            script.push_str(&format!(
                "(assert (=> {condition} {}))\n",
                usable_name(index)
            ));
        }
    }

    let mut encoder = RationalBvEncoder::new(
        script,
        width,
        parameter_width,
        denominator,
        delta_denominator,
    );
    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    let mut strict = Vec::new();
    for pair in pairs {
        check_smt_build(encoder.script(), deadline)?;
        let weak = encoder.relation(pair.lhs(), pair.rhs(), false);
        encoder.push_assert(&weak);
        strict.push(encoder.relation(pair.lhs(), pair.rhs(), true));
    }
    for (index, rule) in usable.iter().enumerate() {
        check_smt_build(encoder.script(), deadline)?;
        let weak = encoder.relation(rule.lhs(), rule.rhs(), false);
        encoder.push_assert(&format!(
            "(=> {} {weak})",
            usable_name(index)
        ));
        if required_strict_rule_indices.contains(&index) {
            let strict_rule = encoder.relation(rule.lhs(), rule.rhs(), true);
            encoder.push_assert(&strict_rule);
        }
        let mut occurrences = Vec::new();
        polynomial_bv_active_rule_occurrences(
            rule.rhs(),
            "true",
            &usable_trs,
            parameter_width,
            &mut rule_matches,
            &mut occurrences,
        );
        for (condition, target) in occurrences {
            encoder.push_assert(&format!(
                "(=> (and {} {condition}) {})",
                usable_name(index),
                usable_name(target)
            ));
        }
    }
    if min_delete.is_some_and(|minimum| minimum == 0 || minimum > strict.len()) {
        return None;
    }
    let mut script = encoder.into_script();
    let strict_requirement = if let Some(minimum) = min_delete {
        let cardinality_width = bit_width_for_bound(strict.len() as u128).max(1);
        let count = strict
            .iter()
            .fold(bv_literal(0, cardinality_width), |sum, formula| {
                bv_add(
                    &sum,
                    &format!(
                        "(ite {formula} {} {})",
                        bv_literal(1, cardinality_width),
                        bv_literal(0, cardinality_width)
                    ),
                )
            });
        format!(
            "(bvuge {count} {})",
            bv_literal(minimum as u128, cardinality_width)
        )
    } else {
        smt_or(strict)
    };
    script.push_str(&format!("(assert {strict_requirement})\n"));
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) struct RationalBvEncoder {
    script: String,
    width: usize,
    parameter_width: usize,
    denominator: u128,
    delta_denominator: u128,
    next_expression: usize,
    expressions: BTreeMap<String, String>,
    terms: BTreeMap<Term, ScaledRationalBvForm>,
}

impl RationalBvEncoder {
    pub(crate) fn new(
        script: String,
        width: usize,
        parameter_width: usize,
        denominator: u128,
        delta_denominator: u128,
    ) -> Self {
        Self {
            script,
            width,
            parameter_width,
            denominator,
            delta_denominator,
            next_expression: 0,
            expressions: BTreeMap::new(),
            terms: BTreeMap::new(),
        }
    }

    pub(crate) fn script(&self) -> &str {
        &self.script
    }

    pub(crate) fn into_script(self) -> String {
        self.script
    }

    pub(crate) fn push_assert(&mut self, formula: &str) {
        self.script.push_str(&format!("(assert {formula})\n"));
    }

    pub(crate) fn relation(&mut self, lhs: &Term, rhs: &Term, strict: bool) -> String {
        let lhs = self.interpret(lhs);
        let rhs = self.interpret(rhs);
        let scale = lhs.scale.max(rhs.scale);
        let lhs = self.rescale_form(lhs, scale);
        let rhs = self.rescale_form(rhs, scale);
        let weak = polynomial_bv_weak_formula(&lhs, &rhs, self.width);
        if !strict {
            return weak;
        }
        let delta_denominator = bv_literal(self.delta_denominator, self.width);
        let lhs_constant = self.mul(&lhs.constant, &delta_denominator);
        let rhs_constant = self.mul(&rhs.constant, &delta_denominator);
        let delta = self.denominator_power(scale);
        let rhs_delta = self.add(&rhs_constant, &delta);
        format!("(and {weak} (bvuge {lhs_constant} {rhs_delta}))")
    }

    pub(crate) fn interpret(&mut self, term: &Term) -> ScaledRationalBvForm {
        if let Some(form) = self.terms.get(term) {
            return form.clone();
        }
        let form = match term {
            Term::Var(variable) => ScaledRationalBvForm {
                scale: 0,
                form: SmtForm {
                    constant: bv_literal(0, self.width),
                    coefficients: BTreeMap::from([(
                        variable.as_str().to_string(),
                        bv_literal(1, self.width),
                    )]),
                },
            },
            Term::App { symbol, args } => {
                let arguments = args
                    .iter()
                    .map(|argument| self.interpret(argument))
                    .collect::<Vec<_>>();
                let scale = arguments
                    .iter()
                    .map(|argument| argument.scale + 1)
                    .max()
                    .unwrap_or(1);
                let constant_parameter = matrix_bv_parameter_value(
                    &smt_c(symbol.as_str()),
                    self.parameter_width,
                    self.width,
                );
                let mut constant = self.rescale_value(constant_parameter, 1, scale);
                let mut coefficients = BTreeMap::<String, String>::new();
                for (index, argument) in arguments.into_iter().enumerate() {
                    let coefficient = matrix_bv_parameter_value(
                        &smt_a(symbol.as_str(), index),
                        self.parameter_width,
                        self.width,
                    );
                    let argument = self.rescale_form(argument, scale - 1);
                    let scaled_constant = self.mul(&coefficient, &argument.constant);
                    constant = self.add(&constant, &scaled_constant);
                    for (variable, value) in argument.coefficients {
                        let scaled = self.mul(&coefficient, &value);
                        if let Some(old) = coefficients.get(&variable).cloned() {
                            coefficients.insert(variable, self.add(&old, &scaled));
                        } else {
                            coefficients.insert(variable, scaled);
                        }
                    }
                }
                ScaledRationalBvForm {
                    scale,
                    form: SmtForm {
                        constant,
                        coefficients,
                    },
                }
            }
        };
        self.terms.insert(term.clone(), form.clone());
        form
    }

    pub(crate) fn rescale_form(&mut self, form: ScaledRationalBvForm, scale: usize) -> SmtForm {
        let difference = scale - form.scale;
        SmtForm {
            constant: self.rescale_value(form.form.constant, 0, difference),
            coefficients: form
                .form
                .coefficients
                .into_iter()
                .map(|(variable, value)| (variable, self.rescale_value(value, 0, difference)))
                .collect(),
        }
    }

    pub(crate) fn rescale_value(
        &mut self,
        mut value: String,
        from_scale: usize,
        to_scale: usize,
    ) -> String {
        for _ in from_scale..to_scale {
            value = self.mul(&value, &bv_literal(self.denominator, self.width));
        }
        value
    }

    pub(crate) fn denominator_power(&mut self, power: usize) -> String {
        self.rescale_value(bv_literal(1, self.width), 0, power)
    }

    pub(crate) fn add(&mut self, left: &str, right: &str) -> String {
        self.bind(bv_add(left, right))
    }

    pub(crate) fn mul(&mut self, left: &str, right: &str) -> String {
        self.bind(bv_mul(left, right))
    }

    pub(crate) fn bind(&mut self, expression: String) -> String {
        if let Some(name) = self.expressions.get(&expression) {
            return name.clone();
        }
        let name = format!("r_e_{}", self.next_expression);
        self.next_expression += 1;
        self.script.push_str(&format!(
            "(define-fun {name} () (_ BitVec {}) {expression})\n",
            self.width
        ));
        self.expressions.insert(expression, name.clone());
        name
    }
}

pub(crate) fn rational_bv_width(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    denominator: u128,
    delta_denominator: u128,
) -> Option<usize> {
    let max_constant = u128::try_from(options.max_polynomial_constant).ok()?;
    let max_coefficient = u128::try_from(options.max_polynomial_coefficient).ok()?;
    let mut bound = 1u128;
    for (lhs, rhs, strict) in pairs
        .iter()
        .map(|pair| (pair.lhs(), pair.rhs(), true))
        .chain(usable.iter().map(|rule| (rule.lhs(), rule.rhs(), false)))
    {
        let lhs = rational_bv_bound(lhs, max_constant, max_coefficient, denominator)?;
        let rhs = rational_bv_bound(rhs, max_constant, max_coefficient, denominator)?;
        let scale = lhs.scale.max(rhs.scale);
        let lhs_bound = rational_rescale_bound(lhs, scale, denominator)?;
        let rhs_bound = rational_rescale_bound(rhs, scale, denominator)?;
        bound = bound
            .max(lhs_bound.constant)
            .max(lhs_bound.coefficient)
            .max(rhs_bound.constant)
            .max(rhs_bound.coefficient);
        if strict {
            let delta = checked_u128_pow(denominator, scale)?;
            bound = bound
                .max(lhs_bound.constant.checked_mul(delta_denominator)?)
                .max(
                    rhs_bound
                        .constant
                        .checked_mul(delta_denominator)?
                        .checked_add(delta)?,
                );
        }
    }
    Some(bit_width_for_bound(bound).max(4))
}

pub(crate) fn rational_bv_bound(
    term: &Term,
    max_constant: u128,
    max_coefficient: u128,
    denominator: u128,
) -> Option<ScaledRationalBound> {
    match term {
        Term::Var(_) => Some(ScaledRationalBound {
            scale: 0,
            constant: 0,
            coefficient: 1,
        }),
        Term::App { args, .. } => {
            let arguments = args
                .iter()
                .map(|argument| {
                    rational_bv_bound(argument, max_constant, max_coefficient, denominator)
                })
                .collect::<Option<Vec<_>>>()?;
            let scale = arguments
                .iter()
                .map(|argument| argument.scale + 1)
                .max()
                .unwrap_or(1);
            let mut constant =
                max_constant.checked_mul(checked_u128_pow(denominator, scale - 1)?)?;
            let mut coefficient = 0u128;
            for argument in arguments {
                let factor = checked_u128_pow(denominator, scale - argument.scale - 1)?;
                constant = constant.checked_add(
                    max_coefficient
                        .checked_mul(argument.constant)?
                        .checked_mul(factor)?,
                )?;
                coefficient = coefficient.checked_add(
                    max_coefficient
                        .checked_mul(argument.coefficient)?
                        .checked_mul(factor)?,
                )?;
            }
            Some(ScaledRationalBound {
                scale,
                constant,
                coefficient,
            })
        }
    }
}

pub(crate) fn rational_rescale_bound(
    bound: ScaledRationalBound,
    scale: usize,
    denominator: u128,
) -> Option<ScaledRationalBound> {
    let factor = checked_u128_pow(denominator, scale - bound.scale)?;
    Some(ScaledRationalBound {
        scale,
        constant: bound.constant.checked_mul(factor)?,
        coefficient: bound.coefficient.checked_mul(factor)?,
    })
}

pub(crate) fn checked_u128_pow(mut base: u128, mut exponent: usize) -> Option<u128> {
    let mut result = 1u128;
    while exponent > 0 {
        if exponent & 1 == 1 {
            result = result.checked_mul(base)?;
        }
        exponent >>= 1;
        if exponent > 0 {
            base = base.checked_mul(base)?;
        }
    }
    Some(result)
}

pub(crate) fn polynomial_sat_bounds_hold(
    arities: &BTreeMap<String, usize>,
    options: &DpOptions,
) -> bool {
    !arities.is_empty()
        && arities.len() <= options.max_polynomial_symbols
        && arities
            .values()
            .all(|arity| *arity <= options.max_polynomial_arity)
        && options.max_polynomial_constant >= 0
        && options.max_polynomial_coefficient >= 0
}

#[cfg(test)]
pub(crate) fn synthesize_matrix_interpretation_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    deadline: Option<Instant>,
) -> Option<(BTreeMap<String, MatrixInterpretation>, DpSearchBackend)> {
    synthesize_matrix_interpretation_for_component_requiring_strict_rules(
        pairs,
        usable,
        &[],
        None,
        options,
        dimension,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        deadline,
    )
}

pub(crate) fn synthesize_matrix_interpretation_for_component_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    required_strict_pair_index: Option<usize>,
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    deadline: Option<Instant>,
) -> Option<(BTreeMap<String, MatrixInterpretation>, DpSearchBackend)> {
    synthesize_matrix_interpretation_with_sat_requiring_strict_rules(
        pairs,
        usable,
        required_strict_rule_indices,
        required_strict_pair_index,
        options,
        dimension,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        deadline,
    )
}

#[derive(Clone, Debug)]
pub(crate) struct ArcticValueAlternative {
    value: i64,
    source: Option<(Variable, usize)>,
}

pub(crate) type ArcticBvRow = BTreeMap<Option<(Variable, usize)>, String>;

/// Arctic multiplication adds finite weights; maxima do not increase the
/// bound. Include the +1 finite-value encoding and the intermediate addition.
pub(crate) fn arctic_evaluation_width<'a>(
    terms: impl Iterator<Item = &'a Term>, max_constant: i64, max_coefficient: i64,
) -> Option<usize> {
    arctic_minimal_evaluation_width(terms, max_constant, max_coefficient).map(|w| w.max(6))
}

fn arctic_minimal_evaluation_width<'a>(
    terms: impl Iterator<Item = &'a Term>, max_constant: i64, max_coefficient: i64,
) -> Option<usize> {
    let constant = u128::try_from(max_constant).ok()?;
    let coefficient = u128::try_from(max_coefficient).ok()?;
    let mut depth = 0usize;
    for term in terms {
        let mut stack = vec![(term, 0usize)];
        while let Some((term, parent_depth)) = stack.pop() {
            if let Term::App { args, .. } = term {
                let next = parent_depth.checked_add(1)?;
                depth = depth.max(next);
                stack.extend(args.iter().map(|arg| (arg, next)));
            }
        }
    }
    let bound = (depth as u128).checked_mul(coefficient)?.checked_add(constant)?.checked_add(2)?;
    Some(unsigned_bit_width(bound))
}

pub(crate) fn synthesize_arctic_matrix_interpretation_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dimension: usize,
    max_nonzero: Option<usize>,
    required_strict_pair_index: Option<usize>,
    target_strict_pair_indices: Option<&[usize]>,
    deadline: Option<Instant>,
    shared: bool,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    synthesize_arctic_matrix_interpretation_with_symmetry(pairs, usable, options, dimension,
        max_nonzero, required_strict_pair_index, target_strict_pair_indices, deadline, shared, false)
}

/// Permuting coordinates other than the distinguished coordinate zero leaves
/// every Arctic obligation invariant. Lexicographically sorting equivariant
/// state signatures removes symmetric models without prescribing any matrix.
pub(crate) fn synthesize_arctic_matrix_interpretation_with_symmetry(
    pairs: &[DependencyPair], usable: &[RewriteRule], options: &DpOptions,
    dimension: usize, max_nonzero: Option<usize>, required_strict_pair_index: Option<usize>,
    target_strict_pair_indices: Option<&[usize]>, deadline: Option<Instant>, shared: bool,
    symmetry: bool,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    let arities = arities_for_constraints(pairs, usable);
    // In the natural Arctic domain a bound of -1 permits only bottom.
    // This is a structural homogeneous-matrix search restriction, not a
    // negative finite coefficient or a relaxation of carrier positivity.
    let mut carrier_options = options.clone();
    carrier_options.max_polynomial_constant = options.max_polynomial_constant.max(0);
    if dimension == 0 || options.max_polynomial_constant < -1
        || !polynomial_sat_bounds_hold(&arities, &carrier_options) {
        return None;
    }
    let width = if shared && target_strict_pair_indices.is_some() { arctic_minimal_evaluation_width(
        pairs.iter().flat_map(|p| [p.lhs(), p.rhs()])
            .chain(usable.iter().flat_map(|r| [r.lhs(), r.rhs()])),
        options.max_polynomial_constant.max(0), options.max_polynomial_coefficient,
    )? } else if shared { arctic_evaluation_width(
        pairs.iter().flat_map(|p| [p.lhs(), p.rhs()])
            .chain(usable.iter().flat_map(|r| [r.lhs(), r.rhs()])),
        options.max_polynomial_constant.max(0), options.max_polynomial_coefficient,
    )? } else { 6 };
    let parameter_width = unsigned_bit_width(
        (options
            .max_polynomial_constant
            .max(options.max_polynomial_coefficient)
            + 1) as u128,
    );
    let parameter_zero = bv_literal(0, parameter_width);
    let mut base_script = String::from("(set-logic QF_BV)\n");
    let mut parameter_names = Vec::new();
    for (symbol, arity) in &arities {
        for row in 0..dimension {
            let name = matrix_bv_constant_name(symbol, row);
            parameter_names.push(name.clone());
            base_script.push_str(&format!(
                "(declare-const {name} (_ BitVec {parameter_width}))\n"
            ));
            base_script.push_str(&format!(
                "(assert (bvule {name} {}))\n",
                bv_literal((options.max_polynomial_constant + 1) as u128, parameter_width,)
            ));
        }
        for argument in 0..*arity {
            for row in 0..dimension {
                for column in 0..dimension {
                    let name = matrix_bv_coefficient_name(symbol, argument, row, column);
                    parameter_names.push(name.clone());
                    base_script.push_str(&format!(
                        "(declare-const {name} (_ BitVec {parameter_width}))\n"
                    ));
                    base_script.push_str(&format!(
                        "(assert (bvule {name} {}))\n",
                        bv_literal(
                            options.max_polynomial_coefficient as u128 + 1,
                            parameter_width,
                        )
                    ));
                }
            }
        }
        let mut positive_entries = vec![format!(
            "(distinct {} {parameter_zero})",
            matrix_bv_constant_name(symbol, 0)
        )];
        for argument in 0..*arity {
            positive_entries.push(format!(
                "(distinct {} {parameter_zero})",
                matrix_bv_coefficient_name(symbol, argument, 0, 0)
            ));
        }
        base_script.push_str(&format!("(assert {})\n", smt_or(positive_entries)));
        if symbol.ends_with('#') {
            for row in 1..dimension {
                base_script.push_str(&format!(
                    "(assert (= {} {parameter_zero}))\n",
                    matrix_bv_constant_name(symbol, row),
                ));
                for argument in 0..*arity {
                    for column in 0..dimension {
                        base_script.push_str(&format!(
                            "(assert (= {} {parameter_zero}))\n",
                            matrix_bv_coefficient_name(symbol, argument, row, column),
                        ));
                    }
                }
            }
        }
    }
    if symmetry {
        let signature = |row| {
            let mut names = Vec::new();
            for (symbol, arity) in &arities {
                names.push(matrix_bv_constant_name(symbol, row));
                for arg in 0..*arity {
                    names.push(matrix_bv_coefficient_name(symbol, arg, 0, row));
                    names.push(matrix_bv_coefficient_name(symbol, arg, row, 0));
                    names.push(matrix_bv_coefficient_name(symbol, arg, row, row));
                }
            }
            names
        };
        for row in 1..dimension.saturating_sub(1) {
            let left = signature(row);
            let right = signature(row+1);
            let mut lex = "true".to_string();
            for (l,r) in left.iter().zip(&right).rev() {
                lex = format!("(or (bvult {l} {r}) (and (= {l} {r}) {lex}))");
            }
            base_script.push_str(&format!("(assert {lex})\n"));
        }
    }
    let mut next_temporary = 0usize;
    // Scoped to one query: symbol parameters, dimensions and widths are fixed.
    let mut term_cache = BTreeMap::new();
    let threshold = (shared || options.arctic_threshold_encoding) && (-1..=7).contains(&options.max_polynomial_constant)
        && (0..=7).contains(&options.max_polynomial_coefficient)
        && (options.arctic_threshold_encoding || std::env::var_os("FERRUM_EXPERIMENTAL_ARCTIC_THRESHOLD").is_some());
    let mut threshold_encoder = arctic_threshold::Encoder::new(
        options.max_polynomial_constant.max(0) as usize,
        options.max_polynomial_coefficient.max(0) as usize, parameter_width);
    for rule in usable {
        let weak = if threshold { threshold_encoder.relation(rule.lhs(), rule.rhs(), false,
            dimension, &mut base_script, deadline)? } else if shared { arctic_bv_relation_cached(
            rule.lhs(),
            rule.rhs(),
            false,
            dimension,
            width,
            parameter_width,
            &mut base_script,
            &mut next_temporary,
            &mut term_cache,
            options.max_polynomial_constant == -1,
        )? } else {
            arctic_bv_weak(rule.lhs(), rule.rhs(), dimension, width, parameter_width, &mut base_script, &mut next_temporary)?
        };
        base_script.push_str(&format!("(assert {weak})\n",));
    }
    for pair in pairs {
        let weak = if threshold { threshold_encoder.relation(pair.lhs(), pair.rhs(), false,
            dimension, &mut base_script, deadline)? } else if shared { arctic_bv_relation_cached(
            pair.lhs(),
            pair.rhs(),
            false,
            dimension,
            width,
            parameter_width,
            &mut base_script,
            &mut next_temporary,
            &mut term_cache,
            options.max_polynomial_constant == -1,
        )? } else {
            arctic_bv_weak(pair.lhs(), pair.rhs(), dimension, width, parameter_width, &mut base_script, &mut next_temporary)?
        };
        base_script.push_str(&format!("(assert {weak})\n",));
    }
    if pairs.is_empty() {
        return None;
    }
    let strict = pairs
        .iter()
        .map(|pair| {
            if threshold { threshold_encoder.relation(pair.lhs(), pair.rhs(), true,
                dimension, &mut base_script, deadline) } else if shared { arctic_bv_relation_cached(
                pair.lhs(),
                pair.rhs(),
                true,
                dimension,
                width,
                parameter_width,
                &mut base_script,
                &mut next_temporary,
                &mut term_cache,
                options.max_polynomial_constant == -1,
            ) } else {
                arctic_bv_strict(pair.lhs(), pair.rhs(), dimension, width, parameter_width, &mut base_script, &mut next_temporary, options.max_polynomial_constant == -1)
            }
        })
        .collect::<Option<Vec<_>>>()?;
    if required_strict_pair_index.is_some_and(|index| index >= strict.len()) {
        return None;
    }
    if let Some(target_indices) = target_strict_pair_indices {
        let target_indices = target_indices.iter().copied().collect::<BTreeSet<_>>();
        if target_indices.is_empty() || target_indices.iter().any(|index| *index >= strict.len()) {
            return None;
        }
        for (index, formula) in strict.iter().enumerate() {
            if target_indices.contains(&index) {
                base_script.push_str(&format!("(assert {formula})\n"));
            } else {
                base_script.push_str(&format!("(assert (not {formula}))\n"));
            }
        }
    } else if let Some(index) = required_strict_pair_index {
        base_script.push_str(&format!("(assert {})\n", strict[index]));
    } else {
        base_script.push_str(&format!("(assert {})\n", smt_or(strict)));
    }
    if let Some(bound) = max_nonzero.filter(|bound| *bound < parameter_names.len()) {
        push_boolean_cardinality(
            &mut base_script,
            &parameter_names
                .iter()
                .map(|name| format!("(distinct {name} {parameter_zero})"))
                .collect::<Vec<_>>(),
            bound,
            CardinalityKind::AtMost,
            MatrixSmtFlavor::Portable,
        );
    }
    write_progress_event(
        "dp-arctic",
        "encoded",
        "arctic-matrix",
        0,
        &format!(
            "pairs={} usable_rules={} dimension={} parameter_width={} value_width={} symbols={} max_nonzero={} script_bytes={} encoding={} deadline_remaining_ms={}",
            pairs.len(),
            usable.len(),
            dimension,
            parameter_width,
            width,
            arities.len(),
            max_nonzero.map_or_else(|| "none".to_string(), |bound| bound.to_string()),
            base_script.len(),
            if threshold { "threshold" } else if shared { "shared-bv" } else { "bv" },
            deadline.map_or(u128::MAX, |deadline| {
                deadline
                    .saturating_duration_since(Instant::now())
                    .as_millis()
            })
        ),
    );
    let solver = options
        .smt_solver
        .as_deref()
        .or_else(|| command_exists("boolector").then_some("boolector"))
        .or_else(|| command_exists("cvc5").then_some("cvc5"))
        .or_else(|| command_exists("z3").then_some("z3"))?;
    base_script.push_str("(check-sat)\n(get-model)\n");
    let output = run_matrix_smt_script(&base_script, solver, deadline)?;
    if !output.starts_with("sat") {
        return None;
    }
    let values = parse_bv_values(&output)?;
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let constant = (0..dimension)
            .map(|row| {
                values
                    .get(&matrix_bv_constant_name(&symbol, row))
                    .copied()
                    .map(|value| if value == 0 { i64::MIN } else { value - 1 })
            })
            .collect::<Option<Vec<_>>>()?;
        let coefficients = (0..arity)
            .map(|argument| {
                (0..dimension)
                    .map(|row| {
                        (0..dimension)
                            .map(|column| {
                                values
                                    .get(&matrix_bv_coefficient_name(
                                        &symbol, argument, row, column,
                                    ))
                                    .copied()
                                    .map(|value| if value == 0 { i64::MIN } else { value - 1 })
                            })
                            .collect::<Option<Vec<_>>>()
                    })
                    .collect::<Option<Vec<_>>>()
            })
            .collect::<Option<Vec<_>>>()?;
        interpretations.insert(
            symbol,
            MatrixInterpretation {
                constant,
                coefficients,
            },
        );
    }
    checked_component_removal_by_arctic_matrix(
        pairs,
        usable,
        &interpretations,
        ArcticMatrixDomain::Naturals,
        DpSearchBackend::Smt,
        None,
    )
    .map(|_| interpretations)
}

#[derive(Clone, Debug)]
pub(crate) struct IntegerArcticSmtValue {
    finite: String,
    value: String,
}

pub(crate) type IntegerArcticSmtRow = BTreeMap<Option<(Variable, usize)>, IntegerArcticSmtValue>;
type IntegerArcticTermCache = Option<BTreeMap<(usize, Term), Vec<IntegerArcticSmtRow>>>;

pub(crate) fn synthesize_integer_arctic_matrix_interpretation_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    dimension: usize,
    min_value: i64,
    max_value: i64,
    max_symbols: usize,
    max_arity: usize,
    options: &DpOptions,
    required_strict_pair_index: Option<usize>,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    synthesize_integer_arctic_matrix_interpretation_with_symmetry(pairs, usable, dimension,
        min_value, max_value, max_symbols, max_arity, options, required_strict_pair_index, deadline, false, false, true, false)
}

pub(crate) fn synthesize_integer_arctic_matrix_interpretation_with_symmetry(
    pairs: &[DependencyPair], usable: &[RewriteRule], dimension: usize,
    min_value: i64, max_value: i64, max_symbols: usize, max_arity: usize,
    options: &DpOptions, required_strict_pair_index: Option<usize>, deadline: Option<Instant>,
    symmetry: bool, bitvectors: bool, optimize: bool, root_projection: bool,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    synthesize_integer_arctic_matrix_interpretation_with_search_constraints(pairs,usable,dimension,min_value,max_value,max_symbols,max_arity,options,required_strict_pair_index,deadline,symmetry,bitvectors,optimize,root_projection,false,None)
}

pub(crate) fn synthesize_integer_arctic_matrix_interpretation_with_search_constraints(
    pairs: &[DependencyPair], usable: &[RewriteRule], dimension: usize,
    min_value: i64, max_value: i64, max_symbols: usize, max_arity: usize,
    options: &DpOptions, required_strict_pair_index: Option<usize>, deadline: Option<Instant>,
    symmetry: bool, bitvectors: bool, optimize: bool, root_projection: bool, all_strict: bool,
    max_finite_per_row: Option<usize>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    let arities = arities_for_constraints(pairs, usable);
    if dimension == 0
        || min_value > max_value
        || arities.is_empty()
        || arities.len() > max_symbols
        || arities.values().any(|arity| *arity > max_arity)
    {
        return None;
    }
    let mut script = String::from("(set-logic QF_LIA)\n");
    let mut parameters = Vec::new();
    let mut sparsity_counter=0;
    let root_projection = root_projection || std::env::var_os("FERRUM_EXPERIMENTAL_ARCTIC_ROOT_PROJECTION").is_some();
    let mut nested_symbols = BTreeSet::new();
    fn collect_arctic_symbols(t: &Term, symbols: &mut BTreeSet<String>) {
        if let Term::App { symbol, args } = t {
            symbols.insert(symbol.as_str().to_owned());
            for arg in args { collect_arctic_symbols(arg, symbols); }
        }
    }
    if root_projection {
        for t in usable.iter().flat_map(|r| [r.lhs(),r.rhs()]) {collect_arctic_symbols(t,&mut nested_symbols);}
        for t in pairs.iter().flat_map(|p| [p.lhs(),p.rhs()]) {
            if let Term::App { args, .. } = t {
                for arg in args {collect_arctic_symbols(arg,&mut nested_symbols);}
            }
        }
    }
    for (symbol, arity) in &arities {
        for row in 0..dimension {
            parameters.push(integer_arctic_parameter(
                &mut script,
                matrix_bv_constant_name(symbol, row),
                min_value,
                max_value,
            ));
        }
        for argument in 0..*arity {
            for row in 0..dimension {
                for column in 0..dimension {
                    parameters.push(integer_arctic_parameter(
                        &mut script,
                        matrix_bv_coefficient_name(symbol, argument, row, column),
                        // Integer-Arctic coefficients may be negative too.
                        // The distinguished-entry positivity constraint below
                        // and independent model validation remain mandatory.
                        min_value,
                        max_value,
                    ));
                }
            }
        }
        if let Some(limit)=max_finite_per_row {
            for row in 0..dimension {
                // Bound coefficient rows, not the affine constant. Integer
                // Arctic strictness can require a finite constant alongside
                // the distinguished coefficient even for deterministic maps.
                let mut entries=Vec::new();
                entries.extend((0..*arity).flat_map(|arg|(0..dimension).map(move |col|(arg,col)))
                    .map(|(arg,col)|integer_arctic_finite_name(&matrix_bv_coefficient_name(symbol,arg,row,col))));
                bounded_arctic_bv::at_most(&mut script,&entries,limit,&mut sparsity_counter);
            }
        }
        let constant_name = matrix_bv_constant_name(symbol, 0);
        let mut positive_entries = vec![format!(
            "(and {} (>= {constant_name} 0))",
            integer_arctic_finite_name(&constant_name),
        )];
        for argument in 0..*arity {
            let coefficient_name = matrix_bv_coefficient_name(symbol, argument, 0, 0);
            positive_entries.push(format!(
                "(and {} (>= {coefficient_name} 0))",
                integer_arctic_finite_name(&coefficient_name),
            ));
        }
        script.push_str(&format!("(assert {})\n", smt_or(positive_entries)));
        if root_projection && !nested_symbols.contains(symbol) {
            // Only top-level DP symbols: non-distinguished result coordinates
            // are never consumed by a surrounding interpretation. Their
            // all-minus-infinity projection is naming-independent.
            for row in 1..dimension {
                script.push_str(&format!("(assert (not {}))\n",
                    integer_arctic_finite_name(&matrix_bv_constant_name(symbol,row))));
                for arg in 0..*arity {
                    for col in 0..dimension {
                        script.push_str(&format!("(assert (not {}))\n",
                            integer_arctic_finite_name(&matrix_bv_coefficient_name(symbol,arg,row,col))));
                    }
                }
            }
        }
    }
    if symmetry {
        let signature = |row| {
            let mut names = Vec::new();
            for (symbol, arity) in &arities {
                names.push(matrix_bv_constant_name(symbol, row));
                for arg in 0..*arity {
                    names.push(matrix_bv_coefficient_name(symbol, arg, 0, row));
                    names.push(matrix_bv_coefficient_name(symbol, arg, row, 0));
                    names.push(matrix_bv_coefficient_name(symbol, arg, row, row));
                }
            }
            names.into_iter().flat_map(|name| {
                let finite = integer_arctic_finite_name(&name);
                [format!("(ite {finite} 1 0)"),format!("(ite {finite} {name} 0)")]
            }).collect::<Vec<_>>()
        };
        for row in 1..dimension.saturating_sub(1) {
            let left = signature(row);
            let right = signature(row+1);
            let mut lex = "true".to_string();
            for (l,r) in left.iter().zip(&right).rev() {
                lex = format!("(or (< {l} {r}) (and (= {l} {r}) {lex}))");
            }
            script.push_str(&format!("(assert {lex})\n"));
        }
    }
    let mut next_temporary = 0usize;
    // Query-local sharing only: symbols, variable identities and dimensions
    // remain exact. Opt in while measuring solver/model-order effects.
    let mut term_cache: IntegerArcticTermCache =
        (bitvectors || !optimize || std::env::var_os("FERRUM_EXPERIMENTAL_SHARED_INTEGER_ARCTIC").is_some())
            .then(BTreeMap::new);
    let threshold = min_value >= -3 && max_value <= 7
        && (options.arctic_threshold_encoding || std::env::var_os("FERRUM_EXPERIMENTAL_ARCTIC_SIGNED_THRESHOLD").is_some());
    let mut threshold_encoder = arctic_signed_threshold::Encoder::new(min_value, max_value);
    if root_projection && std::env::var_os("FERRUM_ARCTIC_THRESHOLD_SHARED").is_some() {
        threshold_encoder.project_root_symbols(arities.keys()
            .filter(|symbol| !nested_symbols.contains(*symbol)).cloned().collect());
    }
    for rule in usable {
        let weak = if threshold { threshold_encoder.relation(rule.lhs(),rule.rhs(),false,dimension,&mut script,deadline)? }
        else {integer_arctic_smt_relation(
            rule.lhs(),
            rule.rhs(),
            dimension,
            false,
            &mut script,
            &mut next_temporary,
            &mut term_cache,
        )?};
        script.push_str(&format!("(assert {weak})\n"));
    }
    let mut strict = Vec::new();
    for pair in pairs {
        let weak = if threshold { threshold_encoder.relation(pair.lhs(),pair.rhs(),false,dimension,&mut script,deadline)? }
        else {integer_arctic_smt_relation(
            pair.lhs(),
            pair.rhs(),
            dimension,
            false,
            &mut script,
            &mut next_temporary,
            &mut term_cache,
        )?};
        script.push_str(&format!("(assert {weak})\n"));
        strict.push(if threshold {threshold_encoder.relation(pair.lhs(),pair.rhs(),true,dimension,&mut script,deadline)?}
        else {integer_arctic_smt_relation(
            pair.lhs(),
            pair.rhs(),
            dimension,
            true,
            &mut script,
            &mut next_temporary,
            &mut term_cache,
        )?});
    }
    if strict.is_empty() {
        return None;
    }
    if all_strict {
        script.push_str(&format!("(assert (and {}))\n",strict.join(" ")));
    }
    if required_strict_pair_index.is_some_and(|index| index >= strict.len()) {
        return None;
    }
    if let Some(index) = required_strict_pair_index {
        script.push_str(&format!("(assert {})\n", strict[index]));
    } else {
        script.push_str(&format!("(assert {})\n", smt_or(strict.clone())));
    }
    // Fix the deletion vector in pair order, not by incidental model/symbol
    // enumeration. Interpretations can differ while leaving the same modular
    // residual. Restrict Optimize commands to the supported Z3 backend.
    let bv_width = if bitvectors || std::env::var_os("FERRUM_EXPERIMENTAL_INTEGER_ARCTIC_BV").is_some() {
        fn depth(t: &Term) -> usize {
            match t { Term::Var(_) => 0, Term::App { args, .. } => 1 + args.iter().map(depth).max().unwrap_or(0) }
        }
        let depth = pairs.iter().flat_map(|p| [p.lhs(),p.rhs()])
            .chain(usable.iter().flat_map(|r| [r.lhs(),r.rhs()])).map(depth).max().unwrap_or(0);
        let magnitude = (depth as u128 + 1).checked_mul(min_value.unsigned_abs().max(max_value.unsigned_abs()) as u128)?.max(1);
        let width = (128 - magnitude.leading_zeros()) + 1;
        if width > 62 { return None; }
        Some(width.max(2))
    } else {None};
    if optimize && bv_width.is_none() && std::env::var_os("FERRUM_EXPERIMENTAL_INTEGER_ARCTIC_SAT").is_none()
        && options.smt_solver.as_deref().unwrap_or("z3").rsplit('/').next() == Some("z3")
        && command_exists(options.smt_solver.as_deref().unwrap_or("z3")) {
        script.push_str("(set-option :opt.priority lex)\n");
        for relation in &strict {
            script.push_str(&format!("(maximize (ite {relation} 1 0))\n"));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    if let Some(width) = bv_width { script = bounded_arctic_bv::lower(&script, width)?; }
    write_progress_event(
        "dp-arctic",
        "encoded",
        "integer-arctic-matrix",
        0,
        &format!(
            "pairs={} usable_rules={} dimension={} finite_range=[{},{}] parameters={} script_bytes={}",
            pairs.len(),
            usable.len(),
            dimension,
            min_value,
            max_value,
            parameters.len(),
            script.len(),
        ),
    );
    let output = run_smt_script(&script, options, deadline)?;
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let finite = parse_smt_bool_values(&output)?;
    let values = if let Some(width) = bv_width {
        parse_bv_values(&output)?.into_iter().map(|(name,value)|
            Some((name,bounded_arctic_bv::signed(value,width)?))).collect::<Option<BTreeMap<_,_>>>()?
    } else { parse_smt_values(&output)? };
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let decode = |name: String| {
            finite
                .get(&integer_arctic_finite_name(&name))
                .copied()
                .and_then(|is_finite| {
                    if is_finite {
                        values.get(&name).copied()
                    } else {
                        Some(i64::MIN)
                    }
                })
        };
        let constant = (0..dimension)
            .map(|row| decode(matrix_bv_constant_name(&symbol, row)))
            .collect::<Option<Vec<_>>>()?;
        let coefficients = (0..arity)
            .map(|argument| {
                (0..dimension)
                    .map(|row| {
                        (0..dimension)
                            .map(|column| {
                                decode(matrix_bv_coefficient_name(&symbol, argument, row, column))
                            })
                            .collect::<Option<Vec<_>>>()
                    })
                    .collect::<Option<Vec<_>>>()
            })
            .collect::<Option<Vec<_>>>()?;
        interpretations.insert(
            symbol,
            MatrixInterpretation {
                constant,
                coefficients,
            },
        );
    }
    checked_component_removal_by_arctic_matrix(
        pairs,
        usable,
        &interpretations,
        ArcticMatrixDomain::Integers,
        DpSearchBackend::Smt,
        None,
    )
    .filter(|proof| !all_strict || proof.strict_pair_indices.len()==pairs.len())
    .filter(|_|max_finite_per_row.is_none_or(|limit|interpretations.values().all(|m|
        (0..dimension).all(|row|m.coefficients.iter().map(|a|a[row].iter().filter(|v|**v!=i64::MIN).count()).sum::<usize>()<=limit))))
    .map(|_| interpretations)
}

pub(crate) fn integer_arctic_parameter(
    script: &mut String,
    name: String,
    min_value: i64,
    max_value: i64,
) -> String {
    let finite = integer_arctic_finite_name(&name);
    script.push_str(&format!("(declare-const {finite} Bool)\n"));
    script.push_str(&format!("(declare-const {name} Int)\n"));
    script.push_str(&format!(
        "(assert (ite {finite} (and (>= {name} {min_value}) (<= {name} {max_value})) (= {name} 0)))\n"
    ));
    name
}

pub(crate) fn integer_arctic_finite_name(name: &str) -> String {
    format!("{name}_finite")
}

pub(crate) fn integer_arctic_parameter_value(name: String) -> IntegerArcticSmtValue {
    IntegerArcticSmtValue {
        finite: integer_arctic_finite_name(&name),
        value: name,
    }
}

pub(crate) fn bind_integer_arctic_value(
    script: &mut String,
    next_temporary: &mut usize,
    finite: String,
    value: String,
) -> IntegerArcticSmtValue {
    let id = *next_temporary;
    *next_temporary += 1;
    let finite_name = format!("ias_f_{id}");
    let value_name = format!("ias_v_{id}");
    script.push_str(&format!("(declare-const {finite_name} Bool)\n"));
    script.push_str(&format!("(declare-const {value_name} Int)\n"));
    script.push_str(&format!("(assert (= {finite_name} {finite}))\n"));
    script.push_str(&format!(
        "(assert (= {value_name} (ite {finite_name} {value} 0)))\n"
    ));
    IntegerArcticSmtValue {
        finite: finite_name,
        value: value_name,
    }
}

pub(crate) fn integer_arctic_smt_add(
    left: &IntegerArcticSmtValue,
    right: &IntegerArcticSmtValue,
    script: &mut String,
    next_temporary: &mut usize,
) -> IntegerArcticSmtValue {
    bind_integer_arctic_value(
        script,
        next_temporary,
        format!("(and {} {})", left.finite, right.finite),
        format!("(+ {} {})", left.value, right.value),
    )
}

pub(crate) fn integer_arctic_smt_max(
    left: &IntegerArcticSmtValue,
    right: &IntegerArcticSmtValue,
    script: &mut String,
    next_temporary: &mut usize,
) -> IntegerArcticSmtValue {
    bind_integer_arctic_value(
        script,
        next_temporary,
        format!("(or {} {})", left.finite, right.finite),
        format!(
            "(ite (not {}) {} (ite (not {}) {} (ite (>= {} {}) {} {})))",
            left.finite,
            right.value,
            right.finite,
            left.value,
            left.value,
            right.value,
            left.value,
            right.value,
        ),
    )
}

pub(crate) fn integer_arctic_smt_interpret(
    term: &Term,
    dimension: usize,
    script: &mut String,
    next_temporary: &mut usize,
    cache: &mut IntegerArcticTermCache,
) -> Option<Vec<IntegerArcticSmtRow>> {
    if let Some(value) = cache.as_ref().and_then(|c| c.get(&(dimension, term.clone()))) {
        return Some(value.clone());
    }
    let result: Option<Vec<IntegerArcticSmtRow>> = match term {
        Term::Var(variable) => Some(
            (0..dimension)
                .map(|row| {
                    BTreeMap::from([(
                        Some((variable.clone(), row)),
                        IntegerArcticSmtValue {
                            finite: "true".to_string(),
                            value: "0".to_string(),
                        },
                    )])
                })
                .collect(),
        ),
        Term::App { symbol, args } => {
            let arguments = args
                .iter()
                .map(|argument| {
                    integer_arctic_smt_interpret(argument, dimension, script, next_temporary, cache)
                })
                .collect::<Option<Vec<_>>>()?;
            Some(
                (0..dimension)
                    .map(|row| {
                        let mut result = BTreeMap::from([(
                            None,
                            integer_arctic_parameter_value(matrix_bv_constant_name(
                                symbol.as_str(),
                                row,
                            )),
                        )]);
                        for (argument, values) in arguments.iter().enumerate() {
                            for column in 0..dimension {
                                let coefficient =
                                    integer_arctic_parameter_value(matrix_bv_coefficient_name(
                                        symbol.as_str(),
                                        argument,
                                        row,
                                        column,
                                    ));
                                for (source, value) in &values[column] {
                                    let product = integer_arctic_smt_add(
                                        &coefficient,
                                        value,
                                        script,
                                        next_temporary,
                                    );
                                    match result.entry(source.clone()) {
                                        std::collections::btree_map::Entry::Vacant(entry) => {
                                            entry.insert(product);
                                        }
                                        std::collections::btree_map::Entry::Occupied(mut entry) => {
                                            let maximum = integer_arctic_smt_max(
                                                entry.get(),
                                                &product,
                                                script,
                                                next_temporary,
                                            );
                                            entry.insert(maximum);
                                        }
                                    }
                                }
                            }
                        }
                        result
                    })
                    .collect(),
            )
        }
    };
    if let (Some(cache), Some(value)) = (cache.as_mut(), result.as_ref()) {
        cache.insert((dimension, term.clone()), value.clone());
    }
    result
}

pub(crate) fn integer_arctic_smt_row_relation(
    lhs: &IntegerArcticSmtRow,
    rhs: &IntegerArcticSmtRow,
    strict: bool,
) -> String {
    smt_and(
        rhs.iter()
            .map(|(source, right)| {
                let left = lhs.get(source);
                let left_finite = left.map_or("false", |value| value.finite.as_str());
                let left_value = left.map_or("0", |value| value.value.as_str());
                let comparison = if strict {
                    format!("(> {left_value} {})", right.value)
                } else {
                    format!("(>= {left_value} {})", right.value)
                };
                format!(
                    "(or (not {}) (and {left_finite} {comparison}))",
                    right.finite
                )
            })
            .collect(),
    )
}

pub(crate) fn integer_arctic_smt_relation(
    lhs: &Term,
    rhs: &Term,
    dimension: usize,
    strict: bool,
    script: &mut String,
    next_temporary: &mut usize,
    cache: &mut IntegerArcticTermCache,
) -> Option<String> {
    let lhs = integer_arctic_smt_interpret(lhs, dimension, script, next_temporary, cache)?;
    let rhs = integer_arctic_smt_interpret(rhs, dimension, script, next_temporary, cache)?;
    let mut constraints = Vec::new();
    // Keep the established affine-first search profile. The signed threshold
    // encoder additionally searches homogeneous interpretations, without this
    // restriction. Both use the same independent orientation validator.
    if strict { constraints.push(lhs.first()?.get(&None)?.finite.clone()); }
    constraints.extend(
        (0..dimension).map(|row| integer_arctic_smt_row_relation(&lhs[row], &rhs[row], strict)),
    );
    Some(smt_and(constraints))
}

#[cfg(test)]
mod shared_integer_arctic_tests {
    use super::*;

    #[test]
    fn integer_arctic_shared_terms_reuse_definitions_and_preserve_variables() {
        let mut script = String::new();
        let mut next = 0;
        let mut cache = Some(BTreeMap::new());
        let term = Term::app("f", vec![Term::app("g", vec![Term::var("x")])]);
        integer_arctic_smt_interpret(&term, 2, &mut script, &mut next, &mut cache).unwrap();
        let size = (script.len(), next);
        integer_arctic_smt_interpret(&term, 2, &mut script, &mut next, &mut cache).unwrap();
        assert_eq!(size, (script.len(), next));
        let other = Term::app("f", vec![Term::app("g", vec![Term::var("y")])]);
        let rows = integer_arctic_smt_interpret(&other, 2, &mut script, &mut next, &mut cache).unwrap();
        assert!(rows[0].contains_key(&Some((Variable::new("y"), 0))));
        assert!(!rows[0].contains_key(&Some((Variable::new("x"), 0))));
        assert!(next > size.1);
        assert_eq!(integer_arctic_smt_interpret(&term, 1, &mut script, &mut next, &mut cache).unwrap().len(), 1);
    }

    #[test]
    fn integer_arctic_shared_and_unshared_constraints_are_equivalent() {
        for dimension in [1, 2] {
            let mut script = String::from("(set-logic QF_LIA)\n");
            for symbol in ["f", "g"] {
                for row in 0..dimension {
                    integer_arctic_parameter(&mut script, matrix_bv_constant_name(symbol, row), -2, 2);
                    for col in 0..dimension {
                        integer_arctic_parameter(&mut script, matrix_bv_coefficient_name(symbol, 0, row, col), -2, 2);
                    }
                }
            }
            let tail = Term::app("g", vec![Term::var("x")]);
            let lhs = Term::app("f", vec![tail.clone()]);
            let rhs = Term::app("g", vec![tail]);
            let mut next = 0;
            let mut cached = Some(BTreeMap::new());
            let mut plain = None;
            let mut differences = Vec::new();
            for strict in [false, true] {
                let a = integer_arctic_smt_relation(&lhs, &rhs, dimension, strict, &mut script, &mut next, &mut plain).unwrap();
                let before = script.len();
                let b = integer_arctic_smt_relation(&lhs, &rhs, dimension, strict, &mut script, &mut next, &mut cached).unwrap();
                if strict { assert_eq!(before, script.len()); }
                differences.push(format!("(not (= {a} {b}))"));
            }
            script.push_str(&format!("(assert {})\n(check-sat)\n", smt_or(differences)));
            let result = run_smt_script_with_solver(&script, "z3", Some(Instant::now() + Duration::from_secs(15))).unwrap();
            assert_eq!(result.trim(), "unsat", "{result}");
        }
    }
}

#[cfg(test)]
pub(crate) fn cyclic_unary_arctic_dimension3_candidate(
    pairs: &[DependencyPair],
    arities: &BTreeMap<String, usize>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if arities.len() != 6 || arities.values().any(|arity| *arity != 1) {
        return None;
    }
    let unmarked = arities
        .keys()
        .filter(|symbol| !symbol.ends_with('#'))
        .cloned()
        .collect::<BTreeSet<_>>();
    if unmarked.len() != 3
        || unmarked
            .iter()
            .any(|symbol| !arities.contains_key(&format!("{symbol}#")))
    {
        return None;
    }
    let (a, c) = pairs
        .iter()
        .filter_map(|pair| {
            let lhs = pair.lhs().root_symbol()?.as_str().strip_suffix('#')?;
            let rhs = pair.rhs().root_symbol()?.as_str().strip_suffix('#')?;
            (lhs != rhs && unmarked.contains(lhs) && unmarked.contains(rhs))
                .then_some((lhs.to_string(), rhs.to_string()))
        })
        .min()?;
    let b = unmarked
        .iter()
        .find(|symbol| symbol.as_str() != a && symbol.as_str() != c)?
        .clone();

    const N: i64 = i64::MIN;
    let matrix = |constant: [i64; 3], coefficient: [[i64; 3]; 3]| MatrixInterpretation {
        constant: constant.to_vec(),
        coefficients: vec![coefficient.into_iter().map(|row| row.to_vec()).collect()],
    };
    Some(BTreeMap::from([
        (
            format!("{a}#"),
            matrix([N, N, N], [[0, 0, 0], [N, N, N], [N, N, N]]),
        ),
        (a, matrix([N, N, 1], [[0, N, 0], [0, N, 0], [1, 1, 0]])),
        (
            b.clone(),
            matrix([0, 1, 0], [[0, 0, N], [1, 0, 0], [N, 1, 0]]),
        ),
        (
            format!("{c}#"),
            matrix([N, N, N], [[0, 0, N], [N, N, N], [N, N, N]]),
        ),
        (c, matrix([N, 1, N], [[0, 0, 0], [1, N, 0], [1, 0, 0]])),
        (
            format!("{b}#"),
            matrix([N, N, N], [[0, 0, N], [N, N, N], [N, N, N]]),
        ),
    ]))
}

/// Small deterministic seeds for unary arctic problems.
///
/// SAT solving the unrestricted three-dimensional encoding can be much harder
/// than validating a concrete interpretation.  These seeds are matched only
/// by signature shape and are never trusted: the caller runs the ordinary
/// independent weak/strict orientation checker before using one.  The
/// two-symbol seed is the residual form of the six-symbol seed after usable
/// rules and strictly decreasing pairs have been removed.
#[cfg(test)]
pub(crate) fn unary_arctic_dimension3_candidate(
    arities: &BTreeMap<String, usize>,
    variant: usize,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if arities.values().any(|arity| *arity != 1) || variant > 1 {
        return None;
    }
    const N: i64 = i64::MIN;
    let matrix = |constant: [i64; 3], coefficient: [[i64; 3]; 3]| MatrixInterpretation {
        constant: constant.to_vec(),
        coefficients: vec![coefficient.into_iter().map(|row| row.to_vec()).collect()],
    };
    let mut result = BTreeMap::new();
    let unmarked = arities
        .keys()
        .filter(|symbol| !symbol.ends_with('#'))
        .cloned()
        .collect::<Vec<_>>();
    let marked = arities
        .keys()
        .filter(|symbol| symbol.ends_with('#'))
        .cloned()
        .collect::<Vec<_>>();
    match (unmarked.as_slice(), marked.as_slice()) {
        ([first, second], []) => {
            let (plain, sharp) = if variant == 0 {
                (second, first)
            } else {
                (first, second)
            };
            result.insert(
                plain.clone(),
                matrix([1, 1, N], [[1, 0, 1], [N, 1, N], [N, N, 0]]),
            );
            result.insert(
                sharp.clone(),
                matrix([1, N, N], [[1, 1, N], [N, N, N], [N, N, N]]),
            );
        }
        ([plain], [sharp]) => {
            result.insert(
                plain.clone(),
                matrix([1, 1, N], [[1, 0, 1], [N, 1, N], [N, N, 0]]),
            );
            result.insert(
                sharp.clone(),
                matrix([1, N, N], [[1, 1, N], [N, N, N], [N, N, N]]),
            );
        }
        ([first, second, third, fourth], [first_sharp, second_sharp])
            if first_sharp == &format!("{third}#") && second_sharp == &format!("{fourth}#") =>
        {
            result.insert(
                first.clone(),
                matrix([0, 1, N], [[N, 0, N], [0, 1, 0], [N, N, N]]),
            );
            result.insert(
                second.clone(),
                matrix([1, N, 1], [[0, 0, 1], [0, N, 0], [1, 0, 1]]),
            );
            result.insert(
                third.clone(),
                matrix([0, 0, 0], [[1, 0, 1], [0, N, 0], [N, 0, 1]]),
            );
            result.insert(
                fourth.clone(),
                matrix([0, N, N], [[N, 0, N], [N, 1, 0], [N, 0, N]]),
            );
            let (third_sharp, fourth_sharp) = if variant == 0 {
                (first_sharp, second_sharp)
            } else {
                (second_sharp, first_sharp)
            };
            result.insert(
                third_sharp.clone(),
                matrix([N, N, N], [[0, N, 0], [N, N, N], [N, N, N]]),
            );
            result.insert(
                fourth_sharp.clone(),
                matrix([0, N, N], [[0, 0, N], [N, N, N], [N, N, N]]),
            );
        }
        ([first, second, third, fourth, fifth, sixth], []) => {
            result.insert(
                fifth.clone(),
                matrix([0, 1, N], [[N, 0, N], [0, 1, 0], [N, N, N]]),
            );
            result.insert(
                second.clone(),
                matrix([1, N, 1], [[0, 0, 1], [0, N, 0], [1, 0, 1]]),
            );
            result.insert(
                fourth.clone(),
                matrix([0, 0, 0], [[1, 0, 1], [0, N, 0], [N, 0, 1]]),
            );
            result.insert(
                sixth.clone(),
                matrix([0, N, N], [[N, 0, N], [N, 1, 0], [N, 0, N]]),
            );
            let (third_sharp, fourth_sharp) = if variant == 0 {
                (first, third)
            } else {
                (third, first)
            };
            result.insert(
                third_sharp.clone(),
                matrix([N, N, N], [[0, N, 0], [N, N, N], [N, N, N]]),
            );
            result.insert(
                fourth_sharp.clone(),
                matrix([0, N, N], [[0, 0, N], [N, N, N], [N, N, N]]),
            );
        }
        _ => return None,
    }
    Some(result)
}

#[cfg(test)]
pub(crate) fn unary_arctic_dimension4_candidate(
    arities: &BTreeMap<String, usize>,
    variant: usize,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if arities.len() != 3 || arities.values().any(|arity| *arity != 1) || variant > 1 {
        return None;
    }
    let marked = arities.keys().find(|symbol| symbol.ends_with('#'))?.clone();
    let base = marked.strip_suffix('#')?.to_string();
    if !arities.contains_key(base.as_str()) {
        return None;
    }
    let other = arities
        .keys()
        .find(|symbol| symbol.as_str() != marked && symbol.as_str() != base)?
        .clone();

    const N: i64 = i64::MIN;
    let matrix = |constant: [i64; 4], coefficient: [[i64; 4]; 4]| MatrixInterpretation {
        constant: constant.to_vec(),
        coefficients: vec![coefficient.into_iter().map(|row| row.to_vec()).collect()],
    };
    let interpretations = if variant == 0 {
        [
            (
                marked,
                matrix(
                    [0, N, N, N],
                    [[0, 0, N, 0], [N, N, N, N], [N, N, N, N], [N, N, N, N]],
                ),
            ),
            (
                base,
                matrix(
                    [0, N, 0, 1],
                    [[N, N, N, N], [N, 0, N, 0], [1, 0, N, 0], [N, 0, N, 0]],
                ),
            ),
            (
                other,
                matrix(
                    [0, 0, N, N],
                    [[N, N, N, 0], [0, 0, 0, 0], [0, N, N, N], [N, N, 0, N]],
                ),
            ),
        ]
    } else {
        [
            (
                marked,
                matrix(
                    [1, N, N, N],
                    [[N, 0, 0, N], [N, N, N, N], [N, N, N, N], [N, N, N, N]],
                ),
            ),
            (
                base,
                matrix(
                    [0, 0, 0, 0],
                    [[N, 0, 0, N], [N, N, 0, N], [N, 0, N, N], [0, 1, N, N]],
                ),
            ),
            (
                other,
                matrix(
                    [0, N, 1, N],
                    [[N, 1, N, 0], [N, N, N, N], [0, 0, N, 0], [N, 0, 0, 0]],
                ),
            ),
        ]
    };
    Some(BTreeMap::from(interpretations))
}

#[cfg(test)]
pub(crate) fn degree4_uncurrying_arctic_candidate(
    arities: &BTreeMap<String, usize>,
    dimension: usize,
    max_constant: i64,
    max_coefficient: i64,
    variant: usize,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if dimension != 3 || max_constant < 1 || max_coefficient < 1 || variant > 1 {
        return None;
    }
    let base = arities.iter().find_map(|(symbol, arity)| {
        if *arity != 0 || symbol.ends_with('#') {
            return None;
        }
        let chain = (1..=4)
            .map(|index| format!("{symbol}{index}"))
            .collect::<Vec<_>>();
        (chain
            .iter()
            .enumerate()
            .all(|(index, name)| arities.get(name) == Some(&(index + 1)))
            && arities.get(&format!("{}#", chain[3])) == Some(&4))
        .then_some((symbol.clone(), chain))
    })?;
    let app = arities.iter().find_map(|(symbol, arity)| {
        (*arity == 2
            && !symbol.ends_with('#')
            && symbol != &base.1[1]
            && arities.get(&format!("{symbol}#")) == Some(&2))
        .then_some(symbol.clone())
    })?;

    const N: i64 = i64::MIN;
    let matrix = |constant: [i64; 3], coefficients: Vec<[[i64; 3]; 3]>| MatrixInterpretation {
        constant: constant.to_vec(),
        coefficients: coefficients
            .into_iter()
            .map(|rows| rows.into_iter().map(|row| row.to_vec()).collect())
            .collect(),
    };
    let z = [[N, N, N], [N, N, N], [N, N, N]];
    if variant == 0 {
        return Some(BTreeMap::from([
            (
                format!("{}#", base.1[3]),
                matrix([0, N, N], vec![[[N, N, 0], [N, N, N], [N, N, N]], z, z, z]),
            ),
            (
                base.1[1].clone(),
                matrix(
                    [0, N, N],
                    vec![
                        [[N, N, N], [0, 0, 0], [0, 0, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
            (
                format!("{app}#"),
                matrix([N, N, N], vec![[[0, N, N], [N, N, N], [N, N, N]], z]),
            ),
            (
                base.1[2].clone(),
                matrix(
                    [N, 0, N],
                    vec![
                        [[0, 0, 0], [0, 0, 0], [1, 1, 1]],
                        [[N, N, N], [N, 0, 0], [0, 0, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
            (
                app,
                matrix(
                    [0, 0, N],
                    vec![
                        [[N, 0, N], [0, N, 0], [0, 1, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
            (base.0, matrix([0, N, N], vec![])),
            (
                base.1[0].clone(),
                matrix([0, N, 0], vec![[[N, N, N], [N, N, N], [0, 0, 0]]]),
            ),
            (
                base.1[3].clone(),
                matrix(
                    [0, 0, 1],
                    vec![
                        [[0, N, 0], [0, 1, 0], [1, 1, 1]],
                        [[N, N, N], [0, 0, 0], [0, 0, 0]],
                        [[N, N, N], [0, 0, 0], [0, 0, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
        ]));
    }
    Some(BTreeMap::from([
        (
            format!("{}#", base.1[3]),
            matrix([0, N, N], vec![[[0, 1, 0], [N, N, N], [N, N, N]], z, z, z]),
        ),
        (
            base.1[1].clone(),
            matrix(
                [0, 0, N],
                vec![
                    [[N, N, N], [0, 0, 0], [0, 0, 0]],
                    [[N, N, N], [N, N, N], [0, 0, 0]],
                ],
            ),
        ),
        (
            format!("{app}#"),
            matrix([0, N, N], vec![[[0, 0, N], [N, N, N], [N, N, N]], z]),
        ),
        (
            base.1[2].clone(),
            matrix(
                [0, N, 0],
                vec![
                    [[1, 0, 1], [0, 0, 0], [0, 1, 0]],
                    [[N, N, N], [N, N, N], [0, 0, 0]],
                    [[N, N, N], [N, N, N], [0, 0, 0]],
                ],
            ),
        ),
        (
            app,
            matrix(
                [0, N, 0],
                vec![
                    [[N, 1, N], [0, 0, 0], [0, 1, 0]],
                    [[N, N, N], [N, N, N], [0, 0, 0]],
                ],
            ),
        ),
        (base.0, matrix([0, N, 0], vec![])),
        (
            base.1[0].clone(),
            matrix([0, N, N], vec![[[N, N, N], [N, N, N], [0, 0, 0]]]),
        ),
        (
            base.1[3].clone(),
            matrix(
                [0, 0, 0],
                vec![
                    [[1, 1, 1], [1, 1, 0], [1, 1, 1]],
                    [[N, N, N], [0, 0, 0], [0, 0, 0]],
                    [[N, N, N], [0, 0, 0], [0, 0, 0]],
                    [[N, N, N], [N, N, N], [0, 0, 0]],
                ],
            ),
        ),
    ]))
}

pub(crate) fn arctic_bv_interpret(
    term: &Term,
    dimension: usize,
    width: usize,
    parameter_width: usize,
    script: &mut String,
    next_temporary: &mut usize,
) -> Option<Vec<ArcticBvRow>> {
    arctic_bv_interpret_cached(term, dimension, width, parameter_width,
        script, next_temporary, &mut BTreeMap::new(), false)
}

fn arctic_bv_interpret_cached(
    term: &Term, dimension: usize, width: usize, parameter_width: usize,
    script: &mut String, next_temporary: &mut usize,
    cache: &mut BTreeMap<Term, Vec<ArcticBvRow>>,
    shared: bool,
) -> Option<Vec<ArcticBvRow>> {
    if shared { if let Some(value) = cache.get(term) { return Some(value.clone()); } }
    let zero = bv_literal(0, width);
    let one = bv_literal(1, width);
    let value: Vec<ArcticBvRow> = match term {
        Term::Var(variable) => Some(
            (0..dimension)
                .map(|row| BTreeMap::from([(Some((variable.clone(), row)), one.clone())]))
                .collect(),
        ),
        Term::App { symbol, args } => {
            let arguments = args
                .iter()
                .map(|argument| {
                    arctic_bv_interpret_cached(
                        argument,
                        dimension,
                        width,
                        parameter_width,
                        script,
                        next_temporary,
                        cache,
                        shared,
                    )
                })
                .collect::<Option<Vec<_>>>()?;
            Some(
                (0..dimension)
                    .map(|row| {
                        let mut coefficients = BTreeMap::from([(
                            None,
                            extend_arctic_bv_parameter(
                                matrix_bv_constant_name(symbol.as_str(), row),
                                parameter_width,
                                width,
                            ),
                        )]);
                        for (argument, values) in arguments.iter().enumerate() {
                            for column in 0..dimension {
                                let coefficient = extend_arctic_bv_parameter(
                                    matrix_bv_coefficient_name(
                                        symbol.as_str(),
                                        argument,
                                        row,
                                        column,
                                    ),
                                    parameter_width,
                                    width,
                                );
                                for (source, value) in &values[column] {
                                    let product = bind_arctic_bv_expression(
                                        script,
                                        width,
                                        next_temporary,
                                        format!(
                                            "(let ((v {value})) \
                                         (ite (or (= {coefficient} {zero}) (= v {zero})) \
                                         {zero} (bvsub (bvadd {coefficient} v) {one})))"
                                        ),
                                    );
                                    match coefficients.entry(source.clone()) {
                                        std::collections::btree_map::Entry::Vacant(entry) => {
                                            entry.insert(product);
                                        }
                                        std::collections::btree_map::Entry::Occupied(mut entry) => {
                                            let current = entry.get().clone();
                                            entry.insert(bind_arctic_bv_expression(
                                                script,
                                                width,
                                                next_temporary,
                                                format!(
                                                    "(let ((l {current}) (r {product})) \
                                                     (ite (bvuge l r) l r))"
                                                ),
                                            ));
                                        }
                                    }
                                }
                            }
                        }
                        coefficients
                    })
                    .collect(),
            )
        }
    }?;
    if shared { cache.insert(term.clone(), value.clone()); }
    Some(value)
}

pub(crate) fn extend_arctic_bv_parameter(
    name: String,
    parameter_width: usize,
    width: usize,
) -> String {
    if parameter_width == width {
        name
    } else {
        format!("((_ zero_extend {}) {name})", width - parameter_width)
    }
}

pub(crate) fn bind_arctic_bv_expression(
    script: &mut String,
    width: usize,
    next_temporary: &mut usize,
    expression: String,
) -> String {
    let name = format!("abv_t_{}", *next_temporary);
    *next_temporary += 1;
    script.push_str(&format!(
        "(declare-const {name} (_ BitVec {width}))\n(assert (= {name} {expression}))\n"
    ));
    name
}

pub(crate) fn arctic_bv_value_for_source(
    coefficients: &ArcticBvRow,
    source: &Option<(Variable, usize)>,
    width: usize,
) -> String {
    coefficients
        .get(source)
        .cloned()
        .unwrap_or_else(|| bv_literal(0, width))
}

pub(crate) fn arctic_bv_row_relation(
    lhs: &ArcticBvRow,
    rhs: &ArcticBvRow,
    strict: bool,
    width: usize,
) -> String {
    let zero = bv_literal(0, width);
    let sources = lhs
        .keys()
        .chain(rhs.keys())
        .cloned()
        .collect::<BTreeSet<_>>();
    smt_and(
        sources
            .into_iter()
            .map(|source| {
                let left = arctic_bv_value_for_source(lhs, &source, width);
                let right = arctic_bv_value_for_source(rhs, &source, width);
                if strict {
                    format!("(or (= {right} {zero}) (bvugt {left} {right}))")
                } else {
                    format!("(bvuge {left} {right})")
                }
            })
            .collect(),
    )
}

fn arctic_bv_relation_cached(
    lhs: &Term, rhs: &Term, strict: bool, dimension: usize,
    width: usize, parameter_width: usize, script: &mut String,
    next_temporary: &mut usize, cache: &mut BTreeMap<Term, Vec<ArcticBvRow>>,
    allow_bottom_constant: bool,
) -> Option<String> {
    let lhs = arctic_bv_interpret_cached(lhs, dimension, width, parameter_width, script, next_temporary, cache, true)?;
    let rhs = arctic_bv_interpret_cached(rhs, dimension, width, parameter_width, script, next_temporary, cache, true)?;
    let mut constraints = Vec::new();
    if strict && !allow_bottom_constant {
        constraints.push(format!("(distinct {} {})", arctic_bv_value_for_source(&lhs[0], &None, width), bv_literal(0, width)));
    }
    constraints.extend((0..dimension).map(|row|
        arctic_bv_row_relation(&lhs[row], &rhs[row], strict, width)));
    Some(smt_and(constraints))
}

#[cfg(test)]
mod arctic_encoding_cache_tests {
    use super::*;

    #[test]
    fn arctic_homogeneous_bound_synthesizes_without_affine_constants() {
        if !command_exists("z3") { return; }
        let x = Term::var("x");
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f", vec![Term::app("s", vec![x.clone()])]),
            Term::app("f", vec![x]),
        )];
        let mut options = DpOptions::default();
        options.smt_solver = Some("z3".into());
        options.max_polynomial_constant = -1;
        options.max_polynomial_coefficient = 1;
        let model = synthesize_arctic_matrix_interpretation_for_component(
            &pairs, &[], &options, 2, None, None, Some(&[0]),
            Some(Instant::now()+Duration::from_secs(10)), true).unwrap();
        assert!(model.values().all(|m| m.constant.iter().all(|c| *c == i64::MIN)));
        assert!(strictly_decreases_by_arctic_matrix(pairs[0].lhs(), pairs[0].rhs(), &model, 2));
        options.max_polynomial_constant = -2;
        assert!(synthesize_arctic_matrix_interpretation_for_component(
            &pairs, &[], &options, 2, None, None, Some(&[0]), None, true).is_none());
    }

    #[test]
    fn arctic_encoders_match_all_coordinate_strictness() {
        if !command_exists("z3") {return;}
        let x=Term::var("x");let lhs=Term::app("f",vec![x.clone()]);
        for cached in [false,true] {
            for second in [0,1] {
                let model=BTreeMap::from([("f".to_owned(),MatrixInterpretation {
                    constant:vec![i64::MIN,i64::MIN],coefficients:vec![vec![vec![1,i64::MIN],vec![i64::MIN,second]]],
                })]);
                let expected=strictly_decreases_by_arctic_matrix(&lhs,&x,&model,2);
                let mut script=String::from("(set-logic QF_BV)\n");
                for row in 0..2 {
                    let name=matrix_bv_constant_name("f",row);
                    script.push_str(&format!("(declare-const {name} (_ BitVec 2))\n(assert (= {name} {}))\n",bv_literal(0,2)));
                    for col in 0..2 {
                        let name=matrix_bv_coefficient_name("f",0,row,col);
                        let value=if row!=col {0} else if row==0 {2} else {second as u128+1};
                        script.push_str(&format!("(declare-const {name} (_ BitVec 2))\n(assert (= {name} {}))\n",bv_literal(value,2)));
                    }
                }
                let relation=if cached {arctic_bv_relation_cached(&lhs,&x,true,2,6,2,&mut script,&mut 0,&mut BTreeMap::new(),true)}
                    else {arctic_bv_strict(&lhs,&x,2,6,2,&mut script,&mut 0,true)}.unwrap();
                script.push_str(&format!("(assert {relation})\n(check-sat)\n"));
                let answer=run_smt_script(&script,&DpOptions::default(),Some(Instant::now()+Duration::from_secs(5))).unwrap();
                assert_eq!(answer.lines().next(),Some(if expected {"sat"} else {"unsat"}));
            }
        }
    }

    #[test]
    fn arctic_cached_weak_and_strict_share_subterm_definitions() {
        let suffix = Term::app("g", vec![Term::var("x")]);
        let lhs = Term::app("f", vec![suffix.clone()]);
        let mut script = String::new();
        let mut next = 0;
        let mut cache = BTreeMap::new();
        let weak = arctic_bv_relation_cached(&lhs, &suffix, false, 2, 6, 2, &mut script, &mut next, &mut cache,false).unwrap();
        let length = script.len();
        let temporaries = next;
        let strict = arctic_bv_relation_cached(&lhs, &suffix, true, 2, 6, 2, &mut script, &mut next, &mut cache,false).unwrap();
        assert_eq!(script.len(), length);
        assert_eq!(next, temporaries);
        assert_ne!(weak, strict);
        assert_eq!(cache.len(), 3);
        let repeated = arctic_bv_relation_cached(&lhs, &suffix, false, 2, 6, 2, &mut script, &mut next, &mut cache,false).unwrap();
        assert_eq!(weak, repeated);
        assert_eq!(script.len(), length);
    }
}

pub(crate) fn arctic_bv_weak(
    lhs: &Term,
    rhs: &Term,
    dimension: usize,
    width: usize,
    parameter_width: usize,
    script: &mut String,
    next_temporary: &mut usize,
) -> Option<String> {
    let lhs = arctic_bv_interpret(
        lhs,
        dimension,
        width,
        parameter_width,
        script,
        next_temporary,
    )?;
    let rhs = arctic_bv_interpret(
        rhs,
        dimension,
        width,
        parameter_width,
        script,
        next_temporary,
    )?;
    Some(smt_and(
        (0..dimension)
            .map(|row| arctic_bv_row_relation(&lhs[row], &rhs[row], false, width))
            .collect(),
    ))
}

pub(crate) fn arctic_bv_strict(
    lhs: &Term,
    rhs: &Term,
    dimension: usize,
    width: usize,
    parameter_width: usize,
    script: &mut String,
    next_temporary: &mut usize,
    allow_bottom_constant: bool,
) -> Option<String> {
    let lhs = arctic_bv_interpret(
        lhs,
        dimension,
        width,
        parameter_width,
        script,
        next_temporary,
    )?;
    let rhs = arctic_bv_interpret(
        rhs,
        dimension,
        width,
        parameter_width,
        script,
        next_temporary,
    )?;
    let mut constraints = Vec::new();
    if !allow_bottom_constant {
        constraints.push(format!("(distinct {} {})", arctic_bv_value_for_source(&lhs[0], &None, width), bv_literal(0, width)));
    }
    constraints.push(arctic_bv_row_relation(&lhs[0], &rhs[0], true, width));
    constraints.extend(
        (1..dimension).map(|row| arctic_bv_row_relation(&lhs[row], &rhs[row], true, width)),
    );
    Some(smt_and(constraints))
}

#[cfg(test)]
pub(crate) fn synthesize_matrix_interpretation_with_sat(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    deadline: Option<Instant>,
) -> Option<(BTreeMap<String, MatrixInterpretation>, DpSearchBackend)> {
    synthesize_matrix_interpretation_with_sat_requiring_strict_rules(
        pairs,
        usable,
        &[],
        None,
        options,
        dimension,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        deadline,
    )
}

pub(crate) fn synthesize_matrix_interpretation_with_sat_requiring_strict_rules(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    required_strict_pair_index: Option<usize>,
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    deadline: Option<Instant>,
) -> Option<(BTreeMap<String, MatrixInterpretation>, DpSearchBackend)> {
    synthesize_matrix_interpretation_with_sat_requiring_strict_rules_and_positions(
        pairs,
        usable,
        required_strict_rule_indices,
        required_strict_pair_index,
        options,
        dimension,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        None,
        deadline,
    )
}

pub(crate) fn synthesize_q_monotonic_matrix_rule_removal(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    q_lhss: &[Term],
    strict_rule_index: usize,
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    deadline: Option<Instant>,
) -> Option<(BTreeMap<String, MatrixInterpretation>, DpSearchBackend)> {
    let active_positions = rule_local_q_monotonic_positions(pairs, rules, q_lhss, strict_rule_index)?;
    synthesize_matrix_interpretation_with_sat_requiring_strict_rules_and_positions(
        pairs,
        rules,
        &[strict_rule_index],
        None,
        options,
        dimension,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        Some(&active_positions),
        deadline,
    )
}

/// Over-approximate CeTA's `get_innermost_strict_repl_map_dpp` for a
/// singleton strict-rule set. Visit *all* contextual subterms in its finite
/// universe instead of just the reachable ones. A position is generated only
/// when its argument's usable closure contains the selected strict rule.
/// Thus omitting the reachability test adds obligations, never removes them.
/// The caller must delete only this selected rule, not every accidentally
/// strict rule of the synthesized interpretation.
fn rule_local_q_monotonic_positions(
    pairs: &[DependencyPair], rules: &[RewriteRule], q_lhss: &[Term],
    strict_rule_index: usize,
) -> Option<ReplacementMap> {
    let strict = rules.get(strict_rule_index)?;
    if q_lhss.is_empty()
        || rules.iter().any(|r| term_is_q_normal(r.lhs(), q_lhss)
            || !r.rhs().variables().is_subset(&r.lhs().variables()))
        || pairs.iter().any(|p| !p.rhs().variables().is_subset(&p.lhs().variables()))
    {
        return conservative_q_monotonic_positions(pairs, rules, strict_rule_index);
    }
    fn visit(
        term: &Term, preserved: &[Term], rules: &[RewriteRule], q: &[Term],
        strict: &RewriteRule, entries: &mut BTreeMap<Symbol, BTreeSet<usize>>,
    ) {
        let Term::App { symbol, args } = term else { return; };
        for (index, arg) in args.iter().enumerate() {
            if cap::ceta_innermost_usable_rules_for_term(rules, q, preserved, arg).contains(strict) {
                entries.entry(symbol.clone()).or_default().insert(index);
            }
            visit(arg, preserved, rules, q, strict, entries);
        }
    }
    let mut entries = BTreeMap::new();
    for pair in pairs {
        visit(pair.rhs(), std::slice::from_ref(pair.lhs()), rules, q_lhss, strict, &mut entries);
    }
    for rule in rules {
        visit(rule.rhs(), graph::term_arguments(rule.lhs()), rules, q_lhss, strict, &mut entries);
    }
    Some(ReplacementMap::new(entries))
}

/// A conservative syntactic over-approximation of the usable replacement map
/// for one proposed strict rule. It follows every non-variable RHS argument;
/// CeTA's exact icap computation may omit more positions. Requiring
/// monotonicity at extra positions only reduces search; it cannot admit a
/// certificate that the exact CeTA computation rejects.
fn conservative_q_monotonic_positions(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    strict_rule_index: usize,
) -> Option<ReplacementMap> {
    rules.get(strict_rule_index)?;
    let mut entries = BTreeMap::<Symbol, BTreeSet<usize>>::new();
    for term in pairs
        .iter()
        .map(DependencyPair::rhs)
        .chain(rules.iter().map(RewriteRule::rhs))
    {
        collect_q_monotonic_positions(term, &mut entries);
    }
    Some(ReplacementMap::new(entries))
}

#[test]
fn q_monotonic_positions_distinguish_selected_rules() {
    let x = Term::var("x");
    let call = |name: &str, arg: Term| Term::app(name, vec![arg]);
    let rules = vec![
        RewriteRule::new(call("f", x.clone()), x.clone()),
        RewriteRule::new(call("g", x.clone()), x.clone()),
    ];
    let pairs = vec![DependencyPair::new_for_test(
        call("F", x.clone()),
        Term::app("G", vec![call("f", x.clone()), call("g", x)]),
    )];
    let q = rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
    let first = rule_local_q_monotonic_positions(&pairs, &rules, &q, 0).unwrap();
    let second = rule_local_q_monotonic_positions(&pairs, &rules, &q, 1).unwrap();
    let root = pairs[0].rhs().root_symbol().unwrap();
    assert_eq!(first.allowed_positions(root), Some(&BTreeSet::from([0])));
    assert_eq!(second.allowed_positions(root), Some(&BTreeSet::from([1])));
    // Without Q coverage, retain the old conservative map, not an empty map.
    let fallback = rule_local_q_monotonic_positions(&pairs, &rules, &[], 0).unwrap();
    assert_eq!(fallback.allowed_positions(root), Some(&BTreeSet::from([0, 1])));
    assert!(rule_local_q_monotonic_positions(&pairs, &rules, &q, 2).is_none());
}

#[test]
fn q_monotonic_positions_include_rule_rhs_contexts() {
    let x = Term::var("x");
    let call = |name: &str, arg: Term| Term::app(name, vec![arg]);
    let rules = vec![
        RewriteRule::new(call("f", x.clone()), call("box", call("g", x.clone()))),
        RewriteRule::new(call("g", x.clone()), x.clone()),
    ];
    let pairs = vec![DependencyPair::new_for_test(
        call("F", x.clone()), call("G", call("f", x)),
    )];
    let q = rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
    let map = rule_local_q_monotonic_positions(&pairs, &rules, &q, 1).unwrap();
    // The selected rule is reachable below G and below box in f's RHS.
    assert_eq!(map.allowed_positions(pairs[0].rhs().root_symbol().unwrap()), Some(&BTreeSet::from([0])));
    assert_eq!(map.allowed_positions(rules[0].rhs().root_symbol().unwrap()), Some(&BTreeSet::from([0])));
}

fn collect_q_monotonic_positions(term: &Term, entries: &mut BTreeMap<Symbol, BTreeSet<usize>>) {
    let Term::App { symbol, args } = term else {
        return;
    };
    for (index, argument) in args.iter().enumerate() {
        // Normal-form substitutions prevent a rewrite step from originating
        // inside a bare variable. Every non-variable argument is retained as
        // a conservative possible step position. This deliberately includes
        // more positions than CeTA's icap refinement, while still permitting
        // the argument filtering that makes Q-monotonic orders useful.
        if !matches!(argument, Term::Var(_)) {
            entries.entry(symbol.clone()).or_default().insert(index);
        }
        collect_q_monotonic_positions(argument, entries);
    }
}

fn synthesize_matrix_interpretation_with_sat_requiring_strict_rules_and_positions(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    required_strict_pair_index: Option<usize>,
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    active_positions: Option<&ReplacementMap>,
    deadline: Option<Instant>,
) -> Option<(BTreeMap<String, MatrixInterpretation>, DpSearchBackend)> {
    synthesize_matrix_interpretation_with_bv_sat(
        pairs,
        usable,
        required_strict_rule_indices,
        required_strict_pair_index,
        options,
        dimension,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        active_positions,
        deadline,
    )
    .map(|interpretations| (interpretations, DpSearchBackend::Sat))
}

pub(crate) fn synthesize_integer_matrix_interpretation_for_component(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    dimension: usize,
    min_value: i64,
    max_value: i64,
    max_symbols: usize,
    max_arity: usize,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if dimension == 0 || min_value > max_value || max_value < 1 {
        return None;
    }
    let arities = arities_for_constraints(pairs, usable);
    if arities.len() > max_symbols || arities.values().any(|arity| *arity > max_arity) {
        return None;
    }
    let width = signed_matrix_bv_width(pairs, usable, dimension, min_value, max_value)?;
    let solver = select_matrix_smt_solver(options.smt_solver.as_deref(), command_exists)?;
    let encode_started = Instant::now();
    let script = integer_matrix_bv_sat_script(
        pairs, usable, &arities, dimension, 1, min_value, max_value, width, None, deadline,
    )?;
    write_smt_encoding_event(
        "integer-matrix-interpretation",
        encode_started,
        &script,
        pairs,
        usable,
        format!(
            "dimension={dimension} width={width} range={min_value}..={max_value} solver={}",
            solver.command
        ),
    );
    let stdout = run_matrix_smt_script(&script, &solver.command, deadline)?;
    let interpretations = parse_signed_bv_matrix_model(&stdout, &arities, dimension, width)?;
    checked_component_removal_by_integer_matrix(
        pairs,
        usable,
        &interpretations,
        DpSearchBackend::Sat,
        None,
    )?;
    Some(interpretations)
}

pub(crate) fn integer_matrix_bv_sat_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    arities: &BTreeMap<String, usize>,
    dimension: usize,
    strict_dimension: usize,
    min_value: i64,
    max_value: i64,
    width: usize,
    active_positions: Option<&ReplacementMap>,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::from("(set-logic QF_BV)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        for row in 0..dimension {
            push_signed_bv_parameter_declaration(
                &mut script,
                &matrix_bv_constant_name(symbol, row),
                min_value,
                max_value,
                width,
            )?;
        }
        for argument in 0..*arity {
            for row in 0..dimension {
                for column in 0..dimension {
                    let name = matrix_bv_coefficient_name(symbol, argument, row, column);
                    push_signed_bv_parameter_declaration(&mut script, &name, 0, max_value, width)?;
                }
            }
        }
    }

    if let Some(active_positions) = active_positions {
        for (symbol, positions) in active_positions.entries() {
            for argument in positions {
                if *argument >= arities.get(symbol.as_str()).copied().unwrap_or(0) {
                    return None;
                }
                script.push_str(&format!(
                    "(assert (bvsge {} {}))\n",
                    matrix_bv_coefficient_name(symbol.as_str(), *argument, 0, 0),
                    signed_bv_literal(1, width)?,
                ));
            }
        }
    }

    let mut next_expression = 0;
    for rule in usable {
        check_smt_build(&script, deadline)?;
        let lhs = integer_matrix_bv_interpret_shared(
            &mut script,
            &mut next_expression,
            rule.lhs(),
            false,
            dimension,
            width,
        );
        let rhs = integer_matrix_bv_interpret_shared(
            &mut script,
            &mut next_expression,
            rule.rhs(),
            true,
            dimension,
            width,
        );
        script.push_str(&format!(
            "(assert {})\n",
            integer_matrix_bv_weak_formula(&lhs, &rhs, dimension, width)
        ));
    }
    let mut strict = Vec::with_capacity(pairs.len());
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let lhs = integer_matrix_bv_interpret_shared(
            &mut script,
            &mut next_expression,
            pair.lhs(),
            false,
            dimension,
            width,
        );
        let rhs = integer_matrix_bv_interpret_shared(
            &mut script,
            &mut next_expression,
            pair.rhs(),
            true,
            dimension,
            width,
        );
        script.push_str(&format!(
            "(assert {})\n",
            integer_matrix_bv_weak_formula(&lhs, &rhs, dimension, width)
        ));
        strict.push(integer_matrix_bv_strict_formula(
            &lhs,
            &rhs,
            dimension,
            strict_dimension,
            width,
        ));
    }
    if strict.is_empty() {
        return None;
    }
    script.push_str(&format!("(assert {})\n", smt_or(strict)));
    script.push_str("(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn push_signed_bv_parameter_declaration(
    script: &mut String,
    name: &str,
    min_value: i64,
    max_value: i64,
    width: usize,
) -> Option<()> {
    script.push_str(&format!("(declare-fun {name} () (_ BitVec {width}))\n"));
    script.push_str(&format!(
        "(assert (bvsge {name} {}))\n",
        signed_bv_literal(min_value, width)?
    ));
    script.push_str(&format!(
        "(assert (bvsle {name} {}))\n",
        signed_bv_literal(max_value, width)?
    ));
    Some(())
}

pub(crate) fn signed_bv_literal(value: i64, width: usize) -> Option<String> {
    if width == 0 || width > 63 {
        return None;
    }
    let modulus = 1i128.checked_shl(u32::try_from(width).ok()?)?;
    let encoded = i128::from(value).rem_euclid(modulus);
    Some(bv_literal(u128::try_from(encoded).ok()?, width))
}

pub(crate) fn integer_matrix_bv_interpret_shared(
    script: &mut String,
    next_expression: &mut usize,
    term: &Term,
    right: bool,
    dimension: usize,
    width: usize,
) -> MatrixBvForm {
    match term {
        Term::Var(variable) => MatrixBvForm {
            constant: vec![bv_literal(0, width); dimension],
            coefficients: BTreeMap::from([(
                variable.clone(),
                bv_identity_matrix(dimension, width),
            )]),
        },
        Term::App { symbol, args } => {
            let mut constant = (0..dimension)
                .map(|row| matrix_bv_constant_name(symbol.as_str(), row))
                .collect::<Vec<_>>();
            let mut coefficients = BTreeMap::<Variable, Vec<Vec<String>>>::new();
            for (argument, arg) in args.iter().enumerate() {
                let matrix = matrix_bv_parameter_matrix(symbol.as_str(), argument, dimension);
                let arg_form = integer_matrix_bv_interpret_shared(
                    script,
                    next_expression,
                    arg,
                    right,
                    dimension,
                    width,
                );
                let scaled_constant = signed_bv_matrix_vector_product_shared(
                    script,
                    next_expression,
                    &matrix,
                    &arg_form.constant,
                    width,
                );
                for (left, right) in constant.iter_mut().zip(scaled_constant) {
                    *left = bv_add_shared(script, next_expression, left, &right, width);
                }
                for (variable, coefficient) in arg_form.coefficients {
                    let scaled = signed_bv_matrix_product_shared(
                        script,
                        next_expression,
                        &matrix,
                        &coefficient,
                        width,
                    );
                    if let Some(old) = coefficients.get_mut(&variable) {
                        bv_add_matrix_in_place_shared(script, next_expression, old, &scaled, width);
                    } else {
                        coefficients.insert(variable, scaled);
                    }
                }
            }
            if right || coefficients.is_empty() {
                let zero = bv_literal(0, width);
                for value in &mut constant {
                    *value = bv_bind_shared(
                        script,
                        next_expression,
                        format!("(ite (bvsge {value} {zero}) {value} {zero})"),
                        width,
                    );
                }
            }
            MatrixBvForm {
                constant,
                coefficients,
            }
        }
    }
}

pub(crate) fn signed_bv_matrix_vector_product_shared(
    script: &mut String,
    next_expression: &mut usize,
    matrix: &[Vec<String>],
    vector: &[String],
    width: usize,
) -> Vec<String> {
    matrix
        .iter()
        .map(|row| {
            row.iter()
                .zip(vector)
                .fold(bv_literal(0, width), |sum, (left, right)| {
                    let product =
                        bv_bind_shared(script, next_expression, bv_mul(left, right), width);
                    bv_add_shared(script, next_expression, &sum, &product, width)
                })
        })
        .collect()
}

pub(crate) fn signed_bv_matrix_product_shared(
    script: &mut String,
    next_expression: &mut usize,
    left: &[Vec<String>],
    right: &[Vec<String>],
    width: usize,
) -> Vec<Vec<String>> {
    let columns = right.first().map_or(0, Vec::len);
    left.iter()
        .map(|left_row| {
            (0..columns)
                .map(|column| {
                    left_row
                        .iter()
                        .enumerate()
                        .fold(bv_literal(0, width), |sum, (index, value)| {
                            let product = bv_bind_shared(
                                script,
                                next_expression,
                                bv_mul(value, &right[index][column]),
                                width,
                            );
                            bv_add_shared(script, next_expression, &sum, &product, width)
                        })
                })
                .collect()
        })
        .collect()
}

pub(crate) fn integer_matrix_bv_weak_formula(
    lhs: &MatrixBvForm,
    rhs: &MatrixBvForm,
    dimension: usize,
    width: usize,
) -> String {
    let mut parts = (0..dimension)
        .map(|row| format!("(bvsge {} {})", lhs.constant[row], rhs.constant[row]))
        .collect::<Vec<_>>();
    for variable in lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .collect::<BTreeSet<_>>()
    {
        let left = lhs
            .coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| bv_zero_matrix(dimension, width));
        let right = rhs
            .coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| bv_zero_matrix(dimension, width));
        for row in 0..dimension {
            for column in 0..dimension {
                parts.push(format!(
                    "(bvsge {} {})",
                    left[row][column], right[row][column]
                ));
            }
        }
    }
    smt_and(parts)
}

pub(crate) fn integer_matrix_bv_strict_formula(
    lhs: &MatrixBvForm,
    rhs: &MatrixBvForm,
    dimension: usize,
    strict_dimension: usize,
    width: usize,
) -> String {
    let strict = (0..strict_dimension)
        .map(|index| format!("(bvsgt {} {})", lhs.constant[index], rhs.constant[index]))
        .collect::<Vec<_>>();
    format!(
        "(and {} {})",
        integer_matrix_bv_weak_formula(lhs, rhs, dimension, width),
        smt_or(strict)
    )
}

pub(crate) fn synthesize_matrix_interpretation_with_bv_sat(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    required_strict_pair_index: Option<usize>,
    options: &DpOptions,
    dimension: usize,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    active_positions: Option<&ReplacementMap>,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    let arities = arities_for_constraints(pairs, usable);
    if !matrix_sat_bounds_hold(&arities, options, dimension) {
        return None;
    }
    let solver = if options.smt_solver.is_none() && dimension == 1 && command_exists("cvc5") {
        MatrixSmtSolver {
            command: "cvc5".to_string(),
            flavor: MatrixSmtFlavor::Portable,
        }
    } else {
        select_matrix_smt_solver(options.smt_solver.as_deref(), command_exists)?
    };
    let strict_dimension = 1;
    let width = matrix_bv_width(pairs, usable, options, dimension)?;
    let encode_started = Instant::now();
    let script = matrix_bv_sat_script(
        pairs,
        usable,
        required_strict_rule_indices,
        required_strict_pair_index,
        options,
        &arities,
        dimension,
        strict_dimension,
        width,
        active_positions,
        min_nonzero,
        max_nonzero,
        max_nonzero_constants,
        max_nonzero_per_row,
        solver.flavor,
        deadline,
    )?;
    write_smt_encoding_event(
        "matrix-interpretation",
        encode_started,
        &script,
        pairs,
        usable,
        format!(
            "dimension={dimension} width={width} solver={}",
            solver.command
        ),
    );
    let stdout = run_matrix_smt_script(&script, &solver.command, deadline)?;
    write_progress_event(
        "dp-matrix",
        "solver-result",
        "matrix-interpretation",
        0,
        &format!(
            "solver={} output={}",
            solver.command,
            stdout
                .chars()
                .take(160)
                .collect::<String>()
                .replace('\n', " ")
        ),
    );
    let interpretations = parse_bv_matrix_model(&stdout, &arities, dimension)?;
    if checked_component_removal_by_matrix_with_required_strict_rules(
        pairs,
        usable,
        &interpretations,
        DpSearchBackend::Sat,
        None,
        required_strict_rule_indices,
    )
    .is_some()
    {
        return Some(interpretations);
    }
    let all_usable_weak = usable.iter().all(|rule| {
        weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations, dimension)
    });
    let weak_pairs = pairs
        .iter()
        .filter(|pair| {
            weakly_decreases_by_matrix(pair.lhs(), pair.rhs(), &interpretations, dimension)
        })
        .count();
    let strict_pairs = pairs
        .iter()
        .filter(|pair| {
            strictly_decreases_by_matrix(
                pair.lhs(),
                pair.rhs(),
                &interpretations,
                dimension,
                strict_dimension,
            )
        })
        .count();
    write_progress_event(
        "dp-matrix",
        "model-rejected",
        "matrix-interpretation",
        0,
        &format!(
            "well_formed={} usable_weak={} weak_pairs={}/{} strict_pairs={} interpretation={interpretations:?}",
            matrix_interpretations_are_well_formed(&interpretations, dimension),
            all_usable_weak,
            weak_pairs,
            pairs.len(),
            strict_pairs,
        ),
    );
    None
}

// Historical exact witness retained only for validator regression tests.
#[cfg(test)]
pub(crate) fn synthesize_pair2hard_shape_matrix(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    arities: &BTreeMap<String, usize>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if pairs.len() != 1 || rules.len() != 2 || arities.len() != 4 {
        return None;
    }
    let sharp = pairs.first()?.lhs().root_symbol()?.as_str();
    let base = sharp.strip_suffix('#')?;
    if arities.get(sharp) != Some(&2) || arities.get(base) != Some(&2) {
        return None;
    }
    let unary_rule = rules.iter().find(|rule| {
        rule.lhs()
            .root_symbol()
            .is_some_and(|root| arities.get(root.as_str()) == Some(&1))
    })?;
    let first_unary = unary_rule.lhs().root_symbol()?.as_str();
    let second_unary = arities.iter().find_map(|(symbol, arity)| {
        (*arity == 1 && symbol != first_unary).then_some(symbol.as_str())
    })?;

    let zero = vec![vec![0; 4]; 4];
    Some(BTreeMap::from([
        (
            sharp.to_string(),
            MatrixInterpretation {
                constant: vec![0, 0, 0, 0],
                coefficients: vec![
                    zero.clone(),
                    vec![
                        vec![0, 0, 0, 2],
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                    ],
                ],
            },
        ),
        (
            first_unary.to_string(),
            MatrixInterpretation {
                constant: vec![0, 0, 1, 0],
                coefficients: vec![vec![
                    vec![0, 1, 0, 0],
                    vec![0, 0, 0, 1],
                    vec![0, 0, 0, 0],
                    vec![1, 0, 2, 2],
                ]],
            },
        ),
        (
            base.to_string(),
            MatrixInterpretation {
                constant: vec![0, 0, 0, 0],
                coefficients: vec![
                    vec![
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                        vec![2, 0, 0, 0],
                    ],
                    vec![
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 1],
                    ],
                ],
            },
        ),
        (
            second_unary.to_string(),
            MatrixInterpretation {
                constant: vec![0, 0, 0, 0],
                coefficients: vec![vec![
                    vec![0, 0, 0, 1],
                    vec![0, 1, 0, 0],
                    vec![0, 0, 0, 0],
                    vec![0, 0, 0, 0],
                ]],
            },
        ),
    ]))
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum MatrixSmtFlavor {
    Z3,
    Portable,
}

pub(crate) fn matrix_bv_sat_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    required_strict_pair_index: Option<usize>,
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    dimension: usize,
    strict_dimension: usize,
    width: usize,
    active_positions: Option<&ReplacementMap>,
    min_nonzero: Option<usize>,
    max_nonzero: Option<usize>,
    max_nonzero_constants: Option<usize>,
    max_nonzero_per_row: Option<usize>,
    flavor: MatrixSmtFlavor,
    deadline: Option<Instant>,
) -> Option<String> {
    fn visit(term: &Term, order: &mut Vec<String>, seen: &mut BTreeSet<String>) {
        if let Term::App { symbol, args } = term {
            if seen.insert(symbol.as_str().to_owned()) { order.push(symbol.as_str().to_owned()); }
            for argument in args { visit(argument, order, seen); }
        }
    }
    // SAT variable numbering must follow the problem structure, not the
    // lexicographic spelling of function symbols.
    let mut symbol_order = Vec::new();
    let mut seen = BTreeSet::new();
    for pair in pairs {
        visit(pair.lhs(), &mut symbol_order, &mut seen);
        visit(pair.rhs(), &mut symbol_order, &mut seen);
    }
    for rule in usable {
        visit(rule.lhs(), &mut symbol_order, &mut seen);
        visit(rule.rhs(), &mut symbol_order, &mut seen);
    }
    let mut script = String::new();
    script.push_str("(set-logic QF_BV)\n");
    let sat_seed = MATRIX_SAT_SEED.fetch_add(1, Ordering::Relaxed);
    if flavor == MatrixSmtFlavor::Z3 {
        script.push_str(&format!("(set-option :sat.random_seed {sat_seed})\n"));
        if min_nonzero.is_some() && min_nonzero == max_nonzero {
            script.push_str("(set-option :sat.local_search true)\n");
        }
        if min_nonzero.is_some()
            || max_nonzero.is_some()
            || max_nonzero_constants.is_some()
            || max_nonzero_per_row.is_some()
        {
            script.push_str("(set-option :sat.phase always_false)\n");
        }
    }
    let parameter_width = unsigned_bit_width(
        options
            .max_polynomial_constant
            .max(options.max_polynomial_coefficient) as u128,
    );
    let marked_root_constants_cancel = pairs.iter().all(|pair| {
        pair.lhs().root_symbol() == pair.rhs().root_symbol()
            && pair
                .lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str().ends_with('#'))
    });
    for symbol in &symbol_order {
        let arity = arities.get(symbol)?;
        check_smt_build(&script, deadline)?;
        for row in 0..dimension {
            push_bv_parameter_declaration(
                &mut script,
                &matrix_bv_constant_name(symbol, row),
                0,
                options.max_polynomial_constant,
                parameter_width,
            )?;
        }
        for argument in 0..*arity {
            for row in 0..dimension {
                for column in 0..dimension {
                    push_bv_parameter_declaration(
                        &mut script,
                        &matrix_bv_coefficient_name(symbol, argument, row, column),
                        0,
                        options.max_polynomial_coefficient,
                        parameter_width,
                    )?;
                }
            }
        }
        if symbol.ends_with('#') {
            let zero = bv_literal(0, parameter_width);
            if marked_root_constants_cancel {
                script.push_str(&format!(
                    "(assert (= {} {zero}))\n",
                    matrix_bv_constant_name(symbol, 0)
                ));
            }
            for row in strict_dimension..dimension {
                script.push_str(&format!(
                    "(assert (= {} {zero}))\n",
                    matrix_bv_constant_name(symbol, row)
                ));
                for argument in 0..*arity {
                    for column in 0..dimension {
                        script.push_str(&format!(
                            "(assert (= {} {zero}))\n",
                            matrix_bv_coefficient_name(symbol, argument, row, column)
                        ));
                    }
                }
            }
        }
    }
    if let Some(min_nonzero) = min_nonzero {
        let nonzero = arities
            .iter()
            .flat_map(|(symbol, arity)| {
                let constants = (0..dimension).map(|row| {
                    format!(
                        "(distinct {} {})",
                        matrix_bv_constant_name(symbol, row),
                        bv_literal(0, parameter_width)
                    )
                });
                let coefficients = (0..*arity).flat_map(move |argument| {
                    (0..dimension).flat_map(move |row| {
                        (0..dimension).map(move |column| {
                            format!(
                                "(distinct {} {})",
                                matrix_bv_coefficient_name(symbol, argument, row, column),
                                bv_literal(0, parameter_width)
                            )
                        })
                    })
                });
                constants.chain(coefficients)
            })
            .collect::<Vec<_>>();
        if min_nonzero > nonzero.len() {
            return None;
        }
        if min_nonzero > 0 {
            let kind = if Some(min_nonzero) == max_nonzero {
                CardinalityKind::Exactly
            } else {
                CardinalityKind::AtLeast
            };
            push_boolean_cardinality(&mut script, &nonzero, min_nonzero, kind, flavor);
        }
    }
    if let Some(max_nonzero) = max_nonzero {
        let parameter_count = arities
            .values()
            .map(|arity| dimension + arity * dimension * dimension)
            .sum::<usize>();
        if Some(max_nonzero) != min_nonzero && max_nonzero < parameter_count {
            let mut nonzero = Vec::with_capacity(parameter_count);
            for (symbol, arity) in arities {
                nonzero.extend((0..dimension).map(|row| {
                    format!(
                        "(distinct {} {})",
                        matrix_bv_constant_name(symbol, row),
                        bv_literal(0, parameter_width)
                    )
                }));
                for argument in 0..*arity {
                    for row in 0..dimension {
                        for column in 0..dimension {
                            nonzero.push(format!(
                                "(distinct {} {})",
                                matrix_bv_coefficient_name(symbol, argument, row, column),
                                bv_literal(0, parameter_width)
                            ));
                        }
                    }
                }
            }
            push_boolean_cardinality(
                &mut script,
                &nonzero,
                max_nonzero,
                CardinalityKind::AtMost,
                flavor,
            );
        }
    }
    if let Some(max_nonzero_constants) = max_nonzero_constants {
        let constants = arities
            .keys()
            .flat_map(|symbol| {
                (0..dimension).map(move |row| {
                    format!(
                        "(distinct {} {})",
                        matrix_bv_constant_name(symbol, row),
                        bv_literal(0, parameter_width)
                    )
                })
            })
            .collect::<Vec<_>>();
        if max_nonzero_constants < constants.len() {
            push_boolean_cardinality(
                &mut script,
                &constants,
                max_nonzero_constants,
                CardinalityKind::AtMost,
                flavor,
            );
        }
    }
    if let Some(max_nonzero_per_row) = max_nonzero_per_row {
        for (symbol, arity) in arities {
            for argument in 0..*arity {
                for row in 0..dimension {
                    if max_nonzero_per_row >= dimension {
                        continue;
                    }
                    let entries = (0..dimension)
                        .map(|column| {
                            format!(
                                "(distinct {} {})",
                                matrix_bv_coefficient_name(symbol, argument, row, column),
                                bv_literal(0, parameter_width)
                            )
                        })
                        .collect::<Vec<_>>();
                    push_boolean_cardinality(
                        &mut script,
                        &entries,
                        max_nonzero_per_row,
                        CardinalityKind::AtMost,
                        flavor,
                    );
                }
            }
        }
    }
    if let Some(active_positions) = active_positions {
        for (symbol, positions) in active_positions.entries() {
            for argument in positions {
                if *argument >= arities.get(symbol.as_str()).copied().unwrap_or(0) {
                    return None;
                }
                script.push_str(&format!(
                    "(assert (bvuge {} {}))\n",
                    matrix_bv_coefficient_name(symbol.as_str(), *argument, 0, 0),
                    bv_literal(1, parameter_width),
                ));
            }
        }
    }
    let mut shared_expression_index = 0;
    // Query-local term sharing is opt-in while measuring model-order effects.
    // Variable identities, dimensions, and bit widths remain unchanged.
    let mut query_term_cache = std::env::var_os("FERRUM_MATRIX_QUERY_CACHE")
        .map(|_| BTreeMap::new());
    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    for (index, rule) in usable.iter().enumerate() {
        check_smt_build(&script, deadline)?;
        let lhs = matrix_bv_interpret_with_query_cache(
            &mut script,
            &mut shared_expression_index,
            &mut query_term_cache,
            rule.lhs(),
            dimension,
            width,
            parameter_width,
        );
        let rhs = matrix_bv_interpret_with_query_cache(
            &mut script,
            &mut shared_expression_index,
            &mut query_term_cache,
            rule.rhs(),
            dimension,
            width,
            parameter_width,
        );
        script.push_str(&format!(
            "(assert {})\n",
            matrix_bv_weak_formula(&lhs, &rhs, dimension, width)
        ));
        if required_strict_rule_indices.contains(&index) {
            script.push_str(&format!(
                "(assert {})\n",
                matrix_bv_strict_formula(&lhs, &rhs, dimension, strict_dimension, width,)
            ));
        }
    }
    let mut strict_terms = Vec::new();
    for pair in pairs {
        check_smt_build(&script, deadline)?;
        let lhs = matrix_bv_interpret_with_query_cache(
            &mut script,
            &mut shared_expression_index,
            &mut query_term_cache,
            pair.lhs(),
            dimension,
            width,
            parameter_width,
        );
        let rhs = matrix_bv_interpret_with_query_cache(
            &mut script,
            &mut shared_expression_index,
            &mut query_term_cache,
            pair.rhs(),
            dimension,
            width,
            parameter_width,
        );
        script.push_str(&format!(
            "(assert {})\n",
            matrix_bv_weak_formula(&lhs, &rhs, dimension, width)
        ));
        strict_terms.push(matrix_bv_strict_formula(
            &lhs,
            &rhs,
            dimension,
            strict_dimension,
            width,
        ));
    }
    if required_strict_pair_index.is_some_and(|index| index >= strict_terms.len()) {
        return None;
    } else if strict_terms.is_empty() && required_strict_rule_indices.is_empty() {
        return None;
    } else if let Some(index) = required_strict_pair_index {
        script.push_str(&format!("(assert {})\n", strict_terms[index]));
    } else if !required_strict_rule_indices.is_empty() {
        // A generalized/Q-monotonic rule-removal step may make every DP only
        // weak while deleting a strict rule. The rule assertions above are
        // then the complete strictness objective.
    } else if strict_terms.len() == 1 {
        script.push_str(&format!("(assert {})\n", strict_terms[0]));
    } else {
        script.push_str("(assert (or");
        for term in &strict_terms {
            script.push(' ');
            script.push_str(term);
        }
        script.push_str("))\n");
    }
    // With one pair the strictness assertion already fixes the objective to
    // one. Asking an Optimize solver to maximize that same Boolean can make
    // nonlinear BV matrix instances dramatically slower.
    if required_strict_rule_indices.is_empty()
        && strict_terms.len() > 1
        && flavor == MatrixSmtFlavor::Z3
    {
        let mut objective_indices = (0..strict_terms.len()).collect::<Vec<_>>();
        if let Some(active_positions) = active_positions {
            objective_indices.sort_by_key(|index| {
                let active_root = pairs[*index]
                    .lhs()
                    .root_symbol()
                    .and_then(|symbol| active_positions.allowed_positions(symbol))
                    .is_some_and(|positions| !positions.is_empty());
                (!active_root, *index)
            });
        }
        for index in objective_indices {
            let term = &strict_terms[index];
            script.push_str(&format!("(maximize (ite {term} 1 0))\n"));
        }
    }
    if strict_terms.len() == 1 && flavor == MatrixSmtFlavor::Z3 {
        script.push_str(
            "(check-sat-using (then simplify propagate-values solve-eqs bit-blast sat))\n(get-model)\n",
        );
    } else {
        script.push_str("(check-sat)\n(get-model)\n");
    }
    check_smt_build(&script, deadline)?;
    write_progress_event(
        "dp-matrix",
        "encoded",
        "matrix-interpretation",
        0,
        &format!(
            "dimension={dimension} width={width} parameter_width={parameter_width} sat_seed={sat_seed} symbols={} parameters={} min_nonzero={} max_nonzero={} max_nonzero_constants={} max_nonzero_per_row={} script_bytes={}",
            arities.len(),
            arities
                .values()
                .map(|arity| dimension + arity * dimension * dimension)
                .sum::<usize>(),
            min_nonzero
                .map(|value| value.to_string())
                .unwrap_or_else(|| "none".to_string()),
            max_nonzero
                .map(|value| value.to_string())
                .unwrap_or_else(|| "none".to_string()),
            max_nonzero_constants
                .map(|value| value.to_string())
                .unwrap_or_else(|| "none".to_string()),
            max_nonzero_per_row
                .map(|value| value.to_string())
                .unwrap_or_else(|| "none".to_string()),
            script.len()
        ),
    );
    Some(script)
}

#[derive(Clone, Copy)]
pub(crate) enum CardinalityKind {
    AtLeast,
    AtMost,
    Exactly,
}

pub(crate) fn push_boolean_cardinality(
    script: &mut String,
    predicates: &[String],
    bound: usize,
    kind: CardinalityKind,
    flavor: MatrixSmtFlavor,
) {
    if flavor == MatrixSmtFlavor::Z3 {
        match kind {
            CardinalityKind::AtLeast | CardinalityKind::AtMost => {
                let operator = match kind {
                    CardinalityKind::AtLeast => "at-least",
                    CardinalityKind::AtMost => "at-most",
                    CardinalityKind::Exactly => unreachable!(),
                };
                script.push_str(&format!(
                    "(assert ((_ {operator} {bound}) {}))\n",
                    predicates.join(" ")
                ));
            }
            CardinalityKind::Exactly => {
                script.push_str(&format!(
                    "(assert (and ((_ at-least {bound}) {}) ((_ at-most {bound}) {})))\n",
                    predicates.join(" "),
                    predicates.join(" ")
                ));
            }
        }
        return;
    }

    let width = unsigned_bit_width(predicates.len() as u128);
    let mut terms = predicates
        .iter()
        .map(|predicate| {
            format!(
                "(ite {predicate} {} {})",
                bv_literal(1, width),
                bv_literal(0, width)
            )
        })
        .collect::<Vec<_>>();
    while terms.len() > 1 {
        terms = terms
            .chunks(2)
            .map(|chunk| {
                if let [left, right] = chunk {
                    format!("(bvadd {left} {right})")
                } else {
                    chunk[0].clone()
                }
            })
            .collect();
    }
    let sum = terms.pop().unwrap_or_else(|| bv_literal(0, width));
    let comparison = match kind {
        CardinalityKind::AtLeast => "bvuge",
        CardinalityKind::AtMost => "bvule",
        CardinalityKind::Exactly => "=",
    };
    script.push_str(&format!(
        "(assert ({comparison} {sum} {}))\n",
        bv_literal(bound as u128, width)
    ));
}

pub(crate) fn synthesize_relative_matrix_rule_removal(
    relative: &RelativeTrs,
    options: &DpOptions,
    dimension: usize,
    deadline: Option<Instant>,
) -> Option<RelativeMatrixRuleRemoval> {
    if relative.strict().is_empty() || dimension == 0 {
        return None;
    }
    let candidate_rules = relative.union().rules().to_vec();
    let strict_pairs = candidate_rules
        .iter()
        .cloned()
        .enumerate()
        .map(|(index, rule)| DependencyPair::from_rule(rule, index))
        .collect::<Vec<_>>();
    let arities = arities_for_constraints(&strict_pairs, &[]);
    if !matrix_sat_bounds_hold(&arities, options, dimension) {
        return None;
    }
    let active_positions = ReplacementMap::new(
        arities
            .iter()
            .map(|(symbol, arity)| (Symbol::new(symbol), (0..*arity).collect::<BTreeSet<_>>()))
            .collect(),
    );
    let solver = select_matrix_smt_solver(options.smt_solver.as_deref(), command_exists)?;
    let strict_dimension = 1;
    let width = matrix_bv_width(&strict_pairs, &[], options, dimension)?;
    let script = matrix_bv_sat_script(
        &strict_pairs,
        &[],
        &[],
        None,
        options,
        &arities,
        dimension,
        strict_dimension,
        width,
        Some(&active_positions),
        None,
        None,
        None,
        None,
        solver.flavor,
        deadline,
    )?;
    let stdout = run_matrix_smt_script(&script, &solver.command, deadline)?;
    let interpretations = parse_bv_matrix_model(&stdout, &arities, dimension)?;
    if !matrix_interpretations_are_well_formed(&interpretations, dimension)
        || !arities.iter().all(|(symbol, arity)| {
            let Some(interpretation) = interpretations.get(symbol) else {
                return false;
            };
            (0..*arity).all(|argument| {
                interpretation
                    .coefficients
                    .get(argument)
                    .and_then(|matrix| matrix.first())
                    .and_then(|row| row.first())
                    .is_some_and(|coefficient| *coefficient >= 1)
            })
        })
        || !relative.union().rules().iter().all(|rule| {
            weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations, dimension)
        })
    {
        return None;
    }
    let removed = candidate_rules
        .iter()
        .filter(|rule| {
            strictly_decreases_by_matrix(
                rule.lhs(),
                rule.rhs(),
                &interpretations,
                dimension,
                strict_dimension,
            )
        })
        .cloned()
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining_rules = relative
        .strict()
        .rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect::<Vec<_>>();
    let remaining_weak_rules = relative
        .weak_rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect::<Vec<_>>();
    let remaining = RelativeTrs::new(
        Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            relative.strict().variables().clone(),
            remaining_rules,
            relative.strict().strategy(),
        ),
        remaining_weak_rules,
    );
    Some(RelativeMatrixRuleRemoval {
        interpretations: interpretations.into_iter().collect(),
        dimension,
        strict_dimension,
        domain: MatrixDomain::Naturals,
        removed,
        remaining,
    })
}

pub(crate) fn checked_relative_matrix_rule_removal(
    relative: &RelativeTrs,
    interpretations: Vec<(String, MatrixInterpretation)>,
    domain: MatrixDomain,
) -> Option<RelativeMatrixRuleRemoval> {
    if relative.strict().is_empty() || interpretations.is_empty() {
        return None;
    }
    let dimension = interpretations.first()?.1.constant.len();
    let strict_dimension = 1;
    let interpretations_map = interpretations.iter().cloned().collect::<BTreeMap<_, _>>();
    let arities = relative.union().arities();
    let well_formed = match domain {
        MatrixDomain::Naturals => {
            matrix_interpretations_are_well_formed(&interpretations_map, dimension)
        }
        MatrixDomain::Integers => integer_matrix_interpretations_are_well_formed(
            &interpretations_map,
            dimension,
            strict_dimension,
        ),
    };
    if dimension == 0
        || !well_formed
        || !arities.iter().all(|(symbol, arity)| {
            let Some(interpretation) = interpretations_map.get(symbol.as_str()) else {
                return false;
            };
            interpretation.coefficients.len() == *arity
                && (0..*arity).all(|argument| {
                    interpretation
                        .coefficients
                        .get(argument)
                        .and_then(|matrix| matrix.first())
                        .and_then(|row| row.first())
                        .is_some_and(|coefficient| *coefficient >= 1)
                })
        })
    {
        return None;
    }
    let weak = |rule: &RewriteRule| match domain {
        MatrixDomain::Naturals => {
            weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations_map, dimension)
        }
        MatrixDomain::Integers => weakly_decreases_by_integer_matrix(
            rule.lhs(),
            rule.rhs(),
            &interpretations_map,
            dimension,
        ),
    };
    if !relative.union().rules().iter().all(weak) {
        return None;
    }
    let removed = relative
        .union()
        .rules()
        .iter()
        .filter(|rule| match domain {
            MatrixDomain::Naturals => strictly_decreases_by_matrix(
                rule.lhs(),
                rule.rhs(),
                &interpretations_map,
                dimension,
                strict_dimension,
            ),
            MatrixDomain::Integers => strictly_decreases_by_integer_matrix(
                rule.lhs(),
                rule.rhs(),
                &interpretations_map,
                dimension,
                strict_dimension,
            ),
        })
        .cloned()
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining = RelativeTrs::new(
        Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            relative.strict().variables().clone(),
            relative
                .strict()
                .rules()
                .iter()
                .filter(|rule| !removed.contains(rule))
                .cloned()
                .collect(),
            relative.strict().strategy(),
        ),
        relative
            .weak_rules()
            .iter()
            .filter(|rule| !removed.contains(rule))
            .cloned()
            .collect(),
    );
    Some(RelativeMatrixRuleRemoval {
        interpretations,
        dimension,
        strict_dimension,
        domain,
        removed,
        remaining,
    })
}

pub(crate) fn synthesize_relative_integer_matrix_rule_removal(
    relative: &RelativeTrs,
    options: &DpOptions,
    dimension: usize,
    min_value: i64,
    max_value: i64,
    deadline: Option<Instant>,
) -> Option<RelativeMatrixRuleRemoval> {
    if relative.strict().is_empty() || dimension == 0 || min_value > max_value || max_value < 1 {
        return None;
    }
    let candidate_rules = relative.union().rules().to_vec();
    let strict_pairs = candidate_rules
        .iter()
        .cloned()
        .enumerate()
        .map(|(index, rule)| DependencyPair::from_rule(rule, index))
        .collect::<Vec<_>>();
    let arities = arities_for_constraints(&strict_pairs, &[]);
    if arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
    {
        return None;
    }
    let active_positions = ReplacementMap::new(
        arities
            .iter()
            .map(|(symbol, arity)| (Symbol::new(symbol), (0..*arity).collect::<BTreeSet<_>>()))
            .collect(),
    );
    let strict_dimension = 1;
    let width = signed_matrix_bv_width(&strict_pairs, &[], dimension, min_value, max_value)?;
    let solver = select_matrix_smt_solver(options.smt_solver.as_deref(), command_exists)?;
    let script = integer_matrix_bv_sat_script(
        &strict_pairs,
        &[],
        &arities,
        dimension,
        strict_dimension,
        min_value,
        max_value,
        width,
        Some(&active_positions),
        deadline,
    )?;
    let stdout = run_matrix_smt_script(&script, &solver.command, deadline)?;
    let interpretations = parse_signed_bv_matrix_model(&stdout, &arities, dimension, width)?;
    if !integer_matrix_interpretations_are_well_formed(
        &interpretations,
        dimension,
        strict_dimension,
    ) || !arities.iter().all(|(symbol, arity)| {
        let Some(interpretation) = interpretations.get(symbol) else {
            return false;
        };
        (0..*arity).all(|argument| {
            interpretation
                .coefficients
                .get(argument)
                .and_then(|matrix| matrix.first())
                .and_then(|row| row.first())
                .is_some_and(|coefficient| *coefficient >= 1)
        })
    }) || !relative.union().rules().iter().all(|rule| {
        weakly_decreases_by_integer_matrix(rule.lhs(), rule.rhs(), &interpretations, dimension)
    }) {
        return None;
    }
    let removed = candidate_rules
        .iter()
        .filter(|rule| {
            strictly_decreases_by_integer_matrix(
                rule.lhs(),
                rule.rhs(),
                &interpretations,
                dimension,
                strict_dimension,
            )
        })
        .cloned()
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining_rules = relative
        .strict()
        .rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect::<Vec<_>>();
    let remaining_weak_rules = relative
        .weak_rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect::<Vec<_>>();
    let remaining = RelativeTrs::new(
        Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            relative.strict().variables().clone(),
            remaining_rules,
            relative.strict().strategy(),
        ),
        remaining_weak_rules,
    );
    Some(RelativeMatrixRuleRemoval {
        interpretations: interpretations.into_iter().collect(),
        dimension,
        strict_dimension,
        domain: MatrixDomain::Integers,
        removed,
        remaining,
    })
}

pub(crate) fn synthesize_csr_matrix_rule_removal(
    csr: &CsrTrs,
    options: &DpOptions,
    dimension: usize,
    deadline: Option<Instant>,
) -> Option<CsrMatrixRuleRemoval> {
    let standardized = standardize_trs_with_bijection(csr.trs()).ok()?;
    let replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter_map(|(symbol, positions)| {
                standardized
                    .function_bijection
                    .get(symbol)
                    .cloned()
                    .map(|canonical| (canonical, positions.clone()))
            })
            .collect(),
    );
    let standardized_csr = CsrTrs::new(standardized.trs.clone(), replacement_map).ok()?;
    let canonical_removal =
        synthesize_csr_matrix_rule_removal_raw(&standardized_csr, options, dimension, deadline)?;
    let removed_canonical_indices = standardized
        .trs
        .rules()
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| canonical_removal.removed.contains(rule).then_some(index))
        .collect::<BTreeSet<_>>();
    let removed_original_indices = standardized
        .rule_metadata
        .iter()
        .filter(|metadata| removed_canonical_indices.contains(&metadata.canonical_pair_index))
        .map(|metadata| metadata.original_pair_index)
        .collect::<BTreeSet<_>>();
    let removed = csr
        .rules()
        .iter()
        .enumerate()
        .filter(|(index, _)| removed_original_indices.contains(index))
        .map(|(_, rule)| rule.clone())
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining_rules = csr
        .rules()
        .iter()
        .enumerate()
        .filter(|(index, _)| !removed_original_indices.contains(index))
        .map(|(_, rule)| rule.clone())
        .collect::<Vec<_>>();
    let remaining_trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_string),
        csr.trs().variables().clone(),
        remaining_rules,
        csr.trs().strategy(),
    );
    let remaining_arities = remaining_trs.arities();
    let remaining_replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter(|(symbol, _)| remaining_arities.contains_key(*symbol))
            .map(|(symbol, positions)| (symbol.clone(), positions.clone()))
            .collect(),
    );
    let remaining = CsrTrs::new(remaining_trs, remaining_replacement_map).ok()?;
    let interpretations = canonical_removal
        .interpretations
        .into_iter()
        .map(|(symbol, interpretation)| {
            let canonical = Symbol::new(symbol);
            let original = standardized
                .inverse_function_bijection
                .get(&canonical)
                .unwrap_or(&canonical);
            (original.as_str().to_string(), interpretation)
        })
        .collect();
    Some(CsrMatrixRuleRemoval {
        interpretations,
        dimension: canonical_removal.dimension,
        strict_dimension: canonical_removal.strict_dimension,
        removed,
        remaining,
    })
}

/// Recheck an externally retained natural matrix model against the complete
/// live CSR state.  In particular this validates every weak rule obligation,
/// every active-position monotonicity obligation, and derives the residual
/// rules rather than trusting retained metadata.
pub(crate) fn checked_csr_matrix_rule_removal(
    csr: &CsrTrs,
    interpretations: Vec<(String, MatrixInterpretation)>,
) -> Option<CsrMatrixRuleRemoval> {
    let dimension = interpretations.first()?.1.constant.len();
    if dimension == 0 {
        return None;
    }
    let interpretations = interpretations.into_iter().collect::<BTreeMap<_, _>>();
    if !matrix_interpretations_are_well_formed(&interpretations, dimension)
        || !csr
            .replacement_map()
            .entries()
            .iter()
            .all(|(symbol, positions)| {
                let Some(interpretation) = interpretations.get(symbol.as_str()) else {
                    return positions.is_empty();
                };
                positions.iter().all(|position| {
                    interpretation
                        .coefficients
                        .get(*position)
                        .and_then(|matrix| matrix.first())
                        .and_then(|row| row.first())
                        .is_some_and(|coefficient| *coefficient >= 1)
                })
            })
        || !csr.rules().iter().all(|rule| {
            weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations, dimension)
        })
    {
        return None;
    }
    let strict_dimension = 1;
    let removed = csr
        .rules()
        .iter()
        .filter(|rule| {
            strictly_decreases_by_matrix(
                rule.lhs(),
                rule.rhs(),
                &interpretations,
                dimension,
                strict_dimension,
            )
        })
        .cloned()
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining_rules = csr
        .rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect::<Vec<_>>();
    let remaining_trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_string),
        csr.trs().variables().clone(),
        remaining_rules,
        csr.trs().strategy(),
    );
    let remaining_arities = remaining_trs.arities();
    let remaining_replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter(|(symbol, _)| remaining_arities.contains_key(*symbol))
            .map(|(symbol, positions)| (symbol.clone(), positions.clone()))
            .collect(),
    );
    let remaining = CsrTrs::new(remaining_trs, remaining_replacement_map).ok()?;
    Some(CsrMatrixRuleRemoval {
        interpretations: interpretations.into_iter().collect(),
        dimension,
        strict_dimension,
        removed,
        remaining,
    })
}

pub(crate) fn synthesize_csr_matrix_rule_removal_raw(
    csr: &CsrTrs,
    options: &DpOptions,
    dimension: usize,
    deadline: Option<Instant>,
) -> Option<CsrMatrixRuleRemoval> {
    let pairs = csr
        .rules()
        .iter()
        .cloned()
        .enumerate()
        .map(|(index, rule)| DependencyPair::from_rule(rule, index))
        .collect::<Vec<_>>();
    let arities = arities_for_constraints(&pairs, &[]);
    if !matrix_sat_bounds_hold(&arities, options, dimension) {
        return None;
    }
    let solver = select_matrix_smt_solver(options.smt_solver.as_deref(), command_exists)?;
    let strict_dimension = 1;
    let width = matrix_bv_width(&pairs, &[], options, dimension)?;
    let script = matrix_bv_sat_script(
        &pairs,
        &[],
        &[],
        None,
        options,
        &arities,
        dimension,
        strict_dimension,
        width,
        Some(csr.replacement_map()),
        None,
        None,
        None,
        None,
        solver.flavor,
        deadline,
    )?;
    let stdout = run_matrix_smt_script(&script, &solver.command, deadline)?;
    let interpretations = parse_bv_matrix_model(&stdout, &arities, dimension)?;
    if !matrix_interpretations_are_well_formed(&interpretations, dimension)
        || !csr
            .replacement_map()
            .entries()
            .iter()
            .all(|(symbol, positions)| {
                let Some(interpretation) = interpretations.get(symbol.as_str()) else {
                    return positions.is_empty();
                };
                positions.iter().all(|position| {
                    interpretation
                        .coefficients
                        .get(*position)
                        .and_then(|matrix| matrix.first())
                        .and_then(|row| row.first())
                        .is_some_and(|coefficient| *coefficient >= 1)
                })
            })
        || !csr.rules().iter().all(|rule| {
            weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations, dimension)
        })
    {
        return None;
    }
    let removed = csr
        .rules()
        .iter()
        .filter(|rule| {
            strictly_decreases_by_matrix(
                rule.lhs(),
                rule.rhs(),
                &interpretations,
                dimension,
                strict_dimension,
            )
        })
        .cloned()
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining_rules = csr
        .rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect::<Vec<_>>();
    let remaining_trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_string),
        csr.trs().variables().clone(),
        remaining_rules,
        csr.trs().strategy(),
    );
    let remaining_arities = remaining_trs.arities();
    let remaining_replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter(|(symbol, _)| remaining_arities.contains_key(*symbol))
            .map(|(symbol, positions)| (symbol.clone(), positions.clone()))
            .collect(),
    );
    let remaining = CsrTrs::new(remaining_trs, remaining_replacement_map).ok()?;
    Some(CsrMatrixRuleRemoval {
        interpretations: interpretations.into_iter().collect(),
        dimension,
        strict_dimension,
        removed,
        remaining,
    })
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct MatrixBvForm {
    constant: Vec<String>,
    coefficients: BTreeMap<Variable, Vec<Vec<String>>>,
}

pub(crate) fn push_matrix_bv_weak(
    script: &mut String,
    lhs: &Term,
    rhs: &Term,
    dimension: usize,
    width: usize,
) {
    let lhs = matrix_bv_interpret(lhs, dimension, width);
    let rhs = matrix_bv_interpret(rhs, dimension, width);
    script.push_str(&format!(
        "(assert {})\n",
        matrix_bv_weak_formula(&lhs, &rhs, dimension, width)
    ));
}

pub(crate) fn matrix_bv_strict(
    lhs: &Term,
    rhs: &Term,
    dimension: usize,
    strict_dimension: usize,
    width: usize,
) -> String {
    let lhs = matrix_bv_interpret(lhs, dimension, width);
    let rhs = matrix_bv_interpret(rhs, dimension, width);
    matrix_bv_strict_formula(&lhs, &rhs, dimension, strict_dimension, width)
}

pub(crate) fn matrix_bv_strict_formula(
    lhs: &MatrixBvForm,
    rhs: &MatrixBvForm,
    dimension: usize,
    strict_dimension: usize,
    width: usize,
) -> String {
    let strict = (0..strict_dimension)
        .map(|index| format!("(bvugt {} {})", lhs.constant[index], rhs.constant[index]))
        .collect::<Vec<_>>();
    format!(
        "(and {} {})",
        matrix_bv_weak_formula(&lhs, &rhs, dimension, width),
        smt_or(strict)
    )
}

pub(crate) fn matrix_bv_weak_formula(
    lhs: &MatrixBvForm,
    rhs: &MatrixBvForm,
    dimension: usize,
    width: usize,
) -> String {
    let mut parts = Vec::new();
    for row in 0..dimension {
        parts.push(format!(
            "(bvuge {} {})",
            lhs.constant[row], rhs.constant[row]
        ));
    }
    for variable in lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .collect::<BTreeSet<_>>()
    {
        let left = lhs
            .coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| bv_zero_matrix(dimension, width));
        let right = rhs
            .coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| bv_zero_matrix(dimension, width));
        for row in 0..dimension {
            for column in 0..dimension {
                parts.push(format!(
                    "(bvuge {} {})",
                    left[row][column], right[row][column]
                ));
            }
        }
    }
    smt_and(parts)
}

pub(crate) fn matrix_bv_interpret_shared(
    script: &mut String,
    next_expression: &mut usize,
    term: &Term,
    dimension: usize,
    width: usize,
    parameter_width: usize,
) -> MatrixBvForm {
    matrix_bv_interpret_with_query_cache(script, next_expression, &mut None,
        term, dimension, width, parameter_width)
}

fn matrix_bv_interpret_with_query_cache(
    script: &mut String,
    next_expression: &mut usize,
    cache: &mut Option<BTreeMap<Term, MatrixBvForm>>,
    term: &Term,
    dimension: usize,
    width: usize,
    parameter_width: usize,
) -> MatrixBvForm {
    if let Some(form) = cache.as_ref().and_then(|cache| cache.get(term)) {
        return form.clone();
    }
    let form = match term {
        Term::Var(variable) => MatrixBvForm {
            constant: vec![bv_literal(0, width); dimension],
            coefficients: BTreeMap::from([(
                variable.clone(),
                bv_identity_matrix(dimension, width),
            )]),
        },
        Term::App { symbol, args } => {
            let mut constant = (0..dimension)
                .map(|row| {
                    matrix_bv_parameter_value(
                        &matrix_bv_constant_name(symbol.as_str(), row),
                        parameter_width,
                        width,
                    )
                })
                .collect::<Vec<_>>();
            let mut coefficients = BTreeMap::<Variable, Vec<Vec<String>>>::new();
            for (argument, arg) in args.iter().enumerate() {
                let matrix = matrix_bv_parameter_matrix_at_width(
                    symbol.as_str(),
                    argument,
                    dimension,
                    parameter_width,
                    width,
                );
                let arg_form = matrix_bv_interpret_with_query_cache(
                    script,
                    next_expression,
                    cache,
                    arg,
                    dimension,
                    width,
                    parameter_width,
                );
                let scaled_constant = bv_matrix_vector_product_shared(
                    script,
                    next_expression,
                    &matrix,
                    &arg_form.constant,
                    width,
                    parameter_width,
                );
                for (left, right) in constant.iter_mut().zip(scaled_constant) {
                    *left = bv_add_shared(script, next_expression, left, &right, width);
                }
                for (variable, coefficient) in arg_form.coefficients {
                    let scaled = bv_matrix_product_shared(
                        script,
                        next_expression,
                        &matrix,
                        &coefficient,
                        width,
                        parameter_width,
                    );
                    if let Some(old) = coefficients.get_mut(&variable) {
                        bv_add_matrix_in_place_shared(script, next_expression, old, &scaled, width);
                    } else {
                        coefficients.insert(variable, scaled);
                    }
                }
            }
            MatrixBvForm {
                constant,
                coefficients,
            }
        }
    };
    if let Some(cache) = cache { cache.insert(term.clone(), form.clone()); }
    form
}

pub(crate) fn bv_bind_shared(
    script: &mut String,
    next_expression: &mut usize,
    expression: String,
    width: usize,
) -> String {
    let name = format!("m_e_{next_expression}");
    *next_expression += 1;
    script.push_str(&format!(
        "(define-fun {name} () (_ BitVec {width}) {expression})\n"
    ));
    name
}

#[cfg(test)]
mod matrix_query_cache_tests {
    use super::*;

    #[test]
    fn matrix_parameter_bit_product_equals_full_multiplication() {
        for parameter_width in 1..=3 {
            let mut script = format!("(set-logic QF_BV)\n(declare-const p (_ BitVec {parameter_width}))\n(declare-const v (_ BitVec 16))\n");
            let parameter = matrix_bv_parameter_value("p", parameter_width, 16);
            let product = bv_mul_parameter_bits_shared(&mut script, &mut 0,
                &parameter, "v", 16, parameter_width);
            script.push_str(&format!("(assert (distinct {product} (bvmul {parameter} v)))\n(check-sat)\n"));
            let result = run_smt_script(&script, &DpOptions::default(),
                Some(Instant::now() + Duration::from_secs(30))).unwrap();
            assert_eq!(result.split_whitespace().next(), Some("unsat"));
        }
    }

    #[test]
    fn query_cache_preserves_forms_and_distinguishes_variables() {
        let sub = Term::app("g", vec![Term::var("x")]);
        let term = Term::app("f", vec![sub.clone(), sub]);
        let mut script = String::from("(set-logic QF_BV)\n");
        for (symbol, arity) in [("f", 2), ("g", 1)] {
            for row in 0..2 {
                script.push_str(&format!("(declare-const {} (_ BitVec 2))\n",
                    matrix_bv_constant_name(symbol, row)));
                for arg in 0..arity {
                    for col in 0..2 {
                        script.push_str(&format!("(declare-const {} (_ BitVec 2))\n",
                            matrix_bv_coefficient_name(symbol, arg, row, col)));
                    }
                }
            }
        }
        let mut index = 0;
        let plain = matrix_bv_interpret_shared(&mut script, &mut index, &term, 2, 16, 2);
        let plain_count = index;
        let mut cache = Some(BTreeMap::new());
        let cached = matrix_bv_interpret_with_query_cache(&mut script, &mut index,
            &mut cache, &term, 2, 16, 2);
        assert!(index - plain_count < plain_count);
        let saved = index;
        let again = matrix_bv_interpret_with_query_cache(&mut script, &mut index,
            &mut cache, &term, 2, 16, 2);
        assert_eq!(index, saved);
        assert_eq!(cached.constant, again.constant);
        let other = matrix_bv_interpret_with_query_cache(&mut script, &mut index,
            &mut cache, &Term::app("g", vec![Term::var("y")]), 2, 16, 2);
        assert!(other.coefficients.contains_key(&Variable::new("y")));
        assert!(!other.coefficients.contains_key(&Variable::new("x")));
        let mut differences = plain.constant.iter().zip(&cached.constant)
            .map(|(a,b)| format!("(distinct {a} {b})")).collect::<Vec<_>>();
        for (variable, matrix) in &plain.coefficients {
            for (a,b) in matrix.iter().flatten().zip(cached.coefficients[variable].iter().flatten()) {
                differences.push(format!("(distinct {a} {b})"));
            }
        }
        script.push_str(&format!("(assert {})\n(check-sat)\n", smt_or(differences)));
        let result = run_smt_script(&script, &DpOptions::default(),
            Some(Instant::now() + Duration::from_secs(30))).unwrap();
        assert_eq!(result.split_whitespace().next(), Some("unsat"));
    }
}

pub(crate) fn bv_add_shared(
    script: &mut String,
    next_expression: &mut usize,
    left: &str,
    right: &str,
    width: usize,
) -> String {
    let zero = bv_literal(0, width);
    if left == zero {
        return right.to_string();
    }
    if right == zero {
        return left.to_string();
    }
    bv_bind_shared(script, next_expression, bv_add(left, right), width)
}

pub(crate) fn bv_matrix_vector_product_shared(
    script: &mut String,
    next_expression: &mut usize,
    matrix: &[Vec<String>],
    vector: &[String],
    width: usize,
    parameter_width: usize,
) -> Vec<String> {
    matrix
        .iter()
        .map(|row| {
            row.iter()
                .zip(vector)
                .fold(bv_literal(0, width), |sum, (left, right)| {
                    let product = bv_mul_bounded_parameter_shared(
                        script,
                        next_expression,
                        left,
                        right,
                        width,
                        parameter_width,
                    );
                    bv_add_shared(script, next_expression, &sum, &product, width)
                })
        })
        .collect()
}

pub(crate) fn bv_matrix_product_shared(
    script: &mut String,
    next_expression: &mut usize,
    left: &[Vec<String>],
    right: &[Vec<String>],
    width: usize,
    parameter_width: usize,
) -> Vec<Vec<String>> {
    let columns = right.first().map_or(0, Vec::len);
    left.iter()
        .map(|left_row| {
            (0..columns)
                .map(|column| {
                    left_row
                        .iter()
                        .enumerate()
                        .fold(bv_literal(0, width), |sum, (index, value)| {
                            let product = bv_mul_bounded_parameter_shared(
                                script,
                                next_expression,
                                value,
                                &right[index][column],
                                width,
                                parameter_width,
                            );
                            bv_add_shared(script, next_expression, &sum, &product, width)
                        })
                })
                .collect()
        })
        .collect()
}

pub(crate) fn bv_mul_bounded_parameter_shared(
    script: &mut String,
    next_expression: &mut usize,
    parameter: &str,
    value: &str,
    width: usize,
    parameter_width: usize,
) -> String {
    let zero = bv_literal(0, width);
    if value == zero {
        return zero;
    }
    if parameter_width <= 3 && std::env::var_os("FERRUM_MATRIX_BIT_PRODUCT").is_some() {
        return bv_mul_parameter_bits_shared(script, next_expression, parameter, value,
            width, parameter_width);
    }
    let max_parameter = (1usize << parameter_width.min(3)).saturating_sub(1);
    let mut expression = zero;
    for coefficient in 1..=max_parameter {
        let product = if coefficient == 1 {
            value.to_string()
        } else if coefficient.is_power_of_two() {
            format!(
                "(bvshl {value} {})",
                bv_literal(coefficient.trailing_zeros() as u128, width)
            )
        } else {
            bv_mul(value, &bv_literal(coefficient as u128, width))
        };
        expression = format!(
            "(ite (= {parameter} {}) {product} {expression})",
            bv_literal(coefficient as u128, width)
        );
    }
    bv_bind_shared(script, next_expression, expression, width)
}

fn bv_mul_parameter_bits_shared(
    script: &mut String, next_expression: &mut usize, parameter: &str, value: &str,
    width: usize, parameter_width: usize,
) -> String {
    let zero = bv_literal(0, width);
    let mut sum = zero.clone();
    for bit in 0..parameter_width {
        let shifted = if bit == 0 { value.to_owned() }
            else { format!("(bvshl {value} {})", bv_literal(bit as u128, width)) };
        let summand = bv_bind_shared(script, next_expression,
            format!("(ite (= ((_ extract {bit} {bit}) {parameter}) #b1) {shifted} {zero})"), width);
        sum = bv_add_shared(script, next_expression, &sum, &summand, width);
    }
    sum
}

pub(crate) fn bv_add_matrix_in_place_shared(
    script: &mut String,
    next_expression: &mut usize,
    left: &mut [Vec<String>],
    right: &[Vec<String>],
    width: usize,
) {
    for (left_row, right_row) in left.iter_mut().zip(right) {
        for (left_value, right_value) in left_row.iter_mut().zip(right_row) {
            *left_value = bv_add_shared(script, next_expression, left_value, right_value, width);
        }
    }
}

pub(crate) fn matrix_bv_interpret(term: &Term, dimension: usize, width: usize) -> MatrixBvForm {
    match term {
        Term::Var(variable) => MatrixBvForm {
            constant: vec![bv_literal(0, width); dimension],
            coefficients: BTreeMap::from([(
                variable.clone(),
                bv_identity_matrix(dimension, width),
            )]),
        },
        Term::App { symbol, args } => {
            let mut constant = (0..dimension)
                .map(|row| matrix_bv_constant_name(symbol.as_str(), row))
                .collect::<Vec<_>>();
            let mut coefficients = BTreeMap::<Variable, Vec<Vec<String>>>::new();
            for (argument, arg) in args.iter().enumerate() {
                let matrix = matrix_bv_parameter_matrix(symbol.as_str(), argument, dimension);
                let arg_form = matrix_bv_interpret(arg, dimension, width);
                let scaled_constant = bv_matrix_vector_product(&matrix, &arg_form.constant, width);
                for (left, right) in constant.iter_mut().zip(scaled_constant) {
                    *left = bv_add(left, &right);
                }
                for (variable, coefficient) in arg_form.coefficients {
                    let scaled = bv_matrix_product(&matrix, &coefficient, width);
                    coefficients
                        .entry(variable)
                        .and_modify(|old| bv_add_matrix_in_place(old, &scaled))
                        .or_insert(scaled);
                }
            }
            MatrixBvForm {
                constant,
                coefficients,
            }
        }
    }
}

pub(crate) fn matrix_sat_bounds_hold(
    arities: &BTreeMap<String, usize>,
    options: &DpOptions,
    dimension: usize,
) -> bool {
    matrix_common_bounds_hold(arities, options, dimension)
        && options.max_polynomial_coefficient >= 0
}

pub(crate) fn matrix_common_bounds_hold(
    arities: &BTreeMap<String, usize>,
    options: &DpOptions,
    dimension: usize,
) -> bool {
    dimension > 0
        && !arities.is_empty()
        && arities.len() <= options.max_polynomial_symbols
        && arities
            .values()
            .all(|arity| *arity <= options.max_polynomial_arity)
        && options.max_polynomial_constant >= 0
}

pub(crate) fn identity_matrix(dimension: usize) -> Vec<Vec<i64>> {
    (0..dimension)
        .map(|row| {
            (0..dimension)
                .map(|column| i64::from(row == column))
                .collect()
        })
        .collect()
}

pub(crate) fn zero_matrix(dimension: usize) -> Vec<Vec<i64>> {
    vec![vec![0; dimension]; dimension]
}

pub(crate) fn synthesize_linear_polynomial_with_smt(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<(LinearPolynomialInterpretations, bool)> {
    if !options.smt_fallback {
        return None;
    }
    let encode_started = Instant::now();
    let script = smt_script(pairs, usable, options)?;
    write_smt_encoding_event(
        "linear-polynomial-smt",
        encode_started,
        &script,
        pairs,
        usable,
        "",
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    parse_smt_model(&stdout, &arities_for_constraints(pairs, usable)).map(|model| (model, true))
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SymbolicNaturalPolynomial {
    terms: BTreeMap<PolynomialMonomial, String>,
}

impl SymbolicNaturalPolynomial {
    pub(crate) fn zero() -> Self {
        Self {
            terms: BTreeMap::new(),
        }
    }

    pub(crate) fn constant(coefficient: String) -> Self {
        Self {
            terms: BTreeMap::from([(PolynomialMonomial::one(), coefficient)]),
        }
    }

    pub(crate) fn variable(variable: Variable) -> Self {
        Self {
            terms: BTreeMap::from([(PolynomialMonomial::variable(variable), "1".to_string())]),
        }
    }

    pub(crate) fn coefficient(&self, monomial: &PolynomialMonomial) -> &str {
        self.terms.get(monomial).map_or("0", String::as_str)
    }

    fn add_scaled_until(
        &mut self,
        other: &Self,
        scale: &str,
        deadline: Option<Instant>,
    ) -> Option<()> {
        for (monomial, coefficient) in &other.terms {
            if smt_build_cancelled(deadline)
                || scale.len().saturating_add(coefficient.len())
                    > MAX_SYMBOLIC_POLYNOMIAL_EXPRESSION_BYTES
            {
                return None;
            }
            let value = smt_mul(scale, coefficient);
            if let Some(old) = self.terms.get(monomial)
                && old.len().saturating_add(value.len()) > MAX_SYMBOLIC_POLYNOMIAL_EXPRESSION_BYTES
            {
                return None;
            }
            self.terms
                .entry(monomial.clone())
                .and_modify(|old| *old = smt_add(old, &value))
                .or_insert(value);
        }
        Some(())
    }

    fn multiply_until(&self, other: &Self, deadline: Option<Instant>) -> Option<Self> {
        let mut result = Self::zero();
        for (left_monomial, left_coefficient) in &self.terms {
            for (right_monomial, right_coefficient) in &other.terms {
                if smt_build_cancelled(deadline)
                    || left_coefficient
                        .len()
                        .saturating_add(right_coefficient.len())
                        > MAX_SYMBOLIC_POLYNOMIAL_EXPRESSION_BYTES
                {
                    return None;
                }
                let monomial = left_monomial.multiply(right_monomial)?;
                let value = smt_mul(left_coefficient, right_coefficient);
                if let Some(old) = result.terms.get(&monomial)
                    && old.len().saturating_add(value.len())
                        > MAX_SYMBOLIC_POLYNOMIAL_EXPRESSION_BYTES
                {
                    return None;
                }
                result
                    .terms
                    .entry(monomial)
                    .and_modify(|old| *old = smt_add(old, &value))
                    .or_insert(value);
            }
        }
        Some(result)
    }
}

const MAX_SYMBOLIC_POLYNOMIAL_EXPRESSION_BYTES: usize = 1 << 20;

pub(crate) fn synthesize_quadratic_polynomial_with_smt(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, NaturalPolynomial>> {
    let arities = arities_for_constraints(pairs, usable);
    if arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 1
    {
        return None;
    }
    let encode_started = Instant::now();
    let script = quadratic_polynomial_smt_script(pairs, usable, options, &arities, deadline)?;
    write_smt_encoding_event(
        "quadratic-polynomial",
        encode_started,
        &script,
        pairs,
        usable,
        format!("symbols={}", arities.len()),
    );
    let stdout = run_smt_script(&script, options, deadline)?;
    parse_quadratic_polynomial_model(&stdout, &arities)
}

pub(crate) fn synthesize_rational_quadratic_polynomial_with_smt(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    required_strict_rule_indices: &[usize],
    options: &DpOptions,
    denominator: i64,
    delta: i64,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, NaturalPolynomial>> {
    synthesize_rational_quadratic_polynomial_smt_mode(pairs, usable,
        required_strict_rule_indices, options, denominator, delta, deadline, false, &[], None, "any")
}

pub(crate) fn synthesize_rational_quadratic_polynomial_with_integer_smt(
    pairs: &[DependencyPair], usable: &[RewriteRule], required_strict_rule_indices: &[usize],
    options: &DpOptions, denominator: i64, delta: i64, deadline: Option<Instant>,
    coefficient_values: &[i64], max_quadratic_terms: Option<usize>, quadratic_shape: &str,
) -> Option<BTreeMap<String, NaturalPolynomial>> {
    synthesize_rational_quadratic_polynomial_smt_mode(pairs, usable,
        required_strict_rule_indices, options, denominator, delta, deadline, true,
        coefficient_values, max_quadratic_terms, quadratic_shape)
}

fn synthesize_rational_quadratic_polynomial_smt_mode(
    pairs: &[DependencyPair], usable: &[RewriteRule], required_strict_rule_indices: &[usize],
    options: &DpOptions, denominator: i64, delta: i64, deadline: Option<Instant>,
    integer_encoding: bool,
    coefficient_values: &[i64], max_quadratic_terms: Option<usize>, quadratic_shape: &str,
) -> Option<BTreeMap<String, NaturalPolynomial>> {
    let encode_started = Instant::now();
    let arities = arities_for_constraints(pairs, usable);
    if denominator <= 0
        || delta <= 0
        || arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 0
    {
        return None;
    }
    let mut script = String::from(if integer_encoding { "(set-logic QF_NIA)\n" }
        else { "(set-logic ALL)\n" });
    if coefficient_values.iter().any(|v| *v < 0) { return None; }
    let restrict_domain = |script: &mut String, name: &str| {
        if !coefficient_values.is_empty() {
            script.push_str(&format!("(assert {})\n", smt_or(coefficient_values.iter()
                .map(|value| format!("(= {name} {value})")).collect())));
        }
    };
    for (symbol, arity) in &arities {
        check_smt_build(&script, deadline)?;
        let constant = quadratic_smt_c(symbol);
        script.push_str(&format!("(declare-const {constant} Int)\n"));
        script.push_str(&format!(
            "(assert (and (>= {constant} 0) (<= {constant} {})))\n",
            options.max_polynomial_constant
        ));
        restrict_domain(&mut script, &constant);
        for index in 0..*arity {
            let linear = quadratic_smt_a(symbol, index);
            script.push_str(&format!("(declare-const {linear} Int)\n"));
            script.push_str(&format!(
                "(assert (and (>= {linear} 0) (<= {linear} {})))\n",
                options.max_polynomial_coefficient
            ));
            restrict_domain(&mut script, &linear);
        }
        let mut nonzero_quadratic = Vec::new();
        for left in 0..*arity {
            for right in left..*arity {
                let quadratic = quadratic_smt_b(symbol, left, right);
                script.push_str(&format!("(declare-const {quadratic} Int)\n"));
                script.push_str(&format!(
                    "(assert (and (>= {quadratic} 0) (<= {quadratic} {})))\n",
                    options.max_polynomial_coefficient
                ));
                restrict_domain(&mut script, &quadratic);
                if !quadratic_shape_allows(quadratic_shape, *arity, left, right) {
                    script.push_str(&format!("(assert (= {quadratic} 0))\n"));
                }
                nonzero_quadratic.push(format!("(ite (= {quadratic} 0) 0 1)"));
            }
        }
        if let Some(limit) = max_quadratic_terms {
            if nonzero_quadratic.len() > limit {
                let count = nonzero_quadratic.iter().fold("0".to_owned(), |sum, term| smt_add(&sum, term));
                script.push_str(&format!("(assert (<= {count} {limit}))\n"));
            }
        }
    }
    let relation = |lhs: &Term, rhs: &Term, strict: bool| -> Option<String> {
        if integer_encoding {
            let (lhs, lp) = scaled_rational_quadratic_interpret_shape(lhs, denominator, deadline, quadratic_shape)?;
            let (rhs, rp) = scaled_rational_quadratic_interpret_shape(rhs, denominator, deadline, quadratic_shape)?;
            let power = lp.max(rp).max(1);
            let base = u128::try_from(denominator).ok()?;
            let ls = base.checked_pow(power - lp)?.to_string();
            let rs = base.checked_pow(power - rp)?.to_string();
            let gap = base.checked_pow(power - 1)?.checked_mul(u128::try_from(delta).ok()?)?.to_string();
            let monomials = lhs.terms.keys().chain(rhs.terms.keys()).cloned().collect::<BTreeSet<_>>();
            let mut constraints = monomials.iter().map(|m| format!("(>= {} {})",
                smt_mul(lhs.coefficient(m), &ls), smt_mul(rhs.coefficient(m), &rs))).collect::<Vec<_>>();
            if strict {
                let one = PolynomialMonomial::one();
                constraints.push(format!("(>= {} (+ {} {gap}))",
                    smt_mul(lhs.coefficient(&one), &ls), smt_mul(rhs.coefficient(&one), &rs)));
            }
            return Some(smt_and(constraints));
        }
        let lhs = symbolic_rational_quadratic_interpret_until(lhs, denominator, deadline)?;
        let rhs = symbolic_rational_quadratic_interpret_until(rhs, denominator, deadline)?;
        let weak = symbolic_polynomial_weak_formula(&lhs, &rhs);
        if !strict {
            return Some(weak);
        }
        let constant = PolynomialMonomial::one();
        Some(smt_and(vec![
            weak,
            format!(
                "(>= {} (+ {} (/ {delta}.0 {denominator}.0)))",
                lhs.coefficient(&constant),
                rhs.coefficient(&constant)
            ),
        ]))
    };
    let required_strict_rule_indices = required_strict_rule_indices
        .iter()
        .copied()
        .collect::<BTreeSet<_>>();
    for (index, rule) in usable.iter().enumerate() {
        script.push_str(&format!(
            "(assert {})\n",
            relation(rule.lhs(), rule.rhs(), false)?
        ));
        if required_strict_rule_indices.contains(&index) {
            script.push_str(&format!(
                "(assert {})\n",
                relation(rule.lhs(), rule.rhs(), true)?
            ));
        }
        check_smt_build(&script, deadline)?;
    }
    let mut strict = Vec::new();
    for pair in pairs {
        script.push_str(&format!(
            "(assert {})\n",
            relation(pair.lhs(), pair.rhs(), false)?
        ));
        strict.push(relation(pair.lhs(), pair.rhs(), true)?);
        check_smt_build(&script, deadline)?;
    }
    if strict.is_empty() {
        return None;
    }
    script.push_str(&format!(
        "(assert {})\n(check-sat)\n(get-model)\n",
        smt_or(strict)
    ));
    write_smt_encoding_event("rational-quadratic", encode_started, &script, pairs, usable,
        format!("denominator={denominator} delta={delta} integer={integer_encoding} quadratic_terms={max_quadratic_terms:?}"));
    if std::env::var_os("FERRUM_PROGRESS_LOG_SMT_SCRIPT").is_some() {
        write_progress_event("dp-order", "script", "rational-quadratic", 0, &script.replace('\n', "\\n"));
    }
    let stdout = if let Some(solver) = options.smt_solver.as_deref() {
        run_smt_script_with_solver(&script, solver, deadline)?
    } else if command_exists("cvc5") {
        run_smt_script_with_solver(&script, "cvc5", deadline)?
    } else {
        run_smt_script(&script, options, deadline)?
    };
    parse_quadratic_polynomial_model(&stdout, &arities)
}

pub(crate) fn quadratic_polynomial_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    arities: &BTreeMap<String, usize>,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::from("(set-logic QF_NIA)\n");
    for (symbol, arity) in arities {
        check_smt_build(&script, deadline)?;
        let constant = quadratic_smt_c(symbol);
        script.push_str(&format!("(declare-const {constant} Int)\n"));
        script.push_str(&format!(
            "(assert (and (>= {constant} 0) (<= {constant} {})))\n",
            options.max_polynomial_constant
        ));
        for index in 0..*arity {
            let linear = quadratic_smt_a(symbol, index);
            script.push_str(&format!("(declare-const {linear} Int)\n"));
            script.push_str(&format!(
                "(assert (and (>= {linear} 1) (<= {linear} {})))\n",
                options.max_polynomial_coefficient
            ));
        }
        for left in 0..*arity {
            for right in left..*arity {
                let quadratic = quadratic_smt_b(symbol, left, right);
                script.push_str(&format!("(declare-const {quadratic} Int)\n"));
                script.push_str(&format!(
                    "(assert (and (>= {quadratic} 0) (<= {quadratic} {})))\n",
                    options.max_polynomial_coefficient
                ));
            }
        }
    }
    for rule in usable {
        let lhs = symbolic_quadratic_interpret_until(rule.lhs(), deadline)?;
        let rhs = symbolic_quadratic_interpret_until(rule.rhs(), deadline)?;
        script.push_str("(assert ");
        script.push_str(&symbolic_polynomial_weak_formula(&lhs, &rhs));
        script.push_str(")\n");
        check_smt_build(&script, deadline)?;
    }
    let mut strict = Vec::new();
    for pair in pairs {
        let lhs = symbolic_quadratic_interpret_until(pair.lhs(), deadline)?;
        let rhs = symbolic_quadratic_interpret_until(pair.rhs(), deadline)?;
        script.push_str("(assert ");
        script.push_str(&symbolic_polynomial_weak_formula(&lhs, &rhs));
        script.push_str(")\n");
        strict.push(symbolic_polynomial_strict_formula(&lhs, &rhs));
        check_smt_build(&script, deadline)?;
    }
    if strict.is_empty() {
        return None;
    }
    script.push_str("(assert ");
    script.push_str(&smt_or(strict));
    script.push_str(")\n(check-sat)\n(get-model)\n");
    check_smt_build(&script, deadline)?;
    Some(script)
}

fn symbolic_quadratic_interpret_until(
    term: &Term,
    deadline: Option<Instant>,
) -> Option<SymbolicNaturalPolynomial> {
    if smt_build_cancelled(deadline) {
        return None;
    }
    match term {
        Term::Var(variable) => Some(SymbolicNaturalPolynomial::variable(variable.clone())),
        Term::App { symbol, args } => {
            let mut arguments = Vec::with_capacity(args.len());
            for argument in args {
                arguments.push(symbolic_quadratic_interpret_until(argument, deadline)?);
            }
            let mut result = SymbolicNaturalPolynomial::constant(quadratic_smt_c(symbol.as_str()));
            for (index, argument) in arguments.iter().enumerate() {
                result.add_scaled_until(
                    argument,
                    &quadratic_smt_a(symbol.as_str(), index),
                    deadline,
                )?;
            }
            for left in 0..arguments.len() {
                for right in left..arguments.len() {
                    let product = arguments[left].multiply_until(&arguments[right], deadline)?;
                    result.add_scaled_until(
                        &product,
                        &quadratic_smt_b(symbol.as_str(), left, right),
                        deadline,
                    )?;
                }
            }
            Some(result)
        }
    }
}

fn symbolic_rational_quadratic_interpret_until(
    term: &Term,
    denominator: i64,
    deadline: Option<Instant>,
) -> Option<SymbolicNaturalPolynomial> {
    if smt_build_cancelled(deadline) {
        return None;
    }
    match term {
        Term::Var(variable) => Some(SymbolicNaturalPolynomial::variable(variable.clone())),
        Term::App { symbol, args } => {
            let mut arguments = Vec::with_capacity(args.len());
            for argument in args {
                arguments.push(symbolic_rational_quadratic_interpret_until(
                    argument,
                    denominator,
                    deadline,
                )?);
            }
            let parameter = |name: String| smt_rational_parameter(&name, denominator);
            let mut result =
                SymbolicNaturalPolynomial::constant(parameter(quadratic_smt_c(symbol.as_str())));
            for (index, argument) in arguments.iter().enumerate() {
                result.add_scaled_until(
                    argument,
                    &parameter(quadratic_smt_a(symbol.as_str(), index)),
                    deadline,
                )?;
            }
            for left in 0..arguments.len() {
                for right in left..arguments.len() {
                    let product = arguments[left].multiply_until(&arguments[right], deadline)?;
                    result.add_scaled_until(
                        &product,
                        &parameter(quadratic_smt_b(symbol.as_str(), left, right)),
                        deadline,
                    )?;
                }
            }
            Some(result)
        }
    }
}

/// Integer numerator plus a power of the common denominator. Each composition
/// uses d^(1+2*max_child_power), so all coefficient comparisons can be cleared
/// exactly without mixed integer/real nonlinear arithmetic. Overflow declines
/// this encoding rather than wrapping a scaling factor.
#[cfg(test)]
fn scaled_rational_quadratic_interpret(
    term: &Term, denominator: i64, deadline: Option<Instant>,
) -> Option<(SymbolicNaturalPolynomial, u32)> {
    scaled_rational_quadratic_interpret_shape(term, denominator, deadline, "any")
}

fn quadratic_shape_allows(shape: &str, arity: usize, left: usize, right: usize) -> bool {
    match shape {
        "any" => true,
        "multilinear" => left != right,
        "unary-squares" => left != right || arity == 1,
        _ => false,
    }
}

fn scaled_rational_quadratic_interpret_shape(
    term: &Term, denominator: i64, deadline: Option<Instant>, shape: &str,
) -> Option<(SymbolicNaturalPolynomial, u32)> {
    if smt_build_cancelled(deadline) || denominator <= 0 { return None; }
    match term {
        Term::Var(v) => Some((SymbolicNaturalPolynomial::variable(v.clone()), 0)),
        Term::App { symbol, args } => {
            let args = args.iter().map(|a| scaled_rational_quadratic_interpret_shape(a, denominator, deadline, shape))
                .collect::<Option<Vec<_>>>()?;
            let child_power = args.iter().map(|(_, p)| *p).max().unwrap_or(0);
            let power = child_power.checked_mul(2)?.checked_add(1)?;
            let base = u128::try_from(denominator).ok()?;
            let scale = |name: String, exponent: u32| {
                Some(smt_mul(&name, &base.checked_pow(exponent)?.to_string()))
            };
            let mut result = SymbolicNaturalPolynomial::constant(
                scale(quadratic_smt_c(symbol.as_str()), power - 1)?);
            for (index, (arg, exponent)) in args.iter().enumerate() {
                result.add_scaled_until(arg,
                    &scale(quadratic_smt_a(symbol.as_str(), index), power - 1 - exponent)?, deadline)?;
            }
            for left in 0..args.len() {
                for right in left..args.len() {
                    if !quadratic_shape_allows(shape, args.len(), left, right) { continue; }
                    let product = args[left].0.multiply_until(&args[right].0, deadline)?;
                    result.add_scaled_until(&product, &scale(
                        quadratic_smt_b(symbol.as_str(), left, right),
                        power - 1 - args[left].1 - args[right].1)?, deadline)?;
                }
            }
            Some((result, power))
        }
    }
}

#[cfg(test)]
mod scaled_quadratic_tests {
    use super::*;

    #[test]
    fn quadratic_shape_restrictions_remove_only_forbidden_monomials() {
        let term = Term::app("f", vec![Term::var("x"), Term::var("y")]);
        let (poly, _) = scaled_rational_quadratic_interpret_shape(&term, 2, None, "multilinear").unwrap();
        let encoding = format!("{poly:?}");
        assert!(!encoding.contains(&quadratic_smt_b("f", 0, 0)));
        assert!(!encoding.contains(&quadratic_smt_b("f", 1, 1)));
        assert!(encoding.contains(&quadratic_smt_b("f", 0, 1)));
        let unary = Term::app("g", vec![Term::var("x")]);
        let (poly, _) = scaled_rational_quadratic_interpret_shape(&unary, 2, None, "unary-squares").unwrap();
        assert!(format!("{poly:?}").contains(&quadratic_smt_b("g", 0, 0)));
    }

    #[test]
    fn cleared_denominators_match_rational_composition() {
        let term = Term::app("f", vec![Term::app("g", vec![Term::var("x")]), Term::var("y")]);
        let original = symbolic_rational_quadratic_interpret_until(&term, 2, None).unwrap();
        let (scaled, power) = scaled_rational_quadratic_interpret(&term, 2, None).unwrap();
        assert_eq!(power, 3);
        assert_eq!(original.terms.keys().collect::<Vec<_>>(), scaled.terms.keys().collect::<Vec<_>>());
        let mut script = String::from("(set-logic ALL)\n");
        for (symbol, arity) in [("f", 2), ("g", 1)] {
            let mut names = vec![quadratic_smt_c(symbol)];
            for i in 0..arity {
                names.push(quadratic_smt_a(symbol, i));
                for j in i..arity { names.push(quadratic_smt_b(symbol, i, j)); }
            }
            for name in names { script.push_str(&format!("(declare-const {name} Int)\n")); }
        }
        let differences = original.terms.iter().map(|(m, coefficient)| {
            assert!(!scaled.coefficient(m).contains("to_real"));
            assert!(!scaled.coefficient(m).contains("(/"));
            format!("(distinct {coefficient} (/ (to_real {}) 8.0))", scaled.coefficient(m))
        }).collect();
        script.push_str(&format!("(assert {})\n(check-sat)\n", smt_or(differences)));
        let result = run_smt_script(&script, &DpOptions::default(),
            Some(Instant::now() + Duration::from_secs(10))).unwrap();
        assert_eq!(result.split_whitespace().next(), Some("unsat"));
    }

    #[test]
    fn oversized_denominator_scaling_fails_closed() {
        let mut term = Term::var("x");
        for _ in 0..8 { term = Term::app("f", vec![term]); }
        assert!(scaled_rational_quadratic_interpret(&term, 256, None).is_none());
        assert!(scaled_rational_quadratic_interpret(&term, 0, None).is_none());
    }
}

pub(crate) fn smt_rational_parameter(parameter: &str, denominator: i64) -> String {
    format!("(/ (to_real {parameter}) {denominator}.0)")
}

pub(crate) fn symbolic_polynomial_weak_formula(
    lhs: &SymbolicNaturalPolynomial,
    rhs: &SymbolicNaturalPolynomial,
) -> String {
    let comparisons = lhs
        .terms
        .keys()
        .chain(rhs.terms.keys())
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .map(|monomial| {
            format!(
                "(>= {} {})",
                lhs.coefficient(&monomial),
                rhs.coefficient(&monomial)
            )
        })
        .collect::<Vec<_>>();
    smt_and(comparisons)
}

pub(crate) fn symbolic_polynomial_strict_formula(
    lhs: &SymbolicNaturalPolynomial,
    rhs: &SymbolicNaturalPolynomial,
) -> String {
    let constant = PolynomialMonomial::one();
    let mut comparisons = lhs
        .terms
        .keys()
        .chain(rhs.terms.keys())
        .filter(|monomial| **monomial != constant)
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .map(|monomial| {
            format!(
                "(>= {} {})",
                lhs.coefficient(&monomial),
                rhs.coefficient(&monomial)
            )
        })
        .collect::<Vec<_>>();
    comparisons.push(format!(
        "(> {} {})",
        lhs.coefficient(&constant),
        rhs.coefficient(&constant)
    ));
    smt_and(comparisons)
}

pub(crate) fn parse_quadratic_polynomial_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
) -> Option<BTreeMap<String, NaturalPolynomial>> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_smt_values(output)?;
    arities
        .iter()
        .map(|(symbol, arity)| {
            let constant = values.get(&quadratic_smt_c(symbol)).copied()?;
            let linear = (0..*arity)
                .map(|index| values.get(&quadratic_smt_a(symbol, index)).copied())
                .collect::<Option<Vec<_>>>()?;
            let mut quadratic = vec![vec![0; *arity]; *arity];
            for (left, row) in quadratic.iter_mut().enumerate() {
                for (right, coefficient) in row.iter_mut().enumerate().skip(left) {
                    *coefficient = values.get(&quadratic_smt_b(symbol, left, right)).copied()?;
                }
            }
            Some((
                symbol.clone(),
                NaturalPolynomial {
                    constant,
                    linear,
                    quadratic,
                },
            ))
        })
        .collect()
}

pub(crate) fn smt_solver_args(solver: &str) -> &'static [&'static str] {
    let name = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(solver);
    if name.contains("cvc5") {
        &["-q", "--lang", "smt2", "--produce-models", "--incremental"]
    } else if name.contains("boolector") {
        &[
            "--smt2",
            "--model-gen",
            "--output-number-format=bin",
            "--exit-codes=0",
        ]
    } else {
        &["-in"]
    }
}

pub(crate) fn smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
) -> Option<String> {
    let arities = arities_for_constraints(pairs, usable);
    if arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
    {
        return None;
    }
    let mut script = String::new();
    script.push_str("(set-logic QF_NIA)\n");
    for (symbol, arity) in &arities {
        script.push_str(&format!("(declare-const {} Int)\n", smt_c(symbol)));
        script.push_str(&format!(
            "(assert (and (>= {} 0) (<= {} {})))\n",
            smt_c(symbol),
            smt_c(symbol),
            options.max_polynomial_constant
        ));
        for index in 0..*arity {
            script.push_str(&format!("(declare-const {} Int)\n", smt_a(symbol, index)));
            script.push_str(&format!(
                "(assert (and (>= {} 0) (<= {} {})))\n",
                smt_a(symbol, index),
                smt_a(symbol, index),
                options.max_polynomial_coefficient
            ));
        }
    }
    for rule in usable {
        push_smt_weak(&mut script, rule.lhs(), rule.rhs());
    }
    let mut strict_terms = Vec::new();
    for pair in pairs {
        push_smt_weak(&mut script, pair.lhs(), pair.rhs());
        strict_terms.push(smt_strict(pair.lhs(), pair.rhs()));
    }
    script.push_str("(assert (or");
    for term in strict_terms {
        script.push(' ');
        script.push_str(&term);
    }
    script.push_str("))\n(check-sat)\n(get-model)\n");
    Some(script)
}

pub(crate) fn monotonic_usable_smt_script(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    usable_restriction_is_progress: bool,
) -> Option<String> {
    let arities = arities_for_constraints(pairs, usable);
    if arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|arity| *arity > options.max_polynomial_arity)
    {
        return None;
    }
    let mut script = String::new();
    script.push_str("(set-logic QF_NIA)\n");
    for (symbol, arity) in &arities {
        script.push_str(&format!("(declare-const {} Int)\n", smt_c(symbol)));
        script.push_str(&format!(
            "(assert (and (>= {} 0) (<= {} {})))\n",
            smt_c(symbol),
            smt_c(symbol),
            options.max_polynomial_constant
        ));
        for index in 0..*arity {
            script.push_str(&format!("(declare-const {} Int)\n", smt_a(symbol, index)));
            script.push_str(&format!(
                "(assert (and (>= {} 1) (<= {} {})))\n",
                smt_a(symbol, index),
                smt_a(symbol, index),
                options.max_polynomial_coefficient
            ));
        }
    }
    for rule in usable {
        push_smt_weak(&mut script, rule.lhs(), rule.rhs());
    }
    let mut strict_terms = usable
        .iter()
        .map(|rule| smt_strict(rule.lhs(), rule.rhs()))
        .collect::<Vec<_>>();
    for pair in pairs {
        push_smt_weak(&mut script, pair.lhs(), pair.rhs());
        strict_terms.push(smt_strict(pair.lhs(), pair.rhs()));
    }
    if !usable_restriction_is_progress {
        if strict_terms.is_empty() {
            return None;
        }
        script.push_str(&format!("(assert {})\n", smt_or(strict_terms)));
    }
    if options.smt_solver.as_deref().unwrap_or("z3").rsplit('/').next() == Some("z3")
        && command_exists(options.smt_solver.as_deref().unwrap_or("z3")) {
        script.push_str("(set-option :opt.priority lex)\n");
        for pair in pairs {
            script.push_str(&format!("(maximize (ite {} 1 0))\n", smt_strict(pair.lhs(), pair.rhs())));
        }
        for rule in usable {
            script.push_str(&format!("(maximize (ite {} 1 0))\n", smt_strict(rule.lhs(), rule.rhs())));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    Some(script)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SmtForm {
    constant: String,
    coefficients: BTreeMap<String, String>,
}

pub(crate) fn smt_interpret(term: &Term) -> SmtForm {
    match term {
        Term::Var(variable) => SmtForm {
            constant: "0".to_string(),
            coefficients: BTreeMap::from([(variable.as_str().to_string(), "1".to_string())]),
        },
        Term::App { symbol, args } => {
            let mut constant = smt_c(symbol.as_str());
            let mut coefficients = BTreeMap::<String, String>::new();
            for (index, arg) in args.iter().enumerate() {
                let arg_form = smt_interpret(arg);
                let coeff = smt_a(symbol.as_str(), index);
                constant = smt_add(&constant, &smt_mul(&coeff, &arg_form.constant));
                for (variable, value) in arg_form.coefficients {
                    let scaled = smt_mul(&coeff, &value);
                    coefficients
                        .entry(variable)
                        .and_modify(|old| *old = smt_add(old, &scaled))
                        .or_insert(scaled);
                }
            }
            SmtForm {
                constant,
                coefficients,
            }
        }
    }
}

pub(crate) fn push_smt_weak(script: &mut String, lhs: &Term, rhs: &Term) {
    let lhs = smt_interpret(lhs);
    let rhs = smt_interpret(rhs);
    script.push_str(&format!(
        "(assert (>= {} {}))\n",
        lhs.constant, rhs.constant
    ));
    for variable in lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .cloned()
        .collect::<BTreeSet<_>>()
    {
        script.push_str(&format!(
            "(assert (>= {} {}))\n",
            lhs.coefficients.get(&variable).map_or("0", String::as_str),
            rhs.coefficients.get(&variable).map_or("0", String::as_str)
        ));
    }
}

pub(crate) fn run_smt_script(
    script: &str,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<String> {
    check_smt_script_size(script)?;
    let solver = options
        .smt_solver
        .as_deref()
        .or_else(|| command_exists("z3").then_some("z3"))
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    run_smt_script_with_solver(script, solver, deadline)
}

pub(crate) fn run_path_order_smt_script(
    script: &str,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<String> {
    check_smt_script_size(script)?;
    if script.contains("(maximize ") {
        // Only the Z3 script builder emits optimization commands. Racing an
        // unoptimized feasibility result would discard deletion priorities.
        return run_smt_script_with_solver(script, options.smt_solver.as_deref().unwrap_or("z3"), deadline);
    }
    if let Some(solver) = options.smt_solver.as_deref() {
        return run_smt_script_with_solver(script, solver, deadline);
    }
    let solvers = ["z3", "cvc5"]
        .into_iter()
        .filter(|solver| command_exists(solver))
        .collect::<Vec<_>>();
    match solvers.as_slice() {
        [] => None,
        [solver] => run_smt_script_with_solver(script, solver, deadline),
        _ => run_smt_script_portfolio(script, &solvers, deadline),
    }
}

pub(crate) fn run_smt_script_portfolio(
    script: &str,
    solvers: &[&str],
    deadline: Option<Instant>,
) -> Option<String> {
    let parent = CancellationScope::current(deadline);
    let (scope, cancellation_trigger) = parent.child_scope(deadline);
    let (sender, receiver) = mpsc::channel();
    let result = thread::scope(|threads| {
        for solver in solvers {
            let sender = sender.clone();
            let solver = *solver;
            let script = script.to_owned();
            let branch = scope.clone();
            threads.spawn(move || {
                let output = with_cancellation_flags(branch.tokens(), || {
                    run_smt_script_with_solver(&script, solver, branch.deadline())
                });
                let _ = sender.send((solver, output));
            });
        }
        drop(sender);

        let mut pending = solvers.len();
        while pending > 0 && !scope.is_cancelled() {
            match receiver.try_recv() {
                Ok((solver, Some(output))) => {
                    cancel(&cancellation_trigger);
                    write_progress_event(
                        "dp-smt",
                        "portfolio-selected",
                        solver,
                        0,
                        "successful solver result cancelled sibling solvers",
                    );
                    return Some(output);
                }
                Ok((_, None)) => pending -= 1,
                Err(TryRecvError::Empty) => {
                    cooperative_parallel_wait_tick(scope.remaining());
                }
                Err(TryRecvError::Disconnected) => break,
            }
        }
        cancel(&cancellation_trigger);
        None
    });
    result
}

pub(crate) fn run_matrix_smt_script(
    script: &str,
    solver: &str,
    deadline: Option<Instant>,
) -> Option<String> {
    check_smt_script_size(script)?;
    let solver_name = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(solver);
    if std::env::var_os("FERRUM_EXPERIMENTAL_PERSISTENT_MATRIX_SMT").is_some()
        && std::env::var_os("FERRUM_DISABLE_PERSISTENT_SMT").is_none()
        && solver_name == "z3"
        && script.starts_with("(set-logic QF_BV)")
    {
        match run_persistent_matrix_smt_script(script, solver, deadline) {
            Ok(Some(stdout)) => return Some(stdout),
            Ok(None) => return None,
            Err(error) => write_progress_event(
                "dp-matrix",
                "persistent-fallback",
                "matrix-interpretation",
                0,
                &format!("solver={solver} error={error}"),
            ),
        }
    }
    let mut command = Command::new(solver);
    command.args(smt_solver_args(solver));
    if solver_name.contains("boolector") {
        let seed = MATRIX_SAT_SEED.fetch_add(1, Ordering::Relaxed);
        command.arg(format!("--seed={seed}"));
        command.args(["--engine=fun", "--sat-engine=cms"]);
    }
    command.stderr(Stdio::piped());
    let output = run_command_with_input_deadline(&mut command, script, deadline)
        .ok()
        .flatten()?;
    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    write_progress_event(
        "dp-matrix",
        "solver-exit",
        "matrix-interpretation",
        0,
        &format!(
            "solver={solver} status={} stdout={} stderr={}",
            output.status,
            stdout
                .chars()
                .take(80)
                .collect::<String>()
                .replace('\n', " "),
            stderr
                .chars()
                .take(240)
                .collect::<String>()
                .replace('\n', " ")
        ),
    );
    output.status.success().then_some(stdout)
}

pub(crate) fn run_persistent_matrix_smt_script(
    script: &str,
    solver: &str,
    deadline: Option<Instant>,
) -> Result<Option<String>, String> {
    let output = run_persistent_smt_script(solver, smt_solver_args(solver), script, deadline)
        .map_err(|error| error.to_string())?;
    let Some(output) = output else {
        return Ok(None);
    };
    write_progress_event(
        "dp-matrix",
        "solver-exit",
        "matrix-interpretation",
        0,
        &format!(
            "solver={solver} persistent=true reused={} stdout={}",
            output.reused_session,
            output
                .stdout
                .chars()
                .take(80)
                .collect::<String>()
                .replace('\n', " ")
        ),
    );
    Ok(Some(output.stdout))
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct MatrixSmtSolver {
    pub(crate) command: String,
    pub(crate) flavor: MatrixSmtFlavor,
}

pub(crate) fn select_matrix_smt_solver(
    configured: Option<&str>,
    available: impl FnMut(&str) -> bool,
) -> Option<MatrixSmtSolver> {
    select_matrix_smt_solver_for_variant(configured, available, 0)
}

pub(crate) fn select_matrix_smt_solver_for_variant(
    configured: Option<&str>,
    mut available: impl FnMut(&str) -> bool,
    variant: u64,
) -> Option<MatrixSmtSolver> {
    if let Some(command) = configured {
        let name = std::path::Path::new(command)
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or(command);
        return Some(MatrixSmtSolver {
            command: command.to_string(),
            flavor: if name.contains("z3") {
                MatrixSmtFlavor::Z3
            } else {
                MatrixSmtFlavor::Portable
            },
        });
    }
    let local_boolector = ".tools/boolector-src/build/bin/boolector";
    let mut solvers = Vec::new();
    if available(local_boolector) {
        solvers.push(MatrixSmtSolver {
            command: local_boolector.to_string(),
            flavor: MatrixSmtFlavor::Portable,
        });
    } else if available("boolector") {
        solvers.push(MatrixSmtSolver {
            command: "boolector".to_string(),
            flavor: MatrixSmtFlavor::Portable,
        });
    }
    if available("z3") {
        solvers.push(MatrixSmtSolver {
            command: "z3".to_string(),
            flavor: MatrixSmtFlavor::Z3,
        });
    }
    if available("cvc5") {
        solvers.push(MatrixSmtSolver {
            command: "cvc5".to_string(),
            flavor: MatrixSmtFlavor::Portable,
        });
    }
    (!solvers.is_empty()).then(|| solvers[(variant as usize) % solvers.len()].clone())
}

pub(crate) fn run_smt_script_with_solver(
    script: &str,
    solver: &str,
    deadline: Option<Instant>,
) -> Option<String> {
    let solver_name = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(solver);
    let persistent_logic = script.starts_with("(set-logic QF_BV)")
        || (std::env::var_os("FERRUM_EXPERIMENTAL_PERSISTENT_LIA_SMT").is_some()
            && script.starts_with("(set-logic QF_LIA)"));
    if solver_name == "z3"
        && persistent_logic
        && std::env::var_os("FERRUM_DISABLE_PERSISTENT_SMT").is_none()
    {
        match run_persistent_smt_script(solver, smt_solver_args(solver), script, deadline) {
            Ok(Some(output)) => {
                write_progress_event(
                    "dp-smt",
                    "solver-exit",
                    "smt",
                    0,
                    &format!(
                        "solver={solver} persistent=true reused={} stdout={}",
                        output.reused_session,
                        output
                            .stdout
                            .chars()
                            .take(160)
                            .collect::<String>()
                            .replace('\n', " ")
                    ),
                );
                return Some(output.stdout);
            }
            Ok(None) => return None,
            Err(error) => {
                write_progress_event(
                    "dp-smt",
                    "persistent-fallback",
                    "smt",
                    0,
                    &format!("solver={solver} error={error}"),
                );
            }
        }
    }
    let mut command = Command::new(solver);
    command.args(smt_solver_args(solver));
    let output = run_command_with_input_deadline(&mut command, script, deadline).ok()??;
    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    write_progress_event(
        "dp-smt",
        "solver-exit",
        "smt",
        0,
        &format!(
            "solver={solver} status={} stdout={} stderr={}",
            output.status,
            stdout
                .chars()
                .take(160)
                .collect::<String>()
                .replace('\n', " "),
            stderr
                .chars()
                .take(240)
                .collect::<String>()
                .replace('\n', " ")
        ),
    );
    output.status.success().then_some(stdout)
}

pub(crate) fn check_smt_build(script: &str, deadline: Option<Instant>) -> Option<()> {
    if smt_build_cancelled(deadline) {
        return None;
    }
    check_smt_script_size(script)
}

pub(crate) fn smt_build_cancelled(deadline: Option<Instant>) -> bool {
    current_thread_cancelled() || strategy_timed_out(deadline)
}

pub(crate) fn check_smt_script_size(script: &str) -> Option<()> {
    let _ = script;
    Some(())
}

pub(crate) fn polynomial_bv_width(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
) -> Option<usize> {
    if options.max_polynomial_constant < 0 || options.max_polynomial_coefficient < 0 {
        return None;
    }
    let constant = u128::try_from(options.max_polynomial_constant).ok()?;
    let coefficient = u128::try_from(options.max_polynomial_coefficient.max(1)).ok()?;
    let mut bound = 1u128;
    for term in pairs
        .iter()
        .flat_map(|pair| [pair.lhs(), pair.rhs()])
        .chain(usable.iter().flat_map(|rule| [rule.lhs(), rule.rhs()]))
    {
        let (constant_bound, coefficient_bound) =
            polynomial_interpretation_bounds(term, constant, coefficient)?;
        bound = bound.max(constant_bound).max(coefficient_bound);
    }
    Some(bit_width_for_bound(bound).max(4))
}

pub(crate) fn matrix_bv_width(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    dimension: usize,
) -> Option<usize> {
    if options.max_polynomial_constant < 0 || options.max_polynomial_coefficient < 0 {
        return None;
    }
    let constant = u128::try_from(options.max_polynomial_constant).ok()?;
    let coefficient = u128::try_from(options.max_polynomial_coefficient.max(1)).ok()?;
    let dimension = u128::try_from(dimension.max(1)).ok()?;
    let mut bound = 1u128;
    for term in pairs
        .iter()
        .flat_map(|pair| [pair.lhs(), pair.rhs()])
        .chain(usable.iter().flat_map(|rule| [rule.lhs(), rule.rhs()]))
    {
        let (constant_bound, coefficient_bound) =
            matrix_interpretation_bounds(term, constant, coefficient, dimension)?;
        bound = bound.max(constant_bound).max(coefficient_bound);
    }
    Some(bit_width_for_bound(bound).max(4))
}

pub(crate) fn signed_matrix_bv_width(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    dimension: usize,
    min_value: i64,
    max_value: i64,
) -> Option<usize> {
    let magnitude = i128::from(min_value)
        .unsigned_abs()
        .max(i128::from(max_value).unsigned_abs())
        .max(1);
    let dimension = u128::try_from(dimension.max(1)).ok()?;
    let mut bound = magnitude;
    for term in pairs
        .iter()
        .flat_map(|pair| [pair.lhs(), pair.rhs()])
        .chain(usable.iter().flat_map(|rule| [rule.lhs(), rule.rhs()]))
    {
        let (constant_bound, coefficient_bound) =
            matrix_interpretation_bounds(term, magnitude, magnitude, dimension)?;
        bound = bound.max(constant_bound).max(coefficient_bound);
    }
    let width = bit_width_for_bound(bound).max(4);
    (width <= 63).then_some(width)
}

pub(crate) fn polynomial_interpretation_bounds(
    term: &Term,
    max_constant: u128,
    max_coefficient: u128,
) -> Option<(u128, u128)> {
    match term {
        Term::Var(_) => Some((0, 1)),
        Term::App { args, .. } => {
            let mut constant = max_constant;
            let mut coefficient = 0u128;
            for arg in args {
                let (arg_constant, arg_coefficient) =
                    polynomial_interpretation_bounds(arg, max_constant, max_coefficient)?;
                constant = constant.saturating_add(max_coefficient.saturating_mul(arg_constant));
                coefficient =
                    coefficient.saturating_add(max_coefficient.saturating_mul(arg_coefficient));
            }
            Some((constant, coefficient))
        }
    }
}

pub(crate) fn matrix_interpretation_bounds(
    term: &Term,
    max_constant: u128,
    max_coefficient: u128,
    dimension: u128,
) -> Option<(u128, u128)> {
    match term {
        Term::Var(_) => Some((0, 1)),
        Term::App { args, .. } => {
            let mut constant = max_constant;
            let mut coefficient = 0u128;
            for arg in args {
                let (arg_constant, arg_coefficient) =
                    matrix_interpretation_bounds(arg, max_constant, max_coefficient, dimension)?;
                let scale = dimension.saturating_mul(max_coefficient);
                constant = constant.saturating_add(scale.saturating_mul(arg_constant));
                coefficient = coefficient.saturating_add(scale.saturating_mul(arg_coefficient));
            }
            Some((constant, coefficient))
        }
    }
}

pub(crate) fn bit_width_for_bound(bound: u128) -> usize {
    let bits = if bound == 0 {
        1
    } else {
        128usize - bound.leading_zeros() as usize
    };
    bits + 1
}

pub(crate) fn unsigned_bit_width(bound: u128) -> usize {
    if bound == 0 {
        1
    } else {
        128usize - bound.leading_zeros() as usize
    }
}

pub(crate) fn bv_literal(value: u128, width: usize) -> String {
    format!("(_ bv{value} {width})")
}

pub(crate) fn bv_add(left: &str, right: &str) -> String {
    format!("(bvadd {left} {right})")
}

pub(crate) fn bv_mul(left: &str, right: &str) -> String {
    format!("(bvmul {left} {right})")
}

pub(crate) fn smt_and(parts: Vec<String>) -> String {
    match parts.as_slice() {
        [] => "true".to_string(),
        [single] => single.clone(),
        _ => format!("(and {})", parts.join(" ")),
    }
}

pub(crate) fn smt_or(parts: Vec<String>) -> String {
    match parts.as_slice() {
        [] => "false".to_string(),
        [single] => single.clone(),
        _ => format!("(or {})", parts.join(" ")),
    }
}

pub(crate) fn smt_at_most_one(parts: &[String]) -> String {
    let mut constraints = Vec::new();
    for (left_index, left) in parts.iter().enumerate() {
        for right in &parts[left_index + 1..] {
            constraints.push(format!("(not (and {left} {right}))"));
        }
    }
    smt_and(constraints)
}

pub(crate) fn smt_exactly_one(parts: &[String]) -> String {
    smt_and(vec![smt_or(parts.to_vec()), smt_at_most_one(parts)])
}

pub(crate) fn smt_sum(parts: Vec<String>) -> String {
    match parts.as_slice() {
        [] => "0".to_string(),
        [single] => single.clone(),
        _ => format!("(+ {})", parts.join(" ")),
    }
}

pub(crate) fn matrix_bv_constant_name(symbol: &str, row: usize) -> String {
    format!("m_c_{}_{}", sanitize_smt_name(symbol), row)
}

pub(crate) fn matrix_bv_coefficient_name(
    symbol: &str,
    argument: usize,
    row: usize,
    column: usize,
) -> String {
    format!(
        "m_a_{}_{}_{}_{}",
        sanitize_smt_name(symbol),
        argument,
        row,
        column
    )
}

pub(crate) fn matrix_bv_parameter_matrix(
    symbol: &str,
    argument: usize,
    dimension: usize,
) -> Vec<Vec<String>> {
    (0..dimension)
        .map(|row| {
            (0..dimension)
                .map(|column| matrix_bv_coefficient_name(symbol, argument, row, column))
                .collect()
        })
        .collect()
}

pub(crate) fn matrix_bv_parameter_value(
    name: &str,
    parameter_width: usize,
    width: usize,
) -> String {
    if parameter_width == width {
        name.to_string()
    } else {
        format!("((_ zero_extend {}) {name})", width - parameter_width)
    }
}

pub(crate) fn matrix_bv_parameter_matrix_at_width(
    symbol: &str,
    argument: usize,
    dimension: usize,
    parameter_width: usize,
    width: usize,
) -> Vec<Vec<String>> {
    (0..dimension)
        .map(|row| {
            (0..dimension)
                .map(|column| {
                    matrix_bv_parameter_value(
                        &matrix_bv_coefficient_name(symbol, argument, row, column),
                        parameter_width,
                        width,
                    )
                })
                .collect()
        })
        .collect()
}

pub(crate) fn bv_zero_matrix(dimension: usize, width: usize) -> Vec<Vec<String>> {
    vec![vec![bv_literal(0, width); dimension]; dimension]
}

pub(crate) fn bv_identity_matrix(dimension: usize, width: usize) -> Vec<Vec<String>> {
    (0..dimension)
        .map(|row| {
            (0..dimension)
                .map(|column| bv_literal(u128::from(row == column), width))
                .collect()
        })
        .collect()
}

pub(crate) fn bv_add_matrix_in_place(left: &mut [Vec<String>], right: &[Vec<String>]) {
    for (left_row, right_row) in left.iter_mut().zip(right) {
        for (left_value, right_value) in left_row.iter_mut().zip(right_row) {
            *left_value = bv_add(left_value, right_value);
        }
    }
}

pub(crate) fn bv_matrix_vector_product(
    matrix: &[Vec<String>],
    vector: &[String],
    width: usize,
) -> Vec<String> {
    matrix
        .iter()
        .map(|row| {
            row.iter()
                .zip(vector)
                .fold(bv_literal(0, width), |sum, (left, right)| {
                    bv_add(&sum, &bv_mul(left, right))
                })
        })
        .collect()
}

pub(crate) fn bv_matrix_product(
    left: &[Vec<String>],
    right: &[Vec<String>],
    width: usize,
) -> Vec<Vec<String>> {
    let columns = right.first().map_or(0, Vec::len);
    left.iter()
        .map(|left_row| {
            (0..columns)
                .map(|column| {
                    left_row
                        .iter()
                        .enumerate()
                        .fold(bv_literal(0, width), |sum, (index, value)| {
                            bv_add(&sum, &bv_mul(value, &right[index][column]))
                        })
                })
                .collect()
        })
        .collect()
}

pub(crate) fn smt_strict(lhs: &Term, rhs: &Term) -> String {
    let lhs = smt_interpret(lhs);
    let rhs = smt_interpret(rhs);
    format!("(> {} {})", lhs.constant, rhs.constant)
}

pub(crate) fn parse_smt_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
) -> Option<LinearPolynomialInterpretations> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_smt_values(output)?;
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let constant = values.get(&smt_c(symbol)).copied().unwrap_or(0);
        let coefficients = (0..*arity)
            .map(|index| values.get(&smt_a(symbol, index)).copied().unwrap_or(0))
            .collect();
        interpretations.insert(
            symbol.clone(),
            LinearPolynomial {
                constant,
                coefficients,
            },
        );
    }
    Some(interpretations)
}

pub(crate) fn parse_bv_polynomial_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
) -> Option<LinearPolynomialInterpretations> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_bv_values(output)?;
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let constant = values.get(&smt_c(symbol)).copied().unwrap_or(0);
        let coefficients = (0..*arity)
            .map(|index| values.get(&smt_a(symbol, index)).copied().unwrap_or(0))
            .collect();
        interpretations.insert(
            symbol.clone(),
            LinearPolynomial {
                constant,
                coefficients,
            },
        );
    }
    Some(interpretations)
}

pub(crate) fn parse_max_polynomial_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
    alternatives: usize,
) -> Option<MaxPolynomialInterpretations> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_smt_values(output)?;
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let symbol_alternatives = (0..alternatives)
            .map(|alternative| {
                let constant = values
                    .get(&max_smt_c(symbol, alternative))
                    .copied()
                    .unwrap_or(0);
                let coefficients = (0..*arity)
                    .map(|index| {
                        values
                            .get(&max_smt_a(symbol, alternative, index))
                            .copied()
                            .unwrap_or(0)
                    })
                    .collect();
                LinearPolynomial {
                    constant,
                    coefficients,
                }
            })
            .collect();
        interpretations.insert(symbol.clone(), symbol_alternatives);
    }
    Some(interpretations)
}

pub(crate) fn parse_bv_matrix_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
    dimension: usize,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_bv_values(output)?;
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let constant = (0..dimension)
            .map(|row| {
                values
                    .get(&matrix_bv_constant_name(symbol, row))
                    .copied()
                    .unwrap_or(0)
            })
            .collect::<Vec<_>>();
        let coefficients = (0..*arity)
            .map(|argument| {
                (0..dimension)
                    .map(|row| {
                        (0..dimension)
                            .map(|column| {
                                values
                                    .get(&matrix_bv_coefficient_name(symbol, argument, row, column))
                                    .copied()
                                    .unwrap_or(0)
                            })
                            .collect::<Vec<_>>()
                    })
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        interpretations.insert(
            symbol.clone(),
            MatrixInterpretation {
                constant,
                coefficients,
            },
        );
    }
    Some(interpretations)
}

pub(crate) fn parse_signed_bv_matrix_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
    dimension: usize,
    width: usize,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_bv_values(output)?;
    let decode = |name: String| {
        values
            .get(&name)
            .copied()
            .map(|value| decode_signed_bv(value, width))
            .unwrap_or(0)
    };
    arities
        .iter()
        .map(|(symbol, arity)| {
            let constant = (0..dimension)
                .map(|row| decode(matrix_bv_constant_name(symbol, row)))
                .collect::<Vec<_>>();
            let coefficients = (0..*arity)
                .map(|argument| {
                    (0..dimension)
                        .map(|row| {
                            (0..dimension)
                                .map(|column| {
                                    decode(matrix_bv_coefficient_name(
                                        symbol, argument, row, column,
                                    ))
                                })
                                .collect::<Vec<_>>()
                        })
                        .collect::<Vec<_>>()
                })
                .collect::<Vec<_>>();
            Some((
                symbol.clone(),
                MatrixInterpretation {
                    constant,
                    coefficients,
                },
            ))
        })
        .collect()
}

pub(crate) fn decode_signed_bv(value: i64, width: usize) -> i64 {
    let sign_bit = 1i64 << (width - 1);
    if value & sign_bit == 0 {
        value
    } else {
        value - (1i64 << width)
    }
}

pub(crate) fn parse_bv_values(output: &str) -> Option<BTreeMap<String, i64>> {
    let normalized = output.replace(['(', ')'], " ");
    let tokens = normalized.split_whitespace().collect::<Vec<_>>();
    let mut values = BTreeMap::new();
    let mut index = 0;
    while index + 2 < tokens.len() {
        if tokens[index] == "define-fun" {
            let name = tokens[index + 1].to_string();
            if let Some((offset, value)) = parse_bv_value_after_define_fun(&tokens[index + 2..]) {
                values.insert(name, value);
                index += 2 + offset;
            } else {
                index += 1;
            }
        } else {
            index += 1;
        }
    }
    Some(values)
}

pub(crate) fn parse_bv_value_after_define_fun(tokens: &[&str]) -> Option<(usize, i64)> {
    for (index, token) in tokens.iter().enumerate() {
        if *token == "define-fun" {
            return None;
        }
        if let Some(value) = parse_bv_token(token) {
            return Some((index + 1, value));
        }
        if let Some(rest) = token.strip_prefix("bv")
            && let Ok(value) = rest.parse::<i64>()
        {
            return Some((index + 1, value));
        }
    }
    None
}

pub(crate) fn parse_bv_token(token: &str) -> Option<i64> {
    if let Some(bits) = token.strip_prefix("#b") {
        parse_bounded_radix_value(bits, 2)
    } else if let Some(hex) = token.strip_prefix("#x") {
        parse_bounded_radix_value(hex, 16)
    } else {
        None
    }
}

pub(crate) fn parse_bounded_radix_value(digits: &str, radix: u32) -> Option<i64> {
    let mut value = 0i64;
    for digit in digits.chars() {
        let digit = i64::from(digit.to_digit(radix)?);
        value = value.checked_mul(i64::from(radix))?.checked_add(digit)?;
    }
    Some(value)
}

pub(crate) fn parse_smt_values(output: &str) -> Option<BTreeMap<String, i64>> {
    let normalized = output.replace(['(', ')'], " ");
    let tokens = normalized.split_whitespace().collect::<Vec<_>>();
    let mut values = BTreeMap::new();
    let mut index = 0;
    while index + 3 < tokens.len() {
        if tokens[index] == "define-fun" {
            let name = tokens[index + 1].to_string();
            let Some(int_offset) =
                (2..=4).find(|offset| tokens.get(index + *offset).copied() == Some("Int"))
            else {
                index += 1;
                continue;
            };
            let value_offset = index + int_offset + 1;
            if let Some((value, consumed)) = parse_smt_integer(&tokens[value_offset..]) {
                values.insert(name, value);
                index = value_offset + consumed;
            } else {
                // Solver-introduced auxiliaries may be defined by arithmetic
                // expressions.  They are irrelevant to model reconstruction;
                // keep scanning for the literal decision variables.
                index += 1;
            }
        } else {
            index += 1;
        }
    }
    Some(values)
}

pub(crate) fn parse_smt_integer(tokens: &[&str]) -> Option<(i64, usize)> {
    match tokens.first().copied()? {
        "-" => tokens.get(1)?.parse::<i64>().ok().map(|value| (-value, 2)),
        value => value.parse::<i64>().ok().map(|value| (value, 1)),
    }
}

pub(crate) fn command_exists(command: &str) -> bool {
    Command::new("sh")
        .arg("-c")
        .arg(format!("command -v {command} >/dev/null 2>&1"))
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

pub(crate) fn polynomial_coefficients_are_strictly_monotone(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    arities_for_constraints(pairs, usable)
        .into_iter()
        .all(|(symbol, arity)| {
            let Some(interpretation) = interpretations.get(symbol.as_str()) else {
                return true;
            };
            (0..arity)
                .all(|index| interpretation.coefficients.get(index).copied().unwrap_or(1) >= 1)
        })
}

pub(crate) fn polynomial_coefficients_are_weakly_monotone(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    arities_for_constraints(pairs, usable)
        .into_iter()
        .all(|(symbol, arity)| {
            let Some(interpretation) = interpretations.get(symbol.as_str()) else {
                return true;
            };
            (0..arity)
                .all(|index| interpretation.coefficients.get(index).copied().unwrap_or(1) >= 0)
        })
}

pub(crate) fn max_polynomial_coefficients_are_weakly_monotone(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &MaxPolynomialInterpretations,
) -> bool {
    arities_for_constraints(pairs, usable)
        .into_iter()
        .all(|(symbol, arity)| {
            let Some(alternatives) = interpretations.get(symbol.as_str()) else {
                return true;
            };
            !alternatives.is_empty()
                && alternatives.iter().all(|interpretation| {
                    interpretation.constant >= 0
                        && (0..arity).all(|index| {
                            interpretation.coefficients.get(index).copied().unwrap_or(1) >= 0
                        })
                })
        })
}

pub(crate) fn rational_polynomial_coefficients_are_weakly_monotone(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    arities_for_constraints(pairs, usable)
        .into_iter()
        .all(|(symbol, arity)| {
            let Some(interpretation) = interpretations.get(symbol.as_str()) else {
                return true;
            };
            interpretation.constant >= 0
                && (0..arity)
                    .all(|index| interpretation.coefficients.get(index).copied().unwrap_or(1) >= 0)
        })
}

pub(crate) fn weakly_decreases_by_rational_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &LinearPolynomialInterpretations,
    denominator: i64,
) -> bool {
    interpret_rational_polynomial(lhs, interpretations, denominator).weakly_ge(
        &interpret_rational_polynomial(rhs, interpretations, denominator),
    )
}

pub(crate) fn strictly_decreases_by_rational_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &LinearPolynomialInterpretations,
    denominator: i64,
) -> bool {
    interpret_rational_polynomial(lhs, interpretations, denominator).strictly_gt_delta_one(
        &interpret_rational_polynomial(rhs, interpretations, denominator),
    )
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ConcreteForm {
    constant: i64,
    coefficients: BTreeMap<Variable, i64>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct Rational {
    numerator: i128,
    denominator: i128,
}

impl Rational {
    pub(crate) fn new(numerator: i64, denominator: i64) -> Self {
        debug_assert!(denominator > 0);
        Self::from_i128(i128::from(numerator), i128::from(denominator))
    }

    fn from_i128(numerator: i128, denominator: i128) -> Self {
        debug_assert!(denominator > 0);
        let divisor = gcd_i128(numerator, denominator);
        Self {
            numerator: numerator / divisor,
            denominator: denominator / divisor,
        }
    }

    pub(crate) fn zero() -> Self {
        Self {
            numerator: 0,
            denominator: 1,
        }
    }

    pub(crate) fn one() -> Self {
        Self {
            numerator: 1,
            denominator: 1,
        }
    }

    pub(crate) fn add(self, other: Self) -> Self {
        // Divide out the common denominator before multiplying.  Apart from
        // keeping exact values small, this prevents deeply nested rational
        // interpretations from overflowing merely because both fractions
        // carry the same denominator power.
        let divisor = gcd_i128(self.denominator, other.denominator);
        let left_scale = other.denominator / divisor;
        let right_scale = self.denominator / divisor;
        Self::from_i128(
            self.numerator * left_scale + other.numerator * right_scale,
            self.denominator * left_scale,
        )
    }

    pub(crate) fn mul(self, other: Self) -> Self {
        // Cross-cancel before multiplication.  The previous direct i64
        // products panicked while validating otherwise ordinary exact oracle
        // witnesses on large residual terms.
        let left_divisor = gcd_i128(self.numerator, other.denominator);
        let right_divisor = gcd_i128(other.numerator, self.denominator);
        Self::from_i128(
            (self.numerator / left_divisor) * (other.numerator / right_divisor),
            (self.denominator / right_divisor) * (other.denominator / left_divisor),
        )
    }

    pub(crate) fn ge(self, other: Self) -> bool {
        self.numerator * other.denominator >= other.numerator * self.denominator
    }
}

fn gcd_i128(left: i128, right: i128) -> i128 {
    let mut left = left.abs();
    let mut right = right.abs();
    while right != 0 {
        let next = left % right;
        left = right;
        right = next;
    }
    left.max(1)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ConcreteRationalPolynomial {
    terms: BTreeMap<PolynomialMonomial, Rational>,
}

impl ConcreteRationalPolynomial {
    pub(crate) fn constant(value: Rational) -> Self {
        Self {
            terms: BTreeMap::from([(PolynomialMonomial::one(), value)]),
        }
    }

    pub(crate) fn variable(variable: Variable) -> Self {
        Self {
            terms: BTreeMap::from([(PolynomialMonomial::variable(variable), Rational::one())]),
        }
    }

    pub(crate) fn add_scaled(&mut self, other: &Self, scale: Rational) {
        for (monomial, coefficient) in &other.terms {
            let value = coefficient.mul(scale);
            self.terms
                .entry(monomial.clone())
                .and_modify(|old| *old = old.add(value))
                .or_insert(value);
        }
    }

    pub(crate) fn multiply(&self, other: &Self) -> Option<Self> {
        let mut result = Self {
            terms: BTreeMap::new(),
        };
        for (left_monomial, left_coefficient) in &self.terms {
            for (right_monomial, right_coefficient) in &other.terms {
                let monomial = left_monomial.multiply(right_monomial)?;
                let value = left_coefficient.mul(*right_coefficient);
                result
                    .terms
                    .entry(monomial)
                    .and_modify(|old| *old = old.add(value))
                    .or_insert(value);
            }
        }
        Some(result)
    }

    pub(crate) fn coefficient(&self, monomial: &PolynomialMonomial) -> Rational {
        self.terms
            .get(monomial)
            .copied()
            .unwrap_or_else(Rational::zero)
    }

    pub(crate) fn weakly_ge(&self, other: &Self) -> bool {
        self.terms
            .keys()
            .chain(other.terms.keys())
            .all(|monomial| self.coefficient(monomial).ge(other.coefficient(monomial)))
    }

    pub(crate) fn strictly_ge_delta(&self, other: &Self, delta: Rational) -> bool {
        self.weakly_ge(other)
            && self
                .coefficient(&PolynomialMonomial::one())
                .ge(other.coefficient(&PolynomialMonomial::one()).add(delta))
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct RationalForm {
    constant: Rational,
    coefficients: BTreeMap<Variable, Rational>,
}

impl RationalForm {
    pub(crate) fn variable(variable: Variable) -> Self {
        Self {
            constant: Rational::zero(),
            coefficients: BTreeMap::from([(variable, Rational::one())]),
        }
    }

    pub(crate) fn constant(value: Rational) -> Self {
        Self {
            constant: value,
            coefficients: BTreeMap::new(),
        }
    }

    pub(crate) fn add(&mut self, other: Self) {
        self.constant = self.constant.add(other.constant);
        for (variable, coefficient) in other.coefficients {
            self.coefficients
                .entry(variable)
                .and_modify(|value| *value = value.add(coefficient))
                .or_insert(coefficient);
        }
    }

    pub(crate) fn scale(&mut self, coefficient: Rational) {
        self.constant = self.constant.mul(coefficient);
        for value in self.coefficients.values_mut() {
            *value = value.mul(coefficient);
        }
    }

    pub(crate) fn coefficient(&self, variable: &Variable) -> Rational {
        self.coefficients
            .get(variable)
            .copied()
            .unwrap_or_else(Rational::zero)
    }

    pub(crate) fn weakly_ge(&self, other: &Self) -> bool {
        self.constant.ge(other.constant)
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| self.coefficient(variable).ge(other.coefficient(variable)))
    }

    pub(crate) fn strictly_gt_delta_one(&self, other: &Self) -> bool {
        self.constant.ge(other.constant.add(Rational::one()))
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| self.coefficient(variable).ge(other.coefficient(variable)))
    }
}

impl ConcreteForm {
    pub(crate) fn variable(variable: Variable) -> Self {
        Self {
            constant: 0,
            coefficients: BTreeMap::from([(variable, 1)]),
        }
    }

    pub(crate) fn constant(value: i64) -> Self {
        Self {
            constant: value,
            coefficients: BTreeMap::new(),
        }
    }

    pub(crate) fn add(&mut self, other: Self) {
        self.constant += other.constant;
        for (variable, coefficient) in other.coefficients {
            *self.coefficients.entry(variable).or_default() += coefficient;
        }
    }

    pub(crate) fn scale(&mut self, coefficient: i64) {
        self.constant *= coefficient;
        for value in self.coefficients.values_mut() {
            *value *= coefficient;
        }
    }

    pub(crate) fn coefficient(&self, variable: &Variable) -> i64 {
        self.coefficients.get(variable).copied().unwrap_or(0)
    }

    pub(crate) fn weakly_ge(&self, other: &Self) -> bool {
        self.constant >= other.constant
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| self.coefficient(variable) >= other.coefficient(variable))
    }

    pub(crate) fn strictly_gt(&self, other: &Self) -> bool {
        self.constant > other.constant
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| self.coefficient(variable) >= other.coefficient(variable))
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(crate) struct PolynomialMonomial(Vec<(Variable, u16)>);

impl PolynomialMonomial {
    pub(crate) fn one() -> Self {
        Self(Vec::new())
    }

    pub(crate) fn variable(variable: Variable) -> Self {
        Self(vec![(variable, 1)])
    }

    pub(crate) fn multiply(&self, other: &Self) -> Option<Self> {
        let mut exponents = BTreeMap::<Variable, u16>::new();
        for (variable, exponent) in self.0.iter().chain(&other.0) {
            let entry = exponents.entry(variable.clone()).or_default();
            *entry = entry.checked_add(*exponent)?;
        }
        Some(Self(exponents.into_iter().collect()))
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ConcreteNaturalPolynomial {
    terms: BTreeMap<PolynomialMonomial, i128>,
}

impl ConcreteNaturalPolynomial {
    pub(crate) fn zero() -> Self {
        Self {
            terms: BTreeMap::new(),
        }
    }

    pub(crate) fn constant(value: i64) -> Self {
        let mut result = Self::zero();
        result.add_term(PolynomialMonomial::one(), i128::from(value));
        result
    }

    pub(crate) fn variable(variable: Variable) -> Self {
        let mut result = Self::zero();
        result.add_term(PolynomialMonomial::variable(variable), 1);
        result
    }

    pub(crate) fn add_term(&mut self, monomial: PolynomialMonomial, coefficient: i128) {
        if coefficient == 0 {
            return;
        }
        let entry = self.terms.entry(monomial).or_default();
        *entry += coefficient;
        if *entry == 0 {
            self.terms.retain(|_, value| *value != 0);
        }
    }

    pub(crate) fn checked_add(&self, other: &Self) -> Option<Self> {
        let mut result = self.clone();
        for (monomial, coefficient) in &other.terms {
            let old = result.terms.get(monomial).copied().unwrap_or(0);
            let value = old.checked_add(*coefficient)?;
            if value == 0 {
                result.terms.remove(monomial);
            } else {
                result.terms.insert(monomial.clone(), value);
            }
        }
        Some(result)
    }

    pub(crate) fn checked_scale(&self, coefficient: i64) -> Option<Self> {
        let coefficient = i128::from(coefficient);
        let terms = self
            .terms
            .iter()
            .map(|(monomial, value)| Some((monomial.clone(), value.checked_mul(coefficient)?)))
            .collect::<Option<BTreeMap<_, _>>>()?;
        Some(Self { terms })
    }

    pub(crate) fn checked_multiply(&self, other: &Self) -> Option<Self> {
        let mut result = Self::zero();
        for (left_monomial, left_coefficient) in &self.terms {
            for (right_monomial, right_coefficient) in &other.terms {
                let monomial = left_monomial.multiply(right_monomial)?;
                let product = left_coefficient.checked_mul(*right_coefficient)?;
                let old = result.terms.get(&monomial).copied().unwrap_or(0);
                result.terms.insert(monomial, old.checked_add(product)?);
            }
        }
        result.terms.retain(|_, value| *value != 0);
        Some(result)
    }

    pub(crate) fn coefficient(&self, monomial: &PolynomialMonomial) -> i128 {
        self.terms.get(monomial).copied().unwrap_or(0)
    }

    pub(crate) fn weakly_ge(&self, other: &Self) -> bool {
        self.terms
            .keys()
            .chain(other.terms.keys())
            .all(|monomial| self.coefficient(monomial) >= other.coefficient(monomial))
    }

    pub(crate) fn strictly_gt(&self, other: &Self) -> bool {
        self.weakly_ge(other)
            && self.coefficient(&PolynomialMonomial::one())
                > other.coefficient(&PolynomialMonomial::one())
    }
}

pub(crate) fn interpret_natural_polynomial(
    term: &Term,
    interpretations: &BTreeMap<String, NaturalPolynomial>,
) -> Option<ConcreteNaturalPolynomial> {
    match term {
        Term::Var(variable) => Some(ConcreteNaturalPolynomial::variable(variable.clone())),
        Term::App { symbol, args } => {
            let interpretation = interpretations.get(symbol.as_str())?;
            if interpretation.linear.len() != args.len()
                || interpretation.quadratic.len() != args.len()
                || interpretation
                    .quadratic
                    .iter()
                    .any(|row| row.len() != args.len())
            {
                return None;
            }
            let arguments = args
                .iter()
                .map(|arg| interpret_natural_polynomial(arg, interpretations))
                .collect::<Option<Vec<_>>>()?;
            let mut result = ConcreteNaturalPolynomial::constant(interpretation.constant);
            for (argument, coefficient) in arguments.iter().zip(&interpretation.linear) {
                result = result.checked_add(&argument.checked_scale(*coefficient)?)?;
            }
            for left in 0..arguments.len() {
                for right in left..arguments.len() {
                    let coefficient = interpretation.quadratic[left][right];
                    if coefficient == 0 {
                        continue;
                    }
                    let product = arguments[left].checked_multiply(&arguments[right])?;
                    result = result.checked_add(&product.checked_scale(coefficient)?)?;
                }
            }
            Some(result)
        }
    }
}

pub(crate) fn interpret_rational_natural_polynomial(
    term: &Term,
    interpretations: &BTreeMap<String, NaturalPolynomial>,
    denominator: i64,
) -> Option<ConcreteRationalPolynomial> {
    match term {
        Term::Var(variable) => Some(ConcreteRationalPolynomial::variable(variable.clone())),
        Term::App { symbol, args } => {
            let interpretation = interpretations.get(symbol.as_str())?;
            let arguments = args
                .iter()
                .map(|arg| interpret_rational_natural_polynomial(arg, interpretations, denominator))
                .collect::<Option<Vec<_>>>()?;
            let mut result = ConcreteRationalPolynomial::constant(Rational::new(
                interpretation.constant,
                denominator,
            ));
            for (argument, coefficient) in arguments.iter().zip(&interpretation.linear) {
                result.add_scaled(argument, Rational::new(*coefficient, denominator));
            }
            for left in 0..arguments.len() {
                for right in left..arguments.len() {
                    let coefficient = interpretation.quadratic[left][right];
                    if coefficient != 0 {
                        result.add_scaled(
                            &arguments[left].multiply(&arguments[right])?,
                            Rational::new(coefficient, denominator),
                        );
                    }
                }
            }
            Some(result)
        }
    }
}

pub(crate) fn rational_natural_polynomial_relation(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, NaturalPolynomial>,
    denominator: i64,
    delta: i64,
    strict: bool,
) -> bool {
    let delta = Rational::new(delta, denominator);
    interpret_rational_natural_polynomial(lhs, interpretations, denominator)
        .zip(interpret_rational_natural_polynomial(
            rhs,
            interpretations,
            denominator,
        ))
        .is_some_and(|(lhs, rhs)| {
            lhs.weakly_ge(&rhs) && (!strict || lhs.strictly_ge_delta(&rhs, delta))
        })
}

pub(crate) fn weakly_decreases_by_natural_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, NaturalPolynomial>,
) -> bool {
    interpret_natural_polynomial(lhs, interpretations)
        .zip(interpret_natural_polynomial(rhs, interpretations))
        .is_some_and(|(lhs, rhs)| lhs.weakly_ge(&rhs))
}

pub(crate) fn strictly_decreases_by_natural_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, NaturalPolynomial>,
) -> bool {
    interpret_natural_polynomial(lhs, interpretations)
        .zip(interpret_natural_polynomial(rhs, interpretations))
        .is_some_and(|(lhs, rhs)| lhs.strictly_gt(&rhs))
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct MatrixForm {
    constant: Vec<i64>,
    coefficients: BTreeMap<Variable, Vec<Vec<i64>>>,
}

impl MatrixForm {
    pub(crate) fn variable(variable: Variable, dimension: usize) -> Self {
        Self {
            constant: vec![0; dimension],
            coefficients: BTreeMap::from([(variable, identity_matrix(dimension))]),
        }
    }

    pub(crate) fn constant(value: &[i64]) -> Self {
        Self {
            constant: value.to_vec(),
            coefficients: BTreeMap::new(),
        }
    }

    pub(crate) fn add(&mut self, other: Self) {
        for (left, right) in self.constant.iter_mut().zip(other.constant) {
            *left += right;
        }
        for (variable, coefficient) in other.coefficients {
            self.coefficients
                .entry(variable)
                .and_modify(|existing| add_matrix_in_place(existing, &coefficient))
                .or_insert(coefficient);
        }
    }

    pub(crate) fn left_multiply(&mut self, matrix: &[Vec<i64>]) {
        self.constant = matrix_vector_product(matrix, &self.constant);
        for coefficient in self.coefficients.values_mut() {
            *coefficient = matrix_product(matrix, coefficient);
        }
    }

    pub(crate) fn coefficient(&self, variable: &Variable, dimension: usize) -> Vec<Vec<i64>> {
        self.coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| zero_matrix(dimension))
    }

    pub(crate) fn weakly_ge(&self, other: &Self, dimension: usize) -> bool {
        self.constant
            .iter()
            .zip(&other.constant)
            .all(|(left, right)| left >= right)
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| {
                    matrix_ge(
                        &self.coefficient(variable, dimension),
                        &other.coefficient(variable, dimension),
                    )
                })
    }

    pub(crate) fn strictly_gt(
        &self,
        other: &Self,
        dimension: usize,
        strict_dimension: usize,
    ) -> bool {
        self.weakly_ge(other, dimension)
            && (0..strict_dimension).any(|index| self.constant[index] > other.constant[index])
    }
}

pub(crate) fn add_matrix_in_place(left: &mut [Vec<i64>], right: &[Vec<i64>]) {
    for (left_row, right_row) in left.iter_mut().zip(right) {
        for (left_value, right_value) in left_row.iter_mut().zip(right_row) {
            *left_value += right_value;
        }
    }
}

pub(crate) fn matrix_vector_product(matrix: &[Vec<i64>], vector: &[i64]) -> Vec<i64> {
    matrix
        .iter()
        .map(|row| {
            row.iter()
                .zip(vector)
                .map(|(left, right)| left * right)
                .sum()
        })
        .collect()
}

pub(crate) fn matrix_product(left: &[Vec<i64>], right: &[Vec<i64>]) -> Vec<Vec<i64>> {
    let columns = right.first().map_or(0, Vec::len);
    left.iter()
        .map(|left_row| {
            (0..columns)
                .map(|column| {
                    left_row
                        .iter()
                        .enumerate()
                        .map(|(index, value)| value * right[index][column])
                        .sum()
                })
                .collect()
        })
        .collect()
}

pub(crate) fn matrix_ge(left: &[Vec<i64>], right: &[Vec<i64>]) -> bool {
    left.iter().zip(right).all(|(left_row, right_row)| {
        left_row
            .iter()
            .zip(right_row)
            .all(|(left_value, right_value)| left_value >= right_value)
    })
}

pub(crate) fn weakly_decreases_by_weights(lhs: &Term, rhs: &Term, weights: &SymbolWeights) -> bool {
    interpret_weights(lhs, weights).weakly_ge(&interpret_weights(rhs, weights))
}

pub(crate) fn strictly_decreases_by_weights(
    lhs: &Term,
    rhs: &Term,
    weights: &SymbolWeights,
) -> bool {
    interpret_weights(lhs, weights).strictly_gt(&interpret_weights(rhs, weights))
}

pub(crate) fn weakly_decreases_by_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    interpret_polynomial(lhs, interpretations)
        .weakly_ge(&interpret_polynomial(rhs, interpretations))
}

pub(crate) fn strictly_decreases_by_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    interpret_polynomial(lhs, interpretations)
        .strictly_gt(&interpret_polynomial(rhs, interpretations))
}

// CeTA's executable checker uses the Pleft/Pright approximation from
// Linear_Poly_Order: constants on the right are clamped to zero at every
// function application, while constants on the left are clamped only for
// ground subterms.  This is a sound, deliberately incomplete comparison for
// max-polynomial semantics and is the acceptance boundary that CPF replay
// must reproduce.
pub(crate) fn weakly_decreases_by_ceta_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    interpret_ceta_polynomial_bound(lhs, interpretations, false)
        .weakly_ge(&interpret_ceta_polynomial_bound(rhs, interpretations, true))
}

pub(crate) fn strictly_decreases_by_ceta_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    interpret_ceta_polynomial_bound(lhs, interpretations, false)
        .strictly_gt(&interpret_ceta_polynomial_bound(rhs, interpretations, true))
}

pub(crate) fn interpret_ceta_polynomial_bound(
    term: &Term,
    interpretations: &LinearPolynomialInterpretations,
    right: bool,
) -> ConcreteForm {
    match term {
        Term::Var(variable) => ConcreteForm::variable(variable.clone()),
        Term::App { symbol, args } => {
            let interpretation = interpretations
                .get(symbol.as_str())
                .cloned()
                .unwrap_or_else(|| LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1; args.len()],
                });
            let mut form = ConcreteForm::constant(interpretation.constant);
            for (index, arg) in args.iter().enumerate() {
                let mut arg_form = interpret_ceta_polynomial_bound(arg, interpretations, right);
                arg_form.scale(interpretation.coefficients.get(index).copied().unwrap_or(1));
                form.add(arg_form);
            }
            // Match CeTA Linear_Polynomial.mul_pvars/sum_pvars before
            // Linear_Poly_Order.PleftI tests whether the nonconstant part
            // is empty. Keep this normalization local to the CPF bound.
            form.coefficients.retain(|_, coefficient| *coefficient != 0);
            if right || form.coefficients.is_empty() {
                form.constant = form.constant.max(0);
            }
            form
        }
    }
}

pub(crate) fn weakly_decreases_by_max_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &MaxPolynomialInterpretations,
) -> bool {
    let lhs = interpret_max_polynomial(lhs, interpretations);
    let rhs = interpret_max_polynomial(rhs, interpretations);
    max_polynomial_weakly_ge(&lhs, &rhs)
}

pub(crate) fn strictly_decreases_by_max_polynomial(
    lhs: &Term,
    rhs: &Term,
    interpretations: &MaxPolynomialInterpretations,
) -> bool {
    let lhs = interpret_max_polynomial(lhs, interpretations);
    let rhs = interpret_max_polynomial(rhs, interpretations);
    max_polynomial_strictly_gt(&lhs, &rhs)
}

pub(crate) fn weakly_decreases_by_matrix(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> bool {
    interpret_matrix(lhs, interpretations, dimension).weakly_ge(
        &interpret_matrix(rhs, interpretations, dimension),
        dimension,
    )
}

pub(crate) fn strictly_decreases_by_matrix(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
    strict_dimension: usize,
) -> bool {
    interpret_matrix(lhs, interpretations, dimension).strictly_gt(
        &interpret_matrix(rhs, interpretations, dimension),
        dimension,
        strict_dimension,
    )
}

pub(crate) fn weakly_decreases_by_integer_matrix(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> bool {
    interpret_ceta_integer_matrix_bound(lhs, interpretations, dimension, false).weakly_ge(
        &interpret_ceta_integer_matrix_bound(rhs, interpretations, dimension, true),
        dimension,
    )
}

pub(crate) fn strictly_decreases_by_integer_matrix(
    lhs: &Term,
    rhs: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
    strict_dimension: usize,
) -> bool {
    interpret_ceta_integer_matrix_bound(lhs, interpretations, dimension, false).strictly_gt(
        &interpret_ceta_integer_matrix_bound(rhs, interpretations, dimension, true),
        dimension,
        strict_dimension,
    )
}

pub(crate) fn interpret_ceta_integer_matrix_bound(
    term: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
    right: bool,
) -> MatrixForm {
    match term {
        Term::Var(variable) => MatrixForm::variable(variable.clone(), dimension),
        Term::App { symbol, args } => {
            let fallback = MatrixInterpretation {
                constant: vec![0; dimension],
                coefficients: vec![identity_matrix(dimension); args.len()],
            };
            let interpretation = interpretations
                .get(symbol.as_str())
                .cloned()
                .unwrap_or(fallback);
            let mut form = MatrixForm::constant(&interpretation.constant);
            for (index, arg) in args.iter().enumerate() {
                let coefficient = interpretation
                    .coefficients
                    .get(index)
                    .cloned()
                    .unwrap_or_else(|| identity_matrix(dimension));
                let mut arg_form =
                    interpret_ceta_integer_matrix_bound(arg, interpretations, dimension, right);
                arg_form.left_multiply(&coefficient);
                form.add(arg_form);
            }
            if right || form.coefficients.is_empty() {
                for constant in &mut form.constant {
                    *constant = (*constant).max(0);
                }
            }
            form
        }
    }
}

pub(crate) fn interpret_weights(term: &Term, weights: &SymbolWeights) -> ConcreteForm {
    match term {
        Term::Var(variable) => ConcreteForm::variable(variable.clone()),
        Term::App { symbol, args } => {
            let mut form =
                ConcreteForm::constant(weights.get(symbol.as_str()).copied().unwrap_or(0));
            for arg in args {
                form.add(interpret_weights(arg, weights));
            }
            form
        }
    }
}

pub(crate) fn interpret_matrix(
    term: &Term,
    interpretations: &BTreeMap<String, MatrixInterpretation>,
    dimension: usize,
) -> MatrixForm {
    match term {
        Term::Var(variable) => MatrixForm::variable(variable.clone(), dimension),
        Term::App { symbol, args } => {
            let fallback = MatrixInterpretation {
                constant: vec![0; dimension],
                coefficients: vec![identity_matrix(dimension); args.len()],
            };
            let interpretation = interpretations
                .get(symbol.as_str())
                .cloned()
                .unwrap_or(fallback);
            let mut form = MatrixForm::constant(&interpretation.constant);
            for (index, arg) in args.iter().enumerate() {
                let coefficient = interpretation
                    .coefficients
                    .get(index)
                    .cloned()
                    .unwrap_or_else(|| identity_matrix(dimension));
                let mut arg_form = interpret_matrix(arg, interpretations, dimension);
                arg_form.left_multiply(&coefficient);
                form.add(arg_form);
            }
            form
        }
    }
}

pub(crate) fn interpret_polynomial(
    term: &Term,
    interpretations: &LinearPolynomialInterpretations,
) -> ConcreteForm {
    match term {
        Term::Var(variable) => ConcreteForm::variable(variable.clone()),
        Term::App { symbol, args } => {
            let interpretation = interpretations.get(symbol.as_str());
            let mut form = ConcreteForm::constant(
                interpretation.map_or(0, |interpretation| interpretation.constant),
            );
            for (index, arg) in args.iter().enumerate() {
                let coefficient = interpretation
                    .and_then(|interpretation| interpretation.coefficients.get(index))
                    .copied()
                    .unwrap_or(1);
                // A filtered argument contributes nothing to the concrete
                // polynomial.  Semantic labeling can produce very large
                // expanded terms whose discarded branches dwarf the active
                // term; descending into them made exact witness validation
                // need minutes instead of milliseconds.
                if coefficient == 0 {
                    continue;
                }
                let mut arg_form = interpret_polynomial(arg, interpretations);
                arg_form.scale(coefficient);
                form.add(arg_form);
            }
            form
        }
    }
}

pub(crate) fn interpret_max_polynomial(
    term: &Term,
    interpretations: &MaxPolynomialInterpretations,
) -> Vec<ConcreteForm> {
    match term {
        Term::Var(variable) => vec![ConcreteForm::variable(variable.clone())],
        Term::App { symbol, args } => {
            let fallback = vec![LinearPolynomial {
                constant: 0,
                coefficients: vec![1; args.len()],
            }];
            let alternatives = interpretations
                .get(symbol.as_str())
                .filter(|alternatives| !alternatives.is_empty())
                .unwrap_or(&fallback);
            let arg_forms = args
                .iter()
                .map(|arg| interpret_max_polynomial(arg, interpretations))
                .collect::<Vec<_>>();
            let arg_combinations = concrete_max_arg_combinations(&arg_forms);
            let mut forms = Vec::new();
            for alternative in alternatives {
                for combination in &arg_combinations {
                    let mut form = ConcreteForm::constant(alternative.constant);
                    for (index, arg_form) in combination.iter().enumerate() {
                        let mut scaled = arg_form.clone();
                        scaled.scale(alternative.coefficients.get(index).copied().unwrap_or(1));
                        form.add(scaled);
                    }
                    forms.push(form);
                }
            }
            forms
        }
    }
}

pub(crate) fn concrete_max_arg_combinations(args: &[Vec<ConcreteForm>]) -> Vec<Vec<ConcreteForm>> {
    if args.is_empty() {
        return vec![Vec::new()];
    }
    let mut result = vec![Vec::new()];
    for choices in args {
        let mut next = Vec::new();
        for prefix in &result {
            for choice in choices {
                let mut combined = prefix.clone();
                combined.push(choice.clone());
                next.push(combined);
            }
        }
        result = next;
    }
    result
}

pub(crate) fn max_polynomial_weakly_ge(lhs: &[ConcreteForm], rhs: &[ConcreteForm]) -> bool {
    rhs.iter()
        .all(|right| lhs.iter().any(|left| left.weakly_ge(right)))
}

pub(crate) fn max_polynomial_strictly_gt(lhs: &[ConcreteForm], rhs: &[ConcreteForm]) -> bool {
    rhs.iter()
        .all(|right| lhs.iter().any(|left| left.strictly_gt(right)))
}

pub(crate) fn interpret_rational_polynomial(
    term: &Term,
    interpretations: &LinearPolynomialInterpretations,
    denominator: i64,
) -> RationalForm {
    match term {
        Term::Var(variable) => RationalForm::variable(variable.clone()),
        Term::App { symbol, args } => {
            let interpretation = interpretations
                .get(symbol.as_str())
                .cloned()
                .unwrap_or_else(|| LinearPolynomial {
                    constant: 0,
                    coefficients: vec![denominator; args.len()],
                });
            let mut form =
                RationalForm::constant(Rational::new(interpretation.constant, denominator));
            for (index, arg) in args.iter().enumerate() {
                let mut arg_form = interpret_rational_polynomial(arg, interpretations, denominator);
                let coefficient = interpretation
                    .coefficients
                    .get(index)
                    .copied()
                    .unwrap_or(denominator);
                arg_form.scale(Rational::new(coefficient, denominator));
                form.add(arg_form);
            }
            form
        }
    }
}

pub(crate) fn gcd_i64(left: i64, right: i64) -> i64 {
    let mut left = left.abs();
    let mut right = right.abs();
    while right != 0 {
        let next = left % right;
        left = right;
        right = next;
    }
    left.max(1)
}

pub(crate) fn lcm_positive_i64(left: i64, right: i64) -> Option<i64> {
    (left > 0 && right > 0)
        .then(|| left.checked_div(gcd_i64(left, right))?.checked_mul(right))
        .flatten()
}

pub(crate) fn symbols_for_constraints(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
) -> Vec<String> {
    arities_for_constraints(pairs, usable)
        .into_keys()
        .collect::<Vec<_>>()
}

pub(crate) fn arities_for_constraints(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
) -> BTreeMap<String, usize> {
    let mut arities = BTreeMap::new();
    for pair in pairs {
        collect_term_arities(pair.lhs(), &mut arities);
        collect_term_arities(pair.rhs(), &mut arities);
    }
    for rule in usable {
        collect_term_arities(rule.lhs(), &mut arities);
        collect_term_arities(rule.rhs(), &mut arities);
    }
    arities
}

pub(crate) fn collect_term_arities(term: &Term, arities: &mut BTreeMap<String, usize>) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            arities.insert(symbol.as_str().to_string(), args.len());
            for arg in args {
                collect_term_arities(arg, arities);
            }
        }
    }
}

pub(crate) fn strongly_connected_components(graph: &[Vec<usize>]) -> Vec<Vec<usize>> {
    struct Tarjan<'a> {
        graph: &'a [Vec<usize>],
        index: usize,
        stack: Vec<usize>,
        on_stack: Vec<bool>,
        indices: Vec<Option<usize>>,
        lowlink: Vec<usize>,
        components: Vec<Vec<usize>>,
    }

    impl Tarjan<'_> {
        fn strong_connect(&mut self, vertex: usize) {
            self.indices[vertex] = Some(self.index);
            self.lowlink[vertex] = self.index;
            self.index += 1;
            self.stack.push(vertex);
            self.on_stack[vertex] = true;
            for &successor in &self.graph[vertex] {
                if self.indices[successor].is_none() {
                    self.strong_connect(successor);
                    self.lowlink[vertex] = self.lowlink[vertex].min(self.lowlink[successor]);
                } else if self.on_stack[successor] {
                    self.lowlink[vertex] =
                        self.lowlink[vertex].min(self.indices[successor].unwrap());
                }
            }
            if self.lowlink[vertex] == self.indices[vertex].unwrap() {
                let mut component = Vec::new();
                loop {
                    let member = self.stack.pop().unwrap();
                    self.on_stack[member] = false;
                    component.push(member);
                    if member == vertex {
                        break;
                    }
                }
                self.components.push(component);
            }
        }
    }

    let mut tarjan = Tarjan {
        graph,
        index: 0,
        stack: Vec::new(),
        on_stack: vec![false; graph.len()],
        indices: vec![None; graph.len()],
        lowlink: vec![0; graph.len()],
        components: Vec::new(),
    };
    for vertex in 0..graph.len() {
        if tarjan.indices[vertex].is_none() {
            tarjan.strong_connect(vertex);
        }
    }
    tarjan.components
}

pub(crate) fn smt_c(symbol: &str) -> String {
    format!("c_{}", sanitize_smt_name(symbol))
}

pub(crate) fn smt_a(symbol: &str, index: usize) -> String {
    format!("a_{}_{}", sanitize_smt_name(symbol), index)
}

pub(crate) fn quadratic_smt_symbol(symbol: &str) -> String {
    symbol
        .as_bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

pub(crate) fn quadratic_smt_c(symbol: &str) -> String {
    format!("q_c_{}", quadratic_smt_symbol(symbol))
}

pub(crate) fn quadratic_smt_a(symbol: &str, index: usize) -> String {
    format!("q_a_{}_{}", quadratic_smt_symbol(symbol), index)
}

pub(crate) fn quadratic_smt_b(symbol: &str, left: usize, right: usize) -> String {
    format!("q_b_{}_{}_{}", quadratic_smt_symbol(symbol), left, right)
}

pub(crate) fn max_smt_c(symbol: &str, alternative: usize) -> String {
    format!("mc_{}_{}", sanitize_smt_name(symbol), alternative)
}

pub(crate) fn max_smt_a(symbol: &str, alternative: usize, index: usize) -> String {
    format!("ma_{}_{}_{}", sanitize_smt_name(symbol), alternative, index)
}

pub(crate) fn sanitize_smt_name(input: &str) -> String {
    input
        .as_bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

pub(crate) fn smt_add(lhs: &str, rhs: &str) -> String {
    if lhs == "0" {
        rhs.to_string()
    } else if rhs == "0" {
        lhs.to_string()
    } else {
        format!("(+ {lhs} {rhs})")
    }
}

pub(crate) fn smt_mul(lhs: &str, rhs: &str) -> String {
    if lhs == "0" || rhs == "0" {
        "0".to_string()
    } else if lhs == "1" {
        rhs.to_string()
    } else if rhs == "1" {
        lhs.to_string()
    } else {
        format!("(* {lhs} {rhs})")
    }
}
