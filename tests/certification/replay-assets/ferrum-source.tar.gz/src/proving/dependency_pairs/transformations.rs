//! Narrowing, instantiation, forward instantiation, and rewriting transitions.
//!
//! Each public routine constructs one candidate residual DP state. Scheduling
//! and recursive solving are deliberately absent from this module.

use super::*;

#[cfg(test)]
pub(crate) fn synthesize_narrowing_step(
    trs: &Trs,
    pairs: &[DependencyPair],
    options: &DpOptions,
) -> Option<(DpNarrowingStep, Vec<DependencyPair>)> {
    synthesize_narrowing_step_filtered(
        trs,
        pairs,
        options,
        None,
        None,
        &DpStrategyCancellation::default(),
        |_| true,
    )
}

#[cfg(test)]
pub(crate) fn synthesize_narrowing_step_filtered(
    trs: &Trs,
    pairs: &[DependencyPair],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
    pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<(DpNarrowingStep, Vec<DependencyPair>)> {
    synthesize_narrowing_steps_filtered(
        None,
        trs,
        pairs,
        options,
        innermost_lhss,
        deadline,
        cancellation,
        pair_allowed,
    )?
    .into_iter()
    .next()
    .map(|(_, step, residual)| (step, residual))
}

pub(crate) fn synthesize_narrowing_steps_filtered(
    stats: Option<&DpProofStats>,
    trs: &Trs,
    pairs: &[DependencyPair],
    options: &DpOptions,
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
    mut pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<Vec<(ResidualDpGraphScore, DpNarrowingStep, Vec<DependencyPair>)>> {
    let default_innermost_lhss =
        (trs.strategy() == RewriteStrategy::Innermost && innermost_lhss.is_none()).then(|| {
            trs.rules()
                .iter()
                .map(|rule| rule.lhs().clone())
                .collect::<Vec<_>>()
        });
    let q_lhss = if trs.strategy() == RewriteStrategy::Innermost {
        innermost_lhss
            .or(default_innermost_lhss.as_deref())
            .unwrap_or_default()
    } else {
        &[]
    };
    let mut blocked_by_budget = 0usize;
    let mut blocked_by_side_condition = 0usize;
    let mut blocked_by_q_side_condition = 0usize;
    let mut inadmissible_positions = 0usize;
    let mut positions_without_narrowings = 0usize;
    let mut empty_narrowing_sets = 0usize;
    let mut identity_residuals = 0usize;
    let mut candidates = Vec::new();
    for (pair_index, pair) in pairs.iter().enumerate() {
        if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        if !pair_allowed(pair) {
            blocked_by_budget += 1;
            continue;
        }
        if !narrowing_pair_side_conditions_hold(trs, pair) {
            blocked_by_side_condition += 1;
            continue;
        }
        let mut narrowing_regions = non_root_positions(pair.rhs());
        narrowing_regions.push(Vec::new());
        narrowing_regions.sort_by_key(|position| std::cmp::Reverse(position.len()));
        for position in narrowing_regions {
            if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
                return None;
            }
            if !narrowing_position_is_admissible(trs, pair, &position, pairs, q_lhss) {
                inadmissible_positions += 1;
                continue;
            }
            if !narrowing_position_is_ceta_q_admissible(trs, pair, &position, q_lhss) {
                blocked_by_q_side_condition += 1;
                continue;
            }
            let Some(narrowings) = narrow_pair_at_position(
                pair,
                &position,
                trs.rules(),
                q_lhss,
                options.max_narrowings_per_step,
            ) else {
                positions_without_narrowings += 1;
                continue;
            };
            let narrowings = alpha_unique_pairs(narrowings);
            if narrowings.is_empty() {
                empty_narrowing_sets += 1;
                continue;
            }
            let mut residual = Vec::with_capacity(pairs.len() - 1 + narrowings.len());
            for (index, existing) in pairs.iter().enumerate() {
                if index == pair_index {
                    residual.extend(narrowings.clone());
                } else {
                    residual.push(existing.clone());
                }
            }
            if residual == pairs {
                identity_residuals += 1;
                continue;
            }
            let score = residual_dp_graph_score_cached(
                stats,
                trs,
                &residual,
                trs.rules(),
                q_lhss,
                deadline,
                cancellation,
            )?;
            candidates.push((
                score,
                DpNarrowingStep {
                    pair: pair.clone(),
                    position,
                    narrowings,
                },
                residual,
            ));
        }
    }
    // No ordering or duplicate test is needed for a unique candidate. Full
    // signature canonicalization can be factorial on symmetric constants;
    // doing it here used to dominate even one bounded narrowing step.
    let mut literal_residuals = BTreeSet::new();
    candidates.retain(|(_, _, residual)| {
        let mut key = residual.iter().map(canonical_dependency_pair_key).collect::<Vec<_>>();
        if trs.strategy() != RewriteStrategy::Innermost {
            key.sort();
        }
        literal_residuals.insert(key)
    });
    if candidates.len() == 1 {
        return Some(candidates);
    }
    let mut seen_residuals = BTreeSet::new();
    // Different term-tree shapes cannot be symbol-renaming isomorphic.
    // Canonicalize only ambiguous buckets; keep the exact canonical test
    // for them, so candidate identities and deduplication are unchanged.
    fn shape(term: &Term) -> String {
        match term {
            Term::Var(_) => "v".into(),
            Term::App { args, .. } => format!("({})", args.iter().map(shape).collect::<Vec<_>>().join(",")),
        }
    }
    let residual_shape = |residual: &[DependencyPair]| {
        let mut shapes = residual.iter().map(|pair| (shape(pair.lhs()), shape(pair.rhs()))).collect::<Vec<_>>();
        shapes.sort();
        shapes
    };
    let mut shape_counts = BTreeMap::new();
    for (_, _, residual) in &candidates {
        *shape_counts.entry(residual_shape(residual)).or_insert(0usize) += 1;
    }
    if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
        eprintln!("narrowing canonicalization candidates={} shape_buckets={}", candidates.len(), shape_counts.len());
    }
    candidates.retain(|(_, _, residual)| {
        if shape_counts[&residual_shape(residual)] == 1 {
            return true;
        }
        let key = if trs.strategy() == RewriteStrategy::Innermost {
            residual.iter().map(canonical_dependency_pair_key).collect::<Vec<_>>().join("\0")
        } else {
            standardized_dp_state_input_cpf3(trs, residual, None, true, false).0
        };
        seen_residuals.insert(key)
    });
    if candidates.is_empty() {
        write_progress_event(
            "dp-transform",
            "rejected",
            "narrowing",
            0,
            &format!(
                "pairs={} blocked_by_budget={} blocked_by_side_condition={} blocked_by_q_side_condition={} inadmissible_positions={} positions_without_narrowings={} empty_narrowing_sets={} identity_residuals={}",
                pairs.len(),
                blocked_by_budget,
                blocked_by_side_condition,
                blocked_by_q_side_condition,
                inadmissible_positions,
                positions_without_narrowings,
                empty_narrowing_sets,
                identity_residuals
            ),
        );
    }
    if trs.strategy() == RewriteStrategy::Innermost {
        candidates.sort_by_key(|(score, step, _)| {
            let mut narrowing_key = step
                .narrowings
                .iter()
                .map(canonical_dependency_pair_key)
                .collect::<Vec<_>>();
            narrowing_key.sort();
            (
                !narrowing_step_specializes_nondeterministic_call(trs, step),
                step.pair.source_rule,
                *score,
                std::cmp::Reverse(term_size(step.pair.rhs())),
                step.position.is_empty(),
                step.position.clone(),
                canonical_dependency_pair_key(&step.pair),
                narrowing_key,
            )
        });
    } else {
        let cheap_key = |(score, step, _): &(ResidualDpGraphScore, DpNarrowingStep, Vec<DependencyPair>)| {
            (
                !narrowing_step_specializes_nondeterministic_call(trs, step),
                *score,
                std::cmp::Reverse(term_size(step.pair.rhs())),
                step.position.is_empty(),
                step.position.clone(),
            )
        };
        candidates.sort_by_key(cheap_key);
        let mut start = 0;
        while start < candidates.len() {
            let mut end = start + 1;
            while end < candidates.len() && cheap_key(&candidates[start]) == cheap_key(&candidates[end]) {
                end += 1;
            }
            if end - start > 1 {
                candidates[start..end].sort_by_cached_key(|(_, _, residual)|
                    standardized_dp_state_input_cpf3(trs, residual, None, true, false).0);
            }
            start = end;
        }
    }
    Some(candidates)
}

pub(crate) fn narrowing_step_specializes_nondeterministic_call(
    trs: &Trs,
    step: &DpNarrowingStep,
) -> bool {
    let Some(redex) = subterm_at_position(step.pair.rhs(), &step.position) else {
        return false;
    };
    let Term::App { symbol, .. } = redex else {
        return false;
    };
    trs.rules()
        .iter()
        .filter(|rule| rule.lhs().root_symbol() == Some(symbol))
        .take(2)
        .count()
        > 1
}

#[cfg(test)]
pub(crate) fn synthesize_instantiation_step(
    trs: &Trs,
    pairs: &[DependencyPair],
) -> Option<(DpInstantiationStep, Vec<DependencyPair>)> {
    let q_lhss = initial_innermost_lhss(trs).unwrap_or_default();
    let active_rules = if trs.strategy() == RewriteStrategy::Innermost {
        usable_rules_in_innermost_context(trs, pairs, Some(&q_lhss))
    } else {
        trs.rules().to_vec()
    };
    synthesize_instantiation_step_filtered(
        None,
        trs,
        pairs,
        &active_rules,
        &q_lhss,
        None,
        None,
        &DpStrategyCancellation::default(),
        |_| true,
    )
}

pub(crate) fn synthesize_instantiation_step_filtered(
    stats: Option<&DpProofStats>,
    trs: &Trs,
    pairs: &[DependencyPair],
    active_rules: &[RewriteRule],
    q_lhss: &[Term],
    csr_instantiation: Option<&CsrTrs>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
    mut pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<(DpInstantiationStep, Vec<DependencyPair>)> {
    let defined_symbols = trs.defined_symbols();
    let mut blocked_by_budget = 0usize;
    let mut blocked_by_auxiliary_variables = 0usize;
    let mut blocked_by_standard_coverage = 0usize;
    let mut skeleton_variants = 0usize;
    let mut failed_unifications = 0usize;
    let mut generated_candidates = 0usize;
    let mut alpha_duplicates = 0usize;
    let mut identity_groups = 0usize;
    let mut identity_residuals = 0usize;
    let mut best_candidate: Option<(
        (ResidualDpGraphScore, std::cmp::Reverse<usize>, usize, usize),
        DpInstantiationStep,
        Vec<DependencyPair>,
    )> = None;
    for (pair_index, pair) in pairs.iter().enumerate() {
        if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        if !pair_allowed(pair) {
            blocked_by_budget += 1;
            continue;
        }
        if pair_contains_instantiation_auxiliary_variables(pair) {
            blocked_by_auxiliary_variables += 1;
            continue;
        }
        let mut instantiation_groups: Vec<Vec<DependencyPair>> = Vec::new();
        let selected_variables = pair_variables(pair);
        for (predecessor_index, predecessor) in pairs.iter().enumerate() {
            if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
                return None;
            }
            let predecessor =
                freshen_pair_avoiding(predecessor, predecessor_index, &selected_variables);
            let mut cap_index = 0usize;
            let skeleton =
                cap_defined_subterms(predecessor.rhs(), &defined_symbols, true, &mut cap_index);
            for (variant_index, skeleton) in
                instantiation_skeleton_variants(&skeleton, "inst", trs.strategy())
                    .into_iter()
                    .enumerate()
            {
                if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
                    return None;
                }
                skeleton_variants += 1;
                if instantiation_groups.len() <= variant_index {
                    instantiation_groups.resize_with(variant_index + 1, Vec::new);
                }
                let mut substitution = BTreeMap::new();
                if !unify_terms(&skeleton, pair.lhs(), &mut substitution) {
                    failed_unifications += 1;
                    continue;
                }
                let instantiated_lhs = apply_substitution(pair.lhs(), &substitution);
                let instantiated_rhs = apply_substitution(pair.rhs(), &substitution);
                let instantiated_pair = DependencyPair {
                    lhs: instantiated_lhs,
                    rhs: instantiated_rhs,
                    source_rule: pair.source_rule,
                };
                if !contains_alpha_equivalent_pair(
                    &instantiation_groups[variant_index],
                    &instantiated_pair,
                ) {
                    generated_candidates += 1;
                    instantiation_groups[variant_index].push(instantiated_pair);
                } else {
                    alpha_duplicates += 1;
                }
            }
        }
        let mut exact_instantiations = Vec::new();
        for predecessor in pairs {
            let required = if let Some(csr) = csr_instantiation {
                csr_instantiation_required_pair(csr, active_rules, predecessor, pair)
            } else {
                q_instantiation_required_pair(active_rules, q_lhss, predecessor, pair)
            };
            let Some(required) = required else {
                continue;
            };
            if !contains_alpha_equivalent_pair(&exact_instantiations, &required) {
                exact_instantiations.push(required);
            }
        }
        if !exact_instantiations.is_empty() {
            // Retain the exact Ren_mu(Cap_mu) set as an alternative to the
            // ordinary CAP skeletons.  Candidate ranking below compares their
            // residual graphs.  Putting the exact set first made equal-score
            // ties suppress a coverage-checked general instance; on Ex1_GM03
            // that selected a dead four-pair residual instead of the instance
            // which enables forward instantiation.
            instantiation_groups.push(exact_instantiations);
        }

        let mut saw_non_identity_group = false;
        for instantiations in instantiation_groups {
            if instantiations.len() == 1
                && dependency_pairs_alpha_equivalent(&instantiations[0], pair)
            {
                identity_groups += 1;
                continue;
            }
            saw_non_identity_group = true;
            let coverage_holds = if let Some(csr) = csr_instantiation {
                csr_instantiation_coverage_holds(csr, pairs, pair, &instantiations, active_rules)
            } else {
                q_instantiation_ceta_coverage_holds(
                    pairs,
                    pair,
                    &instantiations,
                    q_lhss,
                    active_rules,
                )
            };
            if !coverage_holds {
                blocked_by_standard_coverage += 1;
                continue;
            }
            let residual = exact_instantiation_residual(pairs, pair_index, &instantiations);
            // Keep the checker's exact `replace_pair` result.  The CPF
            // checker treats the pair list extensionally for soundness, but
            // its graph-coverage check still requires every syntactically
            // spelled source pair.  Alpha-deduplicating here could therefore
            // discard (for example) one U(X) -> f#(X) while retaining only
            // the alpha-equivalent U(N) -> f#(N), yielding a proof tree that
            // was complete for Ferrum's altered state but rejected by CeTA.
            //
            // Fresh alpha copies must still not count as search progress.
            // Detect that set-level identity without changing the certified
            // residual itself; the generic transformation-depth bound then
            // prevents growth along genuinely changing chains.
            let alpha_identity = residual
                .iter()
                .all(|candidate| contains_alpha_equivalent_pair(pairs, candidate))
                && pairs
                    .iter()
                    .all(|candidate| contains_alpha_equivalent_pair(&residual, candidate));
            if alpha_identity {
                identity_residuals += 1;
                continue;
            }
            let step = DpInstantiationStep {
                pair: pair.clone(),
                instantiations,
                context_sensitive: csr_instantiation.is_some(),
            };
            let graph_score = residual_dp_graph_score_cached(
                stats,
                trs,
                &residual,
                active_rules,
                q_lhss,
                deadline,
                cancellation,
            )?;
            if graph_score.0 == 0 {
                return Some((step, residual));
            }
            let lhs_specificity = positions_with_subterms(pair.lhs())
                .into_iter()
                .filter(|(position, term)| !position.is_empty() && matches!(term, Term::App { .. }))
                .count();
            let score = (
                graph_score,
                std::cmp::Reverse(lhs_specificity),
                pair.source_rule,
                pair_index,
            );
            let replace_best = best_candidate
                .as_ref()
                .is_none_or(|(best_score, _, _)| score < *best_score);
            if replace_best {
                best_candidate = Some((score, step, residual));
            }
        }
        if !saw_non_identity_group {
            identity_groups += 1;
        }
    }
    if let Some((_, step, residual)) = best_candidate {
        return Some((step, residual));
    }
    write_progress_event(
        "dp-transform",
        "rejected",
        "instantiation",
        0,
        &format!(
            "pairs={} blocked_by_budget={} blocked_by_auxiliary_variables={} blocked_by_standard_coverage={} skeleton_variants={} failed_unifications={} generated_candidates={} alpha_duplicates={} identity_groups={} identity_residuals={}",
            pairs.len(),
            blocked_by_budget,
            blocked_by_auxiliary_variables,
            blocked_by_standard_coverage,
            skeleton_variants,
            failed_unifications,
            generated_candidates,
            alpha_duplicates,
            identity_groups,
            identity_residuals
        ),
    );
    None
}

/// Mirror CPF/CeTA's `replace_pair` operation without alpha-deduplicating the
/// untouched source list.  Variable names are immaterial to DP semantics but
/// remain syntactically visible to the checker's graph-coverage obligation.
pub(crate) fn exact_instantiation_residual(
    pairs: &[DependencyPair],
    selected_index: usize,
    instantiations: &[DependencyPair],
) -> Vec<DependencyPair> {
    let mut residual = Vec::with_capacity(pairs.len() - 1 + instantiations.len());
    for (index, existing) in pairs.iter().enumerate() {
        if index == selected_index {
            residual.extend_from_slice(instantiations);
        } else {
            residual.push(existing.clone());
        }
    }
    residual
}

#[cfg(test)]
pub(crate) fn synthesize_forward_instantiation_step(
    trs: &Trs,
    pairs: &[DependencyPair],
    usable_rules: &[RewriteRule],
) -> Option<(DpForwardInstantiationStep, Vec<DependencyPair>)> {
    synthesize_forward_instantiation_step_filtered(
        trs,
        pairs,
        usable_rules,
        None,
        false,
        None,
        &DpStrategyCancellation::default(),
        |_| true,
    )
}

#[cfg(test)]
pub(crate) fn synthesize_forward_instantiation_step_filtered(
    trs: &Trs,
    pairs: &[DependencyPair],
    usable_rules: &[RewriteRule],
    innermost_lhss: Option<&[Term]>,
    allow_usable_rule_subset: bool,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
    pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<(DpForwardInstantiationStep, Vec<DependencyPair>)> {
    synthesize_forward_instantiation_candidates_filtered(
        None,
        trs,
        pairs,
        usable_rules,
        false,
        innermost_lhss,
        allow_usable_rule_subset,
        deadline,
        cancellation,
        pair_allowed,
    )?
    .into_iter()
    .next()
    .map(|(_, step, residual)| (step, residual))
}

pub(crate) type ResidualDpGraphScore = (usize, usize, usize, usize);

pub(crate) type DpForwardInstantiationCandidate = (
    ResidualDpGraphScore,
    DpForwardInstantiationStep,
    Vec<DependencyPair>,
);

pub(crate) fn forward_instantiation_candidate_priority(
    is_exact: bool,
    score: ResidualDpGraphScore,
    step: &DpForwardInstantiationStep,
) -> (
    std::cmp::Reverse<bool>,
    std::cmp::Reverse<bool>,
    std::cmp::Reverse<bool>,
    ResidualDpGraphScore,
    std::cmp::Reverse<usize>,
) {
    // Prefer transformations at a call-family boundary.  They expose the
    // control-flow split that forward instantiation is intended to refine
    // (for example if#(...) -> U(...)) without first specializing projection
    // chains such as U(s(x)) -> U(x).  The latter are normally better left
    // general for subterm/SCT processors and can otherwise multiply the
    // residual problem.
    let crosses_root_boundary = step.pair.lhs().root_symbol() != step.pair.rhs().root_symbol();
    let unary_projection = matches!(
        step.pair.rhs(),
        Term::App { args, .. }
            if args.len() == 1 && matches!(args.first(), Some(Term::Var(_)))
    );
    (
        std::cmp::Reverse(is_exact),
        std::cmp::Reverse(crosses_root_boundary),
        std::cmp::Reverse(unary_projection),
        score,
        std::cmp::Reverse(term_size(step.pair.rhs())),
    )
}

pub(crate) fn synthesize_forward_instantiation_candidates_filtered(
    stats: Option<&DpProofStats>,
    trs: &Trs,
    pairs: &[DependencyPair],
    usable_rules: &[RewriteRule],
    active_rules_are_residual: bool,
    innermost_lhss: Option<&[Term]>,
    allow_usable_rule_subset: bool,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
    mut pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<Vec<DpForwardInstantiationCandidate>> {
    let default_innermost_lhss =
        (trs.strategy() == RewriteStrategy::Innermost && innermost_lhss.is_none()).then(|| {
            trs.rules()
                .iter()
                .map(|rule| rule.lhs().clone())
                .collect::<Vec<_>>()
        });
    let q_lhss = if trs.strategy() == RewriteStrategy::Innermost {
        innermost_lhss
            .or(default_innermost_lhss.as_deref())
            .unwrap_or_default()
    } else {
        &[]
    };
    // CeTA permits the optional usable-rule component of forward
    // instantiation only when NF(Q) is contained in NF(R).  Its executable
    // criterion is exact here: every active R left-hand side must fail to be
    // Q-normal.  In particular, an explicit empty innermost-LHS set means
    // Q = empty, so a nonempty R cannot use the restricted processor even
    // when minimality or normal-form substitutions otherwise suffice.
    // A search-local usable-rule hint and a certified residual R are
    // intentionally distinct.  Only the latter replaces the incoming rule
    // universe; otherwise CeTA's NF(Q) subset NF(R) side condition is checked
    // against the full DP problem.
    let input_rules = if active_rules_are_residual {
        usable_rules
    } else {
        trs.rules()
    };
    let use_usable_rule_subset = allow_usable_rule_subset
        && input_rules
            .iter()
            .all(|rule| !term_is_q_normal(rule.lhs(), q_lhss));
    let reverse_base_rules = if use_usable_rule_subset {
        usable_rules
    } else {
        input_rules
    };
    let defined_symbols = trs.defined_symbols();
    let mut blocked_by_budget = 0usize;
    let mut blocked_by_auxiliary_variables = 0usize;
    let mut blocked_by_standard_coverage = 0usize;
    let mut skeleton_variants = 0usize;
    let mut failed_unifications = 0usize;
    let mut blocked_by_innermost_normality = 0usize;
    let mut generated_candidates = 0usize;
    let mut alpha_duplicates = 0usize;
    let mut identity_groups = 0usize;
    let mut identity_residuals = 0usize;
    let mut exact_edges = 0usize;
    let mut exact_required_pairs = 0usize;
    let mut candidates = Vec::new();
    for (pair_index, pair) in pairs.iter().enumerate() {
        if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        if !pair_allowed(pair) {
            blocked_by_budget += 1;
            continue;
        }
        if pair_contains_instantiation_auxiliary_variables(pair) {
            blocked_by_auxiliary_variables += 1;
            continue;
        }
        let pair_instantiation_rules = if use_usable_rule_subset {
            ceta_innermost_usable_rules_for_term(
                reverse_base_rules,
                q_lhss,
                std::slice::from_ref(pair.lhs()),
                pair.rhs(),
            )
        } else {
            reverse_base_rules.to_vec()
        };
        let mut instantiation_groups: Vec<(bool, Vec<DependencyPair>)> = Vec::new();
        let selected_variables = pair_variables(pair);
        for (successor_index, successor) in pairs.iter().enumerate() {
            if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
                return None;
            }
            let successor = freshen_pair_avoiding(successor, successor_index, &selected_variables);
            let mut cap_index = 0usize;
            let skeleton =
                cap_defined_subterms(successor.lhs(), &defined_symbols, true, &mut cap_index);
            for (variant_index, skeleton) in
                instantiation_skeleton_variants(&skeleton, "finst", trs.strategy())
                    .into_iter()
                    .enumerate()
            {
                if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
                    return None;
                }
                skeleton_variants += 1;
                if instantiation_groups.len() <= variant_index {
                    instantiation_groups.resize_with(variant_index + 1, || (false, Vec::new()));
                }
                let mut substitution = BTreeMap::new();
                if !unify_terms(pair.rhs(), &skeleton, &mut substitution) {
                    failed_unifications += 1;
                    continue;
                }
                let instantiated_lhs = apply_substitution(pair.lhs(), &substitution);
                let instantiated_rhs = apply_substitution(pair.rhs(), &substitution);
                if trs.strategy() == RewriteStrategy::Innermost {
                    let successor_lhs = apply_substitution(successor.lhs(), &substitution);
                    if !term_is_guaranteed_normal(&instantiated_rhs, trs.rules())
                        || !term_is_guaranteed_normal(&successor_lhs, trs.rules())
                    {
                        blocked_by_innermost_normality += 1;
                        continue;
                    }
                }
                let instantiated_pair = DependencyPair {
                    lhs: instantiated_lhs,
                    rhs: instantiated_rhs,
                    source_rule: pair.source_rule,
                };
                if !contains_alpha_equivalent_pair(
                    &instantiation_groups[variant_index].1,
                    &instantiated_pair,
                ) {
                    generated_candidates += 1;
                    instantiation_groups[variant_index]
                        .1
                        .push(instantiated_pair);
                } else {
                    alpha_duplicates += 1;
                }
            }
        }

        if use_usable_rule_subset {
            let mut ground_terms = Vec::new();
            for successor in pairs {
                for (_, subterm) in positions_with_subterms(successor.lhs()) {
                    if subterm.variables().is_empty() && !ground_terms.contains(subterm) {
                        ground_terms.push(subterm.clone());
                    }
                }
            }
            for variable in pair.rhs().variables() {
                for ground in &ground_terms {
                    if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
                        return None;
                    }
                    let substitution = BTreeMap::from([(variable.clone(), ground.clone())]);
                    let instantiated_pair = DependencyPair {
                        lhs: apply_substitution(pair.lhs(), &substitution),
                        rhs: apply_substitution(pair.rhs(), &substitution),
                        source_rule: pair.source_rule,
                    };
                    if trs.strategy() == RewriteStrategy::Innermost
                        && !term_is_guaranteed_normal(instantiated_pair.rhs(), trs.rules())
                    {
                        blocked_by_innermost_normality += 1;
                        continue;
                    }
                    generated_candidates += 1;
                    instantiation_groups.push((false, vec![instantiated_pair]));
                }
            }
        }

        let mut exact_instantiations = Vec::new();
        for successor in pairs {
            if !ceta_q_iedg_edge(trs, pair, successor, q_lhss, reverse_base_rules) {
                continue;
            }
            exact_edges += 1;
            let Some(required) = forward_instantiation_required_pair(
                pair,
                successor,
                q_lhss,
                &pair_instantiation_rules,
            ) else {
                continue;
            };
            exact_required_pairs += 1;
            if !contains_alpha_equivalent_pair(&exact_instantiations, &required) {
                exact_instantiations.push(required);
            }
        }
        if !exact_instantiations.is_empty() {
            instantiation_groups.push((true, exact_instantiations));
        }

        let mut saw_non_identity_group = false;
        let mut candidate_groups = Vec::new();
        for (is_exact, instantiations) in instantiation_groups {
            let minimized = remove_subsumed_forward_instantiations(instantiations.clone());
            if instantiations != minimized {
                candidate_groups.push((false, minimized));
            }
            candidate_groups.push((is_exact, instantiations));
        }
        for (is_exact, instantiations) in candidate_groups {
            if instantiations.is_empty()
                || (instantiations.len() == 1
                    && dependency_pairs_alpha_equivalent(&instantiations[0], pair))
            {
                identity_groups += 1;
                continue;
            }
            saw_non_identity_group = true;
            if !forward_instantiation_ceta_coverage_holds(
                trs,
                pairs,
                pair,
                &instantiations,
                q_lhss,
                reverse_base_rules,
                &pair_instantiation_rules,
            ) {
                blocked_by_standard_coverage += 1;
                continue;
            }
            let mut residual = Vec::with_capacity(pairs.len() - 1 + instantiations.len());
            for (index, existing) in pairs.iter().enumerate() {
                if index == pair_index {
                    residual.extend(instantiations.clone());
                } else {
                    residual.push(existing.clone());
                }
            }
            if residual == pairs {
                identity_residuals += 1;
                continue;
            }
            let step = DpForwardInstantiationStep {
                pair: pair.clone(),
                instantiations,
                usable_rules: pair_instantiation_rules.clone(),
                uses_usable_rules: use_usable_rule_subset,
            };
            let score = residual_dp_graph_score_cached(
                stats,
                trs,
                &residual,
                usable_rules,
                innermost_lhss.unwrap_or(&[]),
                deadline,
                cancellation,
            )?;
            if !candidates
                .iter()
                .any(|(_, _, _, existing_residual)| *existing_residual == residual)
            {
                candidates.push((is_exact, score, step, residual));
            }
        }
        if !saw_non_identity_group {
            identity_groups += 1;
        }
        if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
    }
    if !candidates.is_empty() {
        candidates.sort_by_key(|(is_exact, score, step, _)| {
            forward_instantiation_candidate_priority(*is_exact, *score, step)
        });
        return Some(
            candidates
                .into_iter()
                .map(|(_, score, step, residual)| (score, step, residual))
                .collect(),
        );
    }
    write_progress_event(
        "dp-transform",
        "rejected",
        "forward-instantiation",
        0,
        &format!(
            "pairs={} usable_rules={} blocked_by_budget={} blocked_by_auxiliary_variables={} blocked_by_standard_coverage={} skeleton_variants={} failed_unifications={} blocked_by_innermost_normality={} generated_candidates={} alpha_duplicates={} identity_groups={} identity_residuals={} exact_edges={} exact_required_pairs={}",
            pairs.len(),
            usable_rules.len(),
            blocked_by_budget,
            blocked_by_auxiliary_variables,
            blocked_by_standard_coverage,
            skeleton_variants,
            failed_unifications,
            blocked_by_innermost_normality,
            generated_candidates,
            alpha_duplicates,
            identity_groups,
            identity_residuals,
            exact_edges,
            exact_required_pairs
        ),
    );
    Some(Vec::new())
}

pub(crate) fn remove_subsumed_forward_instantiations(
    instantiations: Vec<DependencyPair>,
) -> Vec<DependencyPair> {
    instantiations
        .iter()
        .enumerate()
        .filter(|(index, candidate)| {
            !instantiations
                .iter()
                .enumerate()
                .any(|(other_index, other)| {
                    index != &other_index
                        && dependency_pair_is_instance_of(candidate, other)
                        && !dependency_pair_is_instance_of(other, candidate)
                })
        })
        .map(|(_, pair)| pair.clone())
        .collect()
}

pub(crate) fn residual_dp_graph_score(
    trs: &Trs,
    pairs: &[DependencyPair],
    active_rules: &[RewriteRule],
    q_lhss: &[Term],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<ResidualDpGraphScore> {
    if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    let graph = dependency_pair_graph_with_rules_deadline(
        trs,
        active_rules,
        pairs,
        (!q_lhss.is_empty()).then_some(q_lhss),
        deadline,
        cancellation,
    )?;
    if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    Some(residual_dp_graph_score_from_graph(&graph))
}

pub(crate) fn residual_dp_graph_score_cached(
    stats: Option<&DpProofStats>,
    trs: &Trs,
    pairs: &[DependencyPair],
    active_rules: &[RewriteRule],
    q_lhss: &[Term],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<ResidualDpGraphScore> {
    let Some(stats) = stats else {
        return residual_dp_graph_score(trs, pairs, active_rules, q_lhss, deadline, cancellation);
    };
    if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    let graph = cached_dp_problem_dependency_graph_with_context_deadline(
        stats,
        trs,
        pairs,
        (!q_lhss.is_empty()).then_some(q_lhss),
        Some(active_rules),
        deadline,
        cancellation,
    )?;
    if dp_transform_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    Some(residual_dp_graph_score_from_graph(&graph))
}

pub(crate) fn residual_dp_graph_score_from_graph(graph: &[Vec<usize>]) -> ResidualDpGraphScore {
    let cyclic_component_sizes = strongly_connected_components(graph)
        .into_iter()
        .filter(|component| component_is_cyclic(component, graph))
        .map(|component| component.len())
        .collect::<Vec<_>>();
    let cyclic_pairs = cyclic_component_sizes.iter().sum();
    let largest_cyclic_component = cyclic_component_sizes.into_iter().max().unwrap_or(0);
    let edges = graph.iter().map(Vec::len).sum();
    (cyclic_pairs, largest_cyclic_component, edges, graph.len())
}

pub(crate) fn dp_transform_timed_out_or_cancelled(
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> bool {
    current_thread_cancelled() || cancellation.is_cancelled() || strategy_timed_out(deadline)
}

pub(crate) fn write_smt_encoding_event(
    name: &str,
    started: Instant,
    script: &str,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    details: impl AsRef<str>,
) {
    write_progress_event(
        "dp-smt-encode",
        "finish",
        name,
        started.elapsed().as_millis(),
        &format!(
            "pairs={} usable_rules={} bytes={} {}",
            pairs.len(),
            usable.len(),
            script.len(),
            details.as_ref()
        ),
    );
}

#[cfg(test)]
pub(crate) fn standard_forward_instantiation_ceta_coverage_holds(
    trs: &Trs,
    pairs: &[DependencyPair],
    selected: &DependencyPair,
    instantiations: &[DependencyPair],
) -> bool {
    forward_instantiation_ceta_coverage_holds(
        trs,
        pairs,
        selected,
        instantiations,
        &[],
        trs.rules(),
        trs.rules(),
    )
}

pub(crate) fn forward_instantiation_ceta_coverage_holds(
    trs: &Trs,
    pairs: &[DependencyPair],
    selected: &DependencyPair,
    instantiations: &[DependencyPair],
    q_lhss: &[Term],
    graph_rules: &[RewriteRule],
    instantiation_rules: &[RewriteRule],
) -> bool {
    instantiations
        .iter()
        .all(|instantiation| dependency_pair_is_instance_of(instantiation, selected))
        && pairs
            .iter()
            .filter(|successor| ceta_q_iedg_edge(trs, selected, successor, q_lhss, graph_rules))
            .all(|successor| {
                let Some(required) = forward_instantiation_required_pair(
                    selected,
                    successor,
                    q_lhss,
                    instantiation_rules,
                ) else {
                    return true;
                };
                instantiations
                    .iter()
                    .any(|instantiation| dependency_pair_is_instance_of(&required, instantiation))
            })
}

/// Validate a fully specified forward-instantiation witness against the live
/// DP obligation. Unlike candidate synthesis, this imposes no search bounds
/// or heuristic skeleton enumeration; it checks the executable CeTA coverage
/// conditions directly.
pub(crate) fn validate_forward_instantiation_step(
    trs: &Trs,
    pairs: &[DependencyPair],
    step: &DpForwardInstantiationStep,
    q_lhss: &[Term],
    input_rules: &[RewriteRule],
) -> bool {
    let trace = std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some();
    let (graph_rules, instantiation_rules) = if step.uses_usable_rules {
        if let Some(rule) = input_rules
            .iter()
            .find(|rule| term_is_q_normal(rule.lhs(), q_lhss))
        {
            if trace {
                eprintln!(
                    "exact-forward usable-rule side condition rejected Q-normal lhs: {}",
                    rule.lhs()
                );
            }
            return false;
        }
        if let Some(rule) = step
            .usable_rules
            .iter()
            .find(|rule| !input_rules.contains(rule))
        {
            if trace {
                eprintln!(
                    "exact-forward archived usable rule is absent from live rules: {} -> {}",
                    rule.lhs(),
                    rule.rhs()
                );
            }
            return false;
        }
        let required = ceta_innermost_usable_rules_for_term(
            input_rules,
            q_lhss,
            std::slice::from_ref(step.pair.lhs()),
            step.pair.rhs(),
        );
        if let Some(rule) = required
            .iter()
            .find(|rule| !step.usable_rules.contains(rule))
        {
            if trace {
                eprintln!(
                    "exact-forward archived usable rules omit required live rule: {} -> {}",
                    rule.lhs(),
                    rule.rhs()
                );
            }
            return false;
        }
        (input_rules, step.usable_rules.as_slice())
    } else {
        (input_rules, input_rules)
    };
    let valid = forward_instantiation_ceta_coverage_holds(
        trs,
        pairs,
        &step.pair,
        &step.instantiations,
        q_lhss,
        graph_rules,
        instantiation_rules,
    );
    if trace && !valid {
        eprintln!(
            "exact-forward coverage selected={} -> {} instantiations={} q={} graph_rules={} instantiation_rules={}",
            step.pair.lhs(),
            step.pair.rhs(),
            step.instantiations.len(),
            q_lhss.len(),
            graph_rules.len(),
            instantiation_rules.len(),
        );
        for successor in pairs {
            let edge = ceta_q_iedg_edge(trs, &step.pair, successor, q_lhss, graph_rules);
            let required = edge
                .then(|| {
                    forward_instantiation_required_pair(
                        &step.pair,
                        successor,
                        q_lhss,
                        instantiation_rules,
                    )
                })
                .flatten();
            let covered = required.as_ref().is_none_or(|required| {
                step.instantiations
                    .iter()
                    .any(|instantiation| dependency_pair_is_instance_of(required, instantiation))
            });
            eprintln!(
                "exact-forward successor={} -> {} edge={} required={:?} covered={}",
                successor.lhs(),
                successor.rhs(),
                edge,
                required
                    .as_ref()
                    .map(|pair| format!("{} -> {}", pair.lhs(), pair.rhs())),
                covered,
            );
        }
    }
    valid
}

#[cfg(test)]
pub(crate) fn standard_forward_instantiation_required_pair(
    trs: &Trs,
    selected: &DependencyPair,
    successor: &DependencyPair,
) -> Option<DependencyPair> {
    if !ceta_forward_iedg_edge(trs, selected, successor) {
        return None;
    }
    forward_instantiation_required_pair(selected, successor, &[], trs.rules())
}

pub(crate) fn forward_instantiation_required_pair(
    selected: &DependencyPair,
    successor: &DependencyPair,
    q_lhss: &[Term],
    reverse_base_rules: &[RewriteRule],
) -> Option<DependencyPair> {
    let selected_lhs = prefix_term_variables(selected.lhs(), "y");
    let selected_rhs = prefix_term_variables(selected.rhs(), "y");
    let successor_lhs = prefix_term_variables(successor.lhs(), "x");
    let reversed_rules = reverse_rules(reverse_base_rules);
    let capped_successor_lhs = ceta_icap_empty_q(&reversed_rules, &[], true, &successor_lhs);
    let mut substitution = BTreeMap::new();
    if !unify_terms(&capped_successor_lhs, &selected_rhs, &mut substitution) {
        return None;
    }
    if !term_is_q_normal(&apply_substitution(&selected_lhs, &substitution), q_lhss)
        || !term_is_q_normal(&apply_substitution(&successor_lhs, &substitution), q_lhss)
    {
        return None;
    }
    let required_lhs = apply_substitution(&selected_lhs, &substitution);
    let required_rhs = apply_substitution(&selected_rhs, &substitution);
    Some(DependencyPair {
        lhs: required_lhs,
        rhs: required_rhs,
        source_rule: selected.source_rule,
    })
}

#[cfg(test)]
pub(crate) fn ceta_forward_iedg_edge(
    trs: &Trs,
    selected: &DependencyPair,
    successor: &DependencyPair,
) -> bool {
    ceta_q_iedg_edge(trs, selected, successor, &[], trs.rules())
}

#[cfg(test)]
pub(crate) fn standard_instantiation_ceta_coverage_holds(
    trs: &Trs,
    pairs: &[DependencyPair],
    selected: &DependencyPair,
    instantiations: &[DependencyPair],
) -> bool {
    q_instantiation_ceta_coverage_holds(pairs, selected, instantiations, &[], trs.rules())
}

pub(crate) fn q_instantiation_ceta_coverage_holds(
    pairs: &[DependencyPair],
    selected: &DependencyPair,
    instantiations: &[DependencyPair],
    q_lhss: &[Term],
    base_rules: &[RewriteRule],
) -> bool {
    instantiations
        .iter()
        .all(|instantiation| dependency_pair_is_instance_of(instantiation, selected))
        && pairs.iter().all(|predecessor| {
            // Instantiation_Impl filters predecessors by is_iedg_edge_dpp
            // before checking the forward-CAP instance. The reverse-CAP half
            // can rule out an otherwise over-approximated incoming call.
            if !ceta_q_iedg_edge_with_usable_rules(
                predecessor, selected, q_lhss, base_rules, None,
            ) {
                return true;
            }
            let Some(required) =
                q_instantiation_required_pair(base_rules, q_lhss, predecessor, selected)
            else {
                return true;
            };
            let covered = instantiations
                .iter()
                .any(|instantiation| dependency_pair_is_instance_of(&required, instantiation));
            if !covered && std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
                eprintln!("instantiation uncovered incoming: {:?}; required: {:?}", predecessor.as_rule(), required.as_rule());
            }
            covered
        })
}

#[cfg(test)]
pub(crate) fn standard_instantiation_required_pair(
    trs: &Trs,
    predecessor: &DependencyPair,
    selected: &DependencyPair,
) -> Option<DependencyPair> {
    q_instantiation_required_pair(trs.rules(), &[], predecessor, selected)
}

pub(crate) fn q_instantiation_required_pair(
    base_rules: &[RewriteRule],
    q_lhss: &[Term],
    predecessor: &DependencyPair,
    selected: &DependencyPair,
) -> Option<DependencyPair> {
    let predecessor_lhs = prefix_term_variables(predecessor.lhs(), "x");
    let predecessor_rhs = prefix_term_variables(predecessor.rhs(), "x");
    let selected_lhs = prefix_term_variables(selected.lhs(), "y");
    let selected_rhs = prefix_term_variables(selected.rhs(), "y");
    let capped_rhs = ceta_icap_q(
        base_rules,
        q_lhss,
        &[predecessor_lhs.clone()],
        &predecessor_rhs,
    );
    let mut substitution = BTreeMap::new();
    if !unify_terms(&capped_rhs, &selected_lhs, &mut substitution) {
        return None;
    }
    if !term_is_q_normal(&apply_substitution(&selected_lhs, &substitution), q_lhss)
        || !term_is_q_normal(&apply_substitution(&predecessor_lhs, &substitution), q_lhss)
    {
        return None;
    }
    let required_lhs = apply_substitution(&selected_lhs, &substitution);
    let required_rhs = apply_substitution(&selected_rhs, &substitution);
    Some(DependencyPair {
        lhs: required_lhs,
        rhs: required_rhs,
        source_rule: selected.source_rule,
    })
}

#[cfg(test)]
mod instantiation_coverage_tests {
    use super::*;

    #[test]
    fn reverse_cap_excludes_impossible_instantiation_predecessors() {
        let a = Term::app("a", vec![]);
        let b = Term::app("b", vec![]);
        let g = |term| Term::app("G#", vec![term]);
        let pair = |lhs, rhs| DependencyPair::from_rule(RewriteRule::new(lhs, rhs), 0);
        let predecessor = pair(Term::app("F#", vec![]), g(Term::app("f", vec![a])));
        let selected = pair(g(b.clone()), Term::app("H#", vec![]));
        let rules = vec![RewriteRule::new(Term::app("f", vec![Term::var("x")]),
                                         Term::app("c", vec![]))];
        assert!(q_instantiation_required_pair(&rules, &[], &predecessor, &selected).is_some());
        assert!(q_instantiation_ceta_coverage_holds(
            &[predecessor, selected.clone()], &selected, &[], &[], &rules));
        // A realizable predecessor still requires an explicit covering instance.
        let reachable = pair(Term::app("F#", vec![]), g(b));
        assert!(!q_instantiation_ceta_coverage_holds(
            &[reachable, selected.clone()], &selected, &[], &[], &rules));
    }
}

pub(crate) fn csr_instantiation_coverage_holds(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    selected: &DependencyPair,
    instantiations: &[DependencyPair],
    active_rules: &[RewriteRule],
) -> bool {
    instantiations
        .iter()
        .all(|instantiation| dependency_pair_is_instance_of(instantiation, selected))
        && pairs.iter().all(|predecessor| {
            let Some(required) =
                csr_instantiation_required_pair(csr, active_rules, predecessor, selected)
            else {
                return true;
            };
            instantiations
                .iter()
                .any(|instantiation| dependency_pair_is_instance_of(&required, instantiation))
        })
}

pub(crate) fn csr_instantiation_required_pair(
    csr: &CsrTrs,
    _active_rules: &[RewriteRule],
    predecessor: &DependencyPair,
    selected: &DependencyPair,
) -> Option<DependencyPair> {
    let predecessor_rhs = prefix_term_variables(predecessor.rhs(), "x");
    let selected_lhs = prefix_term_variables(selected.lhs(), "y");
    let selected_rhs = prefix_term_variables(selected.rhs(), "y");
    let mut fresh_index = 0usize;
    let capped_rhs = csr_shared_instantiation_cap_term(csr, &predecessor_rhs, &mut fresh_index);
    let mut substitution = BTreeMap::new();
    if !unify_terms(&capped_rhs, &selected_lhs, &mut substitution) {
        return None;
    }
    Some(DependencyPair {
        lhs: apply_substitution(&selected_lhs, &substitution),
        rhs: apply_substitution(&selected_rhs, &substitution),
        source_rule: selected.source_rule,
    })
}

pub(crate) fn csr_shared_instantiation_cap_term(
    csr: &CsrTrs,
    term: &Term,
    fresh_index: &mut usize,
) -> Term {
    match term {
        Term::Var(_) => {
            let variable = Term::var(format!("__csr_cap_{}", *fresh_index));
            *fresh_index += 1;
            variable
        }
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .enumerate()
                .map(|(index, argument)| {
                    if csr_symbol_allows_argument(csr, symbol, index) {
                        let variable = Term::var(format!("__csr_cap_{}", *fresh_index));
                        *fresh_index += 1;
                        variable
                    } else {
                        // Cap_mu only abstracts at active positions.  Once an
                        // argument is frozen by the replacement map, every
                        // position below it is frozen as well and its complete
                        // shape must be retained.  Recursing here used to turn
                        // IF(..., minus(...), ...) into IF(..., minus(z1,z2),
                        // ...), losing the LPAR'08 instantiation witness.
                        argument.clone()
                    }
                })
                .collect(),
        ),
    }
}

pub(crate) fn dependency_pair_is_instance_of(
    instance: &DependencyPair,
    general: &DependencyPair,
) -> bool {
    let mut substitution = BTreeMap::new();
    match_term(general.lhs(), instance.lhs(), &mut substitution)
        && match_term(general.rhs(), instance.rhs(), &mut substitution)
}

pub(crate) fn prefix_term_variables(term: &Term, prefix: &str) -> Term {
    match term {
        Term::Var(variable) => Term::var(format!("{prefix}{}", variable.as_str())),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| prefix_term_variables(arg, prefix))
                .collect(),
        ),
    }
}

pub(crate) fn term_is_guaranteed_normal(term: &Term, rules: &[RewriteRule]) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .all(|(_, subterm)| {
            matches!(subterm, Term::Var(_))
                || rules.iter().all(|rule| !unifies(subterm, rule.lhs()))
        })
}

#[cfg(test)]
pub(crate) fn synthesize_rewriting_step(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
) -> Option<(DpRewritingStep, Vec<DependencyPair>)> {
    synthesize_rewriting_step_filtered(pairs, usable, |_| true)
}

#[cfg(test)]
pub(crate) fn synthesize_rewriting_step_filtered(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    mut pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<(DpRewritingStep, Vec<DependencyPair>)> {
    if !usable_rules_have_only_trivial_critical_pairs(usable) {
        write_progress_event(
            "dp-transform",
            "rejected",
            "rewriting",
            0,
            &format!(
                "pairs={} usable_rules={} reason=nontrivial-usable-rule-critical-pair",
                pairs.len(),
                usable.len()
            ),
        );
        return None;
    }
    let mut blocked_by_budget = 0usize;
    let mut attempted_redexes = 0usize;
    let mut failed_matches = 0usize;
    let mut identity_rewrites = 0usize;
    for (pair_index, pair) in pairs.iter().enumerate() {
        if current_thread_cancelled() {
            return None;
        }
        if !pair_allowed(pair) {
            blocked_by_budget += 1;
            continue;
        }
        let used_variables = pair_variables(pair);
        for position in non_root_positions(pair.rhs()) {
            let redex = subterm_at_position(pair.rhs(), &position)?;
            attempted_redexes += 1;
            for (rule_index, rule) in usable.iter().enumerate() {
                let fresh_rule = freshen_rule_avoiding(rule, rule_index, &used_variables);
                let mut substitution = BTreeMap::new();
                if !match_term(fresh_rule.lhs(), redex, &mut substitution) {
                    failed_matches += 1;
                    continue;
                }
                let result = apply_substitution(fresh_rule.rhs(), &substitution);
                let rhs = replace_subterm_at_position(pair.rhs(), &position, &result)?;
                let rewritten_pair = DependencyPair {
                    lhs: pair.lhs().clone(),
                    rhs,
                    source_rule: pair.source_rule,
                };
                if dependency_pairs_alpha_equivalent(&rewritten_pair, pair) {
                    identity_rewrites += 1;
                    continue;
                }
                let mut residual = pairs.to_vec();
                residual[pair_index] = rewritten_pair.clone();
                return Some((
                    DpRewritingStep {
                        original_pair: pair.clone(),
                        rewrite_step: crate::proving::LoopRewriteStep {
                            position,
                            rule: rule.clone(),
                            result: rewritten_pair.rhs().clone(),
                        },
                        rewritten_pair,
                        usable_rules: usable.to_vec(),
                    },
                    residual,
                ));
            }
        }
    }
    write_progress_event(
        "dp-transform",
        "rejected",
        "rewriting",
        0,
        &format!(
            "pairs={} usable_rules={} blocked_by_budget={} attempted_redexes={} failed_matches={} identity_rewrites={}",
            pairs.len(),
            usable.len(),
            blocked_by_budget,
            attempted_redexes,
            failed_matches,
            identity_rewrites
        ),
    );
    None
}

pub(crate) fn synthesize_innermost_rewriting_step_filtered(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<(DpRewritingStep, Vec<DependencyPair>)> {
    synthesize_innermost_rewriting_step_candidate_filtered(
        trs,
        pairs,
        innermost_lhss,
        0,
        pair_allowed,
    )
}

pub(crate) fn synthesize_innermost_rewriting_step_candidate_filtered(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    mut candidate_index: usize,
    mut pair_allowed: impl FnMut(&DependencyPair) -> bool,
) -> Option<(DpRewritingStep, Vec<DependencyPair>)> {
    let mut selected = None;
    visit_innermost_rewriting_candidates(trs, pairs, innermost_lhss, &mut pair_allowed,
        |step, residual| {
            if candidate_index > 0 {
                candidate_index -= 1;
                false
            } else {
                selected = Some((step, residual));
                true
            }
        });
    selected
}

pub(crate) fn innermost_rewriting_candidate_count(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) -> usize {
    let mut count = 0;
    visit_innermost_rewriting_candidates(trs, pairs, innermost_lhss, |_| true,
        |_, _| { count += 1; false });
    count
}

fn visit_innermost_rewriting_candidates(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    mut pair_allowed: impl FnMut(&DependencyPair) -> bool,
    mut visit: impl FnMut(DpRewritingStep, Vec<DependencyPair>) -> bool,
) -> Option<()> {
    let cancellation = crate::proving::runtime::CancellationScope::current(None);
    for (pair_index, pair) in pairs.iter().enumerate() {
        if cancellation.is_cancelled() { return None; }
        if !pair_allowed(pair) {
            continue;
        }
        let used_variables = pair_variables(pair);
        for position in non_root_positions(pair.rhs()) {
            let redex = subterm_at_position(pair.rhs(), &position)?;
            let usable = innermost_lhss.map_or_else(
                || usable_rules(trs, std::slice::from_ref(pair)),
                |q_lhss| {
                    ceta_innermost_usable_rules_for_term(
                        trs.rules(),
                        q_lhss,
                        std::slice::from_ref(pair.lhs()),
                        redex,
                    )
                },
            );
            if !usable_rules_have_only_trivial_critical_pairs(&usable) {
                continue;
            }
            for (rule_index, rule) in usable.iter().enumerate() {
                let fresh_rule = freshen_rule_avoiding(rule, rule_index, &used_variables);
                let mut substitution = BTreeMap::new();
                if !match_term(fresh_rule.lhs(), redex, &mut substitution) {
                    continue;
                }
                let result = apply_substitution(fresh_rule.rhs(), &substitution);
                let rhs = replace_subterm_at_position(pair.rhs(), &position, &result)?;
                let rewritten_pair = DependencyPair {
                    lhs: pair.lhs().clone(),
                    rhs,
                    source_rule: pair.source_rule,
                };
                if dependency_pairs_alpha_equivalent(&rewritten_pair, pair) {
                    continue;
                }
                let step = DpRewritingStep {
                    original_pair: pair.clone(),
                    rewrite_step: crate::proving::LoopRewriteStep {
                        position: position.clone(),
                        rule: rule.clone(),
                        result: rewritten_pair.rhs().clone(),
                    },
                    rewritten_pair: rewritten_pair.clone(),
                    usable_rules: usable.clone(),
                };
                let mut residual = pairs.to_vec();
                residual[pair_index] = rewritten_pair;
                if visit(step, residual) { return Some(()); }
            }
        }
    }
    None
}

/// A conservative executable fragment of CeTA's innermost rewriting
/// precondition.  Root overlaps are harmless when both contractions yield
/// the same term (for example `min(0, y) -> 0` and `min(x, 0) -> 0`).  The
/// former discovery guard rejected those systems merely because an overlap
/// existed, although CeTA accepts the corresponding trivial critical pairs.
///
/// Requiring every critical pair to be literally trivial is stronger than
/// CeTA's joinability check, but unlike the old non-overlap test it admits
/// this common orthogonal-up-to-trivial-overlaps case without adding search.
pub(crate) fn usable_rules_have_only_trivial_critical_pairs(rules: &[RewriteRule]) -> bool {
    for (left_index, left_rule) in rules.iter().enumerate() {
        for (right_index, right_rule) in rules.iter().enumerate() {
            let used_variables = left_rule.lhs().variables();
            let right_rule = freshen_rule_avoiding(right_rule, right_index, &used_variables);
            for (position, subterm) in positions_with_subterms(right_rule.lhs()) {
                if left_index == right_index && position.is_empty() {
                    continue;
                }
                if matches!(subterm, Term::Var(_)) {
                    continue;
                }
                let mut substitution = BTreeMap::new();
                if unify_terms(left_rule.lhs(), subterm, &mut substitution) {
                    let contracted = apply_substitution(left_rule.rhs(), &substitution);
                    // `positions_with_subterms` uses zero-based child indices,
                    // whereas CPF rewrite positions (and this helper) are
                    // one-based.
                    let rewrite_position =
                        position.iter().map(|index| index + 1).collect::<Vec<_>>();
                    let Some(overlap) = replace_subterm_at_position(
                        right_rule.lhs(),
                        &rewrite_position,
                        &contracted,
                    ) else {
                        return false;
                    };
                    let overlap = apply_substitution(&overlap, &substitution);
                    let root = apply_substitution(right_rule.rhs(), &substitution);
                    if overlap != root {
                        return false;
                    }
                }
            }
        }
    }
    true
}

#[cfg(test)]
mod rewriting_critical_pair_tests {
    use super::*;

    #[test]
    fn trivial_root_overlap_is_admissible_for_rewriting() {
        let zero = Term::app("0", vec![]);
        let rules = vec![
            RewriteRule::new(
                Term::app("min", vec![zero.clone(), Term::var("y")]),
                zero.clone(),
            ),
            RewriteRule::new(Term::app("min", vec![Term::var("x"), zero.clone()]), zero),
        ];
        assert!(usable_rules_have_only_trivial_critical_pairs(&rules));
    }

    #[test]
    fn nontrivial_root_overlap_remains_inadmissible_for_rewriting() {
        let zero = Term::app("0", vec![]);
        let one = Term::app("1", vec![]);
        let rules = vec![
            RewriteRule::new(
                Term::app("pick", vec![zero.clone(), Term::var("y")]),
                zero.clone(),
            ),
            RewriteRule::new(Term::app("pick", vec![Term::var("x"), zero]), one),
        ];
        assert!(!usable_rules_have_only_trivial_critical_pairs(&rules));
    }
}

pub(crate) fn term_is_linear(term: &Term) -> bool {
    let mut variables = BTreeSet::new();
    collect_linear_variables(term, &mut variables)
}

pub(crate) fn collect_linear_variables(term: &Term, variables: &mut BTreeSet<Variable>) -> bool {
    match term {
        Term::Var(variable) => variables.insert(variable.clone()),
        Term::App { args, .. } => args
            .iter()
            .all(|arg| collect_linear_variables(arg, variables)),
    }
}

pub(crate) fn contains_proper_subterm(term: &Term, needle: &Term) -> bool {
    let Term::App { args, .. } = term else {
        return false;
    };
    args.iter()
        .any(|arg| arg == needle || contains_proper_subterm(arg, needle))
}

pub(crate) fn match_term(
    pattern: &Term,
    term: &Term,
    substitution: &mut BTreeMap<Variable, Term>,
) -> bool {
    match (pattern, term) {
        (Term::Var(variable), term) => match substitution.get(variable) {
            Some(existing) => existing == term,
            None => {
                if matches!(term, Term::Var(other) if other == variable) {
                    return true;
                }
                substitution.insert(variable.clone(), term.clone());
                true
            }
        },
        (
            Term::App {
                symbol: left_symbol,
                args: left_args,
            },
            Term::App {
                symbol: right_symbol,
                args: right_args,
            },
        ) => {
            left_symbol == right_symbol
                && left_args.len() == right_args.len()
                && left_args
                    .iter()
                    .zip(right_args)
                    .all(|(left, right)| match_term(left, right, substitution))
        }
        (Term::App { .. }, Term::Var(_)) => false,
    }
}

pub(crate) fn narrowing_position_is_admissible(
    trs: &Trs,
    pair: &DependencyPair,
    position: &[usize],
    pairs: &[DependencyPair],
    q_lhss: &[Term],
) -> bool {
    let Some(redex) = subterm_at_position(pair.rhs(), position) else {
        return false;
    };
    // CeTA checks the successor-overlap side condition even when Q is empty:
    // then every term is Q-normal, so a unifiable estimated successor makes
    // this narrowing position inadmissible.  Search may still inspect such a
    // candidate heuristically, but it must never be emitted as narrowingProc.
    let used_variables = pair_variables(pair);
    for (other_index, other) in pairs.iter().enumerate() {
        if !ceta_q_iedg_edge(trs, pair, other, q_lhss, trs.rules()) {
            continue;
        }
        let other = freshen_pair_avoiding(other, other_index, &used_variables);
        let Some(lhs_subterm) = subterm_at_position(other.lhs(), position) else {
            return false;
        };
        let mut substitution = BTreeMap::new();
        if unify_terms(redex, lhs_subterm, &mut substitution)
            && term_is_q_normal(&apply_substitution(pair.lhs(), &substitution), q_lhss)
            && term_is_q_normal(&apply_substitution(other.lhs(), &substitution), q_lhss)
        {
            return false;
        }
    }
    true
}

pub(crate) fn narrowing_position_is_ceta_q_admissible(
    trs: &Trs,
    pair: &DependencyPair,
    position: &[usize],
    q_lhss: &[Term],
) -> bool {
    let Some(redex) = subterm_at_position(pair.rhs(), position) else {
        return false;
    };
    if !term_is_q_normal(redex, q_lhss) {
        return true;
    }
    let capped = ceta_icap_q(trs.rules(), q_lhss, &[pair.lhs().clone()], pair.rhs());
    subterm_at_position(&capped, position).is_some()
}

pub(crate) fn freshen_pair_avoiding(
    pair: &DependencyPair,
    pair_index: usize,
    used_variables: &BTreeSet<Variable>,
) -> DependencyPair {
    let mut attempt = 0;
    loop {
        let suffix = if attempt == 0 {
            format!("__dp{pair_index}")
        } else {
            format!("__dp{pair_index}_{attempt}")
        };
        let fresh = DependencyPair {
            lhs: freshen_term(pair.lhs(), &suffix),
            rhs: freshen_term(pair.rhs(), &suffix),
            source_rule: pair.source_rule,
        };
        if pair_variables(&fresh).is_disjoint(used_variables) {
            return fresh;
        }
        attempt += 1;
    }
}

pub(crate) fn narrow_pair_at_position(
    pair: &DependencyPair,
    position: &[usize],
    rules: &[RewriteRule],
    q_lhss: &[Term],
    max_narrowings: usize,
) -> Option<Vec<DependencyPair>> {
    let subterm = subterm_at_position(pair.rhs(), position)?;
    let mut positions = vec![position.to_vec()];
    positions.extend(non_root_positions(subterm).into_iter().map(|suffix| {
        let mut descendant = position.to_vec();
        descendant.extend(suffix);
        descendant
    }));
    let mut narrowings = Vec::new();
    for exact_position in positions {
        narrowings.extend(narrow_pair_at_exact_position(
            pair,
            &exact_position,
            rules,
            q_lhss,
        )?);
        if narrowings.len() > max_narrowings {
            return None;
        }
    }
    let narrowings = alpha_unique_pairs(narrowings);
    (narrowings.len() <= max_narrowings).then_some(narrowings)
}

pub(crate) fn narrow_pair_at_exact_position(
    pair: &DependencyPair,
    position: &[usize],
    rules: &[RewriteRule],
    q_lhss: &[Term],
) -> Option<Vec<DependencyPair>> {
    let redex = subterm_at_position(pair.rhs(), position)?;
    let mut narrowings = Vec::new();
    let used_variables = pair_variables(pair);
    for (rule_index, rule) in rules.iter().enumerate() {
        let fresh_rule = freshen_rule_avoiding(rule, rule_index, &used_variables);
        let mut substitution = BTreeMap::new();
        if unify_terms(redex, fresh_rule.lhs(), &mut substitution) {
            let lhs = apply_substitution(pair.lhs(), &substitution);
            let instantiated_rule_lhs = apply_substitution(fresh_rule.lhs(), &substitution);
            let rule_arguments_are_q_normal = match &instantiated_rule_lhs {
                Term::App { args, .. } => args
                    .iter()
                    .all(|argument| term_is_q_normal(argument, q_lhss)),
                Term::Var(_) => false,
            };
            // CeTA's qnarrows_impl retains only innermost overlaps: every
            // immediate argument of the instantiated rewrite-rule lhs and
            // the instantiated source of the dependency pair must be
            // Q-normal.  Previously Ferrum emitted the larger ordinary
            // narrowing set.  Those extra pairs were sound over-approximations
            // accepted by the checker, but could introduce artificial cycles
            // such as the forbidden root step g(h(0)) -> g(0) while h(0) is
            // still reducible.
            if !rule_arguments_are_q_normal || !term_is_q_normal(&lhs, q_lhss) {
                continue;
            }
            let rhs = replace_subterm_at_position(pair.rhs(), position, fresh_rule.rhs())?;
            let rhs = apply_substitution(&rhs, &substitution);
            let narrowed = DependencyPair {
                lhs,
                rhs,
                source_rule: pair.source_rule,
            };
            if !narrowings.contains(&narrowed) {
                narrowings.push(narrowed);
            }
        }
    }
    Some(narrowings)
}

pub(crate) fn pair_variables(pair: &DependencyPair) -> BTreeSet<Variable> {
    let mut variables = pair.lhs().variables();
    variables.extend(pair.rhs().variables());
    variables
}

pub(crate) fn alpha_unique_pairs(pairs: Vec<DependencyPair>) -> Vec<DependencyPair> {
    let mut unique = Vec::new();
    for pair in pairs {
        if !contains_alpha_equivalent_pair(&unique, &pair) {
            unique.push(pair);
        }
    }
    unique
}

pub(crate) fn alpha_unique_pairs_with_deadline(
    pairs: Vec<DependencyPair>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<DependencyPair>> {
    let mut unique = Vec::new();
    for pair in pairs {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        if !contains_alpha_equivalent_pair(&unique, &pair) {
            unique.push(pair);
        }
    }
    Some(unique)
}

pub(crate) fn contains_alpha_equivalent_pair(
    pairs: &[DependencyPair],
    candidate: &DependencyPair,
) -> bool {
    pairs
        .iter()
        .any(|pair| dependency_pairs_alpha_equivalent(pair, candidate))
}

pub(crate) fn dependency_pairs_alpha_equivalent(
    left: &DependencyPair,
    right: &DependencyPair,
) -> bool {
    left.source_rule == right.source_rule && dependency_pair_rules_alpha_equivalent(left, right)
}

/// Compare the actual dependency-pair rules while deliberately ignoring
/// Ferrum's internal source-rule provenance.  CPF DP witnesses do not encode
/// that provenance; exact replay must recover it from the matching live pair
/// instead of comparing against the witness's placeholder source index.
pub(crate) fn dependency_pair_rules_alpha_equivalent(
    left: &DependencyPair,
    right: &DependencyPair,
) -> bool {
    let mut left_variables = BTreeMap::new();
    let left_key = format!(
        "{}->{}",
        canonical_term_variable_key(left.lhs(), &mut left_variables),
        canonical_term_variable_key(left.rhs(), &mut left_variables),
    );
    let mut right_variables = BTreeMap::new();
    let right_key = format!(
        "{}->{}",
        canonical_term_variable_key(right.lhs(), &mut right_variables),
        canonical_term_variable_key(right.rhs(), &mut right_variables),
    );
    left_key == right_key
}

pub(crate) fn canonical_dependency_pair_key(pair: &DependencyPair) -> String {
    let mut variables = BTreeMap::new();
    format!(
        "{}:{}->{}",
        pair.source_rule,
        canonical_term_variable_key(pair.lhs(), &mut variables),
        canonical_term_variable_key(pair.rhs(), &mut variables)
    )
}

pub(crate) fn canonical_term_variable_key(
    term: &Term,
    variables: &mut BTreeMap<Variable, usize>,
) -> String {
    match term {
        Term::Var(variable) => {
            let next = variables.len();
            let index = *variables.entry(variable.clone()).or_insert(next);
            format!("v{index}")
        }
        Term::App { symbol, args } => {
            let rendered_args = args
                .iter()
                .map(|arg| canonical_term_variable_key(arg, variables))
                .collect::<Vec<_>>()
                .join(",");
            format!("{}({rendered_args})", symbol.as_str())
        }
    }
}

pub(crate) fn pair_contains_instantiation_auxiliary_variables(pair: &DependencyPair) -> bool {
    pair_variables(pair)
        .iter()
        .any(|variable| instantiation_auxiliary_variable(variable))
}

pub(crate) fn instantiation_auxiliary_variable(variable: &Variable) -> bool {
    let name = variable.as_str();
    name.starts_with("inst_") || name.starts_with("finst_") || name.starts_with("__cap")
}

pub(crate) fn non_root_positions(term: &Term) -> Vec<Vec<usize>> {
    let mut positions = Vec::new();
    collect_non_root_positions(term, &mut Vec::new(), &mut positions);
    positions
}

pub(crate) fn positions_with_subterms(term: &Term) -> Vec<(Vec<usize>, &Term)> {
    let mut positions = Vec::new();
    collect_positions_with_subterms(term, &mut Vec::new(), &mut positions);
    positions
}

pub(crate) fn collect_positions_with_subterms<'a>(
    term: &'a Term,
    current: &mut Vec<usize>,
    positions: &mut Vec<(Vec<usize>, &'a Term)>,
) {
    positions.push((current.clone(), term));
    if let Term::App { args, .. } = term {
        for (index, arg) in args.iter().enumerate() {
            current.push(index);
            collect_positions_with_subterms(arg, current, positions);
            current.pop();
        }
    }
}

pub(crate) fn collect_non_root_positions(
    term: &Term,
    current: &mut Vec<usize>,
    positions: &mut Vec<Vec<usize>>,
) {
    let Term::App { args, .. } = term else {
        return;
    };
    for (index, arg) in args.iter().enumerate() {
        current.push(index + 1);
        if matches!(arg, Term::App { .. }) {
            positions.push(current.clone());
            collect_non_root_positions(arg, current, positions);
        }
        current.pop();
    }
}

pub(crate) fn subterm_at_position<'a>(term: &'a Term, position: &[usize]) -> Option<&'a Term> {
    if position.is_empty() {
        return Some(term);
    }
    let Term::App { args, .. } = term else {
        return None;
    };
    let index = *position.first()? - 1;
    subterm_at_position(args.get(index)?, &position[1..])
}

pub(crate) fn replace_subterm_at_position(
    term: &Term,
    position: &[usize],
    replacement: &Term,
) -> Option<Term> {
    if position.is_empty() {
        return Some(replacement.clone());
    }
    let Term::App { symbol, args } = term else {
        return None;
    };
    let index = *position.first()? - 1;
    let mut replaced_args = args.clone();
    let child = replaced_args.get(index)?;
    replaced_args[index] = replace_subterm_at_position(child, &position[1..], replacement)?;
    Some(Term::App {
        symbol: symbol.clone(),
        args: replaced_args,
    })
}

pub(crate) fn freshen_rule_avoiding(
    rule: &RewriteRule,
    rule_index: usize,
    used_variables: &BTreeSet<Variable>,
) -> RewriteRule {
    let mut attempt = 0;
    loop {
        let suffix = if attempt == 0 {
            format!("__n{rule_index}")
        } else {
            format!("__n{rule_index}_{attempt}")
        };
        let fresh = RewriteRule::new(
            freshen_term(rule.lhs(), &suffix),
            freshen_term(rule.rhs(), &suffix),
        );
        let mut fresh_variables = fresh.lhs().variables();
        fresh_variables.extend(fresh.rhs().variables());
        if fresh_variables.is_disjoint(used_variables) {
            return fresh;
        }
        attempt += 1;
    }
}

pub(crate) fn freshen_term(term: &Term, suffix: &str) -> Term {
    match term {
        Term::Var(variable) => Term::Var(Variable::new(format!("{}{}", variable.as_str(), suffix))),
        Term::App { symbol, args } => Term::App {
            symbol: symbol.clone(),
            args: args.iter().map(|arg| freshen_term(arg, suffix)).collect(),
        },
    }
}

pub(crate) fn first_polynomial_reduction_summary(
    reductions: &[DpRemovalProof],
) -> (Option<PolynomialSummary>, Option<DpSearchBackend>) {
    reductions
        .iter()
        .find_map(|reduction| match &reduction.reduction_pair {
            DpReductionPairProof::Polynomial {
                interpretation,
                backend,
            }
            | DpReductionPairProof::RationalPolynomial {
                interpretation,
                backend,
                ..
            } => Some((Some(interpretation.clone()), Some(backend.clone()))),
            DpReductionPairProof::MaxPolynomial {
                interpretation,
                backend,
            } => Some((
                Some(
                    interpretation
                        .iter()
                        .map(|(symbol, alternatives)| {
                            let (constant, coefficients) =
                                alternatives.first().cloned().unwrap_or((0, Vec::new()));
                            (symbol.clone(), constant, coefficients)
                        })
                        .collect(),
                ),
                Some(backend.clone()),
            )),
            DpReductionPairProof::Matrix { .. }
            | DpReductionPairProof::IntegerMatrix { .. }
            | DpReductionPairProof::ArcticMatrix { .. }
            | DpReductionPairProof::NaturalPolynomial { .. }
            | DpReductionPairProof::WeightedPathOrderMax { .. }
            | DpReductionPairProof::RationalNaturalPolynomial { .. }
            | DpReductionPairProof::PathOrder { .. }
            | DpReductionPairProof::Kbo { .. } => None,
        })
        .unwrap_or((None, None))
}

pub(crate) fn topologically_order_components(
    components: Vec<Vec<usize>>,
    graph: &[Vec<usize>],
) -> Vec<Vec<usize>> {
    let mut component_of = BTreeMap::new();
    let component_min_vertex = components
        .iter()
        .map(|component| component.iter().copied().min().unwrap_or(usize::MAX))
        .collect::<Vec<_>>();
    for (component_index, component) in components.iter().enumerate() {
        for vertex in component {
            component_of.insert(*vertex, component_index);
        }
    }
    let mut outgoing = vec![BTreeSet::new(); components.len()];
    let mut indegree = vec![0usize; components.len()];
    for (from, successors) in graph.iter().enumerate() {
        let Some(&from_component) = component_of.get(&from) else {
            continue;
        };
        for successor in successors {
            let Some(&to_component) = component_of.get(successor) else {
                continue;
            };
            if from_component != to_component && outgoing[from_component].insert(to_component) {
                indegree[to_component] += 1;
            }
        }
    }
    let mut ready = indegree
        .iter()
        .enumerate()
        .filter_map(|(index, degree)| {
            (*degree == 0).then_some((component_min_vertex[index], index))
        })
        .collect::<BTreeSet<_>>();
    let mut order = Vec::new();
    while let Some((_, component)) = ready.pop_first() {
        order.push(component);
        for successor in &outgoing[component] {
            indegree[*successor] -= 1;
            if indegree[*successor] == 0 {
                ready.insert((component_min_vertex[*successor], *successor));
            }
        }
    }
    if order.len() != components.len() {
        return components;
    }
    order
        .into_iter()
        .map(|component| components[component].clone())
        .collect()
}

pub(crate) fn variable_occurrences(term: &Term, needle: &Variable) -> usize {
    match term {
        Term::Var(variable) => usize::from(variable == needle),
        Term::App { args, .. } => args
            .iter()
            .map(|arg| variable_occurrences(arg, needle))
            .sum(),
    }
}

pub(crate) fn term_root_is_defined(term: &Term, defined_symbols: &BTreeSet<Symbol>) -> bool {
    term.root_symbol().is_some_and(|symbol| {
        defined_symbols.contains(symbol)
            || symbol
                .as_str()
                .strip_suffix('#')
                .is_some_and(|unmarked| defined_symbols.contains(&Symbol::new(unmarked)))
    })
}

pub(crate) fn defined_rhs_subterms_are_ground_normal(
    term: &Term,
    defined_symbols: &BTreeSet<Symbol>,
    rules: &[RewriteRule],
) -> bool {
    match term {
        Term::Var(_) => true,
        Term::App { symbol, args } => {
            if defined_symbols.contains(symbol) {
                return term.variables().is_empty()
                    && rules
                        .iter()
                        .all(|rule| !unifies_with_rule_lhs(term, rule.lhs()))
                    && args.iter().all(|arg| {
                        defined_rhs_subterms_are_ground_normal(arg, defined_symbols, rules)
                    });
            }
            args.iter()
                .all(|arg| defined_rhs_subterms_are_ground_normal(arg, defined_symbols, rules))
        }
    }
}

pub(crate) fn defined_rhs_subterms_are_innermost_normal(
    term: &Term,
    source_lhs: &Term,
    defined_symbols: &BTreeSet<Symbol>,
    rules: &[RewriteRule],
) -> bool {
    match term {
        Term::Var(_) => true,
        Term::App { symbol, args } => {
            let defined = defined_symbols.contains(symbol);
            if defined
                && !contains_proper_subterm(source_lhs, term)
                && rules
                    .iter()
                    .any(|rule| unifies_with_rule_lhs(term, rule.lhs()))
            {
                return false;
            }
            args.iter().all(|arg| {
                defined_rhs_subterms_are_innermost_normal(arg, source_lhs, defined_symbols, rules)
            })
        }
    }
}

pub(crate) fn cap_defined_subterms(
    term: &Term,
    defined_symbols: &BTreeSet<Symbol>,
    is_root: bool,
    cap_index: &mut usize,
) -> Term {
    match term {
        Term::Var(_) => term.clone(),
        Term::App { symbol, args } => {
            let unmarked = symbol.as_str().strip_suffix('#').map(Symbol::new);
            let is_defined = defined_symbols.contains(symbol)
                || unmarked
                    .as_ref()
                    .is_some_and(|symbol| defined_symbols.contains(symbol));
            if !is_root && is_defined {
                let variable = Term::var(format!("__cap{cap_index}"));
                *cap_index += 1;
                return variable;
            }
            Term::app(
                symbol.as_str(),
                args.iter()
                    .map(|arg| cap_defined_subterms(arg, defined_symbols, false, cap_index))
                    .collect(),
            )
        }
    }
}

pub(crate) fn instantiation_skeleton_variants(
    skeleton: &Term,
    prefix: &str,
    strategy: RewriteStrategy,
) -> Vec<Term> {
    if strategy == RewriteStrategy::Innermost {
        return vec![skeleton.clone()];
    }
    let mut ren_index = 0usize;
    let renamed = rename_variable_occurrences(skeleton, prefix, &mut ren_index);
    if &renamed == skeleton {
        vec![skeleton.clone()]
    } else {
        vec![skeleton.clone(), renamed]
    }
}

pub(crate) fn rename_variable_occurrences(term: &Term, prefix: &str, index: &mut usize) -> Term {
    match term {
        Term::Var(_) => {
            let variable = Term::var(format!("{prefix}_{index}"));
            *index += 1;
            variable
        }
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| rename_variable_occurrences(arg, prefix, index))
                .collect(),
        ),
    }
}

pub(crate) fn standardize_variables_apart(term: &Term, prefix: &str) -> Term {
    match term {
        Term::Var(variable) => Term::var(format!("{prefix}_{}", variable.as_str())),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| standardize_variables_apart(arg, prefix))
                .collect(),
        ),
    }
}

pub(crate) fn unifies(lhs: &Term, rhs: &Term) -> bool {
    let mut substitution = BTreeMap::new();
    unify_terms(lhs, rhs, &mut substitution)
}

pub(crate) fn unifies_with_rule_lhs(term: &Term, rule_lhs: &Term) -> bool {
    unifies(
        &standardize_variables_apart(term, "term"),
        &standardize_variables_apart(rule_lhs, "rule"),
    )
}

pub(crate) fn unify_terms(
    lhs: &Term,
    rhs: &Term,
    substitution: &mut BTreeMap<Variable, Term>,
) -> bool {
    let lhs = apply_substitution(lhs, substitution);
    let rhs = apply_substitution(rhs, substitution);
    match (&lhs, &rhs) {
        (Term::Var(variable), term) => bind_unification_variable(variable, term, substitution),
        (term, Term::Var(variable)) => bind_unification_variable(variable, term, substitution),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            lhs_symbol == rhs_symbol
                && lhs_args.len() == rhs_args.len()
                && lhs_args
                    .iter()
                    .zip(rhs_args)
                    .all(|(left, right)| unify_terms(left, right, substitution))
        }
    }
}

pub(crate) fn bind_unification_variable(
    variable: &Variable,
    term: &Term,
    substitution: &mut BTreeMap<Variable, Term>,
) -> bool {
    if matches!(term, Term::Var(other) if other == variable) {
        return true;
    }
    if substitution_reaches_variable(term, variable, substitution) {
        return false;
    }
    substitution.insert(variable.clone(), term.clone());
    true
}

pub(crate) fn substitution_reaches_variable(
    term: &Term,
    variable: &Variable,
    substitution: &BTreeMap<Variable, Term>,
) -> bool {
    let mut seen = BTreeSet::new();
    substitution_reaches_variable_inner(term, variable, substitution, &mut seen)
}

pub(crate) fn substitution_reaches_variable_inner(
    term: &Term,
    variable: &Variable,
    substitution: &BTreeMap<Variable, Term>,
    seen: &mut BTreeSet<Variable>,
) -> bool {
    match term {
        Term::Var(term_variable) => {
            if term_variable == variable {
                return true;
            }
            if !seen.insert(term_variable.clone()) {
                return false;
            }
            substitution.get(term_variable).is_some_and(|term| {
                substitution_reaches_variable_inner(term, variable, substitution, seen)
            })
        }
        Term::App { args, .. } => args
            .iter()
            .any(|arg| substitution_reaches_variable_inner(arg, variable, substitution, seen)),
    }
}

pub(crate) fn apply_substitution(term: &Term, substitution: &BTreeMap<Variable, Term>) -> Term {
    let mut expanding = BTreeSet::new();
    apply_substitution_inner(term, substitution, &mut expanding)
}

pub(crate) fn apply_substitution_inner(
    term: &Term,
    substitution: &BTreeMap<Variable, Term>,
    expanding: &mut BTreeSet<Variable>,
) -> Term {
    match term {
        Term::Var(variable) => {
            let Some(replacement) = substitution.get(variable) else {
                return term.clone();
            };
            if !expanding.insert(variable.clone()) {
                return term.clone();
            }
            let result = apply_substitution_inner(replacement, substitution, expanding);
            expanding.remove(variable);
            result
        }
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| apply_substitution_inner(arg, substitution, expanding))
                .collect(),
        ),
    }
}
