use std::collections::BTreeMap;
use std::fmt;
use std::hash::Hash;
use std::time::Duration;

use crate::core::{RewriteRule, RewriteStrategy, Symbol, Term};
use crate::llm::{LlmClient, UtilityGuidanceLookup};

use super::KBO_SMT_SYMBOL_LIMIT;
use super::proof::{
    DpArgumentFilter, DpPathOrderKind, MaxPolynomialBounds, MaxPolynomialSummary,
    RationalPolynomialBounds, SemanticLabelingModel, SemanticLabelingModelWire,
    WeakPolynomialBounds,
};

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum DpStrategy {
    Processor(DpStrategyProcessor),
    Sequence(Vec<DpStrategy>),
    Pipeline(Vec<DpStrategy>),
    Choice(Vec<DpStrategy>),
    Parallel {
        cancel_on: DpParallelCancel,
        strategies: Vec<DpStrategy>,
    },
    Repeat {
        max_iterations: usize,
        strategy: Box<DpStrategy>,
    },
    Timeout {
        duration: Duration,
        strategy: Box<DpStrategy>,
    },
    Delay {
        duration: Duration,
        strategy: Box<DpStrategy>,
    },
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum DpParallelCancel {
    Proof,
    Progress,
}

impl DpStrategy {
    fn parallel(strategies: Vec<DpStrategy>) -> Self {
        Self::Parallel {
            cancel_on: DpParallelCancel::Proof,
            strategies,
        }
    }

    pub fn with_timeout_multiplier(&self, multiplier: f64) -> Self {
        match self {
            Self::Processor(processor) => Self::Processor(processor.clone()),
            Self::Sequence(strategies) => Self::Sequence(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Pipeline(strategies) => Self::Pipeline(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Choice(strategies) => Self::Choice(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Parallel {
                cancel_on,
                strategies,
            } => Self::Parallel {
                cancel_on: *cancel_on,
                strategies: strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            },
            Self::Repeat {
                max_iterations,
                strategy,
            } => Self::Repeat {
                max_iterations: *max_iterations,
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
            Self::Timeout { duration, strategy } => Self::Timeout {
                duration: scale_strategy_duration(*duration, multiplier),
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
            Self::Delay { duration, strategy } => Self::Delay {
                duration: *duration,
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
        }
    }
}

fn scale_strategy_duration(duration: Duration, multiplier: f64) -> Duration {
    if multiplier == 1.0 {
        return duration;
    }
    let scaled = duration.as_secs_f64() * multiplier;
    if duration.is_zero() || scaled <= 0.0 {
        return Duration::ZERO;
    }
    Duration::from_secs_f64(scaled.max(0.001))
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum DpStrategyProcessor {
    ConditionalPolynomial { max_coefficient: i64, degree: usize, before: usize, after: usize, squares: bool, reinduct: usize, induction: usize },
    DependencyGraph,
    RefinedDependencyGraph,
    ExactDependencyGraph {
        components: Vec<(Vec<usize>, bool)>,
        source_dp_input_xml: Option<String>,
        /// The oracle lookup matched the carried source against this exact
        /// live state. This runtime-only bit is deliberately omitted from the
        /// stable strategy atom.
        source_is_live: bool,
    },
    ExactGeneralRedPair {
        payload_xml: String,
        strict_indices: Vec<usize>,
        bound_indices: Vec<usize>,
        merge: bool,
        source_dp_input_xml: Option<String>,
    },
    ExactReductionPair {
        processor_tag: String,
        payload_xml: String,
        removed_indices: Vec<usize>,
        source_pairs_xml: Option<String>,
        source_rules_xml: Option<String>,
        source_weak_pairs_xml: Option<String>,
        source_strict_rules_xml: Option<String>,
    },
    ExactUsableRules {
        payload_xml: String,
        source_pairs_xml: Option<String>,
        source_rules_xml: Option<String>,
    },
    ExactInnermostLhss {
        payload_xml: String,
        source_dp_input_xml: Option<String>,
    },
    ExactDpTransformation {
        processor_tag: String,
        payload_xml: String,
        dp_input_xml: String,
        source_dp_input_xml: Option<String>,
    },
    ExactTerminationProof {
        source_dp_input_xml: String,
        dp_proof_xml: String,
    },
    ExactNonterminationRuleRemoval {
        source_dp_input_xml: String,
        residual_dp_input_xml: String,
    },
    SwitchFullNontermination,
    NonterminationUsableRules,
    NonterminationCycle { candidate: usize, min_length: usize, max_length: usize, repeated: bool },
    NonterminationNarrowing { candidate: usize, lookahead: bool, all: bool, below: bool },
    NonterminationInnermostLhss,
    /// Search for a checked terminal loop witness on the current DP state.
    /// This is distinct from the top-level `nontermination(dp-loop)` wrapper:
    /// oracle guidance may reach this processor only after several DP
    /// transformations and must be able to close that residual directly.
    NonterminationLoop,
    /// Search for a checked terminal non-loop witness on the current DP
    /// state.  This is a DP worklist atom (rather than a top-level alias), so
    /// certified nontermination chains can continue after transformations.
    NonterminationNonLoop,
    NonterminationSymbolicLoop,
    NonterminationBackwardLoop,
    NonterminationForkLoop,
    NonterminationFairLoop,
    NonterminationInstance { candidate: usize, constants: bool, all: bool },
    NonterminationRuleFilter { max_lhs: usize, max_rhs: usize, collapsing: bool },
    /// A complete CPF loop fragment bound to the exact DP obligation from a
    /// checker-certified source proof. Unlike `nontermination(dp-loop)`,
    /// replay does not depend on rediscovering the witness under a deadline.
    ExactNonterminationLoop {
        source_dp_input_xml: String,
        loop_xml: String,
    },
    /// A complete DP-nontermination proof for one exact residual.  This is
    /// useful when the certified proof has already lifted a concrete loop
    /// through instantiation processors and therefore cannot be represented
    /// by a terminal loop fragment alone.
    ExactNonterminationProof {
        source_dp_input_xml: String,
        dp_proof_xml: String,
    },
    /// A complete CPF non-loop fragment, bound to the exact DP obligation
    /// from the certified source proof.  CeTA remains the authority for the
    /// (potentially large) pattern proof; Ferrum checks that it is being
    /// placed only at the matching live residual.
    ExactNonterminationNonLoop {
        source_dp_input_xml: String,
        non_loop_xml: String,
    },
    ExactSplit {
        selected_pair_index: Option<usize>,
        selected_rule_index: Option<usize>,
        source_dp_input_xml: String,
    },
    UsableRules,
    MutermExpand,
    InnermostLhss,
    Split,
    /// One explicitly selected split alternative. `candidate_index` indexes
    /// the live strong pairs followed by the active ordinary rules.
    SelectedSplit {
        candidate_index: usize,
    },
    SwitchInnermost,
    QdpToSrs,
    SwitchToTrs,
    Subterm,
    ExactSubterm {
        projection: Vec<(String, usize, usize)>,
    },
    SizeChange,
    /// Replay exact syntactic size-change graphs. Each tuple identifies the
    /// live pair by index and lists its one-based left position, strictness,
    /// and one-based right position.
    ExactSizeChange {
        graphs: Vec<(usize, Vec<(usize, bool, usize)>)>,
    },
    Llm,
    SymbolWeights {
        max_weight: i64,
    },
    LinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    SelectedLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        candidate_index: usize,
    },
    TargetLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        strict_pair_indices: Vec<usize>,
    },
    MinimumDeletionLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        min_delete: usize,
        residual_budget: usize,
    },
    /// A retained, independently validated linear polynomial witness.
    ///
    /// Unlike bounded synthesis this identifies one processor result exactly,
    /// so applying oracle guidance reaches the same residual DP state as the
    /// certified source proof.  The witness is never trusted: the ordinary
    /// reduction-pair checker below validates every weak and strict obligation
    /// before constructing a proof node.
    ExactLinearPolynomial {
        interpretation: Vec<(String, i64, Vec<i64>)>,
    },
    /// An exact monotonic polynomial witness which also deletes every
    /// strictly oriented rewrite rule.  This is a distinct processor result
    /// from `ExactLinearPolynomial`: its residual R component is smaller.
    ExactMonotonicPolynomial {
        interpretation: Vec<(String, i64, Vec<i64>)>,
    },
    /// A retained CPF natural-polynomial witness with possibly negative
    /// constants.  The live DP and usable-rule obligations are rechecked with
    /// CeTA's affine Pleft/Pright criterion before any pair is deleted.
    ExactWeakPolynomial {
        interpretation: Vec<(String, i64, Vec<i64>)>,
    },
    /// A retained max-polynomial witness, rechecked against every live pair
    /// and usable rule before constructing a reduction-pair proof.
    ExactMaxPolynomial {
        interpretation: MaxPolynomialSummary,
    },
    /// A retained WPO(Max) witness. Every live weak and strict obligation is
    /// rechecked before the residual state is constructed.
    ExactWeightedPathOrderMax {
        witness: super::DpWpoMaxWitness,
    },
    /// A retained rational linear-polynomial witness.  Coefficients and
    /// constants are numerators over the positive shared denominator.
    ExactRationalPolynomial {
        denominator: i64,
        interpretation: Vec<(String, i64, Vec<i64>)>,
    },
    /// A retained rational degree-two natural-polynomial witness.  All
    /// entries are integer numerators over `denominator`; `delta` is the
    /// positive strict-gap numerator.  The live processor independently
    /// rechecks the complete DP and weak-rule obligations.
    ExactRationalNaturalPolynomial {
        denominator: i64,
        delta: i64,
        interpretation: Vec<(String, i64, Vec<i64>, Vec<Vec<i64>>)>,
    },
    /// A retained natural matrix interpretation, independently rechecked on
    /// the live DP state before deleting any pairs or usable rules.
    ExactMatrixInterpretation {
        interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>,
    },
    /// A retained Arctic matrix interpretation. `i64::MIN` represents the
    /// Arctic minus-infinity element; the domain and every orientation are
    /// independently checked on the live DP state.
    ExactArcticMatrixInterpretation {
        integer_domain: bool,
        interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>,
    },
    MonotonicPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    SatPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    WeakPolynomial {
        min_constant: i64,
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    TargetWeakPolynomial {
        min_constant: i64,
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        strict_pair_indices: Vec<usize>,
    },
    MaxPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        alternatives: usize,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    /// Joint max algebra, collapsing filter, precedence and partial lex status synthesis.
    WeightedPathOrderMax {
        max_constant: i64,
        max_coefficient: i64,
        alternatives: usize,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        all_strict: bool,
        permutations: bool,
        compact_ground: bool,
        ordered_alternatives: bool,
    },
    RationalPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        denominator: i64,
        delta_denominator: i64,
    },
    /// Direct degree-two search without first spending the deadline on affine models.
    RationalQuadraticPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        denominator: i64,
        delta_denominator: i64,
        solver: Option<String>,
        coefficient_values: Vec<i64>,
        max_quadratic_terms: Option<usize>,
        quadratic_shape: String,
    },
    TargetRationalPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        denominator: i64,
        delta_denominator: i64,
        min_delete: usize,
        residual_budget: usize,
    },
    SmtPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    QuadraticPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    MatrixInterpretation {
        dimension: usize,
        max_constant: i64,
        max_coefficient: i64,
        min_nonzero: Option<usize>,
        max_nonzero: Option<usize>,
        max_nonzero_constants: Option<usize>,
        max_nonzero_per_row: Option<usize>,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    SelectedMatrixInterpretation {
        dimension: usize,
        max_constant: i64,
        max_coefficient: i64,
        min_nonzero: Option<usize>,
        max_nonzero: Option<usize>,
        max_nonzero_constants: Option<usize>,
        max_nonzero_per_row: Option<usize>,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        candidate_index: usize,
    },
    IntegerMatrixInterpretation {
        dimension: usize,
        min_value: i64,
        max_value: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    ArcticMatrixInterpretation {
        threshold: bool,
        shared: bool,
        dimension: usize,
        max_constant: i64,
        max_coefficient: i64,
        max_nonzero: Option<usize>,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    SelectedArcticMatrixInterpretation {
        threshold: bool,
        shared: bool,
        dimension: usize,
        max_constant: i64,
        max_coefficient: i64,
        max_nonzero: Option<usize>,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        candidate_index: usize,
    },
    TargetArcticMatrixInterpretation {
        threshold: bool,
        shared: bool,
        symmetry: bool,
        solver: Option<String>,
        dimension: usize,
        max_constant: i64,
        max_coefficient: i64,
        max_nonzero: Option<usize>,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        strict_pair_indices: Option<Vec<usize>>,
    },
    QuasiPeriodic { period: usize, max_weight: i64 },
    QuasiPeriodicBv { period: usize, max_weight: i64 },
    IntegerArcticMatrixInterpretation {
        threshold: bool,
        all_strict: bool,
        max_finite_per_row: Option<usize>,
        bitvectors: bool,
        root_projection: bool,
        optimize: bool,
        symmetry: bool,
        solver: Option<String>,
        dimension: usize,
        min_value: i64,
        max_value: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    SelectedIntegerArcticMatrixInterpretation {
        threshold: bool,
        all_strict: bool,
        max_finite_per_row: Option<usize>,
        bitvectors: bool,
        root_projection: bool,
        optimize: bool,
        symmetry: bool,
        solver: Option<String>,
        dimension: usize,
        min_value: i64,
        max_value: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        candidate_index: usize,
    },
    ApplicativeReductionPair,
    PathOrder,
    ConfiguredPathOrder { order: DpPathOrderKind, optimize: bool },
    Gm04AdministrativeRpo,
    ComplexConstantRemoval,
    LargestComplexConstantRemoval,
    SelectedPathOrder {
        candidate_index: usize,
    },
    TargetPathOrder {
        strict_pair_indices: Vec<usize>,
    },
    /// A retained RPO/LPO witness.  It is accepted only after the live
    /// pairs, usable rules, Q context, and every weak/strict comparison have
    /// been checked again.
    ExactPathOrder {
        default_order: DpPathOrderKind,
        statuses: BTreeMap<String, DpPathOrderKind>,
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        argument_filter: DpArgumentFilter,
    },
    Kbo {
        max_weight: i64,
        max_symbols: usize,
    },
    Rewriting {
        max_per_pair: Option<usize>,
    },
    SelectedRewriting {
        max_per_pair: Option<usize>,
        candidate_index: usize,
    },
    Narrowing {
        max_per_pair: Option<usize>,
    },
    SelectedNarrowing {
        max_per_pair: Option<usize>,
        candidate_index: usize,
    },
    AlphaMerge,
    /// Discharge the GM04 top-pair component through an independently solved CSR child.
    Gm04SourceCsr,
    Instantiation {
        max_per_pair: Option<usize>,
    },
    SelectedInstantiation {
        max_per_pair: Option<usize>,
        candidate_index: usize,
    },
    ForwardInstantiation {
        max_per_pair: Option<usize>,
    },
    SelectedForwardInstantiation {
        max_per_pair: Option<usize>,
        candidate_index: usize,
    },
    SemanticLabeling,
    RootLabeling,
    /// A retained finite model for a deterministic semantic-labeling step.
    /// The live model condition and every generated rule/pair are still
    /// checked before this processor may expose its residual obligation.
    ExactSemanticLabeling {
        model: SemanticLabelingModel,
        source_dp_input_xml: Option<String>,
        expected_child_dp_input_xml: Option<String>,
    },
    UncurryBelow,
    Uncurry,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpStrategyParseError {
    message: String,
}

impl fmt::Display for DpStrategyParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for DpStrategyParseError {}

impl DpStrategy {
    pub fn parse(input: &str) -> Result<Self, DpStrategyParseError> {
        DpStrategyParser::new(input).parse()
    }

    /// Serialize this strategy into the public parser language.
    ///
    /// Processor-event evidence must retain the complete continuation that
    /// actually closed a DP problem.  Rust's `Debug` representation is not an
    /// executable strategy and previously caused parameterized `dp(...)`
    /// evidence to be normalized to a non-self-contained bare `dp` atom.
    pub fn to_strategy_atom(&self) -> String {
        match self {
            Self::Processor(processor) => processor.to_strategy_atom(),
            Self::Sequence(strategies) => strategies
                .iter()
                .map(|strategy| {
                    let atom = strategy.to_strategy_atom();
                    if matches!(strategy, Self::Choice(_)) {
                        format!("({atom})")
                    } else {
                        atom
                    }
                })
                .collect::<Vec<_>>()
                .join("; "),
            Self::Pipeline(strategies) => format!(
                "pipeline({})",
                strategies
                    .iter()
                    .map(Self::to_strategy_atom)
                    .collect::<Vec<_>>()
                    .join("; ")
            ),
            Self::Choice(strategies) => strategies
                .iter()
                .map(|strategy| format!("({})", strategy.to_strategy_atom()))
                .collect::<Vec<_>>()
                .join(" | "),
            Self::Parallel {
                cancel_on,
                strategies,
            } => {
                let name = match cancel_on {
                    DpParallelCancel::Proof => "parallel".to_string(),
                    DpParallelCancel::Progress => "parallel(cancel=progress".to_string(),
                };
                let body = strategies
                    .iter()
                    .map(|strategy| format!("({})", strategy.to_strategy_atom()))
                    .collect::<Vec<_>>()
                    .join(" | ");
                match cancel_on {
                    DpParallelCancel::Proof => format!("{name}({body})"),
                    DpParallelCancel::Progress => format!("{name}, {body})"),
                }
            }
            Self::Repeat {
                max_iterations,
                strategy,
            } => format!("repeat({max_iterations}, {})", strategy.to_strategy_atom()),
            Self::Timeout { duration, strategy } => format!(
                "timeout({}ms, {})",
                duration.as_millis(),
                strategy.to_strategy_atom()
            ),
            Self::Delay { duration, strategy } => format!(
                "delay({}ms, {})",
                duration.as_millis(),
                strategy.to_strategy_atom()
            ),
        }
    }

    pub fn default_for(strategy: RewriteStrategy) -> Self {
        match strategy {
            RewriteStrategy::Full => Self::standard(),
            RewriteStrategy::Innermost => Self::innermost(),
            RewriteStrategy::Outermost => Self::Choice(Vec::new()),
        }
    }

    fn standard() -> Self {
        Self::Sequence(vec![
            Self::Processor(DpStrategyProcessor::DependencyGraph),
            Self::Processor(DpStrategyProcessor::UsableRules),
            Self::Processor(DpStrategyProcessor::InnermostLhss),
            Self::Processor(DpStrategyProcessor::QdpToSrs),
            // Factor the FROCOS-style A route into existing certified CPF
            // processors: applicative-top uncurrying, ordinary uncurrying,
            // a usable-rules reduction pair (which removes the generated U
            // rules from the live obligation), and DP-to-relative-TRS. The
            // resulting unary child is closed by the top-level relative
            // match-bound portfolio.
            Self::Pipeline(vec![
                Self::Processor(DpStrategyProcessor::Uncurry),
                Self::Processor(DpStrategyProcessor::UncurryBelow),
                Self::Processor(DpStrategyProcessor::MonotonicPolynomial {
                    max_constant: 1,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                }),
                Self::Processor(DpStrategyProcessor::SwitchToTrs),
            ]),
            Self::Timeout {
                duration: Duration::from_millis(250),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::Llm)),
            },
            Self::fast_component_portfolio(),
            Self::fast_transform_portfolio(RewriteStrategy::Full),
            Self::default_refinement_ladder(RewriteStrategy::Full),
        ])
    }

    fn innermost() -> Self {
        Self::Sequence(vec![
            Self::Pipeline(vec![
                Self::Processor(DpStrategyProcessor::UsableRules),
                Self::Processor(DpStrategyProcessor::InnermostLhss),
                Self::Processor(DpStrategyProcessor::QdpToSrs),
            ]),
            Self::Processor(DpStrategyProcessor::DependencyGraph),
            Self::Processor(DpStrategyProcessor::UsableRules),
            Self::Processor(DpStrategyProcessor::InnermostLhss),
            Self::Processor(DpStrategyProcessor::QdpToSrs),
            Self::fast_innermost_rewriting(),
            Self::fast_innermost_instantiation(),
            Self::Timeout {
                duration: Duration::from_secs(5),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::Narrowing {
                    max_per_pair: Some(1),
                })),
            },
            Self::fast_component_portfolio(),
            Self::Timeout {
                duration: Duration::from_secs(10),
                strategy: Box::new(Self::parallel(vec![
                    Self::rational_polynomial_order(),
                    Self::Timeout {
                        duration: Duration::from_millis(750),
                        strategy: Box::new(Self::Processor(DpStrategyProcessor::SizeChange)),
                    },
                ])),
            },
            Self::fast_transform_portfolio(RewriteStrategy::Innermost),
            Self::default_refinement_ladder(RewriteStrategy::Innermost),
            Self::Timeout {
                duration: Duration::from_millis(250),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::Llm)),
            },
        ])
    }

    pub(super) fn default_refinement_ladder(strategy: RewriteStrategy) -> Self {
        Self::default_refinement_ladder_with_semantic_labeling(strategy, true)
    }

    fn fast_innermost_instantiation() -> Self {
        Self::Sequence(vec![
            Self::Timeout {
                duration: Duration::from_secs(10),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::ForwardInstantiation {
                    max_per_pair: Some(1),
                })),
            },
            Self::Timeout {
                duration: Duration::from_millis(250),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::Instantiation {
                    max_per_pair: Some(1),
                })),
            },
        ])
    }

    fn fast_innermost_rewriting() -> Self {
        Self::Timeout {
            duration: Duration::from_millis(250),
            strategy: Box::new(Self::Processor(DpStrategyProcessor::Rewriting {
                max_per_pair: Some(1),
            })),
        }
    }

    fn default_refinement_ladder_with_semantic_labeling(
        strategy: RewriteStrategy,
        include_semantic_labeling: bool,
    ) -> Self {
        let mut stages = vec![
            Self::default_component_portfolio(),
            Self::Timeout {
                duration: Duration::from_secs(10),
                strategy: Box::new(Self::parallel(vec![
                    Self::rational_polynomial_order(),
                    Self::Timeout {
                        duration: Duration::from_secs(2),
                        strategy: Box::new(Self::Processor(DpStrategyProcessor::SizeChange)),
                    },
                ])),
            },
            Self::default_transform_portfolio(strategy),
        ];
        stages.push(Self::Timeout {
            duration: Duration::from_secs(20),
            strategy: Box::new(Self::Processor(DpStrategyProcessor::Narrowing {
                max_per_pair: None,
            })),
        });
        if include_semantic_labeling {
            stages.push(Self::Processor(DpStrategyProcessor::DependencyGraph));
            stages.push(Self::default_component_portfolio());
            stages.push(Self::Timeout {
                duration: Duration::from_secs(3),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::SemanticLabeling)),
            });
        }
        stages.push(Self::default_component_portfolio());
        Self::Sequence(stages)
    }

    fn fast_component_portfolio() -> Self {
        Self::Sequence(vec![
            Self::Processor(DpStrategyProcessor::DependencyGraph),
            Self::Processor(DpStrategyProcessor::UsableRules),
            Self::Processor(DpStrategyProcessor::InnermostLhss),
            Self::Timeout {
                duration: Duration::from_secs(2),
                strategy: Box::new(Self::parallel(vec![
                    Self::Timeout {
                        duration: Duration::from_millis(100),
                        strategy: Box::new(Self::Processor(DpStrategyProcessor::Subterm)),
                    },
                    Self::Timeout {
                        duration: Duration::from_millis(500),
                        strategy: Box::new(Self::Processor(DpStrategyProcessor::SizeChange)),
                    },
                    Self::default_order_portfolio(),
                ])),
            },
        ])
    }

    fn fast_transform_portfolio(strategy: RewriteStrategy) -> Self {
        let mut branches = vec![
            Self::default_order_portfolio(),
            Self::Sequence(vec![
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::Narrowing {
                        max_per_pair: None,
                    })),
                },
                Self::fast_component_portfolio(),
            ]),
            Self::Sequence(vec![
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::Instantiation {
                        max_per_pair: None,
                    })),
                },
                Self::fast_component_portfolio(),
            ]),
        ];
        if strategy == RewriteStrategy::Innermost {
            branches.push(Self::Sequence(vec![
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::Rewriting {
                        max_per_pair: None,
                    })),
                },
                Self::fast_component_portfolio(),
            ]));
            branches.push(Self::Sequence(vec![
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(
                        DpStrategyProcessor::ForwardInstantiation { max_per_pair: None },
                    )),
                },
                Self::fast_component_portfolio(),
            ]));
        }
        Self::Timeout {
            duration: Duration::from_secs(2),
            strategy: Box::new(Self::parallel(branches)),
        }
    }

    fn default_component_portfolio() -> Self {
        Self::Sequence(vec![
            Self::Processor(DpStrategyProcessor::DependencyGraph),
            Self::Timeout {
                duration: Duration::from_secs(3),
                strategy: Box::new(Self::parallel(vec![
                    Self::Timeout {
                        duration: Duration::from_millis(150),
                        strategy: Box::new(Self::Processor(DpStrategyProcessor::Subterm)),
                    },
                    Self::Timeout {
                        duration: Duration::from_secs(2),
                        strategy: Box::new(Self::Processor(DpStrategyProcessor::SizeChange)),
                    },
                    Self::default_order_portfolio(),
                ])),
            },
        ])
    }

    fn default_transform_portfolio(strategy: RewriteStrategy) -> Self {
        let mut branches = vec![Self::default_order_portfolio()];
        branches.push(Self::Sequence(vec![
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::Narrowing {
                    max_per_pair: None,
                })),
            },
            Self::default_component_portfolio(),
        ]));
        branches.push(Self::Sequence(vec![
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::Instantiation {
                    max_per_pair: None,
                })),
            },
            Self::default_component_portfolio(),
        ]));
        if strategy == RewriteStrategy::Innermost {
            branches.push(Self::Sequence(vec![
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::Rewriting {
                        max_per_pair: None,
                    })),
                },
                Self::default_component_portfolio(),
            ]));
        }
        branches.push(Self::Sequence(vec![
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(DpStrategyProcessor::ForwardInstantiation {
                    max_per_pair: None,
                })),
            },
            Self::default_component_portfolio(),
        ]));
        Self::Timeout {
            duration: Duration::from_secs(4),
            strategy: Box::new(Self::parallel(branches)),
        }
    }

    fn default_order_portfolio() -> Self {
        Self::Timeout {
            duration: Duration::from_secs(2),
            strategy: Box::new(Self::parallel(vec![
                Self::Timeout {
                    duration: Duration::from_millis(250),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::SymbolWeights {
                        max_weight: 1,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_millis(500),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::LinearPolynomial {
                        max_constant: 1,
                        max_coefficient: 1,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_millis(750),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::LinearPolynomial {
                        max_constant: 2,
                        max_coefficient: 1,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::PathOrder)),
                },
                Self::Timeout {
                    duration: Duration::from_secs(1),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::Kbo {
                        max_weight: 2,
                        max_symbols: KBO_SMT_SYMBOL_LIMIT,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_secs(2),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::LinearPolynomial {
                        max_constant: 2,
                        max_coefficient: 2,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_secs(2),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::WeakPolynomial {
                        min_constant: -2,
                        max_constant: 2,
                        max_coefficient: 2,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_secs(2),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::MaxPolynomial {
                        max_constant: 2,
                        max_coefficient: 1,
                        alternatives: 2,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_secs(2),
                    strategy: Box::new(Self::Processor(
                        DpStrategyProcessor::MatrixInterpretation {
                            dimension: 1,
                            max_constant: 2,
                            max_coefficient: 1,
                            min_nonzero: None,
                            max_nonzero: None,
                            max_nonzero_constants: None,
                            max_nonzero_per_row: None,
                            max_symbols: None,
                            max_arity: None,
                        },
                    )),
                },
                Self::Timeout {
                    duration: Duration::from_secs(2),
                    strategy: Box::new(Self::Processor(
                        DpStrategyProcessor::MatrixInterpretation {
                            dimension: 2,
                            max_constant: 2,
                            max_coefficient: 1,
                            min_nonzero: None,
                            max_nonzero: None,
                            max_nonzero_constants: None,
                            max_nonzero_per_row: None,
                            max_symbols: None,
                            max_arity: None,
                        },
                    )),
                },
                Self::Timeout {
                    duration: Duration::from_secs(2),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::SmtPolynomial {
                        max_constant: 2,
                        max_coefficient: 1,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
                Self::Timeout {
                    duration: Duration::from_secs(3),
                    strategy: Box::new(Self::Processor(DpStrategyProcessor::QuadraticPolynomial {
                        max_constant: 2,
                        max_coefficient: 1,
                        max_symbols: None,
                        max_arity: None,
                    })),
                },
            ])),
        }
    }

    fn rational_polynomial_order() -> Self {
        Self::Timeout {
            duration: Duration::from_secs(20),
            strategy: Box::new(Self::Processor(DpStrategyProcessor::RationalPolynomial {
                max_constant: 16,
                max_coefficient: 16,
                max_symbols: None,
                max_arity: None,
                denominator: 4,
                delta_denominator: 16,
            })),
        }
    }

    pub(super) fn standard_orders() -> Self {
        Self::Sequence(vec![
            Self::Processor(DpStrategyProcessor::Llm),
            Self::Processor(DpStrategyProcessor::SymbolWeights { max_weight: 1 }),
            Self::Processor(DpStrategyProcessor::LinearPolynomial {
                max_constant: 1,
                max_coefficient: 1,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::PathOrder),
            Self::Processor(DpStrategyProcessor::Kbo {
                max_weight: 2,
                max_symbols: KBO_SMT_SYMBOL_LIMIT,
            }),
            Self::Processor(DpStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::WeakPolynomial {
                min_constant: -2,
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::MaxPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                alternatives: 2,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::MatrixInterpretation {
                dimension: 1,
                max_constant: 2,
                max_coefficient: 1,
                min_nonzero: None,
                max_nonzero: None,
                max_nonzero_constants: None,
                max_nonzero_per_row: None,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::MatrixInterpretation {
                dimension: 2,
                max_constant: 2,
                max_coefficient: 1,
                min_nonzero: None,
                max_nonzero: None,
                max_nonzero_constants: None,
                max_nonzero_per_row: None,
                max_symbols: None,
                max_arity: None,
            }),
            Self::Processor(DpStrategyProcessor::SmtPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: None,
                max_arity: None,
            }),
            Self::rational_polynomial_order(),
        ])
    }
}

impl DpStrategyProcessor {
    pub(crate) fn to_strategy_atom(&self) -> String {
        fn bounded_polynomial_atom(
            name: &str,
            max_constant: i64,
            max_coefficient: i64,
            max_symbols: Option<usize>,
            max_arity: Option<usize>,
        ) -> String {
            let mut args = vec![
                format!("max-constant={max_constant}"),
                format!("max-coefficient={max_coefficient}"),
            ];
            if let Some(value) = max_symbols {
                args.push(format!("max-symbols={value}"));
            }
            if let Some(value) = max_arity {
                args.push(format!("max-arity={value}"));
            }
            format!("{name}({})", args.join(","))
        }

        fn transform_atom(name: &str, max_per_pair: Option<usize>) -> String {
            match max_per_pair {
                Some(value) => format!("{name}(per-pair={value})"),
                None => name.to_owned(),
            }
        }

        fn selected_transform_atom(
            name: &str,
            max_per_pair: Option<usize>,
            candidate_index: usize,
        ) -> String {
            let mut args = vec![format!("candidate={candidate_index}")];
            if let Some(value) = max_per_pair {
                args.push(format!("per-pair={value}"));
            }
            format!("{name}({})", args.join(","))
        }

        match self {
            Self::ConditionalPolynomial { max_coefficient, degree, before, after, squares, reinduct, induction } => {
                let mut args = format!("max-coefficient={max_coefficient}");
                if *degree != 1 { args.push_str(&format!(",degree={degree}")); }
                if *before != 1 { args.push_str(&format!(",before={before}")); }
                if *after != 0 { args.push_str(&format!(",after={after}")); }
                if *squares { args.push_str(",squares=1"); }
                if *reinduct != 0 { args.push_str(&format!(",reinduct={reinduct}")); }
                if *induction != 0 { args.push_str(&format!(",induction={induction}")); }
                format!("conditional-poly({args})")
            },
            Self::DependencyGraph => "graph".to_owned(),
            Self::RefinedDependencyGraph => "graph-refined".to_owned(),
            Self::ExactDependencyGraph {
                components,
                source_dp_input_xml,
                ..
            } => {
                let encoded = if let Some(source) = source_dp_input_xml {
                    serde_json::to_vec(&(source, components))
                } else {
                    serde_json::to_vec(components)
                }
                .expect("dependency-graph witnesses are JSON serializable")
                .into_iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>();
                format!("exact-graph(hex={encoded})")
            }
            Self::ExactGeneralRedPair {
                payload_xml,
                strict_indices,
                bound_indices,
                merge,
                source_dp_input_xml,
            } => {
                let bytes = if let Some(source) = source_dp_input_xml {
                    serde_json::to_vec(&(payload_xml, strict_indices, bound_indices, merge, source))
                } else {
                    serde_json::to_vec(&(payload_xml, strict_indices, bound_indices, merge))
                };
                let encoded = bytes
                    .expect("general reduction-pair witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-general-red-pair(hex={encoded})")
            }
            Self::ExactReductionPair {
                processor_tag,
                payload_xml,
                removed_indices,
                source_pairs_xml,
                source_rules_xml,
                source_weak_pairs_xml,
                source_strict_rules_xml,
            } => {
                let encoded = if let (
                    Some(source_pairs_xml),
                    Some(source_rules_xml),
                    Some(source_weak_pairs_xml),
                    Some(source_strict_rules_xml),
                ) = (
                    source_pairs_xml,
                    source_rules_xml,
                    source_weak_pairs_xml,
                    source_strict_rules_xml,
                ) {
                    serde_json::to_vec(&(
                        processor_tag,
                        payload_xml,
                        removed_indices,
                        source_pairs_xml,
                        source_rules_xml,
                        source_weak_pairs_xml,
                        source_strict_rules_xml,
                    ))
                } else if let (Some(source_pairs_xml), Some(source_rules_xml)) =
                    (source_pairs_xml, source_rules_xml)
                {
                    serde_json::to_vec(&(
                        processor_tag,
                        payload_xml,
                        removed_indices,
                        source_pairs_xml,
                        source_rules_xml,
                    ))
                } else {
                    serde_json::to_vec(&(processor_tag, payload_xml, removed_indices))
                }
                .expect("reduction-pair witnesses are JSON serializable")
                .into_iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>();
                format!("exact-red-pair(hex={encoded})")
            }
            Self::ExactUsableRules {
                payload_xml,
                source_pairs_xml,
                source_rules_xml,
            } => {
                let encoded =
                    if let (Some(pairs), Some(rules)) = (source_pairs_xml, source_rules_xml) {
                        serde_json::to_vec(&(payload_xml, pairs, rules))
                    } else {
                        serde_json::to_vec(payload_xml)
                    }
                    .expect("usable rules witness is JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-usable-rules(hex={encoded})")
            }
            Self::ExactInnermostLhss { payload_xml, source_dp_input_xml } => {
                let encoded = match source_dp_input_xml {
                    Some(source) => serde_json::to_vec(&(payload_xml, source)),
                    None => serde_json::to_vec(payload_xml),
                }
                    .expect("innermost LHS witness is JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-innermost-lhss(hex={encoded})")
            }
            Self::ExactDpTransformation {
                processor_tag,
                payload_xml,
                dp_input_xml,
                source_dp_input_xml,
            } => {
                let encoded = match source_dp_input_xml {
                    Some(source) => serde_json::to_vec(&(processor_tag, payload_xml, dp_input_xml, source)),
                    None => serde_json::to_vec(&(processor_tag, payload_xml, dp_input_xml)),
                }
                    .expect("DP transformation witness is JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-dp-transform(hex={encoded})")
            }
            Self::ExactTerminationProof {
                source_dp_input_xml,
                dp_proof_xml,
            } => {
                let encoded = serde_json::to_vec(&(source_dp_input_xml, dp_proof_xml))
                    .expect("exact DP proof witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-dp-proof(hex={encoded})")
            }
            Self::ExactNonterminationRuleRemoval {
                source_dp_input_xml,
                residual_dp_input_xml,
            } => {
                let encoded = serde_json::to_vec(&(source_dp_input_xml, residual_dp_input_xml))
                    .expect("DP nontermination rule-removal witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-dp-no-rule-removal(hex={encoded})")
            }
            Self::SwitchFullNontermination => "switch-full-nontermination".to_owned(),
            Self::NonterminationUsableRules => "nontermination-usable-rules".to_owned(),
            Self::NonterminationCycle { candidate, min_length, max_length, repeated } => {
                let extra = if *repeated { ",repeated=1" } else { "" };
                format!("nontermination-cycle(candidate={candidate},min-length={min_length},max-length={max_length}{extra})")
            },
            Self::NonterminationNarrowing { candidate, lookahead, all, below } => format!("nontermination-narrow(candidate={candidate},lookahead={},all={},below={})", usize::from(*lookahead), usize::from(*all), usize::from(*below)),
            Self::NonterminationInnermostLhss => "nontermination-innermost-lhss".to_owned(),
            Self::NonterminationLoop => "nontermination(dp-loop)".to_owned(),
            Self::NonterminationNonLoop => "nontermination(dp-nonloop)".to_owned(),
            Self::NonterminationSymbolicLoop => "nontermination(dp-symbolic-loop)".to_owned(),
            Self::NonterminationBackwardLoop => "nontermination(dp-backward-loop)".to_owned(),
            Self::NonterminationForkLoop => "nontermination(dp-fork-loop)".to_owned(),
            Self::NonterminationFairLoop => "nontermination(dp-fair-loop)".to_owned(),
            Self::NonterminationInstance { candidate, constants, all } => format!("nontermination-instance(candidate={candidate},constants={},all={})", usize::from(*constants), usize::from(*all)),
            Self::NonterminationRuleFilter { max_lhs, max_rhs, collapsing } => format!("nontermination-rule-filter(max-lhs={max_lhs},max-rhs={max_rhs},collapsing={})", usize::from(*collapsing)),
            Self::ExactNonterminationLoop {
                source_dp_input_xml,
                loop_xml,
            } => {
                let encoded = serde_json::to_vec(&(source_dp_input_xml, loop_xml))
                    .expect("exact loop witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-dp-loop(hex={encoded})")
            }
            Self::ExactNonterminationProof {
                source_dp_input_xml,
                dp_proof_xml,
            } => {
                let encoded = serde_json::to_vec(&(source_dp_input_xml, dp_proof_xml))
                    .expect("exact DP nontermination proofs are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-dp-nontermination-proof(hex={encoded})")
            }
            Self::ExactNonterminationNonLoop {
                source_dp_input_xml,
                non_loop_xml,
            } => {
                let encoded = serde_json::to_vec(&(source_dp_input_xml, non_loop_xml))
                    .expect("exact non-loop witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-dp-nonloop(hex={encoded})")
            }
            Self::ExactSplit {
                selected_pair_index,
                selected_rule_index,
                source_dp_input_xml,
            } => {
                let encoded = serde_json::to_vec(&(
                    selected_pair_index,
                    selected_rule_index,
                    source_dp_input_xml,
                ))
                .expect("split witness is JSON serializable")
                .into_iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>();
                format!("exact-split(hex={encoded})")
            }
            Self::UsableRules => "usable-rules".to_owned(),
            Self::MutermExpand => "muterm-expand".to_owned(),
            Self::InnermostLhss => "innermost-lhss".to_owned(),
            Self::Split => "split".to_owned(),
            Self::SelectedSplit { candidate_index } => {
                format!("split(candidate={candidate_index})")
            }
            Self::SwitchInnermost => "switch-innermost".to_owned(),
            Self::QdpToSrs => "qdp-to-srs".to_owned(),
            Self::SwitchToTrs => "switch-to-trs".to_owned(),
            Self::Subterm => "subterm".to_owned(),
            Self::ExactSubterm { projection } => {
                let encoded = serde_json::to_vec(projection)
                    .expect("subterm projections are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-subterm(hex={encoded})")
            }
            Self::SizeChange => "size-change".to_owned(),
            Self::ExactSizeChange { graphs } => {
                let encoded = serde_json::to_vec(graphs)
                    .expect("size-change witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-size-change(hex={encoded})")
            }
            Self::Llm => "llm".to_owned(),
            Self::SymbolWeights { max_weight } => {
                format!("symbol-weights(max-weight={max_weight})")
            }
            Self::LinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded_polynomial_atom(
                "poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::SelectedLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                candidate_index,
            } => {
                let mut atom = bounded_polynomial_atom(
                    "poly",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(atom.len() - 1, &format!(",candidate={candidate_index}"));
                atom
            }
            Self::TargetLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                strict_pair_indices,
            } => {
                let mut atom = bounded_polynomial_atom(
                    "poly-target",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(
                    atom.len() - 1,
                    &format!(
                        ",strict={}",
                        strict_pair_indices
                            .iter()
                            .map(usize::to_string)
                            .collect::<Vec<_>>()
                            .join("+")
                    ),
                );
                atom
            }
            Self::MinimumDeletionLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                min_delete,
                residual_budget,
            } => {
                let mut atom = bounded_polynomial_atom(
                    "poly-min-delete",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(
                    atom.len() - 1,
                    &format!(",min-delete={min_delete},residual-budget={residual_budget}"),
                );
                atom
            }
            Self::ExactLinearPolynomial { interpretation } => {
                let encoded = serde_json::to_vec(interpretation)
                    .expect("linear polynomial witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-poly(hex={encoded})")
            }
            Self::ExactMonotonicPolynomial { interpretation } => {
                let encoded = serde_json::to_vec(interpretation)
                    .expect("monotonic polynomial witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-mono-poly(hex={encoded})")
            }
            Self::ExactWeakPolynomial { interpretation } => {
                let encoded = serde_json::to_vec(interpretation)
                    .expect("weak polynomial witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-weak-poly(hex={encoded})")
            }
            Self::ExactMaxPolynomial { interpretation } => {
                let encoded = serde_json::to_vec(interpretation)
                    .expect("max-polynomial witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-max-poly(hex={encoded})")
            }
            Self::ExactWeightedPathOrderMax { witness } => {
                let encoded = serde_json::to_vec(witness)
                    .expect("WPO(max) witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-wpo-max(hex={encoded})")
            }
            Self::ExactRationalPolynomial {
                denominator,
                interpretation,
            } => {
                let encoded = serde_json::to_vec(&(denominator, interpretation))
                    .expect("rational-polynomial witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-rat-poly(hex={encoded})")
            }
            Self::ExactRationalNaturalPolynomial {
                denominator,
                delta,
                interpretation,
            } => {
                let encoded = serde_json::to_vec(&(denominator, delta, interpretation))
                    .expect("rational natural-polynomial witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-rat-natural-poly(hex={encoded})")
            }
            Self::ExactMatrixInterpretation { interpretation } => {
                let encoded = serde_json::to_vec(interpretation)
                    .expect("matrix witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-matrix(hex={encoded})")
            }
            Self::ExactArcticMatrixInterpretation {
                integer_domain,
                interpretation,
            } => {
                let encoded = serde_json::to_vec(&(integer_domain, interpretation))
                    .expect("Arctic matrix witnesses are JSON serializable")
                    .into_iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                format!("exact-arctic(hex={encoded})")
            }
            Self::MonotonicPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded_polynomial_atom(
                "mono-poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::SatPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded_polynomial_atom(
                "sat-poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::WeakPolynomial {
                min_constant,
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => {
                let mut args = vec![
                    format!("min-constant={min_constant}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                ];
                if let Some(value) = max_symbols {
                    args.push(format!("max-symbols={value}"));
                }
                if let Some(value) = max_arity {
                    args.push(format!("max-arity={value}"));
                }
                format!("weak-poly({})", args.join(","))
            }
            Self::TargetWeakPolynomial {
                min_constant,
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                strict_pair_indices,
            } => {
                let mut args = vec![
                    format!("min-constant={min_constant}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                    format!(
                        "strict={}",
                        strict_pair_indices
                            .iter()
                            .map(usize::to_string)
                            .collect::<Vec<_>>()
                            .join("+")
                    ),
                ];
                if let Some(value) = max_symbols {
                    args.push(format!("max-symbols={value}"));
                }
                if let Some(value) = max_arity {
                    args.push(format!("max-arity={value}"));
                }
                format!("weak-poly-target({})", args.join(","))
            }
            Self::MaxPolynomial {
                max_constant,
                max_coefficient,
                alternatives,
                max_symbols,
                max_arity,
            } | Self::WeightedPathOrderMax {
                max_constant, max_coefficient, alternatives, max_symbols, max_arity, ..
            } => {
                let mut atom = bounded_polynomial_atom(
                    if matches!(self, Self::WeightedPathOrderMax { .. }) { "wpo-max" } else { "max-poly" },
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(atom.len() - 1, &format!(",alternatives={alternatives}"));
                if matches!(self, Self::WeightedPathOrderMax { all_strict: true, .. }) {
                    atom.insert_str(atom.len() - 1, ",all-strict=1");
                }
                if matches!(self, Self::WeightedPathOrderMax { permutations: true, .. }) {
                    atom.insert_str(atom.len() - 1, ",permutations=1");
                }
                if matches!(self, Self::WeightedPathOrderMax { ordered_alternatives: true, .. }) {
                    atom.insert_str(atom.len() - 1, ",ordered-alternatives=1");
                }
                if let Self::WeightedPathOrderMax { compact_ground, permutations, .. } = self {
                    if compact_ground != permutations {
                        atom.insert_str(atom.len() - 1, if *compact_ground {
                            ",compact-ground=1"
                        } else { ",compact-ground=0" });
                    }
                }
                atom
            }
            Self::RationalPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                denominator,
                delta_denominator,
            } | Self::RationalQuadraticPolynomial {
                max_constant, max_coefficient, max_symbols, max_arity,
                denominator, delta_denominator, ..
            } => {
                let mut atom = bounded_polynomial_atom(
                    if matches!(self, Self::RationalQuadraticPolynomial { .. }) {
                        "rat-quadratic-poly"
                    } else { "rat-poly" },
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(
                    atom.len() - 1,
                    &format!(",denominator={denominator},delta-denominator={delta_denominator}"),
                );
                if let Self::RationalQuadraticPolynomial { solver: Some(solver), .. } = self {
                    atom.insert_str(atom.len() - 1, &format!(",solver={solver}"));
                }
                if let Self::RationalQuadraticPolynomial { coefficient_values, max_quadratic_terms, quadratic_shape, .. } = self {
                    if !coefficient_values.is_empty() {
                        atom.insert_str(atom.len() - 1, &format!(",coefficients={}", coefficient_values.iter().map(ToString::to_string).collect::<Vec<_>>().join("+")));
                    }
                    if let Some(n) = max_quadratic_terms {
                        atom.insert_str(atom.len() - 1, &format!(",quadratic-terms={n}"));
                    }
                    if quadratic_shape != "any" {
                        atom.insert_str(atom.len() - 1, &format!(",quadratic-shape={quadratic_shape}"));
                    }
                }
                atom
            }
            Self::TargetRationalPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                denominator,
                delta_denominator,
                min_delete,
                residual_budget,
            } => {
                let mut atom = bounded_polynomial_atom(
                    "rat-poly-target",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(
                    atom.len() - 1,
                    &format!(
                        ",denominator={denominator},delta-denominator={delta_denominator},min-delete={min_delete},residual-budget={residual_budget}"
                    ),
                );
                atom
            }
            Self::SmtPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded_polynomial_atom(
                "smt-poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::QuadraticPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded_polynomial_atom(
                "quadratic-poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::MatrixInterpretation {
                dimension,
                max_constant,
                max_coefficient,
                min_nonzero,
                max_nonzero,
                max_nonzero_constants,
                max_nonzero_per_row,
                max_symbols,
                max_arity,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                ];
                for (name, value) in [
                    ("min-nonzero", min_nonzero),
                    ("max-nonzero", max_nonzero),
                    ("max-nonzero-constants", max_nonzero_constants),
                    ("max-nonzero-per-row", max_nonzero_per_row),
                    ("max-symbols", max_symbols),
                    ("max-arity", max_arity),
                ] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                format!("matrix({})", args.join(","))
            }
            Self::SelectedMatrixInterpretation {
                dimension,
                max_constant,
                max_coefficient,
                min_nonzero,
                max_nonzero,
                max_nonzero_constants,
                max_nonzero_per_row,
                max_symbols,
                max_arity,
                candidate_index,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                    format!("candidate={candidate_index}"),
                ];
                for (name, value) in [
                    ("min-nonzero", min_nonzero),
                    ("max-nonzero", max_nonzero),
                    ("max-nonzero-constants", max_nonzero_constants),
                    ("max-nonzero-per-row", max_nonzero_per_row),
                    ("max-symbols", max_symbols),
                    ("max-arity", max_arity),
                ] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                format!("matrix({})", args.join(","))
            }
            Self::IntegerMatrixInterpretation {
                dimension,
                min_value,
                max_value,
                max_symbols,
                max_arity,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("min-value={min_value}"),
                    format!("max-value={max_value}"),
                ];
                for (name, value) in [("max-symbols", max_symbols), ("max-arity", max_arity)] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                format!("integer-matrix({})", args.join(","))
            }
            Self::ArcticMatrixInterpretation {
                threshold,
                shared,
                dimension,
                max_constant,
                max_coefficient,
                max_nonzero,
                max_symbols,
                max_arity,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                ];
                for (name, value) in [
                    ("max-nonzero", max_nonzero),
                    ("max-symbols", max_symbols),
                    ("max-arity", max_arity),
                ] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                if *threshold { args.push("encoding=threshold".into()); }
                format!("{}({})", if *shared { "arctic-matrix-cached" } else { "arctic-matrix" }, args.join(","))
            }
            Self::SelectedArcticMatrixInterpretation {
                threshold,
                shared,
                dimension,
                max_constant,
                max_coefficient,
                max_nonzero,
                max_symbols,
                max_arity,
                candidate_index,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                    format!("candidate={candidate_index}"),
                ];
                for (name, value) in [
                    ("max-nonzero", max_nonzero),
                    ("max-symbols", max_symbols),
                    ("max-arity", max_arity),
                ] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                if *threshold { args.push("encoding=threshold".into()); }
                format!("{}({})", if *shared { "arctic-matrix-cached" } else { "arctic-matrix" }, args.join(","))
            }
            Self::TargetArcticMatrixInterpretation {
                threshold,
                shared,
                symmetry,
                solver,
                dimension,
                max_constant,
                max_coefficient,
                max_nonzero,
                max_symbols,
                max_arity,
                strict_pair_indices,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("max-constant={max_constant}"),
                    format!("max-coefficient={max_coefficient}"),
                    format!(
                        "strict={}",
                        strict_pair_indices.as_ref().map_or_else(
                            || "all".to_string(),
                            |indices| indices.iter().map(usize::to_string).collect::<Vec<_>>().join("+")
                        )
                    ),
                ];
                for (name, value) in [
                    ("max-nonzero", max_nonzero),
                    ("max-symbols", max_symbols),
                    ("max-arity", max_arity),
                ] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                if let Some(solver) = solver { args.push(format!("solver={solver}")); }
                if *symmetry { args.push("symmetry=true".to_string()); }
                if *threshold { args.push("encoding=threshold".into()); }
                format!("{}({})", if *shared { "arctic-target-cached" } else { "arctic-target" }, args.join(","))
            }
            Self::QuasiPeriodic { period, max_weight } => format!("qpi(period={period},max-weight={max_weight})"),
            Self::QuasiPeriodicBv { period, max_weight } => format!("qpi-bv(period={period},max-weight={max_weight})"),
            Self::IntegerArcticMatrixInterpretation {
                threshold,
                all_strict,
                max_finite_per_row,
                bitvectors,
                root_projection,
                optimize,
                symmetry,
                solver,
                dimension,
                min_value,
                max_value,
                max_symbols,
                max_arity,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("min-value={min_value}"),
                    format!("max-value={max_value}"),
                ];
                for (name, value) in [("max-symbols", max_symbols), ("max-arity", max_arity)] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                if let Some(solver) = solver { args.push(format!("solver={solver}")); }
                if *symmetry { args.push("symmetry=true".to_string()); }
                if *threshold { args.push("encoding=threshold".into()); }
                else if *bitvectors { args.push("encoding=bv".to_string()); }
                if *root_projection { args.push("root-projection=true".to_string()); }
                if !*optimize { args.push("optimize=false".to_string()); }
                if *all_strict { args.push("strict=all".to_string()); }
                if let Some(n)=max_finite_per_row {args.push(format!("max-finite-per-row={n}"));}
                format!("integer-arctic-matrix({})", args.join(","))
            }
            Self::SelectedIntegerArcticMatrixInterpretation {
                threshold,
                all_strict,
                max_finite_per_row,
                bitvectors,
                root_projection,
                optimize,
                symmetry,
                solver,
                dimension,
                min_value,
                max_value,
                max_symbols,
                max_arity,
                candidate_index,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("min-value={min_value}"),
                    format!("max-value={max_value}"),
                    format!("candidate={candidate_index}"),
                ];
                for (name, value) in [("max-symbols", max_symbols), ("max-arity", max_arity)] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                if let Some(solver) = solver { args.push(format!("solver={solver}")); }
                if *symmetry { args.push("symmetry=true".to_string()); }
                if *threshold { args.push("encoding=threshold".into()); }
                else if *bitvectors { args.push("encoding=bv".to_string()); }
                if *root_projection { args.push("root-projection=true".to_string()); }
                if !*optimize { args.push("optimize=false".to_string()); }
                if *all_strict { args.push("strict=all".to_string()); }
                if let Some(n)=max_finite_per_row {args.push(format!("max-finite-per-row={n}"));}
                format!("integer-arctic-matrix({})", args.join(","))
            }
            Self::ApplicativeReductionPair => "applicative-reduction-pair".to_owned(),
            Self::PathOrder => "path-order".to_owned(),
            Self::ConfiguredPathOrder { order, optimize } => format!(
                "path-order(status={},optimize={})",
                if *order == DpPathOrderKind::Rpo { "rpo" } else { "lpo" },
                usize::from(*optimize)),
            Self::Gm04AdministrativeRpo => "gm04-rpo".to_owned(),
            Self::ComplexConstantRemoval => "complex-constant-removal".to_owned(),
            Self::LargestComplexConstantRemoval => "complex-constant-removal-largest".to_owned(),
            Self::SelectedPathOrder { candidate_index } => {
                format!("path-order(candidate={candidate_index})")
            }
            Self::TargetPathOrder {
                strict_pair_indices,
            } => format!(
                "path-order-target(strict={})",
                strict_pair_indices
                    .iter()
                    .map(usize::to_string)
                    .collect::<Vec<_>>()
                    .join("+")
            ),
            Self::ExactPathOrder {
                default_order,
                statuses,
                precedence,
                precedence_ranks,
                argument_filter,
            } => {
                let encoded = serde_json::to_vec(&(
                    default_order,
                    statuses,
                    precedence,
                    precedence_ranks,
                    argument_filter,
                ))
                .expect("path-order witnesses are JSON serializable")
                .into_iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>();
                format!("exact-path-order(hex={encoded})")
            }
            Self::Kbo {
                max_weight,
                max_symbols,
            } => format!("kbo(max-weight={max_weight},max-symbols={max_symbols})"),
            Self::Rewriting { max_per_pair } => transform_atom("rewrite", *max_per_pair),
            Self::SelectedRewriting { max_per_pair, candidate_index } =>
                selected_transform_atom("rewrite", *max_per_pair, *candidate_index),
            Self::Narrowing { max_per_pair } => transform_atom("narrow", *max_per_pair),
            Self::SelectedNarrowing {
                max_per_pair,
                candidate_index,
            } => selected_transform_atom("narrow", *max_per_pair, *candidate_index),
            Self::AlphaMerge => "alpha-merge".to_owned(),
            Self::Gm04SourceCsr => "gm04-source-csr".to_owned(),
            Self::Instantiation { max_per_pair } => transform_atom("instantiate", *max_per_pair),
            Self::SelectedInstantiation {
                max_per_pair,
                candidate_index,
            } => selected_transform_atom("instantiate", *max_per_pair, *candidate_index),
            Self::ForwardInstantiation { max_per_pair } => {
                transform_atom("forward-instantiate", *max_per_pair)
            }
            Self::SelectedForwardInstantiation {
                max_per_pair,
                candidate_index,
            } => selected_transform_atom("forward-instantiate", *max_per_pair, *candidate_index),
            Self::SemanticLabeling => "semantic-labeling".to_owned(),
            Self::RootLabeling => "root-labeling".to_owned(),
            Self::ExactSemanticLabeling {
                model,
                source_dp_input_xml,
                expected_child_dp_input_xml,
            } => {
                let wire = SemanticLabelingModelWire::from(model);
                let encoded = if let (Some(source), Some(child)) =
                    (source_dp_input_xml, expected_child_dp_input_xml)
                {
                    serde_json::to_vec(&(wire, source, child))
                } else if let Some(source) = source_dp_input_xml {
                    serde_json::to_vec(&(wire, source))
                } else {
                    serde_json::to_vec(&wire)
                }
                .expect("semantic-labeling models are JSON serializable")
                .into_iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>();
                format!("exact-semantic-labeling(hex={encoded})")
            }
            Self::UncurryBelow => "uncurry-below".to_owned(),
            Self::Uncurry => "uncurry".to_owned(),
        }
    }
}

impl Default for DpStrategy {
    fn default() -> Self {
        Self::standard()
    }
}

fn decode_exact_witness_hex(
    encoded: &str,
    processor: &str,
) -> Result<Vec<u8>, DpStrategyParseError> {
    if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err(strategy_parse_error(format!(
            "{processor} hex witness must contain an even number of hexadecimal digits"
        )));
    }
    encoded
        .as_bytes()
        .chunks_exact(2)
        .map(|digits| {
            let text = std::str::from_utf8(digits)
                .map_err(|_| strategy_parse_error(format!("invalid {processor} witness")))?;
            u8::from_str_radix(text, 16)
                .map_err(|_| strategy_parse_error(format!("invalid {processor} witness")))
        })
        .collect()
}

struct DpStrategyParser<'a> {
    input: &'a str,
    definitions: BTreeMap<String, DpStrategy>,
}

impl<'a> DpStrategyParser<'a> {
    fn new(input: &'a str) -> Self {
        Self {
            input,
            definitions: BTreeMap::new(),
        }
    }

    fn parse(mut self) -> Result<DpStrategy, DpStrategyParseError> {
        let statements = split_top_level(self.input.trim(), ';');
        let mut body_start = 0usize;
        for (index, statement) in statements.iter().enumerate() {
            let statement = statement.trim();
            if statement.is_empty() {
                body_start = index + 1;
                continue;
            }
            let Some((name, value)) = parse_strategy_definition(statement)? else {
                break;
            };
            let strategy = self.parse_choice(value.trim())?;
            self.definitions.insert(name, strategy);
            body_start = index + 1;
        }
        let body = statements[body_start..]
            .iter()
            .map(|statement| statement.trim())
            .filter(|statement| !statement.is_empty())
            .collect::<Vec<_>>()
            .join("; ");
        if body.is_empty() {
            return Err(strategy_parse_error("strategy body is empty"));
        }
        self.parse_choice(&body)
    }

    fn parse_choice(&self, input: &str) -> Result<DpStrategy, DpStrategyParseError> {
        let parts = split_top_level(input, '|');
        if parts.len() > 1 {
            return Ok(DpStrategy::Choice(
                parts
                    .into_iter()
                    .map(|part| self.parse_sequence(part.trim()))
                    .collect::<Result<Vec<_>, _>>()?,
            ));
        }
        self.parse_sequence(input)
    }

    fn parse_sequence(&self, input: &str) -> Result<DpStrategy, DpStrategyParseError> {
        let mut parts = split_top_level(input, ';');
        if parts.len() == 1 {
            parts = split_top_level(input, ',');
        }
        let strategies = parts
            .into_iter()
            .map(str::trim)
            .filter(|part| !part.is_empty())
            .map(|part| self.parse_atom(part))
            .collect::<Result<Vec<_>, _>>()?;
        match strategies.as_slice() {
            [] => Err(strategy_parse_error("empty strategy")),
            [strategy] => Ok(strategy.clone()),
            _ => Ok(DpStrategy::Sequence(strategies)),
        }
    }

    fn parse_atom(&self, input: &str) -> Result<DpStrategy, DpStrategyParseError> {
        let raw_input = input.trim();
        let input = strip_outer_parentheses(raw_input);
        if input != raw_input
            && (split_top_level(input, '|').len() > 1
                || split_top_level(input, ';').len() > 1
                || split_top_level(input, ',').len() > 1)
        {
            return self.parse_choice(input);
        }
        if let Some(strategy) = self.definitions.get(&input.to_ascii_lowercase()) {
            return Ok(strategy.clone());
        }
        if let Some(inner) = function_arguments(input, "timeout") {
            let args = split_top_level(inner, ',');
            if args.len() != 2 {
                return Err(strategy_parse_error(
                    "timeout expects duration and strategy",
                ));
            }
            return Ok(DpStrategy::Timeout {
                duration: parse_strategy_duration(args[0].trim())?,
                strategy: Box::new(self.parse_choice(args[1].trim())?),
            });
        }
        if let Some(inner) = function_arguments(input, "delay") {
            let args = split_top_level(inner, ',');
            if args.len() != 2 {
                return Err(strategy_parse_error("delay expects duration and strategy"));
            }
            return Ok(DpStrategy::Delay {
                duration: parse_strategy_duration(args[0].trim())?,
                strategy: Box::new(self.parse_choice(args[1].trim())?),
            });
        }
        if let Some(inner) = function_arguments(input, "repeat") {
            let args = split_top_level(inner, ',');
            return match args.as_slice() {
                [strategy] => Ok(DpStrategy::Repeat {
                    max_iterations: 16,
                    strategy: Box::new(self.parse_choice(strategy.trim())?),
                }),
                [max_iterations, strategy] => Ok(DpStrategy::Repeat {
                    max_iterations: max_iterations
                        .trim()
                        .parse()
                        .map_err(|_| strategy_parse_error("repeat count must be a number"))?,
                    strategy: Box::new(self.parse_choice(strategy.trim())?),
                }),
                _ => Err(strategy_parse_error(
                    "repeat expects strategy or count and strategy",
                )),
            };
        }
        if let Some(inner) = function_arguments(input, "parallel") {
            let (cancel_on, strategies) = parse_parallel_arguments(self, inner)?;
            return Ok(DpStrategy::Parallel {
                cancel_on,
                strategies,
            });
        }
        if let Some(inner) = function_arguments(input, "pipeline") {
            let strategy = self.parse_sequence(inner.trim())?;
            return Ok(match strategy {
                DpStrategy::Sequence(strategies) => DpStrategy::Pipeline(strategies),
                strategy => DpStrategy::Pipeline(vec![strategy]),
            });
        }
        if let Some(inner) = function_arguments(input, "split") {
            let (_, candidate_index) = parse_transform_selection(inner, "split")?;
            let Some(candidate_index) = candidate_index else {
                return Err(strategy_parse_error("split requires candidate=N"));
            };
            return Ok(DpStrategy::Processor(DpStrategyProcessor::SelectedSplit {
                candidate_index,
            }));
        }
        if let Some(inner) =
            function_arguments(input, "narrow").or_else(|| function_arguments(input, "narrowing"))
        {
            let (max_per_pair, candidate_index) = parse_transform_selection(inner, "narrow")?;
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedNarrowing {
                    max_per_pair,
                    candidate_index,
                },
                None => DpStrategyProcessor::Narrowing { max_per_pair },
            }));
        }
        if let Some(inner) =
            function_arguments(input, "rewrite").or_else(|| function_arguments(input, "rewriting"))
        {
            let (max_per_pair, candidate_index) = parse_transform_selection(inner, "rewrite")?;
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedRewriting {
                    max_per_pair, candidate_index,
                },
                None => DpStrategyProcessor::Rewriting { max_per_pair },
            }));
        }
        if let Some(inner) = function_arguments(input, "instantiate")
            .or_else(|| function_arguments(input, "instantiation"))
        {
            let (max_per_pair, candidate_index) = parse_transform_selection(inner, "instantiate")?;
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedInstantiation {
                    max_per_pair,
                    candidate_index,
                },
                None => DpStrategyProcessor::Instantiation { max_per_pair },
            }));
        }
        if let Some(inner) = function_arguments(input, "forward-instantiate")
            .or_else(|| function_arguments(input, "forward-instantiation"))
            .or_else(|| function_arguments(input, "forward-instantiation-proc"))
        {
            let (max_per_pair, candidate_index) =
                parse_transform_selection(inner, "forward-instantiation")?;
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedForwardInstantiation {
                    max_per_pair,
                    candidate_index,
                },
                None => DpStrategyProcessor::ForwardInstantiation { max_per_pair },
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-semantic-labeling") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-semantic-labeling")?;
            let encoded = named.value(&["hex"], "hex-encoded semantic-labeling model")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-semantic-labeling")?;
            let value: serde_json::Value = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact semantic-labeling model"))?;
            let (model, source_dp_input_xml, expected_child_dp_input_xml): (
                SemanticLabelingModelWire,
                Option<String>,
                Option<String>,
            ) = if value.is_array() {
                let values = value.as_array().expect("checked JSON array");
                if values.len() == 3 {
                    let (model, source, child): (SemanticLabelingModelWire, String, String) =
                        serde_json::from_value(value).map_err(|_| {
                            strategy_parse_error("invalid exact semantic-labeling transition")
                        })?;
                    (model, Some(source), Some(child))
                } else {
                    let (model, source): (SemanticLabelingModelWire, String) =
                        serde_json::from_value(value).map_err(|_| {
                            strategy_parse_error("invalid context-bound semantic-labeling model")
                        })?;
                    (model, Some(source), None)
                }
            } else {
                let model = serde_json::from_value(value)
                    .map_err(|_| strategy_parse_error("invalid exact semantic-labeling model"))?;
                (model, None, None)
            };
            if model.carrier_size == 0 {
                return Err(strategy_parse_error(
                    "exact semantic-labeling model has an empty carrier",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactSemanticLabeling {
                    model: model.into(),
                    source_dp_input_xml,
                    expected_child_dp_input_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-subterm") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-subterm")?;
            let encoded = named.value(&["hex"], "hex-encoded subterm projection")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-subterm")?;
            let projection = serde_json::from_slice::<Vec<(String, usize, usize)>>(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-subterm projection witness"))?;
            if projection.is_empty() {
                return Err(strategy_parse_error(
                    "exact-subterm projection witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::ExactSubterm {
                projection,
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-size-change") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-size-change")?;
            let encoded = named.value(&["hex"], "hex-encoded size-change graphs")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-size-change")?;
            let graphs = serde_json::from_slice::<Vec<(usize, Vec<(usize, bool, usize)>)>>(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact size-change witness"))?;
            if graphs.is_empty() || graphs.iter().any(|(_, edges)| edges.is_empty()) {
                return Err(strategy_parse_error(
                    "exact size-change witness must contain nonempty graphs",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactSizeChange { graphs },
            ));
        }
        if let Some(inner) = function_arguments(input, "path-order") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "path-order")?;
            if let Some(status) = named.optional_value(&["status"]) {
                let order = match status {
                    "rpo" => DpPathOrderKind::Rpo,
                    "lpo" => DpPathOrderKind::Lpo,
                    _ => return Err(strategy_parse_error("path-order status must be rpo or lpo")),
                };
                let optimize = match named.optional_value(&["optimize"]).unwrap_or("1") {
                    "0" => false, "1" => true,
                    _ => return Err(strategy_parse_error("path-order optimize must be 0 or 1")),
                };
                return Ok(DpStrategy::Processor(DpStrategyProcessor::ConfiguredPathOrder { order, optimize }));
            }
            let candidate_index = named
                .optional_usize(
                    &["candidate", "candidate-index", "candidate_index"],
                    "candidate index",
                )?
                .unwrap_or(0);
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::SelectedPathOrder { candidate_index },
            ));
        }
        if let Some(inner) = function_arguments(input, "path-order-target") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "path-order-target")?;
            let encoded = named.value(
                &["strict", "strict-pairs", "strict_pairs"],
                "strict pair indices",
            )?;
            let strict_pair_indices = encoded
                .split('+')
                .map(|index| {
                    index
                        .parse::<usize>()
                        .map_err(|_| strategy_parse_error("invalid strict pair index"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            if strict_pair_indices.is_empty() {
                return Err(strategy_parse_error(
                    "path-order target must delete at least one pair",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::TargetPathOrder {
                    strict_pair_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-graph") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-graph")?;
            let encoded = named.value(&["hex"], "hex-encoded dependency-graph components")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-graph")?;
            let (source_dp_input_xml, components) = if let Ok(components) =
                serde_json::from_slice::<Vec<(Vec<usize>, bool)>>(&bytes)
            {
                (None, components)
            } else {
                let (source, components) =
                    serde_json::from_slice::<(String, Vec<(Vec<usize>, bool)>)>(&bytes).map_err(
                        |_| strategy_parse_error("invalid exact dependency-graph witness"),
                    )?;
                (Some(source), components)
            };
            if components.is_empty() {
                return Err(strategy_parse_error(
                    "exact dependency graph must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactDependencyGraph {
                    components,
                    source_dp_input_xml,
                    source_is_live: false,
                },
            ));
        }
        if input == "nontermination-usable-rules" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationUsableRules));
        }
        if let Some(inner) = function_arguments(input, "nontermination-instance") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "nontermination-instance")?;
            let candidate = named.optional_usize(&["candidate"], "instance candidate")?.unwrap_or(0);
            let constants = named.optional_usize(&["constants"], "constant instantiation")?.unwrap_or(0);
            let all = named.optional_usize(&["all"], "all instances")?.unwrap_or(0);
            if constants > 1 || all > 1 { return Err(strategy_parse_error("constants and all must be 0 or 1")); }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationInstance { candidate, constants: constants != 0, all: all != 0 }));
        }
        if let Some(inner) = function_arguments(input, "nontermination-rule-filter") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "nontermination-rule-filter")?;
            let max_lhs = named.optional_usize(&["max-lhs"], "left-side node bound")?.unwrap_or(8);
            let max_rhs = named.optional_usize(&["max-rhs"], "right-side node bound")?.unwrap_or(8);
            let collapsing = named.optional_usize(&["collapsing"], "allow collapsing rules")?.unwrap_or(1);
            if collapsing > 1 { return Err(strategy_parse_error("collapsing must be 0 or 1")); }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationRuleFilter { max_lhs, max_rhs, collapsing: collapsing != 0 }));
        }
        if let Some(inner) = function_arguments(input, "nontermination-cycle") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "nontermination-cycle")?;
            let candidate = named.optional_usize(&["candidate"], "cycle candidate")?.unwrap_or(0);
            let max_length = named.optional_usize(&["max-length"], "cycle length")?.unwrap_or(4);
            let min_length = named.optional_usize(&["min-length"], "minimum cycle length")?.unwrap_or(1);
            let repeated = named.optional_usize(&["repeated"], "repeated root cycles")?.unwrap_or(0);
            if repeated > 1 { return Err(strategy_parse_error("repeated must be 0 or 1")); }
            if !(1..=8).contains(&max_length) || min_length == 0 || min_length > max_length { return Err(strategy_parse_error("cycle lengths must satisfy 1 <= min-length <= max-length <= 8")); }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationCycle { candidate, min_length, max_length, repeated: repeated != 0 }));
        }
        if let Some(inner) = function_arguments(input, "nontermination-narrow") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "nontermination-narrow")?;
            let candidate = named.optional_usize(&["candidate"], "narrowing candidate")?.unwrap_or(0);
            let lookahead = named.optional_usize(&["lookahead"], "narrowing lookahead")?.unwrap_or(0);
            if lookahead > 1 { return Err(strategy_parse_error("narrowing lookahead must be 0 or 1")); }
            let all = named.optional_usize(&["all"], "all narrowing branches")?.unwrap_or(0);
            if all > 1 { return Err(strategy_parse_error("narrowing all must be 0 or 1")); }
            let below = named.optional_usize(&["below"], "narrowing region")?.unwrap_or(0);
            if below > 1 { return Err(strategy_parse_error("narrowing below must be 0 or 1")); }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationNarrowing { candidate, lookahead: lookahead != 0, all: all != 0, below: below != 0 }));
        }
        if input == "nontermination-innermost-lhss" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationInnermostLhss));
        }
        if input == "conditional-poly" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::ConditionalPolynomial { max_coefficient: 2, degree: 1, before: 1, after: 0, squares: false, reinduct: 0, induction: 0 }));
        }
        if let Some(inner) = function_arguments(input, "conditional-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "conditional-poly")?;
            let max_coefficient = named.value(&["max-coefficient"], "coefficient bound")?
                .parse::<i64>().map_err(|_| DpStrategyParseError { message: "invalid conditional coefficient bound".to_owned() })?;
            if !(1..=16).contains(&max_coefficient) { return Err(DpStrategyParseError { message: "conditional coefficient bound must be 1..16".to_owned() }); }
            let degree = named.optional_usize(&["degree"], "polynomial degree")?.unwrap_or(1);
            if !(1..=2).contains(&degree) { return Err(DpStrategyParseError { message: "conditional degree must be 1 or 2".to_owned() }); }
            let before = named.optional_usize(&["before"], "predecessor depth")?.unwrap_or(1);
            if before > 3 { return Err(DpStrategyParseError { message: "conditional predecessor depth must be 0..3".to_owned() }); }
            let after = named.optional_usize(&["after"], "successor depth")?.unwrap_or(0);
            if after > 3 || before + after > 3 { return Err(strategy_parse_error("conditional total context depth must be at most 3")); }
            let squares = named.optional_usize(&["squares"], "square-template flag")?.unwrap_or(0);
            if squares > 1 || (squares == 1 && degree != 2) { return Err(strategy_parse_error("squares=1 requires degree=2")); }
            let reinduct = named.optional_usize(&["reinduct"], "re-induction depth")?.unwrap_or(0);
            if reinduct > 3 { return Err(strategy_parse_error("conditional re-induction depth must be at most 3")); }
            let induction = named.optional_usize(&["induction"], "induction shape")?.unwrap_or(0);
            if induction > 7 { return Err(strategy_parse_error("conditional induction shape must be 0..7")); }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::ConditionalPolynomial { max_coefficient, degree, before, after, squares: squares == 1, reinduct, induction }));
        }
        if let Some(inner) = function_arguments(input, "exact-general-red-pair") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-general-red-pair")?;
            let encoded = named.value(&["hex"], "hex-encoded general reduction-pair witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-general-red-pair")?;
            let (payload_xml, strict_indices, bound_indices, merge, source_dp_input_xml) =
                if let Ok((p,s,b,m,source)) = serde_json::from_slice::<(String, Vec<usize>, Vec<usize>, bool, String)>(&bytes) {
                    (p,s,b,m,Some(source))
                } else {
                    let (p,s,b,m) = serde_json::from_slice::<(String, Vec<usize>, Vec<usize>, bool)>(&bytes)
                        .map_err(|_| strategy_parse_error("invalid general reduction-pair witness"))?;
                    (p,s,b,m,None)
                };
            if payload_xml.is_empty() || strict_indices.is_empty() || bound_indices.is_empty() {
                return Err(strategy_parse_error(
                    "incomplete general reduction-pair witness",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactGeneralRedPair {
                    payload_xml,
                    strict_indices,
                    bound_indices,
                    merge,
                    source_dp_input_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-red-pair") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-red-pair")?;
            let encoded = named.value(&["hex"], "hex-encoded reduction-pair witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-red-pair")?;
            let decoded = serde_json::from_slice::<serde_json::Value>(&bytes)
                .map_err(|_| strategy_parse_error("invalid reduction-pair witness"))?;
            let (
                processor_tag,
                payload_xml,
                removed_indices,
                source_pairs_xml,
                source_rules_xml,
                source_weak_pairs_xml,
                source_strict_rules_xml,
            ) = if decoded.as_array().is_some_and(|items| items.len() == 7) {
                let (tag, payload, removed, pairs, rules, weak, strict) =
                    serde_json::from_value::<(
                        String,
                        String,
                        Vec<usize>,
                        String,
                        String,
                        String,
                        String,
                    )>(decoded)
                    .map_err(|_| {
                        strategy_parse_error("invalid generalized reduction-pair witness")
                    })?;
                (
                    tag,
                    payload,
                    removed,
                    Some(pairs),
                    Some(rules),
                    Some(weak),
                    Some(strict),
                )
            } else if decoded.as_array().is_some_and(|items| items.len() == 5) {
                let (tag, payload, removed, pairs, rules) =
                    serde_json::from_value::<(String, String, Vec<usize>, String, String)>(decoded)
                        .map_err(|_| {
                            strategy_parse_error("invalid bound reduction-pair witness")
                        })?;
                (tag, payload, removed, Some(pairs), Some(rules), None, None)
            } else {
                let (tag, payload, removed) =
                    serde_json::from_value::<(String, String, Vec<usize>)>(decoded)
                        .map_err(|_| strategy_parse_error("invalid reduction-pair witness"))?;
                (tag, payload, removed, None, None, None, None)
            };
            if !matches!(
                processor_tag.as_str(),
                "csrRedPairUrProc"
                    | "redPairProc"
                    | "redPairUrProc"
                    | "monoRedPairProc"
                    | "monoRedPairUrProc"
                    | "innermostMonoRedPairProc"
            ) || payload_xml.is_empty()
                || (removed_indices.is_empty()
                    && !matches!(
                        processor_tag.as_str(),
                        "monoRedPairProc" | "monoRedPairUrProc" | "innermostMonoRedPairProc"
                    ))
            {
                return Err(strategy_parse_error("incomplete reduction-pair witness"));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactReductionPair {
                    processor_tag,
                    payload_xml,
                    removed_indices,
                    source_pairs_xml,
                    source_rules_xml,
                    source_weak_pairs_xml,
                    source_strict_rules_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-usable-rules") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-usable-rules")?;
            let encoded = named.value(&["hex"], "hex-encoded usable-rules witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-usable-rules")?;
            let decoded = serde_json::from_slice::<serde_json::Value>(&bytes)
                .map_err(|_| strategy_parse_error("invalid usable-rules witness"))?;
            let (payload_xml, source_pairs_xml, source_rules_xml) =
                if decoded.as_array().is_some_and(|items| items.len() == 3) {
                    let (payload, pairs, rules) =
                        serde_json::from_value::<(String, String, String)>(decoded).map_err(
                            |_| strategy_parse_error("invalid bound usable-rules witness"),
                        )?;
                    (payload, Some(pairs), Some(rules))
                } else {
                    let payload = serde_json::from_value::<String>(decoded)
                        .map_err(|_| strategy_parse_error("invalid usable-rules witness"))?;
                    (payload, None, None)
                };
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactUsableRules {
                    payload_xml,
                    source_pairs_xml,
                    source_rules_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-innermost-lhss") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-innermost-lhss")?;
            let encoded = named.value(&["hex"], "hex-encoded innermost-LHS witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-innermost-lhss")?;
            let (payload_xml, source_dp_input_xml) =
                if let Ok((payload, source)) = serde_json::from_slice::<(String, String)>(&bytes) {
                    (payload, Some(source))
                } else {
                    (serde_json::from_slice::<String>(&bytes)
                        .map_err(|_| strategy_parse_error("invalid innermost-LHS witness"))?, None)
                };
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactInnermostLhss { payload_xml, source_dp_input_xml },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-dp-transform") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-dp-transform")?;
            let encoded = named.value(&["hex"], "hex-encoded DP transformation witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-dp-transform")?;
            let (processor_tag, payload_xml, dp_input_xml, source_dp_input_xml) =
                if let Ok((tag, payload, child, source)) = serde_json::from_slice::<(String, String, String, String)>(&bytes) {
                    (tag, payload, child, Some(source))
                } else {
                    let (tag, payload, child) = serde_json::from_slice::<(String, String, String)>(&bytes)
                        .map_err(|_| strategy_parse_error("invalid DP transformation witness"))?;
                    (tag, payload, child, None)
                };
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactDpTransformation {
                    processor_tag,
                    payload_xml,
                    dp_input_xml,
                    source_dp_input_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-dp-no-rule-removal") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-dp-no-rule-removal")?;
            let encoded = named.value(&["hex"], "hex-encoded DP rule-removal witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-dp-no-rule-removal")?;
            let (source_dp_input_xml, residual_dp_input_xml) =
                serde_json::from_slice::<(String, String)>(&bytes).map_err(|_| {
                    strategy_parse_error("invalid DP nontermination rule-removal witness")
                })?;
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactNonterminationRuleRemoval {
                    source_dp_input_xml,
                    residual_dp_input_xml,
                },
            ));
        }
        if input == "switch-full-nontermination" {
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::SwitchFullNontermination,
            ));
        }
        if input == "nontermination(dp-loop)" {
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::NonterminationLoop,
            ));
        }
        if input == "nontermination(dp-nonloop)" {
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::NonterminationNonLoop,
            ));
        }
        if input == "nontermination(dp-symbolic-loop)" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationSymbolicLoop));
        }
        if input == "nontermination(dp-backward-loop)" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationBackwardLoop));
        }
        if input == "nontermination(dp-fork-loop)" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationForkLoop));
        }
        if input == "nontermination(dp-fair-loop)" {
            return Ok(DpStrategy::Processor(DpStrategyProcessor::NonterminationFairLoop));
        }
        if let Some(inner) = function_arguments(input, "exact-dp-loop") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-dp-loop")?;
            let encoded = named.value(&["hex"], "hex-encoded loop witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-dp-loop")?;
            let (source_dp_input_xml, loop_xml) =
                serde_json::from_slice::<(String, String)>(&bytes)
                    .map_err(|_| strategy_parse_error("invalid exact loop witness"))?;
            if !loop_xml.contains("<loop") {
                return Err(strategy_parse_error("missing exact loop fragment"));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactNonterminationLoop {
                    source_dp_input_xml,
                    loop_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-dp-nontermination-proof") {
            crate::proving::processors::reject_retired_complete_nontermination_proof();
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-dp-nontermination-proof")?;
            let encoded = named.value(&["hex"], "hex-encoded DP nontermination proof")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-dp-nontermination-proof")?;
            let (source_dp_input_xml, dp_proof_xml) =
                serde_json::from_slice::<(String, String)>(&bytes).map_err(|_| {
                    strategy_parse_error("invalid exact DP nontermination proof witness")
                })?;
            if !dp_proof_xml.contains("<dpNonterminationProof") {
                return Err(strategy_parse_error(
                    "missing exact DP nontermination proof fragment",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactNonterminationProof {
                    source_dp_input_xml,
                    dp_proof_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-dp-nonloop") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-dp-nonloop")?;
            let encoded = named.value(&["hex"], "hex-encoded non-loop witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-dp-nonloop")?;
            let (source_dp_input_xml, non_loop_xml) =
                serde_json::from_slice::<(String, String)>(&bytes)
                    .map_err(|_| strategy_parse_error("invalid exact non-loop witness"))?;
            if !non_loop_xml.contains("<nonLoop") {
                return Err(strategy_parse_error("missing exact non-loop fragment"));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactNonterminationNonLoop {
                    source_dp_input_xml,
                    non_loop_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-dp-proof") {
            crate::proving::processors::reject_retired_complete_termination_proof();
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-dp-proof")?;
            let encoded = named.value(&["hex"], "hex-encoded DP proof witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-dp-proof")?;
            let (source_dp_input_xml, dp_proof_xml) =
                serde_json::from_slice::<(String, String)>(&bytes)
                    .map_err(|_| strategy_parse_error("invalid exact DP proof witness"))?;
            if !dp_proof_xml.contains("<dpProof") {
                return Err(strategy_parse_error("missing exact DP proof fragment"));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactTerminationProof {
                    source_dp_input_xml,
                    dp_proof_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-split") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-split")?;
            let encoded = named.value(&["hex"], "hex-encoded split witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-split")?;
            let (selected_pair_index, selected_rule_index, source_dp_input_xml) = if let Ok(value) =
                serde_json::from_slice::<(Option<usize>, Option<usize>, String)>(&bytes)
            {
                value
            } else {
                let (pair, source) = serde_json::from_slice::<(usize, String)>(&bytes)
                    .map_err(|_| strategy_parse_error("invalid exact split witness"))?;
                (Some(pair), None, source)
            };
            if selected_pair_index.is_some() == selected_rule_index.is_some() {
                return Err(strategy_parse_error(
                    "exact split must select exactly one pair or ordinary rule",
                ));
            }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::ExactSplit {
                selected_pair_index,
                selected_rule_index,
                source_dp_input_xml,
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-path-order") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-path-order")?;
            let encoded = named.value(&["hex"], "hex-encoded path-order witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-path-order")?;
            let (default_order, statuses, precedence, precedence_ranks, argument_filter): (
                DpPathOrderKind,
                BTreeMap<String, DpPathOrderKind>,
                Vec<String>,
                BTreeMap<String, usize>,
                DpArgumentFilter,
            ) = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact path-order witness"))?;
            if precedence_ranks.is_empty() {
                return Err(strategy_parse_error(
                    "exact path-order witness has an empty precedence",
                ));
            }
            return Ok(DpStrategy::Processor(DpStrategyProcessor::ExactPathOrder {
                default_order,
                statuses,
                precedence,
                precedence_ranks,
                argument_filter,
            }));
        }
        if let Some(inner) = function_arguments(input, "weights") {
            let max_weight = parse_numeric_or_named_i64(
                inner,
                "weights",
                &["weight", "max-weight", "max_weight"],
            )?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::SymbolWeights {
                max_weight,
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-mono-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-mono-poly")?;
            let encoded = named.value(&["hex"], "hex-encoded monotonic polynomial witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(strategy_parse_error(
                    "exact-mono-poly hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits)
                        .map_err(|_| strategy_parse_error("invalid exact-mono-poly hex witness"))?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| strategy_parse_error("invalid exact-mono-poly hex witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, i64, Vec<i64>)> = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-mono-poly polynomial witness"))?;
            if interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-mono-poly polynomial witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactMonotonicPolynomial { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-poly")?;
            let encoded = named.value(&["hex"], "hex-encoded polynomial witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(strategy_parse_error(
                    "exact-poly hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits)
                        .map_err(|_| strategy_parse_error("invalid exact-poly hex witness"))?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| strategy_parse_error("invalid exact-poly hex witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, i64, Vec<i64>)> = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-poly polynomial witness"))?;
            if interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-poly polynomial witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactLinearPolynomial { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-weak-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-weak-poly")?;
            let encoded = named.value(&["hex"], "hex-encoded weak polynomial witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(strategy_parse_error(
                    "exact-weak-poly hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits)
                        .map_err(|_| strategy_parse_error("invalid exact-weak-poly witness"))?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| strategy_parse_error("invalid exact-weak-poly witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, i64, Vec<i64>)> = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-weak-poly witness"))?;
            if interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-weak-poly witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactWeakPolynomial { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-max-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-max-poly")?;
            let encoded = named.value(&["hex"], "hex-encoded max-polynomial witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-max-poly")?;
            let interpretation: MaxPolynomialSummary = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-max-poly witness"))?;
            if interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-max-poly witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactMaxPolynomial { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-wpo-max") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-wpo-max")?;
            let encoded = named.value(&["hex"], "hex-encoded WPO(max) witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-wpo-max")?;
            let witness: super::DpWpoMaxWitness = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-wpo-max witness"))?;
            if witness.interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-wpo-max witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactWeightedPathOrderMax { witness },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-rat-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-rat-poly")?;
            let encoded = named.value(&["hex"], "hex-encoded rational-polynomial witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-rat-poly")?;
            let (denominator, interpretation): (i64, Vec<(String, i64, Vec<i64>)>) =
                serde_json::from_slice(&bytes)
                    .map_err(|_| strategy_parse_error("invalid exact-rat-poly witness"))?;
            if denominator <= 0 || interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-rat-poly requires a positive denominator and nonempty witness",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactRationalPolynomial {
                    denominator,
                    interpretation,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-rat-natural-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-rat-natural-poly")?;
            let encoded =
                named.value(&["hex"], "hex-encoded rational natural-polynomial witness")?;
            let bytes = decode_exact_witness_hex(encoded, "exact-rat-natural-poly")?;
            let (denominator, delta, interpretation): (
                i64,
                i64,
                Vec<(String, i64, Vec<i64>, Vec<Vec<i64>>)>,
            ) = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-rat-natural-poly witness"))?;
            if denominator <= 0 || delta <= 0 || interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-rat-natural-poly requires positive denominator/delta and nonempty witness",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactRationalNaturalPolynomial {
                    denominator,
                    delta,
                    interpretation,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-matrix") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-matrix")?;
            let encoded = named.value(&["hex"], "hex-encoded matrix witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(strategy_parse_error(
                    "exact-matrix hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits)
                        .map_err(|_| strategy_parse_error("invalid exact-matrix hex witness"))?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| strategy_parse_error("invalid exact-matrix hex witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)> =
                serde_json::from_slice(&bytes)
                    .map_err(|_| strategy_parse_error("invalid exact-matrix witness"))?;
            if interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-matrix witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactMatrixInterpretation { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-arctic") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "exact-arctic")?;
            let encoded = named.value(&["hex"], "hex-encoded Arctic matrix witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(strategy_parse_error(
                    "exact-arctic hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits)
                        .map_err(|_| strategy_parse_error("invalid exact-arctic hex witness"))?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| strategy_parse_error("invalid exact-arctic hex witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let (integer_domain, interpretation): (
                bool,
                Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>,
            ) = serde_json::from_slice(&bytes)
                .map_err(|_| strategy_parse_error("invalid exact-arctic witness"))?;
            if interpretation.is_empty() {
                return Err(strategy_parse_error(
                    "exact-arctic witness must not be empty",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::ExactArcticMatrixInterpretation {
                    integer_domain,
                    interpretation,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "poly") {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "poly")?;
            let args = split_top_level(inner, ',');
            let candidate_index = if args.iter().any(|arg| arg.contains('=')) {
                NamedStrategyArgs::parse(&args, "poly")?.optional_usize(
                    &["candidate", "candidate-index", "candidate_index"],
                    "candidate index",
                )?
            } else {
                None
            };
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    candidate_index,
                },
                None => DpStrategyProcessor::LinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                },
            }));
        }
        if let Some(inner) = function_arguments(input, "poly-target") {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "poly-target")?;
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "poly-target")?;
            let strict_pair_indices = named
                .value(
                    &["strict", "strict-pairs", "strict_pairs"],
                    "strict pair indices",
                )?
                .split('+')
                .map(|index| {
                    index
                        .parse::<usize>()
                        .map_err(|_| strategy_parse_error("invalid strict pair index"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            if strict_pair_indices.is_empty() {
                return Err(strategy_parse_error(
                    "polynomial target must delete at least one pair",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::TargetLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    strict_pair_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "poly-min-delete") {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "poly-min-delete")?;
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "poly-min-delete")?;
            let min_delete = named
                .value(&["min-delete", "min_delete"], "minimum deletion count")?
                .parse::<usize>()
                .map_err(|_| strategy_parse_error("invalid minimum deletion count"))?;
            let residual_budget = named
                .value(&["residual-budget", "residual_budget"], "residual budget")?
                .parse::<usize>()
                .map_err(|_| strategy_parse_error("invalid residual budget"))?;
            if min_delete == 0 || residual_budget != 1 {
                return Err(strategy_parse_error(
                    "polynomial minimum deletion requires min-delete > 0 and residual-budget=1",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::MinimumDeletionLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    min_delete,
                    residual_budget,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "mono-poly")
            .or_else(|| function_arguments(input, "monotonic-poly"))
            .or_else(|| function_arguments(input, "monotonic-polynomial"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "mono-poly")?;
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::MonotonicPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "sat-poly")
            .or_else(|| function_arguments(input, "sat-polynomial"))
            .or_else(|| function_arguments(input, "sat"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "sat-poly")?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::SatPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            }));
        }
        if let Some(inner) = function_arguments(input, "weak-poly")
            .or_else(|| function_arguments(input, "weak-polynomial"))
            .or_else(|| function_arguments(input, "negative-poly"))
            .or_else(|| function_arguments(input, "negative-polynomial"))
        {
            let (min_constant, max_constant, max_coefficient, max_symbols, max_arity) =
                parse_weak_polynomial_bounds(inner, "weak-poly")?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::WeakPolynomial {
                min_constant,
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            }));
        }
        if let Some(inner) = function_arguments(input, "weak-poly-target") {
            let (min_constant, max_constant, max_coefficient, max_symbols, max_arity) =
                parse_weak_polynomial_bounds(inner, "weak-poly-target")?;
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "weak-poly-target")?;
            let strict_pair_indices = named
                .value(
                    &["strict", "strict-pairs", "strict_pairs"],
                    "strict pair indices",
                )?
                .split('+')
                .map(|index| {
                    index
                        .parse::<usize>()
                        .map_err(|_| strategy_parse_error("invalid strict pair index"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            if strict_pair_indices.is_empty() {
                return Err(strategy_parse_error(
                    "weak polynomial target must delete at least one pair",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::TargetWeakPolynomial {
                    min_constant,
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    strict_pair_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "wpo-max") {
            let (max_constant, max_coefficient, alternatives, max_symbols, max_arity) =
                parse_max_polynomial_bounds(inner, "wpo-max")?;
            let args = split_top_level(inner, ',');
            let all_strict = if args.iter().any(|arg| arg.contains('=')) {
                let named = NamedStrategyArgs::parse(&args, "wpo-max")?;
                match named.optional_usize(&["all-strict"], "all-strict flag")? {
                    None | Some(0) => false,
                    Some(1) => true,
                    _ => return Err(strategy_parse_error("all-strict must be 0 or 1")),
                }
            } else { false };
            let permutations = if args.iter().any(|arg| arg.contains('=')) {
                let named = NamedStrategyArgs::parse(&args, "wpo-max")?;
                match named.optional_usize(&["permutations"], "permutations flag")? {
                    None | Some(0) => false,
                    Some(1) => true,
                    _ => return Err(strategy_parse_error("permutations must be 0 or 1")),
                }
            } else { false };
            let compact_ground = if args.iter().any(|arg| arg.contains('=')) {
                let named = NamedStrategyArgs::parse(&args, "wpo-max")?;
                match named.optional_usize(&["compact-ground"], "compact ground flag")? {
                    None => permutations,
                    Some(0) => false,
                    Some(1) => true,
                    _ => return Err(strategy_parse_error("compact-ground must be 0 or 1")),
                }
            } else { false };
            let ordered_alternatives = if args.iter().any(|arg| arg.contains('=')) {
                let named = NamedStrategyArgs::parse(&args, "wpo-max")?;
                match named.optional_usize(&["ordered-alternatives"], "alternative symmetry flag")? {
                    None | Some(0) => false,
                    Some(1) => true,
                    _ => return Err(strategy_parse_error("ordered-alternatives must be 0 or 1")),
                }
            } else { false };
            return Ok(DpStrategy::Processor(DpStrategyProcessor::WeightedPathOrderMax {
                max_constant, max_coefficient, alternatives, max_symbols, max_arity, all_strict, permutations, compact_ground, ordered_alternatives,
            }));
        }
        if let Some(inner) = function_arguments(input, "max-polo")
            .or_else(|| function_arguments(input, "max-poly"))
            .or_else(|| function_arguments(input, "max-polynomial"))
        {
            let (max_constant, max_coefficient, alternatives, max_symbols, max_arity) =
                parse_max_polynomial_bounds(inner, "max-polo")?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::MaxPolynomial {
                max_constant,
                max_coefficient,
                alternatives,
                max_symbols,
                max_arity,
            }));
        }
        if let Some(inner) = function_arguments(input, "rat-poly")
            .or_else(|| function_arguments(input, "rational-poly"))
            .or_else(|| function_arguments(input, "rational-polynomial"))
            .or_else(|| function_arguments(input, "rat-quadratic-poly"))
        {
            let (
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                denominator,
                delta_denominator,
            ) = parse_rational_polynomial_bounds(inner, "rat-poly")?;
            if input.starts_with("rat-quadratic-poly(") {
                let args = split_top_level(inner, ',');
                let named = if args.iter().any(|arg| arg.contains('=')) {
                    Some(NamedStrategyArgs::parse(&args, "rat-quadratic-poly")?)
                } else { None };
                let coefficient_values = named.as_ref().and_then(|n| n.optional_value(&["coefficients"]))
                    .map(|values| values.split('+').map(|v| v.parse::<i64>()
                        .map_err(|_| strategy_parse_error("invalid quadratic coefficient domain")))
                        .collect::<Result<Vec<_>, _>>()).transpose()?.unwrap_or_default();
                if coefficient_values.iter().any(|v| *v < 0)
                    || (!coefficient_values.is_empty() && !coefficient_values.contains(&0)) {
                    return Err(strategy_parse_error("quadratic coefficient domain must be nonnegative and contain zero"));
                }
                let max_quadratic_terms = named.as_ref().and_then(|n| n.optional_value(&["quadratic-terms"]))
                    .map(|v| v.parse::<usize>().map_err(|_| strategy_parse_error("invalid quadratic sparsity bound"))).transpose()?;
                let quadratic_shape = named.as_ref().and_then(|n| n.optional_value(&["quadratic-shape"]))
                    .unwrap_or("any").to_owned();
                if !matches!(quadratic_shape.as_str(), "any" | "multilinear" | "unary-squares") {
                    return Err(strategy_parse_error("quadratic-shape must be any, multilinear or unary-squares"));
                }
                let solver = if args.iter().any(|arg| arg.contains('=')) {
                    NamedStrategyArgs::parse(&args, "rat-quadratic-poly")?
                        .optional_value(&["solver"]).map(str::to_owned)
                } else { None };
                if solver.as_deref().is_some_and(|solver| !matches!(solver, "z3" | "cvc5")) {
                    return Err(strategy_parse_error("rat-quadratic-poly solver must be z3 or cvc5"));
                }
                return Ok(DpStrategy::Processor(DpStrategyProcessor::RationalQuadraticPolynomial {
                    max_constant, max_coefficient, max_symbols, max_arity,
                    denominator, delta_denominator, solver,
                    coefficient_values, max_quadratic_terms, quadratic_shape,
                }));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::RationalPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    denominator,
                    delta_denominator,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "rat-poly-target") {
            let (
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                denominator,
                delta_denominator,
            ) = parse_rational_polynomial_bounds(inner, "rat-poly-target")?;
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "rat-poly-target")?;
            let min_delete = named
                .value(&["min-delete", "min_delete"], "minimum deletion count")?
                .parse::<usize>()
                .map_err(|_| strategy_parse_error("invalid minimum deletion count"))?;
            let residual_budget = named
                .value(&["residual-budget", "residual_budget"], "residual budget")?
                .parse::<usize>()
                .map_err(|_| strategy_parse_error("invalid residual budget"))?;
            if min_delete == 0 || residual_budget != 1 {
                return Err(strategy_parse_error(
                    "rational target requires min-delete > 0 and residual-budget=1",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::TargetRationalPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    denominator,
                    delta_denominator,
                    min_delete,
                    residual_budget,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "smt-poly")
            .or_else(|| function_arguments(input, "smt-polynomial"))
            .or_else(|| function_arguments(input, "smt"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "smt-poly")?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::SmtPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            }));
        }
        if let Some(inner) = function_arguments(input, "quadratic-poly")
            .or_else(|| function_arguments(input, "quadratic-polynomial"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "quadratic-poly")?;
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::QuadraticPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "matrix")
            .or_else(|| function_arguments(input, "matrix-interpretation"))
            .or_else(|| function_arguments(input, "matrix-interpretations"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "matrix")?;
            let dimension = parse_named_dimension(inner, "matrix")?.unwrap_or(2);
            let min_nonzero = parse_named_min_nonzero(inner, "matrix")?;
            let max_nonzero = parse_named_max_nonzero(inner, "matrix")?;
            let max_nonzero_constants = parse_named_max_nonzero_constants(inner, "matrix")?;
            let max_nonzero_per_row = parse_named_max_nonzero_per_row(inner, "matrix")?;
            let args = split_top_level(inner, ',');
            let candidate_index = if args.iter().any(|arg| arg.contains('=')) {
                NamedStrategyArgs::parse(&args, "matrix")?.optional_usize(
                    &["candidate", "candidate-index", "candidate_index"],
                    "candidate index",
                )?
            } else {
                None
            };
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedMatrixInterpretation {
                    dimension,
                    max_constant,
                    max_coefficient,
                    min_nonzero,
                    max_nonzero,
                    max_nonzero_constants,
                    max_nonzero_per_row,
                    max_symbols,
                    max_arity,
                    candidate_index,
                },
                None => DpStrategyProcessor::MatrixInterpretation {
                    dimension,
                    max_constant,
                    max_coefficient,
                    min_nonzero,
                    max_nonzero,
                    max_nonzero_constants,
                    max_nonzero_per_row,
                    max_symbols,
                    max_arity,
                },
            }));
        }
        if let Some(inner) = function_arguments(input, "integer-matrix")
            .or_else(|| function_arguments(input, "integer-matrix-interpretation"))
        {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "integer-matrix")?;
            let dimension = parse_named_dimension(inner, "integer-matrix")?.unwrap_or(2);
            let min_value =
                named.required_i64(&["min", "min-value", "min_value"], "minimum value")?;
            let max_value =
                named.required_i64(&["max", "max-value", "max_value"], "maximum value")?;
            if min_value > max_value {
                return Err(strategy_parse_error(
                    "integer-matrix minimum exceeds maximum",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::IntegerMatrixInterpretation {
                    dimension,
                    min_value,
                    max_value,
                    max_symbols: named
                        .optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?,
                    max_arity: named
                        .optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "arctic-matrix")
            .or_else(|| function_arguments(input, "arctic-matrix-interpretation"))
            .or_else(|| function_arguments(input, "arctic-matrix-cached"))
        {
            let shared = function_arguments(input, "arctic-matrix-cached").is_some();
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "arctic-matrix")?;
            let dimension = parse_named_dimension(inner, "arctic-matrix")?.unwrap_or(2);
            let max_nonzero = parse_named_max_nonzero(inner, "arctic-matrix")?;
            let args = split_top_level(inner, ',');
            let candidate_index = if args.iter().any(|arg| arg.contains('=')) {
                NamedStrategyArgs::parse(&args, "arctic-matrix")?.optional_usize(
                    &["candidate", "candidate-index", "candidate_index"],
                    "candidate index",
                )?
            } else {
                None
            };
            let threshold = if args.iter().any(|arg| arg.contains('=')) {
                match NamedStrategyArgs::parse(&args, "arctic-matrix")?.optional_value(&["encoding"]) {
                    None | Some("bv") => false,
                    Some("threshold") => true,
                    _ => return Err(strategy_parse_error("arctic-matrix encoding must be bv or threshold")),
                }
            } else { false };
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => DpStrategyProcessor::SelectedArcticMatrixInterpretation {
                    threshold,
                    shared,
                    dimension,
                    max_constant,
                    max_coefficient,
                    max_nonzero,
                    max_symbols,
                    max_arity,
                    candidate_index,
                },
                None => DpStrategyProcessor::ArcticMatrixInterpretation {
                    threshold,
                    shared,
                    dimension,
                    max_constant,
                    max_coefficient,
                    max_nonzero,
                    max_symbols,
                    max_arity,
                },
            }));
        }
        if let Some(inner) = function_arguments(input, "arctic-target")
            .or_else(|| function_arguments(input, "arctic-target-cached")) {
            let shared = function_arguments(input, "arctic-target-cached").is_some();
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_polynomial_bounds(inner, "arctic-target")?;
            let dimension = parse_named_dimension(inner, "arctic-target")?.unwrap_or(2);
            let max_nonzero = parse_named_max_nonzero(inner, "arctic-target")?;
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "arctic-target")?;
            let threshold = match named.optional_value(&["encoding"]) {
                None | Some("bv") => false,
                Some("threshold") => true,
                _ => return Err(strategy_parse_error("arctic-target encoding must be bv or threshold")),
            };
            let symmetry = match named.optional_value(&["symmetry"]) {
                None | Some("false") => false,
                Some("true") => true,
                _ => return Err(strategy_parse_error("arctic-target symmetry must be true or false")),
            };
            let solver = named.optional_value(&["solver"]).map(str::to_owned);
            if solver.as_deref().is_some_and(|s| !["z3", "cvc5", "boolector"].contains(&s)) {
                return Err(strategy_parse_error("arctic-target solver must be z3, cvc5 or boolector"));
            }
            let strict_text = named
                .value(
                    &["strict", "strict-pairs", "strict_pairs"],
                    "strict pair indices",
                )?;
            let strict_pair_indices = if strict_text == "all" { None } else { Some(strict_text.split('+')
                .map(|index| {
                    index
                        .parse::<usize>()
                        .map_err(|_| strategy_parse_error("invalid strict pair index"))
                })
                .collect::<Result<Vec<_>, _>>()?) };
            if strict_pair_indices.as_ref().is_some_and(Vec::is_empty) {
                return Err(strategy_parse_error(
                    "Arctic target must delete at least one pair",
                ));
            }
            return Ok(DpStrategy::Processor(
                DpStrategyProcessor::TargetArcticMatrixInterpretation {
                    threshold,
                    shared,
                    symmetry,
                    solver,
                    dimension,
                    max_constant,
                    max_coefficient,
                    max_nonzero,
                    max_symbols,
                    max_arity,
                    strict_pair_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "qpi").or_else(|| function_arguments(input, "qpi-bv")) {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "qpi")?;
            let period = named.optional_usize(&["period"], "period")?.unwrap_or(3);
            let max_weight = named.required_i64(&["max-weight"], "maximum weight")?;
            if !(1..=16).contains(&period) || !(0..=64).contains(&max_weight) {
                return Err(strategy_parse_error("qpi requires period 1..16 and max-weight 0..64"));
            }
            return Ok(DpStrategy::Processor(if function_arguments(input, "qpi-bv").is_some() {
                DpStrategyProcessor::QuasiPeriodicBv { period, max_weight }
            } else { DpStrategyProcessor::QuasiPeriodic { period, max_weight } }));
        }
        if let Some(inner) = function_arguments(input, "integer-arctic-matrix") {
            let args = split_top_level(inner, ',');
            let named = NamedStrategyArgs::parse(&args, "integer-arctic-matrix")?;
            let all_strict=match named.optional_value(&["strict"]) {
                None|Some("any")=>false,
                Some("all")=>true,
                _=>return Err(strategy_parse_error("integer-arctic-matrix strict must be any or all")),
            };
            let max_finite_per_row=named.optional_usize(&["max-finite-per-row"],"finite entries per row")?;
            if max_finite_per_row.is_some_and(|n|n>64) {return Err(strategy_parse_error("max-finite-per-row must be at most 64"));}
            let optimize = match named.optional_value(&["optimize"]) {
                None | Some("true") => true,
                Some("false") => false,
                _ => return Err(strategy_parse_error("integer-arctic-matrix optimize must be true or false")),
            };
            let root_projection = match named.optional_value(&["root-projection"]) {
                None | Some("false") => false,
                Some("true") => true,
                _ => return Err(strategy_parse_error("integer-arctic-matrix root-projection must be true or false")),
            };
            let bitvectors = match named.optional_value(&["encoding"]) {
                None | Some("lia") => false,
                Some("bv" | "threshold") => true,
                _ => return Err(strategy_parse_error("integer-arctic-matrix encoding must be lia, bv or threshold")),
            };
            let threshold = named.optional_value(&["encoding"]) == Some("threshold");
            let symmetry = match named.optional_value(&["symmetry"]) {
                None | Some("false") => false,
                Some("true") => true,
                _ => return Err(strategy_parse_error("integer-arctic-matrix symmetry must be true or false")),
            };
            let solver = named.optional_value(&["solver"]).map(str::to_owned);
            if solver.as_deref().is_some_and(|s| !matches!(s, "z3" | "cvc5")) {
                return Err(strategy_parse_error("integer-arctic-matrix solver must be z3 or cvc5"));
            }
            let dimension = parse_named_dimension(inner, "integer-arctic-matrix")?.unwrap_or(1);
            let min_value =
                named.required_i64(&["min", "min-value", "min_value"], "minimum finite value")?;
            let max_value =
                named.required_i64(&["max", "max-value", "max_value"], "maximum finite value")?;
            if min_value > max_value {
                return Err(strategy_parse_error(
                    "integer-arctic-matrix minimum exceeds maximum",
                ));
            }
            let candidate_index = named.optional_usize(
                &["candidate", "candidate-index", "candidate_index"],
                "candidate index",
            )?;
            let max_symbols =
                named.optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?;
            let max_arity =
                named.optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?;
            return Ok(DpStrategy::Processor(match candidate_index {
                Some(candidate_index) => {
                    DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation {
                        threshold,
                        all_strict,
                        max_finite_per_row,
                        bitvectors,
                        root_projection,
                        optimize,
                        symmetry,
                        solver,
                        dimension,
                        min_value,
                        max_value,
                        max_symbols,
                        max_arity,
                        candidate_index,
                    }
                }
                None => DpStrategyProcessor::IntegerArcticMatrixInterpretation {
                    threshold,
                    all_strict,
                    max_finite_per_row,
                    bitvectors,
                    root_projection,
                    optimize,
                    symmetry,
                    solver,
                    dimension,
                    min_value,
                    max_value,
                    max_symbols,
                    max_arity,
                },
            }));
        }
        if let Some(inner) = function_arguments(input, "kbo") {
            let (max_weight, max_symbols) = parse_kbo_bounds(inner)?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::Kbo {
                max_weight,
                max_symbols,
            }));
        }
        if let Some(inner) = function_arguments(input, "symbol-weights")
            .or_else(|| function_arguments(input, "symbol-weight"))
            .or_else(|| function_arguments(input, "weights"))
        {
            let max_weight = parse_symbol_weight_bound(inner)?;
            return Ok(DpStrategy::Processor(DpStrategyProcessor::SymbolWeights {
                max_weight,
            }));
        }
        match input.to_ascii_lowercase().as_str() {
            "graph-refined" => Ok(DpStrategy::Processor(DpStrategyProcessor::RefinedDependencyGraph)),
            "graph" | "depgraph" | "dependency-graph" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::DependencyGraph))
            }
            "usable-rules" | "usable-rules-proc" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::UsableRules))
            }
            "muterm-expand" | "muterm-expanded" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::MutermExpand))
            }
            "innermost-lhss" | "innermost-lhss-removal" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::InnermostLhss))
            }
            "split" | "dp-split" => Ok(DpStrategy::Processor(DpStrategyProcessor::Split)),
            "gm04-rpo" => Ok(DpStrategy::Processor(DpStrategyProcessor::Gm04AdministrativeRpo)),
            "complex-constant-removal" => Ok(DpStrategy::Processor(DpStrategyProcessor::ComplexConstantRemoval)),
            "complex-constant-removal-largest" => Ok(DpStrategy::Processor(DpStrategyProcessor::LargestComplexConstantRemoval)),
            "switch-innermost" | "switchinnermost" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SwitchInnermost))
            }
            "qdp-to-srs" | "qdptosrs" => Ok(DpStrategy::Processor(DpStrategyProcessor::QdpToSrs)),
            "switch-to-trs" | "switchtotrs" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SwitchToTrs))
            }
            "semlab" | "semantic-labeling" | "semantic-labelling" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SemanticLabeling))
            }
            "root-labeling" | "root-labelling" | "rootlab" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::RootLabeling))
            }
            "uncurry" | "uncurrying" => Ok(DpStrategy::Processor(DpStrategyProcessor::Uncurry)),
            "uncurry-below" | "uncurrying-below" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::UncurryBelow))
            }
            "applicative-reduction-pair" | "applicative-orders" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::ApplicativeReductionPair,
            )),
            "subterm" => Ok(DpStrategy::Processor(DpStrategyProcessor::Subterm)),
            "sct" | "sizechange" | "size-change" | "size-change-proc" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SizeChange))
            }
            "component-portfolio" | "portfolio" => Ok(DpStrategy::default_component_portfolio()),
            "transform-portfolio" | "transforms" => Ok(DpStrategy::default_transform_portfolio(
                RewriteStrategy::Innermost,
            )),
            "orders" | "order" | "redpair" | "red-pair" | "reduction-pairs" => {
                Ok(DpStrategy::standard_orders())
            }
            "llm" => Ok(DpStrategy::Processor(DpStrategyProcessor::Llm)),
            "weights" | "weights1" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SymbolWeights {
                    max_weight: 1,
                }))
            }
            "weights2" => Ok(DpStrategy::Processor(DpStrategyProcessor::SymbolWeights {
                max_weight: 2,
            })),
            "poly01" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::LinearPolynomial {
                    max_constant: 0,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "poly11" | "linear-poly" | "linear-polynomial" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::LinearPolynomial {
                    max_constant: 1,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "poly21" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::LinearPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "poly22" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::LinearPolynomial {
                    max_constant: 2,
                    max_coefficient: 2,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "mono-poly" | "monotonic-poly" | "monotonic-polynomial" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::MonotonicPolynomial {
                    max_constant: 2,
                    max_coefficient: 2,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "sat" | "sat-poly" | "sat-polynomial" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SatPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                }))
            }
            "weak-poly" | "weak-polynomial" | "negative-poly" | "negative-polynomial" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::WeakPolynomial {
                    min_constant: -2,
                    max_constant: 2,
                    max_coefficient: 2,
                    max_symbols: None,
                    max_arity: None,
                }))
            }
            "max-polo" | "max-poly" | "max-polynomial" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::MaxPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    alternatives: 2,
                    max_symbols: None,
                    max_arity: None,
                }))
            }
            "rat" | "rat-poly" | "rational-poly" | "rational-polynomial" => Ok(
                DpStrategy::Processor(DpStrategyProcessor::RationalPolynomial {
                    max_constant: 16,
                    max_coefficient: 16,
                    max_symbols: None,
                    max_arity: None,
                    denominator: 4,
                    delta_denominator: 16,
                }),
            ),
            "matrix" | "matrix-interpretation" | "matrix-interpretations" => Ok(
                DpStrategy::Processor(DpStrategyProcessor::MatrixInterpretation {
                    dimension: 2,
                    max_constant: 2,
                    max_coefficient: 1,
                    min_nonzero: None,
                    max_nonzero: None,
                    max_nonzero_constants: None,
                    max_nonzero_per_row: None,
                    max_symbols: None,
                    max_arity: None,
                }),
            ),
            "matrix1" | "matrix-1" | "matrix-dim1" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::MatrixInterpretation {
                    dimension: 1,
                    max_constant: 2,
                    max_coefficient: 1,
                    min_nonzero: None,
                    max_nonzero: None,
                    max_nonzero_constants: None,
                    max_nonzero_per_row: None,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "matrix2" | "matrix-2" | "matrix-dim2" => Ok(DpStrategy::Processor(
                DpStrategyProcessor::MatrixInterpretation {
                    dimension: 2,
                    max_constant: 2,
                    max_coefficient: 1,
                    min_nonzero: None,
                    max_nonzero: None,
                    max_nonzero_constants: None,
                    max_nonzero_per_row: None,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "smt" | "smt-poly" | "smt-polynomial" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::SmtPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                }))
            }
            "rpo" | "path" | "path-order" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::PathOrder))
            }
            "kbo" => Ok(DpStrategy::Processor(DpStrategyProcessor::Kbo {
                max_weight: 2,
                max_symbols: KBO_SMT_SYMBOL_LIMIT,
            })),
            "rewrite" | "rewriting" => Ok(DpStrategy::Processor(DpStrategyProcessor::Rewriting {
                max_per_pair: None,
            })),
            "narrow" | "narrowing" => Ok(DpStrategy::Processor(DpStrategyProcessor::Narrowing {
                max_per_pair: None,
            })),
            "alpha-merge" => Ok(DpStrategy::Processor(DpStrategyProcessor::AlphaMerge)),
            "gm04-source-csr" => Ok(DpStrategy::Processor(DpStrategyProcessor::Gm04SourceCsr)),
            "instantiate" | "instantiation" => {
                Ok(DpStrategy::Processor(DpStrategyProcessor::Instantiation {
                    max_per_pair: None,
                }))
            }
            "forward-instantiate" | "forward-instantiation" | "forward-instantiation-proc" => {
                Ok(DpStrategy::Processor(
                    DpStrategyProcessor::ForwardInstantiation { max_per_pair: None },
                ))
            }
            "" => Err(strategy_parse_error("empty strategy atom")),
            atom => Err(strategy_parse_error(format!(
                "unknown strategy atom `{atom}`"
            ))),
        }
    }
}

fn parse_symbol_weight_bound(inner: &str) -> Result<i64, DpStrategyParseError> {
    let args = split_top_level(inner, ',');
    if args.is_empty() {
        return Ok(1);
    }
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, "symbol-weights")?;
        let Some(value) = named.optional_value(&["weight", "max-weight", "max_weight"]) else {
            return Ok(1);
        };
        return value
            .parse()
            .map_err(|_| strategy_parse_error("symbol-weights max-weight must be numeric"));
    }
    if args.len() != 1 {
        return Err(strategy_parse_error(
            "symbol-weights expects an optional max weight",
        ));
    }
    args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error("symbol-weights max-weight must be numeric"))
}

fn strategy_parse_error(message: impl Into<String>) -> DpStrategyParseError {
    DpStrategyParseError {
        message: message.into(),
    }
}

fn parse_polynomial_bounds(
    input: &str,
    atom: &str,
) -> Result<(i64, i64, Option<usize>, Option<usize>), DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, atom)?;
        let max_constant = named.required_i64(
            &["const", "constant", "max-constant", "max_constant"],
            "constant",
        )?;
        let max_coefficient = named.required_i64(
            &[
                "coeff",
                "coefficient",
                "max-coeff",
                "max-coefficient",
                "max_coefficient",
            ],
            "coefficient",
        )?;
        return Ok((
            max_constant,
            max_coefficient,
            named.optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?,
            named.optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?,
        ));
    }
    if args.len() != 2 && args.len() != 4 {
        return Err(strategy_parse_error(format!(
            "{atom} expects max constant and max coefficient, optionally max symbols and max arity"
        )));
    }
    let max_constant = args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} constant must be numeric")))?;
    let max_coefficient = args[1]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} coefficient must be numeric")))?;
    let max_symbols = if let Some(value) = args.get(2) {
        Some(
            value
                .trim()
                .parse()
                .map_err(|_| strategy_parse_error(format!("{atom} symbol cap must be numeric")))?,
        )
    } else {
        None
    };
    let max_arity = if let Some(value) = args.get(3) {
        Some(
            value
                .trim()
                .parse()
                .map_err(|_| strategy_parse_error(format!("{atom} arity cap must be numeric")))?,
        )
    } else {
        None
    };
    Ok((max_constant, max_coefficient, max_symbols, max_arity))
}

fn parse_weak_polynomial_bounds(
    input: &str,
    atom: &str,
) -> Result<WeakPolynomialBounds, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, atom)?;
        let min_constant =
            named.required_i64(&["min", "min-constant", "min_constant"], "min constant")?;
        let max_constant = named.required_i64(
            &["const", "constant", "max-constant", "max_constant"],
            "max constant",
        )?;
        let max_coefficient = named.required_i64(
            &[
                "coeff",
                "coefficient",
                "max-coeff",
                "max-coefficient",
                "max_coefficient",
            ],
            "coefficient",
        )?;
        let max_symbols =
            named.optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?;
        let max_arity = named.optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?;
        validate_weak_polynomial_bounds(atom, min_constant, max_constant, max_coefficient)?;
        return Ok((
            min_constant,
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        ));
    }
    if args.len() != 3 && args.len() != 5 {
        return Err(strategy_parse_error(format!(
            "{atom} expects min constant, max constant, and max coefficient, optionally max symbols and max arity"
        )));
    }
    let min_constant = args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} min constant must be numeric")))?;
    let max_constant = args[1]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} max constant must be numeric")))?;
    let max_coefficient = args[2]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} coefficient must be numeric")))?;
    let (max_symbols, max_arity) =
        if args.len() == 5 {
            (
                Some(args[3].trim().parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} symbol cap must be numeric"))
                })?),
                Some(args[4].trim().parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} arity cap must be numeric"))
                })?),
            )
        } else {
            (None, None)
        };
    validate_weak_polynomial_bounds(atom, min_constant, max_constant, max_coefficient)?;
    Ok((
        min_constant,
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
    ))
}

fn parse_transform_limit(input: &str, atom: &str) -> Result<Option<usize>, DpStrategyParseError> {
    let input = input.trim();
    if input.is_empty() {
        return Ok(None);
    }
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, atom)?;
        return named.optional_usize(
            &["max-per-pair", "max_per_pair", "per-pair", "per_pair"],
            "per-pair transform limit",
        );
    }
    if args.len() != 1 {
        return Err(strategy_parse_error(format!(
            "{atom} expects an optional max-per-pair limit"
        )));
    }
    args[0]
        .trim()
        .parse()
        .map(Some)
        .map_err(|_| strategy_parse_error(format!("{atom} max-per-pair must be numeric")))
}

fn parse_transform_selection(
    input: &str,
    atom: &str,
) -> Result<(Option<usize>, Option<usize>), DpStrategyParseError> {
    let input = input.trim();
    if input.is_empty() || !input.contains('=') {
        return Ok((parse_transform_limit(input, atom)?, None));
    }
    let args = split_top_level(input, ',');
    let named = NamedStrategyArgs::parse(&args, atom)?;
    let max_per_pair = named.optional_usize(
        &["max-per-pair", "max_per_pair", "per-pair", "per_pair"],
        "per-pair transform limit",
    )?;
    let candidate_index = named.optional_usize(
        &["candidate", "candidate-index", "candidate_index"],
        "candidate index",
    )?;
    Ok((max_per_pair, candidate_index))
}

fn parse_max_polynomial_bounds(
    input: &str,
    atom: &str,
) -> Result<MaxPolynomialBounds, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, atom)?;
        let max_constant = named.required_i64(
            &["const", "constant", "max-constant", "max_constant"],
            "max constant",
        )?;
        let max_coefficient = named.required_i64(
            &[
                "coeff",
                "coefficient",
                "max-coeff",
                "max-coefficient",
                "max_coefficient",
            ],
            "coefficient",
        )?;
        let alternatives = named.required_usize(
            &["alts", "alternatives", "max-terms", "max_terms"],
            "alternative count",
        )?;
        let max_symbols =
            named.optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?;
        let max_arity = named.optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?;
        validate_max_polynomial_bounds(atom, max_constant, max_coefficient, alternatives)?;
        return Ok((
            max_constant,
            max_coefficient,
            alternatives,
            max_symbols,
            max_arity,
        ));
    }
    if args.len() != 3 && args.len() != 5 {
        return Err(strategy_parse_error(format!(
            "{atom} expects max constant, max coefficient, and alternative count, optionally max symbols and max arity"
        )));
    }
    let max_constant = args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} max constant must be numeric")))?;
    let max_coefficient = args[1]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} coefficient must be numeric")))?;
    let alternatives = args[2]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} alternatives must be numeric")))?;
    let (max_symbols, max_arity) =
        if args.len() == 5 {
            (
                Some(args[3].trim().parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} symbol cap must be numeric"))
                })?),
                Some(args[4].trim().parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} arity cap must be numeric"))
                })?),
            )
        } else {
            (None, None)
        };
    validate_max_polynomial_bounds(atom, max_constant, max_coefficient, alternatives)?;
    Ok((
        max_constant,
        max_coefficient,
        alternatives,
        max_symbols,
        max_arity,
    ))
}

fn parse_rational_polynomial_bounds(
    input: &str,
    atom: &str,
) -> Result<RationalPolynomialBounds, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, atom)?;
        let max_constant = named.required_i64(
            &["const", "constant", "max-constant", "max_constant"],
            "constant",
        )?;
        let max_coefficient = named.required_i64(
            &[
                "coeff",
                "coefficient",
                "max-coeff",
                "max-coefficient",
                "max_coefficient",
            ],
            "coefficient",
        )?;
        let denominator = named.required_i64(&["denom", "denominator"], "denominator")?;
        let delta_denominator = named
            .optional_value(&[
                "delta-denom",
                "delta-denominator",
                "delta_denom",
                "delta_denominator",
            ])
            .map(|value| {
                value.parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} delta denominator must be numeric"))
                })
            })
            .transpose()?
            .unwrap_or(denominator);
        let max_symbols =
            named.optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?;
        let max_arity = named.optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?;
        validate_rational_polynomial_bounds(atom, denominator)?;
        validate_rational_polynomial_bounds(atom, delta_denominator)?;
        return Ok((
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            denominator,
            delta_denominator,
        ));
    }
    if args.len() != 3 && args.len() != 5 {
        return Err(strategy_parse_error(format!(
            "{atom} expects max constant, max coefficient, and denominator, optionally max symbols and max arity before the denominator"
        )));
    }
    let max_constant = args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} constant must be numeric")))?;
    let max_coefficient = args[1]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} coefficient must be numeric")))?;
    let (max_symbols, max_arity, denominator_index) =
        if args.len() == 5 {
            (
                Some(args[2].trim().parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} symbol cap must be numeric"))
                })?),
                Some(args[3].trim().parse().map_err(|_| {
                    strategy_parse_error(format!("{atom} arity cap must be numeric"))
                })?),
                4,
            )
        } else {
            (None, None, 2)
        };
    let denominator = args[denominator_index]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} denominator must be numeric")))?;
    validate_rational_polynomial_bounds(atom, denominator)?;
    Ok((
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
        denominator,
        denominator,
    ))
}

fn parse_numeric_or_named_i64(
    input: &str,
    atom: &str,
    names: &[&str],
) -> Result<i64, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        return NamedStrategyArgs::parse(&args, atom)?.required_i64(names, "value");
    }
    if args.len() != 1 {
        return Err(strategy_parse_error(format!(
            "{atom} expects one numeric value"
        )));
    }
    args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error(format!("{atom} value must be numeric")))
}

fn parse_kbo_bounds(input: &str) -> Result<(i64, usize), DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedStrategyArgs::parse(&args, "kbo")?;
        let max_weight = named.required_i64(&["weight", "max-weight", "max_weight"], "weight")?;
        let max_symbols = named
            .optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?
            .unwrap_or(KBO_SMT_SYMBOL_LIMIT);
        validate_kbo_bounds(max_symbols)?;
        return Ok((max_weight, max_symbols));
    }
    if args.len() != 1 && args.len() != 2 {
        return Err(strategy_parse_error(
            "kbo expects max weight and optionally max symbols",
        ));
    }
    let max_weight = args[0]
        .trim()
        .parse()
        .map_err(|_| strategy_parse_error("kbo weight must be numeric"))?;
    let max_symbols = if let Some(value) = args.get(1) {
        value
            .trim()
            .parse()
            .map_err(|_| strategy_parse_error("kbo symbol cap must be numeric"))?
    } else {
        KBO_SMT_SYMBOL_LIMIT
    };
    validate_kbo_bounds(max_symbols)?;
    Ok((max_weight, max_symbols))
}

fn validate_kbo_bounds(max_symbols: usize) -> Result<(), DpStrategyParseError> {
    if max_symbols == 0 {
        return Err(strategy_parse_error("kbo symbol cap must be positive"));
    }
    Ok(())
}

fn parse_named_dimension(input: &str, atom: &str) -> Result<Option<usize>, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if !args.iter().any(|arg| arg.contains('=')) {
        return Ok(None);
    }
    let dimension = NamedStrategyArgs::parse(&args, atom)?
        .optional_usize(&["dim", "dimension"], "dimension")?;
    if dimension == Some(0) {
        return Err(strategy_parse_error(format!(
            "{atom} dimension must be positive"
        )));
    }
    Ok(dimension)
}

fn parse_named_max_nonzero(input: &str, atom: &str) -> Result<Option<usize>, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if !args.iter().any(|arg| arg.contains('=')) {
        return Ok(None);
    }
    NamedStrategyArgs::parse(&args, atom)?.optional_usize(
        &["max-nonzero", "max_nonzero", "nonzero"],
        "nonzero entry cap",
    )
}

fn parse_named_min_nonzero(input: &str, atom: &str) -> Result<Option<usize>, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if !args.iter().any(|arg| arg.contains('=')) {
        return Ok(None);
    }
    NamedStrategyArgs::parse(&args, atom)?.optional_usize(
        &["min-nonzero", "min_nonzero"],
        "minimum nonzero entry count",
    )
}

fn parse_named_max_nonzero_constants(
    input: &str,
    atom: &str,
) -> Result<Option<usize>, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if !args.iter().any(|arg| arg.contains('=')) {
        return Ok(None);
    }
    NamedStrategyArgs::parse(&args, atom)?.optional_usize(
        &[
            "max-nonzero-constants",
            "max_nonzero_constants",
            "nonzero-constants",
        ],
        "nonzero constant-vector entry cap",
    )
}

fn parse_named_max_nonzero_per_row(
    input: &str,
    atom: &str,
) -> Result<Option<usize>, DpStrategyParseError> {
    let args = split_top_level(input, ',');
    if !args.iter().any(|arg| arg.contains('=')) {
        return Ok(None);
    }
    NamedStrategyArgs::parse(&args, atom)?.optional_usize(
        &[
            "max-nonzero-per-row",
            "max_nonzero_per_row",
            "nonzero-per-row",
        ],
        "nonzero coefficient-matrix row cap",
    )
}

fn validate_weak_polynomial_bounds(
    atom: &str,
    min_constant: i64,
    max_constant: i64,
    max_coefficient: i64,
) -> Result<(), DpStrategyParseError> {
    if min_constant > max_constant {
        return Err(strategy_parse_error(format!(
            "{atom} min constant must not exceed max constant"
        )));
    }
    if max_coefficient < 0 {
        return Err(strategy_parse_error(format!(
            "{atom} coefficient must be nonnegative"
        )));
    }
    Ok(())
}

fn validate_max_polynomial_bounds(
    atom: &str,
    max_constant: i64,
    max_coefficient: i64,
    alternatives: usize,
) -> Result<(), DpStrategyParseError> {
    if max_constant < 0 {
        return Err(strategy_parse_error(format!(
            "{atom} constant must be nonnegative"
        )));
    }
    if max_coefficient < 0 {
        return Err(strategy_parse_error(format!(
            "{atom} coefficient must be nonnegative"
        )));
    }
    if alternatives == 0 {
        return Err(strategy_parse_error(format!(
            "{atom} alternative count must be positive"
        )));
    }
    Ok(())
}

fn validate_rational_polynomial_bounds(
    atom: &str,
    denominator: i64,
) -> Result<(), DpStrategyParseError> {
    if denominator <= 0 {
        return Err(strategy_parse_error(format!(
            "{atom} denominator must be positive"
        )));
    }
    Ok(())
}

struct NamedStrategyArgs {
    values: BTreeMap<String, String>,
    atom: String,
}

impl NamedStrategyArgs {
    fn parse(args: &[&str], atom: &str) -> Result<Self, DpStrategyParseError> {
        let mut values = BTreeMap::new();
        for arg in args {
            let Some((name, value)) = arg.split_once('=') else {
                return Err(strategy_parse_error(format!(
                    "{atom} cannot mix positional and named arguments"
                )));
            };
            let name = normalize_strategy_argument_name(name.trim());
            let value = value.trim();
            if name.is_empty() || value.is_empty() {
                return Err(strategy_parse_error(format!(
                    "{atom} named arguments must be like name=value"
                )));
            }
            if values.insert(name.clone(), value.to_string()).is_some() {
                return Err(strategy_parse_error(format!(
                    "{atom} argument `{name}` is repeated"
                )));
            }
        }
        Ok(Self {
            values,
            atom: atom.to_string(),
        })
    }

    fn required_i64(&self, names: &[&str], label: &str) -> Result<i64, DpStrategyParseError> {
        self.value(names, label)?
            .parse()
            .map_err(|_| strategy_parse_error(format!("{} {label} must be numeric", self.atom)))
    }

    fn required_usize(&self, names: &[&str], label: &str) -> Result<usize, DpStrategyParseError> {
        self.value(names, label)?
            .parse()
            .map_err(|_| strategy_parse_error(format!("{} {label} must be numeric", self.atom)))
    }

    fn optional_usize(
        &self,
        names: &[&str],
        label: &str,
    ) -> Result<Option<usize>, DpStrategyParseError> {
        self.optional_value(names)
            .map(|value| {
                value.parse().map_err(|_| {
                    strategy_parse_error(format!("{} {label} must be numeric", self.atom))
                })
            })
            .transpose()
    }

    fn value(&self, names: &[&str], label: &str) -> Result<&str, DpStrategyParseError> {
        self.optional_value(names)
            .ok_or_else(|| strategy_parse_error(format!("{} missing required {label}", self.atom)))
    }

    fn optional_value(&self, names: &[&str]) -> Option<&str> {
        names
            .iter()
            .map(|name| normalize_strategy_argument_name(name))
            .find_map(|name| self.values.get(&name).map(String::as_str))
    }
}

fn normalize_strategy_argument_name(name: &str) -> String {
    name.trim().to_ascii_lowercase().replace('_', "-")
}

fn parse_strategy_definition(input: &str) -> Result<Option<(String, &str)>, DpStrategyParseError> {
    if let Some(definition) = input.strip_prefix("let ") {
        return parse_named_strategy_definition(definition, '=').map(Some);
    }
    if let Some(definition) = input.strip_prefix("def ") {
        return parse_named_strategy_definition(definition, '=').map(Some);
    }
    if let Some((name, value)) = input.split_once(":=") {
        let name = normalize_strategy_name(name.trim())?;
        if value.trim().is_empty() {
            return Err(strategy_parse_error("strategy definition body is empty"));
        }
        return Ok(Some((name, value)));
    }
    Ok(None)
}

fn parse_named_strategy_definition(
    input: &str,
    separator: char,
) -> Result<(String, &str), DpStrategyParseError> {
    let Some((name, value)) = input.split_once(separator) else {
        return Err(strategy_parse_error(
            "strategy definition must be like `let name = strategy`",
        ));
    };
    let name = normalize_strategy_name(name.trim())?;
    if value.trim().is_empty() {
        return Err(strategy_parse_error("strategy definition body is empty"));
    }
    Ok((name, value))
}

fn normalize_strategy_name(name: &str) -> Result<String, DpStrategyParseError> {
    let name = name.trim();
    if name.is_empty() {
        return Err(strategy_parse_error("strategy definition name is empty"));
    }
    let mut chars = name.chars();
    let Some(first) = chars.next() else {
        return Err(strategy_parse_error("strategy definition name is empty"));
    };
    if !(first.is_ascii_alphabetic() || first == '_') {
        return Err(strategy_parse_error(
            "strategy definition name must start with a letter or underscore",
        ));
    }
    if !chars.all(|ch| ch.is_ascii_alphanumeric() || ch == '_' || ch == '-') {
        return Err(strategy_parse_error(
            "strategy definition name may only contain letters, numbers, underscores, or hyphens",
        ));
    }
    Ok(name.to_ascii_lowercase())
}

fn parse_parallel_arguments(
    parser: &DpStrategyParser<'_>,
    input: &str,
) -> Result<(DpParallelCancel, Vec<DpStrategy>), DpStrategyParseError> {
    let comma_parts = split_top_level(input, ',');
    if let Some((first, rest)) = comma_parts.split_first()
        && let Some(mode) = first.trim().strip_prefix("cancel=")
    {
        let cancel_on = match mode.trim() {
            "proof" | "success" => DpParallelCancel::Proof,
            "progress" => DpParallelCancel::Progress,
            _ => {
                return Err(strategy_parse_error(
                    "parallel cancel mode must be proof or progress",
                ));
            }
        };
        let rest = rest.join(",");
        let (_, strategies) = parse_parallel_arguments(parser, &rest)?;
        return Ok((cancel_on, strategies));
    }
    for separator in ['|', ';', ','] {
        let parts = split_top_level(input, separator);
        if parts.len() > 1 {
            let strategies = parts
                .into_iter()
                .map(str::trim)
                .filter(|part| !part.is_empty())
                .map(|part| parser.parse_choice(part))
                .collect::<Result<Vec<_>, _>>()?;
            if strategies.is_empty() {
                return Err(strategy_parse_error(
                    "parallel expects at least one strategy",
                ));
            }
            return Ok((DpParallelCancel::Proof, strategies));
        }
    }
    Ok((
        DpParallelCancel::Proof,
        vec![parser.parse_choice(input.trim())?],
    ))
}

fn split_top_level(input: &str, separator: char) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut depth = 0usize;
    let mut start = 0usize;
    for (index, ch) in input.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => depth = depth.saturating_sub(1),
            _ if ch == separator && depth == 0 => {
                parts.push(&input[start..index]);
                start = index + ch.len_utf8();
            }
            _ => {}
        }
    }
    parts.push(&input[start..]);
    parts
}

fn strip_outer_parentheses(input: &str) -> &str {
    let mut current = input;
    while current.starts_with('(') && current.ends_with(')') && parentheses_enclose(current) {
        current = current[1..current.len() - 1].trim();
    }
    current
}

fn parentheses_enclose(input: &str) -> bool {
    let mut depth = 0usize;
    for (index, ch) in input.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => {
                depth = depth.saturating_sub(1);
                if depth == 0 && index + ch.len_utf8() != input.len() {
                    return false;
                }
            }
            _ => {}
        }
    }
    depth == 0
}

fn function_arguments<'a>(input: &'a str, name: &str) -> Option<&'a str> {
    input
        .strip_prefix(name)?
        .trim()
        .strip_prefix('(')?
        .strip_suffix(')')
        .filter(|_| parentheses_enclose(input))
}

fn parse_strategy_duration(input: &str) -> Result<Duration, DpStrategyParseError> {
    if let Some(milliseconds) = input.strip_suffix("ms") {
        return milliseconds
            .trim()
            .parse()
            .map(Duration::from_millis)
            .map_err(|_| strategy_parse_error("invalid millisecond timeout"));
    }
    if let Some(seconds) = input.strip_suffix('s') {
        return seconds
            .trim()
            .parse()
            .map(Duration::from_secs)
            .map_err(|_| strategy_parse_error("invalid second timeout"));
    }
    input
        .parse()
        .map(Duration::from_millis)
        .map_err(|_| strategy_parse_error("timeout must be like 250ms or 2s"))
}

#[derive(Clone, Debug)]
pub struct DpOptions {
    /// Query-local Arctic encoding choice, preserved in strategy atoms.
    pub arctic_threshold_encoding: bool,
    /// An explicit state-local DP recipe.  The universal worklist applies
    /// this recipe again at every materialized DP child, so graph/order
    /// continuations remain independently observable and replayable.
    pub strategy: Option<DpStrategy>,
    pub llm_client: Option<LlmClient>,
    pub utility_guidance: Option<UtilityGuidanceLookup>,
    pub llm_iterations: usize,
    pub max_symbol_weight: i64,
    pub max_symbols: usize,
    pub max_polynomial_constant: i64,
    pub max_polynomial_coefficient: i64,
    pub max_polynomial_symbols: usize,
    pub max_polynomial_arity: usize,
    pub max_component_pairs: usize,
    pub max_search_space: usize,
    pub max_narrowing_steps: usize,
    pub max_narrowing_transforms: usize,
    pub max_forward_instantiation_transforms: usize,
    pub max_narrowings_per_pair: usize,
    pub max_rewritings_per_pair: usize,
    pub max_instantiations_per_pair: usize,
    pub max_forward_instantiations_per_pair: usize,
    pub max_narrowings_per_step: usize,
    pub smt_fallback: bool,
    pub smt_solver: Option<String>,
    pub path_order_status: Option<DpPathOrderKind>,
    pub path_order_optimize: bool,
    /// Private theorem context for the complete GM04 inverse transformation.
    ///
    /// This is deliberately not a general "allow assumptions" switch.  A DP
    /// leaf may become an assumption only after its complete obligation is
    /// matched against these exact pairs, rules, and Q terms.  The enclosing
    /// CPF checker repeats that comparison and discharges the sole assumption
    /// from termination of the reconstructed source CSR.
    pub(crate) gm04_residual: Option<Gm04ResidualContext>,
}

#[derive(Clone, Debug)]
pub(crate) struct Gm04ResidualContext {
    pub pairs: Vec<RewriteRule>,
    pub rules: Vec<RewriteRule>,
    pub q: Vec<Term>,
    pub top_sharp: Symbol,
    /// Administrative symbols of the recognized GM04 transformation.  They
    /// determine the generic RPO from Lemma 28; the resulting witness is
    /// nevertheless checked by the ordinary path-order validator.
    pub active: Symbol,
    pub proper: Symbol,
    pub ok: Symbol,
    pub mark: Symbol,
    pub top: Symbol,
    /// Complete transformed signature, collected once at the root. Reusing
    /// it avoids traversing the large generated TRS again for every SCC.
    pub symbols: Vec<String>,
    /// Set on children of the first certified dependency-graph processor.
    /// Every such child is already one SCC, so rerunning the quadratic graph
    /// estimator is redundant and can consume the entire root deadline.
    pub graph_decomposed: bool,
}

impl Default for DpOptions {
    fn default() -> Self {
        Self {
            arctic_threshold_encoding: false,
            strategy: None,
            llm_client: None,
            utility_guidance: None,
            llm_iterations: 2,
            max_symbol_weight: 2,
            max_symbols: usize::MAX,
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: usize::MAX,
            max_polynomial_arity: usize::MAX,
            max_component_pairs: usize::MAX,
            max_search_space: 2_000,
            max_narrowing_steps: 32,
            max_narrowing_transforms: 8,
            max_forward_instantiation_transforms: 16,
            max_narrowings_per_pair: 2,
            max_rewritings_per_pair: 2,
            max_instantiations_per_pair: 2,
            max_forward_instantiations_per_pair: 2,
            max_narrowings_per_step: 8,
            smt_fallback: false,
            smt_solver: None,
            path_order_status: None,
            path_order_optimize: true,
            gm04_residual: None,
        }
    }
}
