use std::collections::{BTreeMap, BTreeSet};
use std::process::{Command, Stdio};
use std::time::Instant;

use super::*;

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
struct ExprId(usize);

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
enum ExprNode {
    Constant(u128),
    Parameter(usize),
    Add(ExprId, ExprId),
    Multiply(ExprId, ExprId),
}

#[derive(Clone, Debug)]
struct Expr {
    node: ExprNode,
    maximum: u128,
}

#[derive(Default)]
struct ExprArena {
    expressions: Vec<Expr>,
    interned: BTreeMap<ExprNode, ExprId>,
}

impl ExprArena {
    fn intern(&mut self, node: ExprNode, maximum: u128) -> ExprId {
        if let Some(id) = self.interned.get(&node) {
            return *id;
        }
        let id = ExprId(self.expressions.len());
        self.expressions.push(Expr {
            node: node.clone(),
            maximum,
        });
        self.interned.insert(node, id);
        id
    }

    fn constant(&mut self, value: u128) -> ExprId {
        self.intern(ExprNode::Constant(value), value)
    }

    fn parameter(&mut self, index: usize, maximum: u128) -> ExprId {
        self.intern(ExprNode::Parameter(index), maximum)
    }

    fn add(&mut self, left: ExprId, right: ExprId) -> ExprId {
        if self.is_zero(left) {
            return right;
        }
        if self.is_zero(right) {
            return left;
        }
        let (left, right) = ordered_pair(left, right);
        let maximum = self.expressions[left.0]
            .maximum
            .saturating_add(self.expressions[right.0].maximum);
        self.intern(ExprNode::Add(left, right), maximum)
    }

    fn multiply(&mut self, left: ExprId, right: ExprId) -> ExprId {
        if self.is_zero(left) || self.is_zero(right) {
            return self.constant(0);
        }
        if self.is_one(left) {
            return right;
        }
        if self.is_one(right) {
            return left;
        }
        let (left, right) = ordered_pair(left, right);
        let maximum = self.expressions[left.0]
            .maximum
            .saturating_mul(self.expressions[right.0].maximum);
        self.intern(ExprNode::Multiply(left, right), maximum)
    }

    fn is_zero(&self, id: ExprId) -> bool {
        self.expressions[id.0].node == ExprNode::Constant(0)
    }

    fn is_one(&self, id: ExprId) -> bool {
        self.expressions[id.0].node == ExprNode::Constant(1)
    }
}

fn ordered_pair(left: ExprId, right: ExprId) -> (ExprId, ExprId) {
    if left <= right {
        (left, right)
    } else {
        (right, left)
    }
}

#[derive(Clone)]
struct SymbolicForm {
    constant: ExprId,
    coefficients: BTreeMap<String, ExprId>,
}

struct SymbolicEncoder {
    arena: ExprArena,
    parameter_indices: BTreeMap<String, usize>,
    parameter_maxima: Vec<u128>,
    terms: BTreeMap<Term, SymbolicForm>,
}

impl SymbolicEncoder {
    fn new(arities: &BTreeMap<String, usize>, constant_max: u128, coefficient_max: u128) -> Self {
        let mut parameter_indices = BTreeMap::new();
        let mut parameter_maxima = Vec::new();
        for (symbol, arity) in arities {
            parameter_indices.insert(smt_c(symbol), parameter_maxima.len());
            parameter_maxima.push(constant_max);
            for index in 0..*arity {
                parameter_indices.insert(smt_a(symbol, index), parameter_maxima.len());
                parameter_maxima.push(coefficient_max);
            }
        }
        Self {
            arena: ExprArena::default(),
            parameter_indices,
            parameter_maxima,
            terms: BTreeMap::new(),
        }
    }

    fn parameter(&mut self, name: &str) -> ExprId {
        let index = self.parameter_indices[name];
        self.arena.parameter(index, self.parameter_maxima[index])
    }

    fn interpret(&mut self, term: &Term) -> SymbolicForm {
        if let Some(form) = self.terms.get(term) {
            return form.clone();
        }
        let form = match term {
            Term::Var(variable) => SymbolicForm {
                constant: self.arena.constant(0),
                coefficients: BTreeMap::from([(
                    variable.as_str().to_string(),
                    self.arena.constant(1),
                )]),
            },
            Term::App { symbol, args } => {
                let mut constant = self.parameter(&smt_c(symbol.as_str()));
                let mut coefficients = BTreeMap::new();
                for (index, argument) in args.iter().enumerate() {
                    let argument = self.interpret(argument);
                    let parameter = self.parameter(&smt_a(symbol.as_str(), index));
                    let scaled_constant = self.arena.multiply(parameter, argument.constant);
                    constant = self.arena.add(constant, scaled_constant);
                    for (variable, value) in argument.coefficients {
                        let scaled = self.arena.multiply(parameter, value);
                        let old = coefficients
                            .remove(&variable)
                            .unwrap_or_else(|| self.arena.constant(0));
                        coefficients.insert(variable, self.arena.add(old, scaled));
                    }
                }
                SymbolicForm {
                    constant,
                    coefficients,
                }
            }
        };
        self.terms.insert(term.clone(), form.clone());
        form
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
enum Gate {
    And(i32, i32),
    Or(i32, i32),
    Xor(i32, i32),
}

struct Cnf {
    next_variable: i32,
    clauses: Vec<Vec<i32>>,
    gates: BTreeMap<Gate, i32>,
}

impl Cnf {
    const TRUE: i32 = 1;
    const FALSE: i32 = -1;

    fn new() -> Self {
        Self {
            next_variable: 2,
            clauses: vec![vec![Self::TRUE]],
            gates: BTreeMap::new(),
        }
    }

    fn variable(&mut self) -> i32 {
        let variable = self.next_variable;
        self.next_variable += 1;
        variable
    }

    fn assert(&mut self, literal: i32) {
        self.clauses.push(vec![literal]);
    }

    fn and(&mut self, left: i32, right: i32) -> i32 {
        if left == Self::FALSE || right == Self::FALSE || left == -right {
            return Self::FALSE;
        }
        if left == Self::TRUE {
            return right;
        }
        if right == Self::TRUE || left == right {
            return left;
        }
        let (left, right) = ordered_literals(left, right);
        let gate = Gate::And(left, right);
        if let Some(output) = self.gates.get(&gate) {
            return *output;
        }
        let output = self.variable();
        self.clauses.push(vec![-output, left]);
        self.clauses.push(vec![-output, right]);
        self.clauses.push(vec![output, -left, -right]);
        self.gates.insert(gate, output);
        output
    }

    fn or(&mut self, left: i32, right: i32) -> i32 {
        if left == Self::TRUE || right == Self::TRUE || left == -right {
            return Self::TRUE;
        }
        if left == Self::FALSE {
            return right;
        }
        if right == Self::FALSE || left == right {
            return left;
        }
        let (left, right) = ordered_literals(left, right);
        let gate = Gate::Or(left, right);
        if let Some(output) = self.gates.get(&gate) {
            return *output;
        }
        let output = self.variable();
        self.clauses.push(vec![output, -left]);
        self.clauses.push(vec![output, -right]);
        self.clauses.push(vec![-output, left, right]);
        self.gates.insert(gate, output);
        output
    }

    fn xor(&mut self, left: i32, right: i32) -> i32 {
        if left == Self::FALSE {
            return right;
        }
        if right == Self::FALSE {
            return left;
        }
        if left == Self::TRUE {
            return -right;
        }
        if right == Self::TRUE {
            return -left;
        }
        if left == right {
            return Self::FALSE;
        }
        if left == -right {
            return Self::TRUE;
        }
        let (left, right) = ordered_literals(left, right);
        let gate = Gate::Xor(left, right);
        if let Some(output) = self.gates.get(&gate) {
            return *output;
        }
        let output = self.variable();
        self.clauses.push(vec![-output, -left, -right]);
        self.clauses.push(vec![-output, left, right]);
        self.clauses.push(vec![output, -left, right]);
        self.clauses.push(vec![output, left, -right]);
        self.gates.insert(gate, output);
        output
    }

    fn and_all(&mut self, mut literals: Vec<i32>) -> i32 {
        if literals.is_empty() {
            return Self::TRUE;
        }
        while literals.len() > 1 {
            literals = literals
                .chunks(2)
                .map(|chunk| match chunk {
                    [literal] => *literal,
                    [left, right] => self.and(*left, *right),
                    _ => unreachable!(),
                })
                .collect();
        }
        literals[0]
    }

    fn equivalent(&mut self, left: i32, right: i32) -> i32 {
        -self.xor(left, right)
    }

    fn majority(&mut self, first: i32, second: i32, third: i32) -> i32 {
        let first_second = self.and(first, second);
        let first_third = self.and(first, third);
        let second_third = self.and(second, third);
        let first_two = self.or(first_second, first_third);
        self.or(first_two, second_third)
    }

    fn dimacs_with_assertion(&self, assertion: Option<i32>) -> String {
        let clause_count = self.clauses.len() + usize::from(assertion.is_some());
        let mut output = format!("p cnf {} {clause_count}\n", self.next_variable - 1);
        for clause in &self.clauses {
            for literal in clause {
                output.push_str(&format!("{literal} "));
            }
            output.push_str("0\n");
        }
        if let Some(assertion) = assertion {
            output.push_str(&format!("{assertion} 0\n"));
        }
        output
    }
}

fn ordered_literals(left: i32, right: i32) -> (i32, i32) {
    if left <= right {
        (left, right)
    } else {
        (right, left)
    }
}

type Bits = Vec<i32>;

struct CircuitEncoder<'a> {
    arena: &'a ExprArena,
    cnf: Cnf,
    parameter_bits: Vec<Bits>,
    expression_bits: BTreeMap<ExprId, Bits>,
}

impl<'a> CircuitEncoder<'a> {
    fn new(arena: &'a ExprArena, parameter_maxima: &[u128]) -> Self {
        let mut cnf = Cnf::new();
        let mut parameter_bits = Vec::new();
        for maximum in parameter_maxima {
            let width = bit_width(*maximum);
            let bits = (0..width).map(|_| cnf.variable()).collect::<Bits>();
            let allowed = unsigned_le_constant(&mut cnf, &bits, *maximum);
            cnf.assert(allowed);
            parameter_bits.push(bits);
        }
        Self {
            arena,
            cnf,
            parameter_bits,
            expression_bits: BTreeMap::new(),
        }
    }

    fn compile(&mut self, id: ExprId) -> Bits {
        if let Some(bits) = self.expression_bits.get(&id) {
            return bits.clone();
        }
        let expression = self.arena.expressions[id.0].clone();
        let target_width = bit_width(expression.maximum);
        let mut bits = match expression.node {
            ExprNode::Constant(value) => constant_bits(value),
            ExprNode::Parameter(index) => self.parameter_bits[index].clone(),
            ExprNode::Add(left, right) => {
                let left = self.compile(left);
                let right = self.compile(right);
                add_bits(&mut self.cnf, &left, &right)
            }
            ExprNode::Multiply(left, right) => {
                let left = self.compile(left);
                let right = self.compile(right);
                multiply_bits(&mut self.cnf, &left, &right)
            }
        };
        bits.resize(target_width, Cnf::FALSE);
        bits.truncate(target_width);
        self.expression_bits.insert(id, bits.clone());
        bits
    }
}

fn bit_width(maximum: u128) -> usize {
    (u128::BITS as usize - maximum.leading_zeros() as usize).max(1)
}

fn constant_bits(value: u128) -> Bits {
    let width = bit_width(value);
    (0..width)
        .map(|index| {
            if value & (1u128 << index) == 0 {
                Cnf::FALSE
            } else {
                Cnf::TRUE
            }
        })
        .collect()
}

fn add_bits(cnf: &mut Cnf, left: &[i32], right: &[i32]) -> Bits {
    let width = left.len().max(right.len());
    let mut result = Vec::with_capacity(width + 1);
    let mut carry = Cnf::FALSE;
    for index in 0..width {
        let left = left.get(index).copied().unwrap_or(Cnf::FALSE);
        let right = right.get(index).copied().unwrap_or(Cnf::FALSE);
        let partial = cnf.xor(left, right);
        result.push(cnf.xor(partial, carry));
        carry = cnf.majority(left, right, carry);
    }
    result.push(carry);
    trim_false_msb(&mut result);
    result
}

fn multiply_bits(cnf: &mut Cnf, left: &[i32], right: &[i32]) -> Bits {
    let mut result = vec![Cnf::FALSE];
    for (shift, bit) in right.iter().copied().enumerate() {
        if bit == Cnf::FALSE {
            continue;
        }
        let mut partial = vec![Cnf::FALSE; shift];
        partial.extend(left.iter().map(|left| cnf.and(*left, bit)));
        result = add_bits(cnf, &result, &partial);
    }
    trim_false_msb(&mut result);
    result
}

fn trim_false_msb(bits: &mut Bits) {
    while bits.len() > 1 && bits.last() == Some(&Cnf::FALSE) {
        bits.pop();
    }
}

fn unsigned_equal(cnf: &mut Cnf, left: &[i32], right: &[i32]) -> i32 {
    let width = left.len().max(right.len());
    let equalities = (0..width)
        .map(|index| {
            cnf.equivalent(
                left.get(index).copied().unwrap_or(Cnf::FALSE),
                right.get(index).copied().unwrap_or(Cnf::FALSE),
            )
        })
        .collect();
    cnf.and_all(equalities)
}

fn unsigned_greater(cnf: &mut Cnf, left: &[i32], right: &[i32]) -> i32 {
    let width = left.len().max(right.len());
    let mut greater = Cnf::FALSE;
    let mut equal_prefix = Cnf::TRUE;
    for index in (0..width).rev() {
        let left = left.get(index).copied().unwrap_or(Cnf::FALSE);
        let right = right.get(index).copied().unwrap_or(Cnf::FALSE);
        let bit_greater = cnf.and(left, -right);
        let first_difference = cnf.and(equal_prefix, bit_greater);
        greater = cnf.or(greater, first_difference);
        let equal = cnf.equivalent(left, right);
        equal_prefix = cnf.and(equal_prefix, equal);
    }
    greater
}

fn unsigned_ge(cnf: &mut Cnf, left: &[i32], right: &[i32]) -> i32 {
    let greater = unsigned_greater(cnf, left, right);
    let equal = unsigned_equal(cnf, left, right);
    cnf.or(greater, equal)
}

fn unsigned_le_constant(cnf: &mut Cnf, bits: &[i32], maximum: u128) -> i32 {
    let maximum = constant_bits(maximum);
    unsigned_ge(cnf, &maximum, bits)
}

fn cardinality_thresholds(cnf: &mut Cnf, literals: &[i32]) -> Vec<i32> {
    let mut thresholds = Vec::with_capacity(literals.len());
    for literal in literals {
        let mut carry = *literal;
        for threshold in &mut thresholds {
            let higher = cnf.or(*threshold, carry);
            let lower = cnf.and(*threshold, carry);
            *threshold = higher;
            carry = lower;
        }
        thresholds.push(carry);
    }
    thresholds
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum StrictMode {
    All,
    Some,
}

impl StrictMode {
    fn name(self) -> &'static str {
        match self {
            Self::All => "all",
            Self::Some => "some",
        }
    }
}

fn strict_modes(configured: Option<&str>) -> Option<Vec<StrictMode>> {
    match configured {
        Some("all") => Some(vec![StrictMode::All]),
        Some("some") => Some(vec![StrictMode::Some]),
        Some("all-then-some") | None => Some(vec![StrictMode::All, StrictMode::Some]),
        Some(_) => None,
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ObjectiveSearch {
    ModelAwareBinary,
    AdaptiveAscent,
}

fn objective_search(configured: Option<&str>) -> Option<ObjectiveSearch> {
    match configured {
        Some("adaptive") => Some(ObjectiveSearch::AdaptiveAscent),
        Some("binary") | None => Some(ObjectiveSearch::ModelAwareBinary),
        Some(_) => None,
    }
}

enum DirectAttempt {
    Model(LinearPolynomialInterpretations),
    Unsatisfiable,
    Failed,
}

enum SatAttempt {
    Model(BTreeSet<i32>),
    Unsatisfiable,
    Failed,
}

pub(super) fn synthesize(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<LinearPolynomialInterpretations> {
    if strategy_timed_out(deadline) || current_thread_cancelled() {
        return None;
    }
    let constant_max = u128::try_from(options.max_polynomial_constant).ok()?;
    let coefficient_max = u128::try_from(options.max_polynomial_coefficient).ok()?;
    let arities = arities_for_constraints(pairs, usable);
    let mut symbolic = SymbolicEncoder::new(&arities, constant_max, coefficient_max);
    let usable_forms = usable
        .iter()
        .map(|rule| {
            (
                symbolic.interpret(rule.lhs()),
                symbolic.interpret(rule.rhs()),
            )
        })
        .collect::<Vec<_>>();
    let pair_forms = pairs
        .iter()
        .map(|pair| {
            (
                symbolic.interpret(pair.lhs()),
                symbolic.interpret(pair.rhs()),
            )
        })
        .collect::<Vec<_>>();

    let solver = std::env::var("FERRUM_DIRECT_SAT_SOLVER").ok().or_else(|| {
        [
            ".tools/kissat-sc2025",
            ".tools/kissat",
            "kissat",
            ".tools/cadical-sc2025",
            "cadical",
        ]
        .into_iter()
        .find(|solver| command_exists(solver))
        .map(str::to_string)
    })?;
    let configured_mode = std::env::var("FERRUM_DIRECT_SAT_STRICT_MODE").ok();
    let modes = strict_modes(configured_mode.as_deref())?;
    for mode in modes {
        if strategy_timed_out(deadline) || current_thread_cancelled() {
            return None;
        }
        match solve_mode(
            pairs,
            usable,
            &arities,
            &symbolic,
            &usable_forms,
            &pair_forms,
            &solver,
            mode,
            deadline,
        ) {
            DirectAttempt::Model(interpretations) => return Some(interpretations),
            DirectAttempt::Unsatisfiable => continue,
            DirectAttempt::Failed => return None,
        }
    }
    None
}

#[allow(clippy::too_many_arguments)]
fn solve_mode(
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    arities: &BTreeMap<String, usize>,
    symbolic: &SymbolicEncoder,
    usable_forms: &[(SymbolicForm, SymbolicForm)],
    pair_forms: &[(SymbolicForm, SymbolicForm)],
    solver: &str,
    mode: StrictMode,
    deadline: Option<Instant>,
) -> DirectAttempt {
    let mut circuit = CircuitEncoder::new(&symbolic.arena, &symbolic.parameter_maxima);
    for (left, right) in usable_forms {
        let weak = weak_formula(&mut circuit, left, right);
        circuit.cnf.assert(weak);
    }
    let mut strict = Vec::new();
    for (left, right) in pair_forms {
        let weak = weak_formula(&mut circuit, left, right);
        circuit.cnf.assert(weak);
        let left = circuit.compile(left.constant);
        let right = circuit.compile(right.constant);
        strict.push(unsigned_greater(&mut circuit.cnf, &left, &right));
    }
    let model = match mode {
        StrictMode::All => {
            for strict in strict {
                circuit.cnf.assert(strict);
            }
            match solve_cnf(
                &circuit.cnf,
                None,
                solver,
                mode,
                None,
                pairs,
                usable,
                arities,
                symbolic,
                deadline,
            ) {
                SatAttempt::Model(model) => model,
                SatAttempt::Unsatisfiable => return DirectAttempt::Unsatisfiable,
                SatAttempt::Failed => return DirectAttempt::Failed,
            }
        }
        StrictMode::Some => {
            if strict.is_empty() {
                return DirectAttempt::Unsatisfiable;
            }
            let thresholds = cardinality_thresholds(&mut circuit.cnf, &strict);
            let search = std::env::var("FERRUM_DIRECT_SAT_OBJECTIVE_SEARCH").ok();
            let Some(search) = objective_search(search.as_deref()) else {
                return DirectAttempt::Failed;
            };
            let mut best = None;
            let mut best_count = 0usize;
            let mut lower = 1usize;
            let mut upper = thresholds.len();
            while lower <= upper {
                let target = match search {
                    ObjectiveSearch::ModelAwareBinary => lower + (upper - lower) / 2,
                    ObjectiveSearch::AdaptiveAscent => lower,
                };
                match solve_cnf(
                    &circuit.cnf,
                    Some(thresholds[target - 1]),
                    solver,
                    mode,
                    Some(target),
                    pairs,
                    usable,
                    arities,
                    symbolic,
                    deadline,
                ) {
                    SatAttempt::Model(model) => {
                        let strict_count = strict
                            .iter()
                            .filter(|literal| literal_is_true(**literal, &model))
                            .count();
                        if strict_count < target {
                            return DirectAttempt::Failed;
                        }
                        write_progress_event(
                            "dp-sat",
                            "objective-model",
                            "direct-sat-polynomial",
                            0,
                            &format!(
                                "strict_mode={} strict_target={target} strict_pairs={strict_count}",
                                mode.name()
                            ),
                        );
                        best = Some(model);
                        best_count = strict_count;
                        if strict_count == strict.len() {
                            break;
                        }
                        lower = strict_count + 1;
                    }
                    SatAttempt::Unsatisfiable => match search {
                        ObjectiveSearch::ModelAwareBinary => upper = target - 1,
                        ObjectiveSearch::AdaptiveAscent => break,
                    },
                    SatAttempt::Failed => return DirectAttempt::Failed,
                }
            }
            let Some(model) = best else {
                return DirectAttempt::Unsatisfiable;
            };
            write_progress_event(
                "dp-sat",
                "optimum",
                "direct-sat-polynomial",
                0,
                &format!("strict_mode={} strict_pairs={best_count}", mode.name()),
            );
            model
        }
    };

    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let constant_index = symbolic.parameter_indices[&smt_c(&symbol)];
        let Some(constant) = decode_parameter(&circuit.parameter_bits[constant_index], &model)
        else {
            return DirectAttempt::Failed;
        };
        let coefficients = (0..*arity)
            .map(|index| {
                let parameter = symbolic.parameter_indices[&smt_a(&symbol, index)];
                decode_parameter(&circuit.parameter_bits[parameter], &model)
            })
            .collect::<Option<Vec<_>>>();
        let Some(coefficients) = coefficients else {
            return DirectAttempt::Failed;
        };
        let Ok(constant) = i64::try_from(constant) else {
            return DirectAttempt::Failed;
        };
        let Ok(coefficients) = coefficients
            .into_iter()
            .map(i64::try_from)
            .collect::<Result<Vec<_>, _>>()
        else {
            return DirectAttempt::Failed;
        };
        interpretations.insert(
            symbol.clone(),
            LinearPolynomial {
                constant,
                coefficients,
            },
        );
    }
    DirectAttempt::Model(interpretations)
}

#[allow(clippy::too_many_arguments)]
fn solve_cnf(
    cnf: &Cnf,
    assertion: Option<i32>,
    solver: &str,
    mode: StrictMode,
    strict_target: Option<usize>,
    pairs: &[DependencyPair],
    usable: &[RewriteRule],
    arities: &BTreeMap<String, usize>,
    symbolic: &SymbolicEncoder,
    deadline: Option<Instant>,
) -> SatAttempt {
    let dimacs = cnf.dimacs_with_assertion(assertion);
    let target = strict_target
        .map(|target| target.to_string())
        .unwrap_or_else(|| "all".to_string());
    write_progress_event(
        "dp-order",
        "encoded",
        "direct-sat-polynomial",
        0,
        &format!(
            "strict_mode={} strict_target={} pairs={} usable_rules={} symbols={} expressions={} variables={} clauses={} dimacs_bytes={} solver={}",
            mode.name(),
            target,
            pairs.len(),
            usable.len(),
            arities.len(),
            symbolic.arena.expressions.len(),
            cnf.next_variable - 1,
            cnf.clauses.len() + usize::from(assertion.is_some()),
            dimacs.len(),
            solver
        ),
    );
    let started = Instant::now();
    let mut command = Command::new(&solver);
    command.stderr(Stdio::piped());
    let Some(output) = run_command_with_input_deadline(&mut command, &dimacs, deadline)
        .ok()
        .flatten()
    else {
        return SatAttempt::Failed;
    };
    let stdout = String::from_utf8_lossy(&output.stdout);
    write_progress_event(
        "dp-sat",
        "solver-exit",
        "direct-sat-polynomial",
        started.elapsed().as_millis(),
        &format!(
            "strict_mode={} strict_target={} solver={} status={} stdout={}",
            mode.name(),
            target,
            solver,
            output.status,
            stdout
                .chars()
                .take(160)
                .collect::<String>()
                .replace('\n', " ")
        ),
    );
    let Some(model) = parse_dimacs_model(&stdout) else {
        return if dimacs_output_is_unsatisfiable(&stdout) {
            SatAttempt::Unsatisfiable
        } else {
            SatAttempt::Failed
        };
    };
    SatAttempt::Model(model)
}

fn weak_formula(
    circuit: &mut CircuitEncoder<'_>,
    left: &SymbolicForm,
    right: &SymbolicForm,
) -> i32 {
    let mut comparisons = Vec::new();
    let left_constant = circuit.compile(left.constant);
    let right_constant = circuit.compile(right.constant);
    comparisons.push(unsigned_ge(
        &mut circuit.cnf,
        &left_constant,
        &right_constant,
    ));
    let variables = left
        .coefficients
        .keys()
        .chain(right.coefficients.keys())
        .cloned()
        .collect::<BTreeSet<_>>();
    for variable in variables {
        let left = left
            .coefficients
            .get(&variable)
            .map(|expression| circuit.compile(*expression))
            .unwrap_or_else(|| vec![Cnf::FALSE]);
        let right = right
            .coefficients
            .get(&variable)
            .map(|expression| circuit.compile(*expression))
            .unwrap_or_else(|| vec![Cnf::FALSE]);
        comparisons.push(unsigned_ge(&mut circuit.cnf, &left, &right));
    }
    circuit.cnf.and_all(comparisons)
}

fn parse_dimacs_model(output: &str) -> Option<BTreeSet<i32>> {
    let satisfiable = output
        .lines()
        .any(|line| line.trim() == "s SATISFIABLE" || line.trim() == "SAT");
    if !satisfiable {
        return None;
    }
    Some(
        output
            .lines()
            .filter_map(|line| line.trim().strip_prefix('v'))
            .flat_map(str::split_whitespace)
            .filter_map(|literal| literal.parse::<i32>().ok())
            .filter(|literal| *literal > 0)
            .collect(),
    )
}

fn dimacs_output_is_unsatisfiable(output: &str) -> bool {
    output
        .lines()
        .any(|line| line.trim() == "s UNSATISFIABLE" || line.trim() == "UNSAT")
}

fn literal_is_true(literal: i32, model: &BTreeSet<i32>) -> bool {
    let assigned = model.contains(&(literal.unsigned_abs() as i32));
    if literal > 0 { assigned } else { !assigned }
}

fn decode_parameter(bits: &[i32], model: &BTreeSet<i32>) -> Option<u128> {
    bits.iter()
        .enumerate()
        .try_fold(0u128, |value, (index, bit)| {
            let variable = bit.unsigned_abs() as i32;
            let assigned = model.contains(&variable);
            let truth = if *bit > 0 { assigned } else { !assigned };
            truth
                .then(|| value.checked_add(1u128.checked_shl(index as u32)?))
                .unwrap_or(Some(value))
        })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn direct_circuit_selects_strictness_modes() {
        assert_eq!(strict_modes(Some("all")), Some(vec![StrictMode::All]));
        assert_eq!(strict_modes(Some("some")), Some(vec![StrictMode::Some]));
        assert_eq!(
            strict_modes(Some("all-then-some")),
            Some(vec![StrictMode::All, StrictMode::Some])
        );
        assert_eq!(
            strict_modes(None),
            Some(vec![StrictMode::All, StrictMode::Some])
        );
        assert_eq!(strict_modes(Some("invalid")), None);
    }

    #[test]
    fn direct_circuit_selects_objective_search() {
        assert_eq!(
            objective_search(None),
            Some(ObjectiveSearch::ModelAwareBinary)
        );
        assert_eq!(
            objective_search(Some("binary")),
            Some(ObjectiveSearch::ModelAwareBinary)
        );
        assert_eq!(
            objective_search(Some("adaptive")),
            Some(ObjectiveSearch::AdaptiveAscent)
        );
        assert_eq!(objective_search(Some("invalid")), None);
    }

    #[test]
    fn direct_circuit_cardinality_thresholds_are_exact_on_constants() {
        for length in 0..8usize {
            for true_count in 0..=length {
                let literals = (0..length)
                    .map(|index| {
                        if index < true_count {
                            Cnf::TRUE
                        } else {
                            Cnf::FALSE
                        }
                    })
                    .collect::<Vec<_>>();
                let mut cnf = Cnf::new();
                let thresholds = cardinality_thresholds(&mut cnf, &literals);
                assert_eq!(thresholds.len(), length);
                for (index, threshold) in thresholds.into_iter().enumerate() {
                    assert_eq!(
                        threshold,
                        if index < true_count {
                            Cnf::TRUE
                        } else {
                            Cnf::FALSE
                        }
                    );
                }
            }
        }
    }

    #[test]
    fn direct_circuit_exact_arithmetic_and_comparison() {
        let mut cnf = Cnf::new();
        let two = constant_bits(2);
        let three = constant_bits(3);
        let six = multiply_bits(&mut cnf, &two, &three);
        let five = constant_bits(5);
        assert_eq!(six, constant_bits(6));
        assert_eq!(unsigned_greater(&mut cnf, &six, &five), Cnf::TRUE);
        assert_eq!(unsigned_ge(&mut cnf, &five, &six), Cnf::FALSE);
    }

    #[test]
    fn direct_circuit_range_constraint_rejects_three_for_bound_two() {
        let mut cnf = Cnf::new();
        let bits = vec![Cnf::TRUE, Cnf::TRUE];
        assert_eq!(unsigned_le_constant(&mut cnf, &bits, 2), Cnf::FALSE);
    }
}
