use super::*;

pub(crate) fn usable_rules(trs: &Trs, pairs: &[DependencyPair]) -> Vec<RewriteRule> {
    if trs
        .rules()
        .iter()
        .any(|rule| matches!(rule.lhs(), Term::Var(_)))
    {
        return trs.rules().to_vec();
    }

    // This is the executable closure checked by CeTA's
    // check_ur_P_closed_rm_af with the full argument filter. At every active
    // RHS subterm, an omitted rule is usable exactly when its LHS matches the
    // root-preserving tcapRM2 of that subterm.
    let mut usable = BTreeSet::new();
    loop {
        let mut changed = false;
        for pair in pairs {
            collect_ceta_usable_rules_at_term(trs, pair.rhs(), &mut usable, &mut changed);
        }
        let current = usable.iter().copied().collect::<Vec<_>>();
        for index in current {
            collect_ceta_usable_rules_at_term(
                trs,
                trs.rules()[index].rhs(),
                &mut usable,
                &mut changed,
            );
        }
        if !changed {
            break;
        }
    }
    usable
        .into_iter()
        .map(|index| trs.rules()[index].clone())
        .collect()
}

pub(super) fn collect_ceta_usable_rules_at_term(
    trs: &Trs,
    term: &Term,
    usable: &mut BTreeSet<usize>,
    changed: &mut bool,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    for argument in args {
        collect_ceta_usable_rules_at_term(trs, argument, usable, changed);
    }
    let cap_below = GroundContext::Fun(
        symbol.clone(),
        args.iter()
            .map(|argument| ceta_tcap_rm2(trs, trs.rules(), argument))
            .collect(),
    );
    for (index, rule) in trs.rules().iter().enumerate() {
        if term_has_same_root_arity(term, rule.lhs())
            && ground_context_matches(&cap_below, rule.lhs())
        {
            *changed |= usable.insert(index);
        }
    }
}

/// Rules possibly applicable at this root after reductions below it. Argument
/// filtering controls traversal to this term, not the arguments of this test.
pub(super) fn ceta_usable_rule_indices_at_root(trs: &Trs, term: &Term) -> Vec<usize> {
    let Term::App { symbol, args } = term else { return Vec::new(); };
    let cap_below = GroundContext::Fun(symbol.clone(), args.iter()
        .map(|argument| ceta_tcap_rm2(trs, trs.rules(), argument)).collect());
    trs.rules().iter().enumerate().filter_map(|(index, rule)| {
        (term_has_same_root_arity(term, rule.lhs())
            && ground_context_matches(&cap_below, rule.lhs())).then_some(index)
    }).collect()
}

pub(super) fn argument_filtered_usable_rules(
    rules: &[RewriteRule],
    pairs: &[DependencyPair],
    argument_filter: &DpArgumentFilter,
) -> Vec<RewriteRule> {
    if rules.iter().any(|rule| matches!(rule.lhs(), Term::Var(_))) {
        return rules.to_vec();
    }

    // CeTA's matchCapRMBelow test uses every immediate argument to distinguish
    // matching rule LHSs. The argument filter controls only the recursive
    // descent that discovers further usable roots.
    let trs = Trs::new_with_strategy(None, BTreeSet::new(), rules.to_vec(), RewriteStrategy::Full);
    let mut usable = BTreeSet::new();
    loop {
        let mut changed = false;
        for pair in pairs {
            collect_argument_filtered_ceta_usable_rules_at_term(
                &trs,
                pair.rhs(),
                argument_filter,
                &mut usable,
                &mut changed,
            );
        }
        let current = usable.iter().copied().collect::<Vec<_>>();
        for index in current {
            collect_argument_filtered_ceta_usable_rules_at_term(
                &trs,
                rules[index].rhs(),
                argument_filter,
                &mut usable,
                &mut changed,
            );
        }
        if !changed {
            break;
        }
    }
    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

pub(super) fn complete_argument_filtered_usable_rules(
    rules: &[RewriteRule],
    pairs: &[DependencyPair],
    initial_usable: &[RewriteRule],
    argument_filter: Option<&DpArgumentFilter>,
) -> Vec<RewriteRule> {
    if rules.iter().any(|rule| matches!(rule.lhs(), Term::Var(_))) {
        return rules.to_vec();
    }
    if rules.is_empty() || initial_usable.is_empty() {
        return initial_usable.to_vec();
    }
    let mut usable = BTreeSet::new();
    for initial in initial_usable {
        for (index, rule) in rules.iter().enumerate() {
            if rule == initial {
                usable.insert(index);
            }
        }
    }
    if usable.is_empty() {
        return Vec::new();
    }

    let trs = Trs::new_with_strategy(None, BTreeSet::new(), rules.to_vec(), RewriteStrategy::Full);
    loop {
        let mut changed = false;
        for pair in pairs {
            if let Some(argument_filter) = argument_filter {
                collect_argument_filtered_ceta_usable_rules_at_term(
                    &trs,
                    pair.rhs(),
                    argument_filter,
                    &mut usable,
                    &mut changed,
                );
            } else {
                collect_ceta_usable_rules_at_term(&trs, pair.rhs(), &mut usable, &mut changed);
            }
        }
        let current = usable.iter().copied().collect::<Vec<_>>();
        for index in current {
            let rule = trs.rules()[index].rhs();
            if let Some(argument_filter) = argument_filter {
                collect_argument_filtered_ceta_usable_rules_at_term(
                    &trs,
                    rule,
                    argument_filter,
                    &mut usable,
                    &mut changed,
                );
            } else {
                collect_ceta_usable_rules_at_term(&trs, rule, &mut usable, &mut changed);
            }
        }
        if !changed {
            break;
        }
    }
    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

pub(super) fn collect_argument_filtered_ceta_usable_rules_at_term(
    trs: &Trs,
    term: &Term,
    argument_filter: &DpArgumentFilter,
    usable: &mut BTreeSet<usize>,
    changed: &mut bool,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    let active_positions = match argument_filter.get(symbol.as_str()) {
        Some(DpArgumentFilterEntry::Collapsing(position)) => vec![*position],
        Some(DpArgumentFilterEntry::NonCollapsing(positions)) => positions.clone(),
        None => (0..args.len()).collect(),
    };
    for position in active_positions {
        if let Some(argument) = args.get(position) {
            collect_argument_filtered_ceta_usable_rules_at_term(
                trs,
                argument,
                argument_filter,
                usable,
                changed,
            );
        }
    }
    let cap_below = GroundContext::Fun(
        symbol.clone(),
        args.iter()
            .map(|argument| ceta_tcap_rm2(trs, trs.rules(), argument))
            .collect(),
    );
    for (index, rule) in trs.rules().iter().enumerate() {
        if term_has_same_root_arity(term, rule.lhs())
            && ground_context_matches(&cap_below, rule.lhs())
        {
            *changed |= usable.insert(index);
        }
    }
}

pub(crate) fn qcs_certificate_usable_rules(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    qcs_certificate_usable_rules_with_unhiding(csr, pairs, None)
}

/// Executable usable-rule closure for improved CS-DPs.
///
/// The improved construction introduces one fresh unsharp symbol `U`.  A DP
/// target rooted by `U` cannot take a CS rewrite step: no rule defines `U`,
/// and descent below an unsharp root is not a CS-DP step.  Such targets
/// therefore seed no usable rules; all ordinary marked targets retain the
/// exact QCS closure.
pub(crate) fn improved_qcs_certificate_usable_rules(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    let unhiding = fresh_unhiding_symbol(csr.trs());
    qcs_certificate_usable_rules_with_unhiding(csr, pairs, Some(&unhiding))
}

fn qcs_certificate_usable_rules_with_unhiding(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    unhiding: Option<&Symbol>,
) -> Vec<RewriteRule> {
    let mut usable = BTreeSet::new();
    for pair in pairs {
        let Term::App { symbol, args } = pair.rhs() else {
            usable.extend(0..csr.rules().len());
            break;
        };
        if unhiding == Some(symbol) {
            continue;
        }
        let Some(unmarked) = symbol.as_str().strip_suffix('#').map(Symbol::new) else {
            usable.extend(0..csr.rules().len());
            break;
        };
        for (index, argument) in args.iter().enumerate() {
            if csr.replacement_map().is_allowed(&unmarked, index) {
                collect_qcs_certificate_usable_rules(csr, argument, &mut usable);
            }
        }
        if usable.len() == csr.rules().len() {
            break;
        }
    }
    usable
        .into_iter()
        .map(|index| csr.rules()[index].clone())
        .collect()
}

pub(crate) fn csr_u3_usable_rules(
    csr: &CsrTrs,
    rules: &[RewriteRule],
    pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    let mut rules_by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    for (index, rule) in rules.iter().enumerate() {
        if let Some(root) = rule.lhs().root_symbol() {
            rules_by_root.entry(root.clone()).or_default().push(index);
        }
    }

    let mut seed_symbols = BTreeSet::new();
    for pair in pairs {
        collect_csr_u3_symbols(csr, pair.rhs(), true, false, &mut seed_symbols);
        collect_csr_u3_symbols(csr, pair.lhs(), false, false, &mut seed_symbols);
    }
    for rule in rules {
        collect_csr_u3_symbols(csr, rule.rhs(), false, false, &mut seed_symbols);
    }

    let mut usable = BTreeSet::new();
    let mut pending = VecDeque::new();
    enqueue_csr_u3_rules(&seed_symbols, &rules_by_root, &mut usable, &mut pending);
    while let Some(index) = pending.pop_front() {
        let rule = &rules[index];
        let mut dependencies = BTreeSet::new();
        collect_csr_u3_symbols(csr, rule.lhs(), false, false, &mut dependencies);
        collect_csr_u3_symbols(csr, rule.rhs(), true, false, &mut dependencies);
        enqueue_csr_u3_rules(&dependencies, &rules_by_root, &mut usable, &mut pending);
    }

    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

/// Computes the context-sensitive usable rules from Definitions 7 and 8 of
/// Gutierrez, Lucas, and Urbain (RTA 2008).
///
/// Unlike U3, this construction follows only active symbols in right-hand
/// sides. It remains sound for arbitrary CS-TRSs by additionally seeding the
/// closure with hidden symbols and symbols below inactive pair-LHS positions.
/// Its reduction-pair processor also needs the projection-rule obligations
/// from Theorem 1; callers must not use this set with the ordinary U3 checker.
pub(crate) fn rta_context_sensitive_usable_rules(
    csr: &CsrTrs,
    rules: &[RewriteRule],
    pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    let defined = csr.trs().defined_symbols();
    let mut rules_by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    let mut dependencies = BTreeMap::<Symbol, BTreeSet<Symbol>>::new();
    let mut seeds = BTreeSet::new();

    for (index, rule) in rules.iter().enumerate() {
        let Some(root) = rule.lhs().root_symbol() else {
            continue;
        };
        rules_by_root.entry(root.clone()).or_default().push(index);

        let targets = dependencies.entry(root.clone()).or_default();
        collect_csr_symbols_by_activity(csr, rule.rhs(), true, true, &defined, targets);
        collect_csr_symbols_by_activity(csr, rule.lhs(), true, false, &defined, targets);

        // H(R, mu): every defined symbol occurring below an inactive position
        // in the right-hand side of any rule is a hidden symbol.
        collect_csr_symbols_by_activity(csr, rule.rhs(), true, false, &defined, &mut seeds);
    }

    for pair in pairs {
        collect_csr_symbols_by_activity(csr, pair.rhs(), true, true, &defined, &mut seeds);
        collect_csr_symbols_by_activity(csr, pair.lhs(), true, false, &defined, &mut seeds);
    }

    let mut reachable = seeds.clone();
    let mut pending = seeds.into_iter().collect::<VecDeque<_>>();
    while let Some(symbol) = pending.pop_front() {
        for dependency in dependencies.get(&symbol).into_iter().flatten() {
            if reachable.insert(dependency.clone()) {
                pending.push_back(dependency.clone());
            }
        }
    }

    let mut usable = BTreeSet::new();
    for symbol in reachable {
        usable.extend(rules_by_root.get(&symbol).into_iter().flatten().copied());
    }
    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

/// Extended-basic context-sensitive usable rules of Gutierrez--Lucas.
///
/// In contrast to the older general RTA'08 closure, this closure is local to
/// the current typed MU-TERM problem.  Collapsing pairs contribute no active
/// right-hand-side symbol; their exact unhiding rules contribute the exposed
/// call instead.  The executable checker closes active positions of the
/// right-hand sides of non-collapsing pairs, unhiding rules, and selected
/// source rules.  Inactive-left dependencies belong to U3 and must not be
/// folded into this distinct processor.
pub(crate) fn muterm_extended_basic_usable_rules(
    csr: &CsrTrs,
    rules: &[RewriteRule],
    pairs: &[DependencyPair],
    unhiding_rules: &[RewriteRule],
) -> Vec<RewriteRule> {
    let defined = csr.trs().defined_symbols();
    let mut rules_by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    let mut dependencies = BTreeMap::<Symbol, BTreeSet<Symbol>>::new();
    let mut seeds = BTreeSet::new();

    for (index, rule) in rules.iter().enumerate() {
        let Some(root) = rule.lhs().root_symbol() else {
            continue;
        };
        rules_by_root.entry(root.clone()).or_default().push(index);
        let targets = dependencies.entry(root.clone()).or_default();
        collect_csr_symbols_by_activity(csr, rule.rhs(), true, true, &defined, targets);
    }

    for pair in pairs
        .iter()
        .filter(|pair| !matches!(pair.rhs(), Term::Var(_)))
    {
        collect_csr_symbols_by_activity(csr, pair.rhs(), true, true, &defined, &mut seeds);
    }
    for rule in unhiding_rules {
        collect_csr_symbols_by_activity(csr, rule.rhs(), true, true, &defined, &mut seeds);
    }

    let mut reachable = seeds.clone();
    let mut pending = seeds.into_iter().collect::<VecDeque<_>>();
    while let Some(symbol) = pending.pop_front() {
        for dependency in dependencies.get(&symbol).into_iter().flatten() {
            if reachable.insert(dependency.clone()) {
                pending.push_back(dependency.clone());
            }
        }
    }

    let mut usable = BTreeSet::new();
    for symbol in reachable {
        usable.extend(rules_by_root.get(&symbol).into_iter().flatten().copied());
    }
    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

/// Usable rules for the innermost CS-DP problem with direct unhiding rules.
/// Marked roots denote DP calls, not rewrite-rule roots. Their arguments are
/// followed with the replacement map of the unmarked symbol. In addition,
/// the arguments exposed by an unhiding rule seed the closure. This is the
/// Alarcon--Lucas innermost usable-rule set printed by MU-TERM.
pub(crate) fn innermost_csr_usable_rules(
    csr: &CsrTrs,
    rules: &[RewriteRule],
    pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    fn collect(
        csr: &CsrTrs,
        term: &Term,
        rule_roots: &BTreeSet<Symbol>,
        out: &mut BTreeSet<Symbol>,
    ) {
        let Term::App { symbol, args } = term else {
            return;
        };
        let base = symbol
            .as_str()
            .strip_suffix('#')
            .map(Symbol::new)
            .unwrap_or_else(|| symbol.clone());
        if symbol.as_str().strip_suffix('#').is_none() && rule_roots.contains(symbol) {
            out.insert(symbol.clone());
        }
        for (index, argument) in args.iter().enumerate() {
            if csr.replacement_map().is_allowed(&base, index) {
                collect(csr, argument, rule_roots, out);
            }
        }
    }

    let auxiliary = rules
        .iter()
        .map(|rule| {
            rule.rhs()
                .root_symbol()
                .is_some_and(|root| root.as_str().ends_with('#'))
        })
        .collect::<Vec<_>>();
    let active_marked_roots = pairs
        .iter()
        .flat_map(|pair| [pair.lhs().root_symbol(), pair.rhs().root_symbol()])
        .flatten()
        .filter(|root| root.as_str().ends_with('#'))
        .cloned()
        .collect::<BTreeSet<_>>();
    let applicable_auxiliary = rules
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| {
            (auxiliary[index]
                && rule
                    .rhs()
                    .root_symbol()
                    .is_some_and(|root| active_marked_roots.contains(root)))
            .then_some(index)
        })
        .collect::<BTreeSet<_>>();
    let mut by_root = BTreeMap::<Symbol, Vec<usize>>::new();
    for (index, rule) in rules.iter().enumerate() {
        if !auxiliary[index]
            && let Some(root) = rule.lhs().root_symbol()
        {
            by_root.entry(root.clone()).or_default().push(index);
        }
    }
    let rule_roots = by_root.keys().cloned().collect::<BTreeSet<_>>();
    let mut symbols = BTreeSet::new();
    for pair in pairs {
        collect(csr, pair.rhs(), &rule_roots, &mut symbols);
    }
    for index in applicable_auxiliary.iter().copied() {
        if let Some(rule) = rules.get(index) {
            collect(csr, rule.rhs(), &rule_roots, &mut symbols);
        }
    }

    let mut usable = BTreeSet::new();
    let mut pending = symbols.into_iter().collect::<VecDeque<_>>();
    while let Some(symbol) = pending.pop_front() {
        for index in by_root.get(&symbol).into_iter().flatten().copied() {
            if usable.insert(index) {
                let mut discovered = BTreeSet::new();
                collect(csr, rules[index].rhs(), &rule_roots, &mut discovered);
                for next in discovered {
                    if !by_root
                        .get(&next)
                        .into_iter()
                        .flatten()
                        .any(|i| usable.contains(i))
                    {
                        pending.push_back(next);
                    }
                }
            }
        }
    }
    usable.extend(applicable_auxiliary);
    usable
        .into_iter()
        .map(|index| rules[index].clone())
        .collect()
}

pub(crate) fn rta_reduction_pair_weak_rules(
    csr: &CsrTrs,
    usable_rules: &[RewriteRule],
    _pairs: &[DependencyPair],
) -> Vec<RewriteRule> {
    let mut obligations = usable_rules.to_vec();
    let arities = csr.trs().arities();
    let projection_symbol = (0usize..)
        .map(|index| Symbol::new(format!("__CSR_PI{index}")))
        .find(|symbol| !arities.contains_key(symbol))
        .expect("the finite signature has a fresh projection symbol");
    let x = Term::var("csr_pi_x");
    let y = Term::var("csr_pi_y");
    let projection_lhs = Term::app(projection_symbol.as_str(), vec![x.clone(), y.clone()]);
    obligations.push(RewriteRule::new(projection_lhs.clone(), x));
    obligations.push(RewriteRule::new(projection_lhs, y));

    // The verified RTA08 checker derives these obligations from the complete
    // transformed signature, not merely from the SCC currently being
    // processed.  Every terminal component therefore needs them, including
    // one whose own pair is non-collapsing.
    let marked_roots = csr.trs().defined_symbols();

    for (symbol, arity) in &arities {
        let arguments = (0..*arity)
            .map(|index| Term::var(format!("csr_arg_{index}")))
            .collect::<Vec<_>>();
        let lhs = Term::app(symbol.as_str(), arguments.clone());
        for (index, argument) in arguments.iter().enumerate() {
            if csr.replacement_map().is_allowed(symbol, index) {
                obligations.push(RewriteRule::new(lhs.clone(), argument.clone()));
                if marked_roots.contains(symbol) {
                    obligations.push(RewriteRule::new(
                        Term::app(format!("{}#", symbol.as_str()), arguments.clone()),
                        argument.clone(),
                    ));
                }
            }
        }
    }

    for symbol in marked_roots {
        let Some(arity) = arities.get(&symbol).copied() else {
            continue;
        };
        let arguments = (0..arity)
            .map(|index| Term::var(format!("csr_mark_arg_{index}")))
            .collect::<Vec<_>>();
        obligations.push(RewriteRule::new(
            Term::app(symbol.as_str(), arguments.clone()),
            Term::app(format!("{}#", symbol.as_str()), arguments),
        ));
    }

    obligations
}

pub(crate) fn is_rta_marking_obligation(rule: &RewriteRule) -> bool {
    let (
        Term::App {
            symbol: lhs_symbol,
            args: lhs_args,
        },
        Term::App {
            symbol: rhs_symbol,
            args: rhs_args,
        },
    ) = (rule.lhs(), rule.rhs())
    else {
        return false;
    };
    rhs_symbol
        .as_str()
        .strip_suffix('#')
        .is_some_and(|base| base == lhs_symbol.as_str())
        && lhs_args == rhs_args
}

pub(super) fn collect_csr_symbols_by_activity(
    csr: &CsrTrs,
    term: &Term,
    position_active: bool,
    collect_active: bool,
    defined: &BTreeSet<Symbol>,
    symbols: &mut BTreeSet<Symbol>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if position_active == collect_active && defined.contains(symbol) {
        symbols.insert(symbol.clone());
    }
    for (index, argument) in args.iter().enumerate() {
        collect_csr_symbols_by_activity(
            csr,
            argument,
            position_active && csr_symbol_allows_argument(csr, symbol, index),
            collect_active,
            defined,
            symbols,
        );
    }
}

pub(super) fn enqueue_csr_u3_rules(
    symbols: &BTreeSet<Symbol>,
    rules_by_root: &BTreeMap<Symbol, Vec<usize>>,
    usable: &mut BTreeSet<usize>,
    pending: &mut VecDeque<usize>,
) {
    for symbol in symbols {
        for index in rules_by_root.get(symbol).into_iter().flatten() {
            if usable.insert(*index) {
                pending.push_back(*index);
            }
        }
    }
}

pub(super) fn collect_csr_u3_symbols(
    csr: &CsrTrs,
    term: &Term,
    all_positions: bool,
    below_inactive: bool,
    symbols: &mut BTreeSet<Symbol>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if all_positions || below_inactive {
        symbols.insert(symbol.clone());
    }
    for (index, argument) in args.iter().enumerate() {
        collect_csr_u3_symbols(
            csr,
            argument,
            all_positions,
            below_inactive || !csr_symbol_allows_argument(csr, symbol, index),
            symbols,
        );
    }
}

pub(super) fn collect_qcs_certificate_usable_rules(
    csr: &CsrTrs,
    term: &Term,
    usable: &mut BTreeSet<usize>,
) {
    match term {
        // A variable can be instantiated by a term with any rewrite root.
        // CeTA's executable qcs_ur_closed_term_check therefore requires all
        // current rules in this case.
        Term::Var(_) => usable.extend(0..csr.rules().len()),
        Term::App { symbol, args } => {
            let root_rules = csr
                .rules()
                .iter()
                .enumerate()
                .filter(|(_, rule)| rule.lhs().root_symbol() == Some(symbol))
                .map(|(index, _)| index)
                .collect::<Vec<_>>();
            for index in root_rules {
                if usable.insert(index) {
                    collect_qcs_certificate_usable_rules(csr, csr.rules()[index].rhs(), usable);
                }
            }
            for (index, argument) in args.iter().enumerate() {
                if csr.replacement_map().is_allowed(symbol, index) {
                    collect_qcs_certificate_usable_rules(csr, argument, usable);
                }
            }
        }
    }
}

/// Computes the estimated QCS usable rules for a standard (non-innermost)
/// context-sensitive dependency-pair problem.
///
/// This follows the simple ECap-mu approximation used by AProVE. In
/// particular, reaching a variable through replacing positions makes every
/// rule usable. Returning a superset is intentional: the result is suitable
/// for sound rule restrictions once the corresponding QCS theorem is checked.
pub fn qcs_usable_rules(csr: &CsrTrs, pairs: &[DependencyPair]) -> Vec<RewriteRule> {
    let mut usable = BTreeSet::new();
    for pair in pairs {
        collect_qcs_usable_rules(csr, pair.rhs(), &mut usable);
        if usable.len() == csr.rules().len() {
            break;
        }
    }
    usable
        .into_iter()
        .map(|index| csr.rules()[index].clone())
        .collect()
}

pub(super) fn collect_qcs_usable_rules(csr: &CsrTrs, term: &Term, usable: &mut BTreeSet<usize>) {
    match term {
        Term::Var(_) => {
            usable.extend(0..csr.rules().len());
        }
        Term::App { symbol, args } => {
            let active_arguments = args
                .iter()
                .enumerate()
                .filter(|(index, _)| csr_symbol_allows_argument(csr, symbol, *index))
                .collect::<Vec<_>>();

            for (_, argument) in &active_arguments {
                collect_qcs_usable_rules(csr, argument, usable);
                if usable.len() == csr.rules().len() {
                    return;
                }
            }

            let capped = Term::app(
                symbol.as_str(),
                args.iter()
                    .enumerate()
                    .map(|(index, argument)| {
                        if csr_symbol_allows_argument(csr, symbol, index) {
                            simple_qcs_ecap(csr, argument)
                        } else {
                            argument.clone()
                        }
                    })
                    .collect(),
            );
            let candidates = csr
                .rules()
                .iter()
                .enumerate()
                .filter(|(_, rule)| rule.lhs().root_symbol() == Some(symbol))
                .filter(|(_, rule)| unifies_with_rule_lhs(&capped, rule.lhs()))
                .map(|(index, _)| index)
                .collect::<Vec<_>>();

            for index in candidates {
                if usable.insert(index) {
                    collect_qcs_usable_rules(csr, csr.rules()[index].rhs(), usable);
                    if usable.len() == csr.rules().len() {
                        return;
                    }
                }
            }
        }
    }
}

pub(super) fn simple_qcs_ecap(csr: &CsrTrs, term: &Term) -> Term {
    fn cap(csr: &CsrTrs, term: &Term, fresh: &mut usize) -> Term {
        match term {
            Term::Var(_) => {
                let result = Term::var(format!("qcs_cap_{fresh}"));
                *fresh += 1;
                result
            }
            Term::App { symbol, .. } if csr.trs().defined_symbols().contains(symbol) => {
                let result = Term::var(format!("qcs_cap_{fresh}"));
                *fresh += 1;
                result
            }
            Term::App { symbol, args } => Term::app(
                symbol.as_str(),
                args.iter()
                    .enumerate()
                    .map(|(index, argument)| {
                        if csr_symbol_allows_argument(csr, symbol, index) {
                            cap(csr, argument, fresh)
                        } else {
                            argument.clone()
                        }
                    })
                    .collect(),
            ),
        }
    }

    cap(csr, term, &mut 0)
}

pub(crate) fn usable_rules_in_innermost_context(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) -> Vec<RewriteRule> {
    let Some(lhss) = innermost_lhss else {
        return usable_rules(trs, pairs);
    };

    let pair_usable = ceta_innermost_usable_rules_for_pairs(trs.rules(), lhss, pairs);
    // `ceta_innermost_usable_rules_for_pair` already performs the complete
    // pair-local icap_Q fixed point, including recursive closure through the
    // RHSs of admitted rules.  Completing by root here is strictly less
    // precise: it revives siblings whose LHS cannot match the Q-normal cap
    // (for example g(0) at the innermost5 hard residual), although CeTA and
    // AProVE's matchCapRMBelow criterion correctly omit them.
    let usable = trs
        .rules()
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| pair_usable.contains(rule).then_some(index))
        .collect::<BTreeSet<_>>();
    usable
        .into_iter()
        .map(|index| trs.rules()[index].clone())
        .collect()
}

/// Conservatively close an innermost usable-rule set for a non-monotone
/// reduction pair.
///
/// The standalone usable-rules processor is checked with the full argument
/// filter. A following `redPairUrProc` is checked with the filter induced by
/// its interpretation, so a root-completed sibling can expose additional
/// rules. Repeating closure here prevents emitting a reduction pair whose
/// printed usable-rule obligation CeTA rejects.
pub(crate) fn innermost_reduction_pair_usable_rules(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: &[Term],
) -> Vec<RewriteRule> {
    let initial = usable_rules_in_innermost_context(trs, pairs, Some(innermost_lhss));
    let mut usable = trs
        .rules()
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| initial.contains(rule).then_some(index))
        .collect::<BTreeSet<_>>();
    loop {
        let before = usable.len();
        let usable_roots = usable
            .iter()
            .filter_map(|index| trs.rules()[*index].lhs().root_symbol().cloned())
            .collect::<BTreeSet<_>>();
        for (index, rule) in trs.rules().iter().enumerate() {
            if rule
                .lhs()
                .root_symbol()
                .is_some_and(|root| usable_roots.contains(root))
            {
                usable.insert(index);
            }
        }
        for index in usable.iter().copied().collect::<Vec<_>>() {
            let rule = &trs.rules()[index];
            for required in ceta_innermost_usable_rules_for_term(
                trs.rules(),
                innermost_lhss,
                term_arguments(rule.lhs()),
                rule.rhs(),
            ) {
                if let Some(required_index) = trs
                    .rules()
                    .iter()
                    .position(|candidate| candidate == &required)
                {
                    usable.insert(required_index);
                }
            }
        }
        if usable.len() == before {
            break;
        }
    }

    usable
        .into_iter()
        .map(|index| trs.rules()[index].clone())
        .collect()
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ComponentRemoval {
    pub(crate) strict_pair_indices: Vec<usize>,
    pub(crate) strict_rule_indices: Vec<usize>,
    pub(crate) reduction_pair: DpReductionPairProof,
    pub(crate) smt_attempted: bool,
    pub(crate) usable_rules: Option<Vec<RewriteRule>>,
}
