use super::*;

#[derive(Default)]
struct Cnf {
    next_variable: i32,
    clauses: Vec<Vec<i32>>,
    and_gates: BTreeMap<(i32, i32), i32>,
    or_gates: BTreeMap<(i32, i32), i32>,
    xor_gates: BTreeMap<(i32, i32), i32>,
}

impl Cnf {
    const TRUE: i32 = 1;
    const FALSE: i32 = -1;

    fn new() -> Self {
        Self {
            next_variable: 2,
            clauses: vec![vec![Self::TRUE]],
            ..Self::default()
        }
    }

    fn variable(&mut self) -> i32 {
        let variable = self.next_variable;
        self.next_variable += 1;
        variable
    }

    fn assert(&mut self, literal: i32) {
        self.clauses.push(vec![literal]);
    }

    fn and(&mut self, left: i32, right: i32) -> i32 {
        if left == Self::FALSE || right == Self::FALSE || left == -right {
            return Self::FALSE;
        }
        if left == Self::TRUE {
            return right;
        }
        if right == Self::TRUE || left == right {
            return left;
        }
        let key = ordered_literals(left, right);
        if let Some(output) = self.and_gates.get(&key) {
            return *output;
        }
        let output = self.variable();
        self.clauses.push(vec![-output, left]);
        self.clauses.push(vec![-output, right]);
        self.clauses.push(vec![output, -left, -right]);
        self.and_gates.insert(key, output);
        output
    }

    fn or(&mut self, left: i32, right: i32) -> i32 {
        if left == Self::TRUE || right == Self::TRUE || left == -right {
            return Self::TRUE;
        }
        if left == Self::FALSE {
            return right;
        }
        if right == Self::FALSE || left == right {
            return left;
        }
        let key = ordered_literals(left, right);
        if let Some(output) = self.or_gates.get(&key) {
            return *output;
        }
        let output = self.variable();
        self.clauses.push(vec![output, -left]);
        self.clauses.push(vec![output, -right]);
        self.clauses.push(vec![-output, left, right]);
        self.or_gates.insert(key, output);
        output
    }

    fn xor(&mut self, left: i32, right: i32) -> i32 {
        if left == Self::FALSE {
            return right;
        }
        if right == Self::FALSE {
            return left;
        }
        if left == Self::TRUE {
            return -right;
        }
        if right == Self::TRUE {
            return -left;
        }
        if left == right {
            return Self::FALSE;
        }
        if left == -right {
            return Self::TRUE;
        }
        let key = ordered_literals(left, right);
        if let Some(output) = self.xor_gates.get(&key) {
            return *output;
        }
        let output = self.variable();
        self.clauses.push(vec![-output, -left, -right]);
        self.clauses.push(vec![-output, left, right]);
        self.clauses.push(vec![output, -left, right]);
        self.clauses.push(vec![output, left, -right]);
        self.xor_gates.insert(key, output);
        output
    }

    fn and_all(&mut self, literals: impl IntoIterator<Item = i32>) -> i32 {
        literals
            .into_iter()
            .fold(Self::TRUE, |result, literal| self.and(result, literal))
    }

    fn or_all(&mut self, literals: impl IntoIterator<Item = i32>) -> i32 {
        literals
            .into_iter()
            .fold(Self::FALSE, |result, literal| self.or(result, literal))
    }

    fn equivalent(&mut self, left: i32, right: i32) -> i32 {
        -self.xor(left, right)
    }

    fn exactly_one(&mut self, literals: &[i32]) {
        let some = self.or_all(literals.iter().copied());
        self.assert(some);
        for left in 0..literals.len() {
            for right in (left + 1)..literals.len() {
                self.clauses.push(vec![-literals[left], -literals[right]]);
            }
        }
    }

    fn dimacs(&self) -> String {
        let mut output = format!("p cnf {} {}\n", self.next_variable - 1, self.clauses.len());
        for clause in &self.clauses {
            for literal in clause {
                output.push_str(&format!("{literal} "));
            }
            output.push_str("0\n");
        }
        output
    }
}

fn ordered_literals(left: i32, right: i32) -> (i32, i32) {
    if left <= right {
        (left, right)
    } else {
        (right, left)
    }
}

struct SemanticSatEncoder {
    cnf: Cnf,
    candidates: BTreeMap<Symbol, Vec<SlArithmeticFunction>>,
    selectors: BTreeMap<Symbol, Vec<i32>>,
}

impl SemanticSatEncoder {
    fn new(
        symbols: &[(Symbol, usize)],
        defined_symbols: &BTreeSet<Symbol>,
        lhs_symbols: &BTreeSet<Symbol>,
    ) -> Self {
        let mut cnf = Cnf::new();
        let mut candidates = BTreeMap::new();
        let mut selectors = BTreeMap::new();
        for (symbol, arity) in symbols {
            let prefer_nonzero_constant = lhs_symbols.contains(symbol)
                && !defined_symbols.contains(symbol)
                && !symbol.as_str().ends_with('#');
            let functions =
                semantic_labeling_function_candidates(*arity, 2, prefer_nonzero_constant);
            let choices = (0..functions.len())
                .map(|_| cnf.variable())
                .collect::<Vec<_>>();
            cnf.exactly_one(&choices);
            candidates.insert(symbol.clone(), functions);
            selectors.insert(symbol.clone(), choices);
        }
        let informative = candidates.iter().flat_map(|(symbol, functions)| {
            functions
                .iter()
                .zip(selectors.get(symbol).into_iter().flatten())
                .filter_map(|(function, selector)| {
                    (!matches!(function, SlArithmeticFunction::Constant(_))).then_some(*selector)
                })
        });
        let informative = cnf.or_all(informative.collect::<Vec<_>>());
        cnf.assert(informative);
        Self {
            cnf,
            candidates,
            selectors,
        }
    }

    fn term_value(&mut self, term: &Term, environment: &BTreeMap<Variable, usize>) -> Option<i32> {
        match term {
            Term::Var(variable) => Some(if environment.get(variable)? % 2 == 0 {
                Cnf::FALSE
            } else {
                Cnf::TRUE
            }),
            Term::App { symbol, args } => {
                let arguments = args
                    .iter()
                    .map(|argument| self.term_value(argument, environment))
                    .collect::<Option<Vec<_>>>()?;
                let candidates = self.candidates.get(symbol)?.clone();
                let selectors = self.selectors.get(symbol)?.clone();
                let guarded = candidates
                    .iter()
                    .zip(selectors)
                    .map(|(candidate, selector)| {
                        let value = self.function_value(candidate, &arguments);
                        self.cnf.and(selector, value)
                    })
                    .collect::<Vec<_>>();
                Some(self.cnf.or_all(guarded))
            }
        }
    }

    fn function_value(&mut self, function: &SlArithmeticFunction, arguments: &[i32]) -> i32 {
        match function {
            SlArithmeticFunction::IfEqual(parts) => {
                let values = parts.each_ref().map(|part| self.function_value(part, arguments));
                let different = self.cnf.xor(values[0], values[1]);
                let yes = self.cnf.and_all([-different, values[2]]);
                let no = self.cnf.and_all([different, values[3]]);
                self.cnf.or_all([yes, no])
            }
            SlArithmeticFunction::Constant(value) => {
                if value % 2 == 0 {
                    Cnf::FALSE
                } else {
                    Cnf::TRUE
                }
            }
            SlArithmeticFunction::Argument(index) => {
                arguments.get(*index).copied().unwrap_or(Cnf::FALSE)
            }
            SlArithmeticFunction::Sum(items) => items.iter().fold(Cnf::FALSE, |value, item| {
                let item = self.function_value(item, arguments);
                self.cnf.xor(value, item)
            }),
            SlArithmeticFunction::Product(items) => {
                let values = items
                    .iter()
                    .map(|item| self.function_value(item, arguments))
                    .collect::<Vec<_>>();
                self.cnf.and_all(values)
            }
        }
    }

    fn assert_rule_assignments(
        &mut self,
        rule: &RewriteRule,
        variables: &[Variable],
        index: usize,
        environment: &mut BTreeMap<Variable, usize>,
        deadline: Option<Instant>,
        cancellation: &DpStrategyCancellation,
    ) -> Option<()> {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        if index == variables.len() {
            let lhs = self.term_value(rule.lhs(), environment)?;
            let rhs = self.term_value(rule.rhs(), environment)?;
            let equivalent = self.cnf.equivalent(lhs, rhs);
            self.cnf.assert(equivalent);
            return Some(());
        }
        let variable = variables[index].clone();
        for value in 0..2 {
            environment.insert(variable.clone(), value);
            self.assert_rule_assignments(
                rule,
                variables,
                index + 1,
                environment,
                deadline,
                cancellation,
            )?;
        }
        environment.remove(&variable);
        Some(())
    }
}

pub(super) fn synthesize(
    trs: &Trs,
    symbols: &[(Symbol, usize)],
    defined_symbols: &BTreeSet<Symbol>,
    lhs_symbols: &BTreeSet<Symbol>,
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<SemanticLabelingModel> {
    synthesize_restricted(trs, symbols, defined_symbols, lhs_symbols, base_model, deadline, cancellation, false)
}

pub(super) fn synthesize_conjunctive(
    trs: &Trs,
    symbols: &[(Symbol, usize)],
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<SemanticLabelingModel> {
    synthesize_restricted(trs, symbols, &BTreeSet::new(), &BTreeSet::new(), base_model, deadline, cancellation, true)
}

fn synthesize_restricted(
    trs: &Trs,
    symbols: &[(Symbol, usize)],
    defined_symbols: &BTreeSet<Symbol>,
    lhs_symbols: &BTreeSet<Symbol>,
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
    conjunctive: bool,
) -> Option<SemanticLabelingModel> {
    if symbols.is_empty() || semlab_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    let mut encoder = SemanticSatEncoder::new(symbols, defined_symbols, lhs_symbols);
    if conjunctive {
        // Synthesize a nontrivial two-valued constructor invariant in one
        // query. Positive-arity functions propagate conjunction; constants
        // are jointly inferred from all rule equations, not enumerated or
        // recognized by their names.
        let mut constants = Vec::new();
        for (symbol, arity) in symbols {
            if *arity > 8 { return None; }
            let functions = &encoder.candidates[symbol];
            let wanted = functions.iter().position(|f| {
                if *arity == 0 { return f == &SlArithmeticFunction::Constant(1); }
                (0..1usize << arity).all(|bits| {
                    let args = (0..*arity).map(|i| (bits >> i) & 1).collect::<Vec<_>>();
                    f.eval(&args, 2) == Some(usize::from(args.iter().all(|a| *a == 1)))
                })
            })?;
            let selector = encoder.selectors[symbol][wanted];
            if *arity == 0 { constants.push(selector); } else { encoder.cnf.assert(selector); }
        }
        if constants.len() < 2 { return None; }
        let some_true = encoder.cnf.or_all(constants.iter().copied());
        let some_false = encoder.cnf.or_all(constants.iter().map(|c| -*c));
        encoder.cnf.assert(some_true);
        encoder.cnf.assert(some_false);
    }
    for rule in trs.rules() {
        let mut variables = rule.lhs().variables();
        variables.extend(rule.rhs().variables());
        encoder.assert_rule_assignments(
            rule,
            &variables.into_iter().collect::<Vec<_>>(),
            0,
            &mut BTreeMap::new(),
            deadline,
            cancellation,
        )?;
    }
    let solver = std::env::var("FERRUM_DIRECT_SAT_SOLVER").ok().or_else(|| [
        ".tools/kissat-sc2025",
        ".tools/kissat",
        "kissat",
        ".tools/cadical-sc2025",
        "cadical",
        "z3",
    ]
    .into_iter()
    .find(|solver| command_exists(solver)).map(str::to_string))?;
    let dimacs = encoder.cnf.dimacs();
    write_progress_event(
        "dp-semantic-labeling",
        "encoded",
        if conjunctive { "conjunctive-direct-sat" } else { "direct-sat" },
        0,
        &format!(
            "symbols={} variables={} clauses={} dimacs_bytes={} solver={solver}",
            symbols.len(),
            encoder.cnf.next_variable - 1,
            encoder.cnf.clauses.len(),
            dimacs.len(),
        ),
    );
    let mut command = Command::new(&solver);
    if std::path::Path::new(&solver).file_name().is_some_and(|name| name == "z3") {
        command.args(["-dimacs", "-in"]);
    }
    command.stderr(Stdio::piped());
    let output = run_command_with_input_deadline(&mut command, &dimacs, deadline)
        .ok()
        .flatten()?;
    let stdout = String::from_utf8_lossy(&output.stdout);
    let model = parse_dimacs_model(&stdout)?;
    let mut result = base_model.clone();
    for (symbol, candidates) in &encoder.candidates {
        let selectors = &encoder.selectors[symbol];
        let index = selectors
            .iter()
            .position(|selector| literal_is_true(*selector, &model))?;
        result
            .interpretations
            .insert(symbol.clone(), candidates.get(index)?.clone());
    }
    semantic_labeling_model_condition_holds(&result, trs.rules(), deadline, cancellation)
        .then_some(result)
}

fn parse_dimacs_model(output: &str) -> Option<BTreeSet<i32>> {
    output
        .lines()
        .any(|line| line.trim() == "s SATISFIABLE" || line.trim() == "SAT")
        .then(|| {
            output
                .lines()
                .filter_map(|line| line.trim().strip_prefix('v'))
                .flat_map(str::split_whitespace)
                .filter_map(|literal| literal.parse::<i32>().ok())
                .filter(|literal| *literal > 0)
                .collect()
        })
}

fn literal_is_true(literal: i32, model: &BTreeSet<i32>) -> bool {
    let assigned = model.contains(&(literal.unsigned_abs() as i32));
    if literal > 0 { assigned } else { !assigned }
}

#[derive(Clone)]
struct GoalPolynomialForm {
    constant: String,
    coefficients: BTreeMap<Variable, String>,
}

struct GoalDirectedEncoder<'a> {
    symbol_indices: BTreeMap<Symbol, usize>,
    candidates: BTreeMap<Symbol, Vec<SlArithmeticFunction>>,
    script: String,
    selector_names: Vec<String>,
    strict_progress: Vec<String>,
    max_constant: usize,
    shared: bool,
    next_definition: usize,
    semantic_cache: BTreeMap<(Term, BTreeMap<Variable, bool>), String>,
    polynomial_cache: BTreeMap<(Term, BTreeMap<Variable, bool>), GoalPolynomialForm>,
    _marker: std::marker::PhantomData<&'a ()>,
}

impl<'a> GoalDirectedEncoder<'a> {
    fn new(symbols: &[(Symbol, usize)], max_constant: usize) -> Self {
        let symbol_indices = symbols
            .iter()
            .enumerate()
            .map(|(index, (symbol, _))| (symbol.clone(), index))
            .collect::<BTreeMap<_, _>>();
        let candidates = symbols
            .iter()
            .map(|(symbol, arity)| {
                (
                    symbol.clone(),
                    semantic_labeling_function_candidates(*arity, 2, false),
                )
            })
            .collect::<BTreeMap<_, _>>();
        Self {
            symbol_indices,
            candidates,
            script: "(set-logic QF_LIA)\n".to_string(),
            selector_names: Vec::new(),
            strict_progress: Vec::new(),
            max_constant,
            shared: std::env::var_os("FERRUM_SEMLAB_GOAL_SHARED").is_some(),
            next_definition: 0,
            semantic_cache: BTreeMap::new(),
            polynomial_cache: BTreeMap::new(),
            _marker: std::marker::PhantomData,
        }
    }

    fn selector_name(&self, symbol: &Symbol, candidate: usize) -> String {
        format!("gsl_s{}_c{candidate}", self.symbol_indices[symbol])
    }

    fn polynomial_name(&self, symbol: &Symbol, labels: usize) -> String {
        format!("gsl_p{}_l{labels}", self.symbol_indices[symbol])
    }

    fn polynomial_coefficient_name(
        &self,
        symbol: &Symbol,
        labels: usize,
        argument: usize,
    ) -> String {
        format!("gsl_a{}_l{labels}_x{argument}", self.symbol_indices[symbol])
    }

    fn declare_parameters(&mut self, symbols: &[(Symbol, usize)]) {
        for (symbol, arity) in symbols {
            let selectors = (0..self.candidates[symbol].len())
                .map(|candidate| {
                    let name = self.selector_name(symbol, candidate);
                    self.script
                        .push_str(&format!("(declare-fun {name} () Bool)\n"));
                    self.selector_names.push(name.clone());
                    name
                })
                .collect::<Vec<_>>();
            self.script
                .push_str(&format!("(assert (or {}))\n", selectors.join(" ")));
            for left in 0..selectors.len() {
                for right in (left + 1)..selectors.len() {
                    self.script.push_str(&format!(
                        "(assert (or (not {}) (not {})))\n",
                        selectors[left], selectors[right]
                    ));
                }
            }
            for labels in 0..(1usize << arity) {
                let name = self.polynomial_name(symbol, labels);
                self.script.push_str(&format!(
                    "(declare-fun {name} () Int)\n(assert (and (<= 0 {name}) (<= {name} {})))\n",
                    self.max_constant
                ));
                for argument in 0..*arity {
                    let coefficient = self.polynomial_coefficient_name(symbol, labels, argument);
                    self.script.push_str(&format!(
                        "(declare-fun {coefficient} () Int)\n(assert (and (<= 0 {coefficient}) (<= {coefficient} 1)))\n"
                    ));
                }
            }
        }
    }

    fn semantic_value(
        &mut self,
        term: &Term,
        environment: &BTreeMap<Variable, bool>,
    ) -> Option<String> {
        let key = self.shared.then(|| (term.clone(), environment.clone()));
        if let Some(value) = key.as_ref().and_then(|key| self.semantic_cache.get(key)) {
            return Some(value.clone());
        }
        let value = match term {
            Term::Var(variable) => Some(environment.get(variable)?.to_string()),
            Term::App { symbol, args } => {
                let arguments = args
                    .iter()
                    .map(|argument| self.semantic_value(argument, environment))
                    .collect::<Option<Vec<_>>>()?;
                let choices = self.candidates.get(symbol)?;
                let alternatives = choices
                    .iter()
                    .enumerate()
                    .map(|(index, candidate)| {
                        let selector = self.selector_name(symbol, index);
                        let value = goal_semantic_function(candidate, &arguments)?;
                        Some(format!("(and {selector} {value})"))
                    })
                    .collect::<Option<Vec<_>>>()?;
                Some(format!("(or {})", alternatives.join(" ")))
            }
        }?;
        if let Some(key) = key {
            let value = self.bind("Bool", value);
            self.semantic_cache.insert(key, value.clone());
            Some(value)
        } else { Some(value) }
    }

    fn bind(&mut self, sort: &str, value: String) -> String {
        let name = format!("gsl_shared_{}", self.next_definition);
        self.next_definition += 1;
        self.script.push_str(&format!("(define-fun {name} () {sort} {value})\n"));
        name
    }

    fn polynomial_constant(&self, symbol: &Symbol, arguments: &[String]) -> String {
        self.polynomial_parameter(symbol, arguments, |labels| {
            self.polynomial_name(symbol, labels)
        })
    }

    fn polynomial_coefficient(
        &self,
        symbol: &Symbol,
        arguments: &[String],
        argument: usize,
    ) -> String {
        self.polynomial_parameter(symbol, arguments, |labels| {
            self.polynomial_coefficient_name(symbol, labels, argument)
        })
    }

    fn polynomial_parameter(
        &self,
        _symbol: &Symbol,
        arguments: &[String],
        parameter: impl Fn(usize) -> String,
    ) -> String {
        if arguments.is_empty() {
            return parameter(0);
        }
        let mut result = parameter(0);
        for labels in 1..(1usize << arguments.len()) {
            let condition = arguments
                .iter()
                .enumerate()
                .map(|(index, argument)| {
                    if labels & (1 << index) == 0 {
                        format!("(not {argument})")
                    } else {
                        argument.clone()
                    }
                })
                .collect::<Vec<_>>();
            result = format!(
                "(ite (and {}) {} {result})",
                condition.join(" "),
                parameter(labels)
            );
        }
        result
    }

    fn polynomial_form(
        &mut self,
        term: &Term,
        environment: &BTreeMap<Variable, bool>,
    ) -> Option<GoalPolynomialForm> {
        let key = self.shared.then(|| (term.clone(), environment.clone()));
        if let Some(form) = key.as_ref().and_then(|key| self.polynomial_cache.get(key)) {
            return Some(form.clone());
        }
        let form = match term {
            Term::Var(variable) => Some(GoalPolynomialForm {
                constant: "0".to_string(),
                coefficients: BTreeMap::from([(variable.clone(), "1".to_string())]),
            }),
            Term::App { symbol, args } => {
                let semantic_arguments = args
                    .iter()
                    .map(|argument| self.semantic_value(argument, environment))
                    .collect::<Option<Vec<_>>>()?;
                let mut constants = vec![self.polynomial_constant(symbol, &semantic_arguments)];
                let mut coefficients = BTreeMap::new();
                for (index, argument) in args.iter().enumerate() {
                    let form = self.polynomial_form(argument, environment)?;
                    let coefficient =
                        self.polynomial_coefficient(symbol, &semantic_arguments, index);
                    constants.push(format!("(ite (= {coefficient} 0) 0 {})", form.constant));
                    for (variable, coefficient) in form.coefficients {
                        let outer = self.polynomial_coefficient(symbol, &semantic_arguments, index);
                        let scaled = format!("(ite (= {outer} 0) 0 {coefficient})");
                        coefficients
                            .entry(variable)
                            .and_modify(|old: &mut String| *old = format!("(+ {old} {scaled})"))
                            .or_insert(scaled);
                    }
                }
                Some(GoalPolynomialForm {
                    constant: format!("(+ {})", constants.join(" ")),
                    coefficients,
                })
            }
        }?;
        if let Some(key) = key {
            let form = GoalPolynomialForm {
                constant: self.bind("Int", form.constant),
                coefficients: form.coefficients.into_iter()
                    .map(|(variable, value)| (variable, self.bind("Int", value))).collect(),
            };
            self.polynomial_cache.insert(key, form.clone());
            Some(form)
        } else { Some(form) }
    }

    fn assert_rule_assignment(
        &mut self,
        rule: &RewriteRule,
        environment: &BTreeMap<Variable, bool>,
        strict: bool,
    ) -> Option<()> {
        let lhs_value = self.semantic_value(rule.lhs(), environment)?;
        let rhs_value = self.semantic_value(rule.rhs(), environment)?;
        self.script
            .push_str(&format!("(assert (= {lhs_value} {rhs_value}))\n"));
        let lhs = self.polynomial_form(rule.lhs(), environment)?;
        let rhs = self.polynomial_form(rule.rhs(), environment)?;
        let variables = lhs
            .coefficients
            .keys()
            .chain(rhs.coefficients.keys())
            .cloned()
            .collect::<BTreeSet<_>>();
        for variable in variables {
            let lhs_coefficient = lhs
                .coefficients
                .get(&variable)
                .map(String::as_str)
                .unwrap_or("0");
            let rhs_coefficient = rhs
                .coefficients
                .get(&variable)
                .map(String::as_str)
                .unwrap_or("0");
            self.script.push_str(&format!(
                "(assert (>= {lhs_coefficient} {rhs_coefficient}))\n"
            ));
        }
        self.script.push_str(&format!(
            "(assert (>= {} {}))\n",
            lhs.constant, rhs.constant
        ));
        if strict {
            self.strict_progress
                .push(format!("(> {} {})", lhs.constant, rhs.constant));
        }
        Some(())
    }

    fn assert_rule(
        &mut self,
        rule: &RewriteRule,
        strict: bool,
        variables: &[Variable],
        index: usize,
        environment: &mut BTreeMap<Variable, bool>,
    ) -> Option<()> {
        if index == variables.len() {
            return self.assert_rule_assignment(rule, environment, strict);
        }
        let variable = variables[index].clone();
        for value in [false, true] {
            environment.insert(variable.clone(), value);
            self.assert_rule(rule, strict, variables, index + 1, environment)?;
        }
        environment.remove(&variable);
        Some(())
    }
}

fn goal_semantic_function(function: &SlArithmeticFunction, arguments: &[String]) -> Option<String> {
    match function {
        SlArithmeticFunction::IfEqual(parts) => {
            let values = parts.iter().map(|part| goal_semantic_function(part, arguments))
                .collect::<Option<Vec<_>>>()?;
            Some(format!("(ite (= {} {}) {} {})", values[0], values[1], values[2], values[3]))
        }
        SlArithmeticFunction::Constant(value) => Some((value % 2 == 1).to_string()),
        SlArithmeticFunction::Argument(index) => arguments.get(*index).cloned(),
        SlArithmeticFunction::Sum(items) => {
            let items = items
                .iter()
                .map(|item| goal_semantic_function(item, arguments))
                .collect::<Option<Vec<_>>>()?;
            Some(match items.as_slice() {
                [] => "false".to_string(),
                [item] => item.clone(),
                _ => format!("(xor {})", items.join(" ")),
            })
        }
        SlArithmeticFunction::Product(items) => {
            let items = items
                .iter()
                .map(|item| goal_semantic_function(item, arguments))
                .collect::<Option<Vec<_>>>()?;
            Some(match items.as_slice() {
                [] => "true".to_string(),
                [item] => item.clone(),
                _ => format!("(and {})", items.join(" ")),
            })
        }
    }
}

pub(super) fn synthesize_goal_directed_relative(
    relative: &RelativeTrs,
    symbols: &[(Symbol, usize)],
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<(SemanticLabelingModel, Vec<(String, i64, Vec<i64>)>)> {
    if semlab_timed_out_or_cancelled(deadline, cancellation)
        || symbols.len() > 128
        || relative.strict().rules().len() > if std::env::var_os("FERRUM_SEMLAB_LARGE_GOAL").is_some() { 128 } else { 4 }
        || relative.strict().rules().len() + relative.weak_rules().len() > 256
    {
        return None;
    }
    let solver = ["z3", "cvc5"]
        .into_iter()
        .find(|solver| command_exists(solver))?;
    let mut encoder = GoalDirectedEncoder::new(symbols, 1);
    encoder.declare_parameters(symbols);
    for (rules, strict) in [
        (relative.strict().rules(), true),
        (relative.weak_rules(), false),
    ] {
        for rule in rules {
            let mut variables = rule.lhs().variables();
            variables.extend(rule.rhs().variables());
            encoder.assert_rule(
                rule,
                strict,
                &variables.into_iter().collect::<Vec<_>>(),
                0,
                &mut BTreeMap::new(),
            )?;
        }
    }
    if encoder.strict_progress.is_empty() {
        return None;
    }
    encoder.script.push_str(&format!(
        "(assert (or {}))\n",
        encoder.strict_progress.join(" ")
    ));
    let score = encoder
        .strict_progress
        .iter()
        .map(|strict| format!("(ite {strict} 1 0)"))
        .collect::<Vec<_>>()
        .join(" ");
    let required_progress = if std::env::var("FERRUM_SEMLAB_LARGE_GOAL").as_deref() == Ok("partial") {
        1
    } else { encoder.strict_progress.len().saturating_sub(2).max(1) };
    encoder
        .script
        .push_str(&format!("(assert (>= (+ {score}) {required_progress}))\n"));
    encoder.script.push_str("(check-sat)\n");
    let mut polynomial_names = Vec::new();
    for (symbol, arity) in symbols {
        for labels in 0..(1usize << arity) {
            polynomial_names.push(encoder.polynomial_name(symbol, labels));
            for argument in 0..*arity {
                polynomial_names
                    .push(encoder.polynomial_coefficient_name(symbol, labels, argument));
            }
        }
    }
    let mut requested_names = encoder.selector_names.clone();
    requested_names.extend(polynomial_names.iter().cloned());
    encoder
        .script
        .push_str(&format!("(get-value ({}))\n", requested_names.join(" ")));
    write_progress_event(
        "relative-semantic-labeling",
        "encoded",
        "joint-additive-polynomial",
        0,
        &format!(
            "symbols={} strict_rules={} weak_rules={} bytes={} solver={solver}",
            symbols.len(),
            relative.strict().rules().len(),
            relative.weak_rules().len(),
            encoder.script.len()
        ),
    );
    let mut command = Command::new(solver);
    if solver == "z3" {
        command.arg("-in");
    } else {
        command.args(["--lang=smt2", "--produce-models"]);
    }
    command.stderr(Stdio::piped());
    let output = run_command_with_input_deadline(&mut command, &encoder.script, deadline)
        .ok()
        .flatten()?;
    let stdout = String::from_utf8_lossy(&output.stdout);
    write_progress_event(
        "relative-semantic-labeling",
        "solver-result",
        "joint-additive-polynomial",
        0,
        stdout.lines().next().unwrap_or("empty solver output"),
    );
    if !stdout.lines().any(|line| line.trim() == "sat") {
        return None;
    }
    let values = parse_smt_bool_values(&stdout)?;
    let integer_values = parse_smt_get_value_integers(&stdout);
    write_progress_event(
        "relative-semantic-labeling",
        "decoded",
        "joint-additive-polynomial",
        0,
        &format!(
            "requested_selectors={} decoded_bools={} output_bytes={}",
            encoder.selector_names.len(),
            values.len(),
            stdout.len()
        ),
    );
    let mut result = base_model.clone();
    for (symbol, candidates) in &encoder.candidates {
        let selected = candidates.iter().enumerate().position(|(index, _)| {
            values
                .get(&encoder.selector_name(symbol, index))
                .copied()
                .unwrap_or(false)
        })?;
        result
            .interpretations
            .insert(symbol.clone(), candidates[selected].clone());
    }
    let union = relative.union();
    let mut used_labeled_symbols = BTreeMap::new();
    for rule in union.rules() {
        for labeled in semantic_label_rule_instances(&result, rule, deadline, cancellation)? {
            collect_symbol_arities(labeled.lhs(), &mut used_labeled_symbols);
            collect_symbol_arities(labeled.rhs(), &mut used_labeled_symbols);
        }
    }
    let interpretation = symbols
        .iter()
        .flat_map(|(symbol, arity)| {
            (0..(1usize << arity)).filter_map(|labels| {
                let label_values = (0..*arity)
                    .map(|index| usize::from(labels & (1 << index) != 0))
                    .collect::<Vec<_>>();
                let labeled_symbol = semantic_label_symbol(symbol, &label_values);
                if !used_labeled_symbols.contains_key(&Symbol::new(labeled_symbol.clone())) {
                    return None;
                }
                Some((
                    labeled_symbol,
                    *integer_values.get(&encoder.polynomial_name(symbol, labels))?,
                    (0..*arity)
                        .map(|argument| {
                            integer_values
                                .get(&encoder.polynomial_coefficient_name(symbol, labels, argument))
                                .copied()
                        })
                        .collect::<Option<Vec<_>>>()?,
                ))
            })
        })
        .collect::<Vec<_>>();
    if !interpretation.is_empty()
        && let Ok(encoded) = serde_json::to_vec(&interpretation)
    {
        let encoded = encoded
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>();
        write_progress_event(
            "dp-semantic-labeling",
            "exact-order",
            "joint-additive-polynomial",
            0,
            &format!("exact-poly(hex={encoded})"),
        );
    }
    semantic_labeling_model_condition_holds(&result, union.rules(), deadline, cancellation)
        .then_some((result, interpretation))
}

fn parse_smt_get_value_integers(output: &str) -> BTreeMap<String, i64> {
    let normalized = output.replace('(', " ( ").replace(')', " ) ");
    let tokens = normalized.split_whitespace().collect::<Vec<_>>();
    let mut values = BTreeMap::new();
    for window in tokens.windows(4) {
        if window[0] == "("
            && window[3] == ")"
            && let Ok(value) = window[2].parse::<i64>()
        {
            values.insert(window[1].to_string(), value);
        }
    }
    values
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shared_goal_encoding_preserves_semantics_and_assignments() {
        let symbols = vec![(Symbol::new("f"), 1), (Symbol::new("g"), 1)];
        let mut encoder = GoalDirectedEncoder::new(&symbols, 2);
        encoder.shared = false;
        encoder.declare_parameters(&symbols);
        let term = (0..6).fold(Term::var("x"), |t,i|
            Term::app(if i%2==0 {"f"} else {"g"}, vec![t]));
        let environment = BTreeMap::from([(Variable::new("x"), false)]);
        let plain_value = encoder.semantic_value(&term, &environment).unwrap();
        let plain_form = encoder.polynomial_form(&term, &environment).unwrap();
        encoder.shared = true;
        let shared_value = encoder.semantic_value(&term, &environment).unwrap();
        let shared_form = encoder.polynomial_form(&term, &environment).unwrap();
        let definitions = encoder.next_definition;
        assert_eq!(encoder.semantic_value(&term, &environment).unwrap(), shared_value);
        assert_eq!(encoder.polynomial_form(&term, &environment).unwrap().constant, shared_form.constant);
        assert_eq!(definitions, encoder.next_definition);
        let other = BTreeMap::from([(Variable::new("x"), true)]);
        assert_ne!(encoder.semantic_value(&term, &other).unwrap(), shared_value);
        let mut differences=vec![format!("(distinct {plain_value} {shared_value})"),
            format!("(distinct {} {})", plain_form.constant, shared_form.constant)];
        for (v,c) in plain_form.coefficients {
            differences.push(format!("(distinct {c} {})", shared_form.coefficients[&v]));
        }
        encoder.script.push_str(&format!("(assert (or {}))\n(check-sat)\n", differences.join(" ")));
        let mut command=Command::new("z3");command.arg("-in");
        let output=run_command_with_input_deadline(&mut command,&encoder.script,
            Some(Instant::now()+Duration::from_secs(30))).unwrap().unwrap();
        assert_eq!(String::from_utf8_lossy(&output.stdout).split_whitespace().next(),Some("unsat"));
    }

    #[test]
    fn parses_every_boolean_from_z3_get_value_output() {
        let values = parse_smt_bool_values("sat\n((first true)\n (second false)\n (third true))\n")
            .expect("Boolean SMT values");
        assert_eq!(
            values,
            BTreeMap::from([
                ("first".to_string(), true),
                ("second".to_string(), false),
                ("third".to_string(), true),
            ])
        );
    }

    #[test]
    fn direct_sat_model_satisfies_the_native_semantic_labeling_condition() {
        if !command_exists(".tools/kissat-sc2025")
            && !command_exists(".tools/kissat")
            && !command_exists("kissat")
            && !command_exists(".tools/cadical-sc2025")
            && !command_exists("cadical")
        {
            return;
        }
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![rule]);
        let symbols = vec![(Symbol::new("f"), 1)];
        let base = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };
        let cancellation = DpStrategyCancellation::default();
        let model = synthesize(
            &trs,
            &symbols,
            &trs.defined_symbols(),
            &BTreeSet::from([Symbol::new("f")]),
            &base,
            None,
            &cancellation,
        )
        .expect("direct SAT should synthesize a two-element model");

        assert!(semantic_labeling_model_condition_holds(
            &model,
            trs.rules(),
            None,
            &cancellation,
        ));
        let mut mutated = model;
        mutated
            .interpretations
            .insert(Symbol::new("f"), SlArithmeticFunction::Constant(0));
        assert!(!semantic_labeling_model_condition_holds(
            &mutated,
            trs.rules(),
            None,
            &cancellation,
        ));
    }

    #[test]
    fn conjunctive_model_infers_constant_partition_from_rules() {
        let crate::parsing::CpfInputProblem::Dp { trs, pairs, .. } =
            crate::parsing::parse_cpf_input(None, include_str!("../../../tests/fixtures/conjunctive_labeling.dp.xml")).unwrap()
        else { panic!("DP fixture expected"); };
        let pairs = pairs.iter().map(|r| DependencyPair::new(r.lhs().clone(), r.rhs().clone(), 0)).collect::<Vec<_>>();
        let arities = semantic_labeling_arities(&trs, &pairs, None);
        let symbols = arities.iter().map(|(s,a)| (s.clone(),*a)).collect::<Vec<_>>();
        let base = SemanticLabelingModel { carrier_size: 2, arities, interpretations: BTreeMap::new() };
        let model = synthesize_conjunctive(&trs, &symbols, &base,
            Some(Instant::now() + std::time::Duration::from_secs(10)), &DpStrategyCancellation::default())
            .expect("native conjunctive model");
        assert!(semantic_labeling_model_condition_holds(&model, trs.rules(), None, &DpStrategyCancellation::default()));
        let constants = symbols.iter().filter(|(_,a)| *a==0).map(|(s,_)|
            model.interpretations[s].eval(&[], 2).unwrap()).collect::<BTreeSet<_>>();
        assert_eq!(constants, BTreeSet::from([0,1]));
        let constant_symbols = symbols.iter().filter(|(_,a)| *a==0).map(|(s,_)| s.clone()).collect::<Vec<_>>();
        let mut rules = trs.rules().to_vec();
        for window in constant_symbols.windows(2) {
            rules.push(RewriteRule::new(Term::app(window[0].as_str(), vec![]), Term::app(window[1].as_str(), vec![])));
        }
        let collapsed = Trs::new(None, trs.variables().clone(), rules);
        assert!(synthesize_conjunctive(&collapsed, &symbols, &base,
            Some(Instant::now() + std::time::Duration::from_secs(10)), &DpStrategyCancellation::default()).is_none());
    }

    #[test]
    fn goal_directed_relative_model_handles_rtl_pwl() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let Ok(input) = std::fs::read_to_string("../TPDB-ARI/TRS_Relative/Relative_05/rtL-pwl.ari")
        else {
            return;
        };
        let original = crate::parsing::parse_ari_relative_trs(None, &input)
            .expect("parse rtL-pwl relative TRS");
        // This is obligation (4) in AProVE's published CADE 2025 proof,
        // after the preceding polynomial and matrix rule-removal steps.
        let strict_rules = [1usize, 3, 7]
            .into_iter()
            .map(|index| original.strict().rules()[index].clone())
            .collect();
        let weak_rules = original
            .weak_rules()
            .iter()
            .enumerate()
            .filter(|(index, _)| !matches!(index, 0 | 7))
            .map(|(_, rule)| rule.clone())
            .collect();
        let residual_trs = |rules| {
            Trs::new_with_strategy(
                None,
                original.strict().variables().clone(),
                rules,
                original.strict().strategy(),
            )
        };
        let relative = RelativeTrs::new(residual_trs(strict_rules), weak_rules);
        let arities = relative.union().arities();
        let symbols = arities
            .iter()
            .map(|(symbol, arity)| (symbol.clone(), *arity))
            .collect::<Vec<_>>();
        let base = SemanticLabelingModel {
            carrier_size: 2,
            arities,
            interpretations: BTreeMap::new(),
        };
        let deadline = Some(Instant::now() + std::time::Duration::from_secs(30));
        let cancellation = DpStrategyCancellation::current(deadline);
        let aprove_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: relative.union().arities(),
            interpretations: BTreeMap::from([
                (Symbol::new("top"), SlArithmeticFunction::Constant(0)),
                (Symbol::new("ok"), SlArithmeticFunction::Argument(0)),
                (
                    Symbol::new("queue"),
                    SlArithmeticFunction::Product(vec![
                        SlArithmeticFunction::Argument(0),
                        SlArithmeticFunction::Argument(1),
                    ]),
                ),
                (Symbol::new("new"), SlArithmeticFunction::Argument(0)),
                (Symbol::new("check"), SlArithmeticFunction::Argument(0)),
                (Symbol::new("old"), SlArithmeticFunction::Constant(0)),
                (Symbol::new("bot"), SlArithmeticFunction::Constant(1)),
            ]),
        };
        assert!(semantic_labeling_model_condition_holds(
            &aprove_model,
            relative.union().rules(),
            deadline,
            &cancellation,
        ));
        let (model, _) =
            synthesize_goal_directed_relative(&relative, &symbols, &base, deadline, &cancellation)
                .expect("joint semantic-labeling/additive-polynomial witness");
        assert!(semantic_labeling_model_condition_holds(
            &model,
            relative.union().rules(),
            deadline,
            &cancellation,
        ));
    }
}
