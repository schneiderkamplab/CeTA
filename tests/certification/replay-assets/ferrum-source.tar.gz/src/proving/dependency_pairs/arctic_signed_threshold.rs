//! Threshold circuits for small signed Arctic ranges. Intermediate thresholds
//! cover exact path sums; bottom is represented by all-false thresholds.
use super::*;

type Source = Option<(Variable, usize)>;
#[derive(Clone)]
struct Value {
    lower: i64,
    bits: Vec<String>,
}
type Row = BTreeMap<Source, Value>;

pub(super) struct Encoder {
    cache: BTreeMap<Term, Vec<Row>>,
    parameter_cache: BTreeMap<(String, i64), String>,
    projected_symbols: BTreeSet<String>,
    shared_parameters: bool,
    serial: usize,
    minimum: i64,
    maximum: i64,
}

impl Encoder {
    pub(super) fn new(minimum: i64, maximum: i64) -> Self {
        Self {
            cache: BTreeMap::new(),
            parameter_cache: BTreeMap::new(),
            projected_symbols: BTreeSet::new(),
            shared_parameters: std::env::var_os("FERRUM_ARCTIC_THRESHOLD_SHARED").is_some(),
            serial: 0,
            minimum,
            maximum,
        }
    }
    /// These rows are already constrained to bottom in the parameter model.
    /// Eliding their circuits does not add a search restriction.
    pub(super) fn project_root_symbols(&mut self, symbols: BTreeSet<String>) {
        self.projected_symbols = symbols;
    }
    fn at(row: &Row, source: &Source, k: i64) -> String {
        row.get(source)
            .and_then(|v| v.bits.get(k.saturating_sub(v.lower).max(0) as usize))
            .cloned()
            .unwrap_or_else(|| "false".into())
    }
    fn parameter_at(&mut self, name: &str, k: i64, script: &mut String) -> String {
        if !self.shared_parameters {
            return format!("(and {} (>= {name} {k}))", integer_arctic_finite_name(name));
        }
        if k <= self.minimum { return integer_arctic_finite_name(name); }
        if k > self.maximum { return "false".into(); }
        let key = (name.to_owned(), k);
        if let Some(bit) = self.parameter_cache.get(&key) { return bit.clone(); }
        let bit = self.bind(script, format!("(and {} (>= {name} {k}))", integer_arctic_finite_name(name)));
        self.parameter_cache.insert(key, bit.clone());
        bit
    }
    fn bind(&mut self, script: &mut String, expression: String) -> String {
        if expression == "true" || expression == "false" {
            return expression;
        }
        let name = format!("arctic_signed_threshold_{}", self.serial);
        self.serial += 1;
        script.push_str(&format!(
            "(declare-const {name} Bool)\n(assert (= {name} {expression}))\n"
        ));
        name
    }
    fn interpret(
        &mut self,
        term: &Term,
        dimension: usize,
        script: &mut String,
        deadline: Option<Instant>,
    ) -> Option<Vec<Row>> {
        if let Some(value) = self.cache.get(term) {
            return Some(value.clone());
        }
        check_smt_build(script, deadline)?;
        let result = match term {
            Term::Var(variable) => (0..dimension)
                .map(|row| {
                    BTreeMap::from([(
                        Some((variable.clone(), row)),
                        Value {
                            lower: 0,
                            bits: vec!["true".into()],
                        },
                    )])
                })
                .collect(),
            Term::App { symbol, args } => {
                let children = args
                    .iter()
                    .map(|a| self.interpret(a, dimension, script, deadline))
                    .collect::<Option<Vec<_>>>()?;
                let sources = std::iter::once(None)
                    .chain(children.iter().flatten().flat_map(|r| r.keys().cloned()))
                    .collect::<BTreeSet<_>>();
                let lower = children
                    .iter()
                    .flatten()
                    .flat_map(|r| r.values().map(|v| v.lower))
                    .min()
                    .unwrap_or(0)
                    .checked_add(self.minimum)?
                    .min(self.minimum);
                let upper = children
                    .iter()
                    .flatten()
                    .flat_map(|r| r.values().map(|v| v.lower + v.bits.len() as i64 - 1))
                    .max()
                    .unwrap_or(0)
                    .checked_add(self.maximum)?
                    .max(self.maximum);
                if upper.checked_sub(lower)? > 4096 {
                    return None;
                }
                let mut result = Vec::new();
                for row in 0..dimension {
                    if row > 0 && self.projected_symbols.contains(symbol.as_str()) {
                        result.push(BTreeMap::new());
                        continue;
                    }
                    let mut values = BTreeMap::new();
                    for source in &sources {
                        let mut bits = Vec::new();
                        for k in lower..=upper {
                            let mut alternatives = Vec::new();
                            if source.is_none() && k <= self.maximum {
                                alternatives.push(self.parameter_at(
                                    &matrix_bv_constant_name(symbol.as_str(), row),
                                    k,
                                    script,
                                ));
                            }
                            for (arg, child) in children.iter().enumerate() {
                                for col in 0..dimension {
                                    let name =
                                        matrix_bv_coefficient_name(symbol.as_str(), arg, row, col);
                                    for weight in self.minimum..=self.maximum {
                                        let suffix =
                                            Self::at(&child[col], source, k.checked_sub(weight)?);
                                        if suffix != "false" {
                                            alternatives.push(format!(
                                                "(and {} {suffix})",
                                                self.parameter_at(&name, weight, script)
                                            ));
                                        }
                                    }
                                }
                            }
                            bits.push(self.bind(script, smt_or(alternatives)));
                        }
                        values.insert(source.clone(), Value { lower, bits });
                        check_smt_build(script, deadline)?;
                    }
                    result.push(values);
                }
                result
            }
        };
        self.cache.insert(term.clone(), result.clone());
        Some(result)
    }
    pub(super) fn relation(
        &mut self,
        lhs: &Term,
        rhs: &Term,
        strict: bool,
        dimension: usize,
        script: &mut String,
        deadline: Option<Instant>,
    ) -> Option<String> {
        let left = self.interpret(lhs, dimension, script, deadline)?;
        let right = self.interpret(rhs, dimension, script, deadline)?;
        let mut constraints = Vec::new();
        for row in 0..dimension {
            for (source, value) in &right[row] {
                for (index, threshold) in value.bits.iter().enumerate() {
                    if threshold != "false" {
                        let k = value.lower + index as i64 + i64::from(strict);
                        constraints.push(format!(
                            "(=> {threshold} {})",
                            Self::at(&left[row], source, k)
                        ));
                    }
                }
            }
        }
        Some(smt_and(constraints))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn signed_threshold_circuits_match_exact_orders() {
        check_exact_orders(false);
    }

    #[test]
    fn projected_signed_threshold_circuits_match_exact_orders() {
        check_exact_orders(true);
    }

    fn check_exact_orders(projected: bool) {
        if !command_exists("z3") {
            return;
        }
        let x = Term::var("x");
        let f = Term::app("f", vec![x.clone()]);
        let ff = Term::app("f", vec![f.clone()]);
        for constant in [i64::MIN, -1, 0, 1] {
            for diagonal in [i64::MIN, -1, 0, 1] {
                let model = BTreeMap::from([(
                    "f".into(),
                    MatrixInterpretation {
                        constant: vec![constant, if projected { i64::MIN } else { -1 }],
                        coefficients: vec![vec![vec![diagonal, 1],
                            if projected { vec![i64::MIN; 2] } else { vec![-1, 0] }]],
                    },
                )]);
                let mut script = String::from("(set-logic QF_LIA)\n");
                for row in 0..2 {
                    let mut values =
                        vec![(matrix_bv_constant_name("f", row), model["f"].constant[row])];
                    for col in 0..2 {
                        values.push((
                            matrix_bv_coefficient_name("f", 0, row, col),
                            model["f"].coefficients[0][row][col],
                        ));
                    }
                    for (name, value) in values {
                        integer_arctic_parameter(&mut script, name.clone(), -1, 1);
                        script.push_str(&format!(
                            "(assert (= {} {}))\n",
                            integer_arctic_finite_name(&name),
                            value != i64::MIN
                        ));
                        if value != i64::MIN {
                            script.push_str(&format!("(assert (= {name} {value}))\n"));
                        }
                    }
                }
                let mut encoder = Encoder::new(-1, 1);
                encoder.shared_parameters = true;
                if projected { encoder.project_root_symbols(BTreeSet::from(["f".into()])); }
                for (lhs, rhs) in [(&ff, &f), (&f, &ff), (&f, &x), (&x, &f)] {
                    for strict in [false, true] {
                        let expected = if strict {
                            strictly_decreases_by_arctic_matrix(lhs, rhs, &model, 2)
                        } else {
                            weakly_decreases_by_arctic_matrix(lhs, rhs, &model, 2)
                        };
                        let relation = encoder
                            .relation(lhs, rhs, strict, 2, &mut script, None)
                            .unwrap();
                        script.push_str(&format!(
                            "(assert {})\n",
                            if expected {
                                relation
                            } else {
                                format!("(not {relation})")
                            }
                        ));
                    }
                }
                script.push_str("(check-sat)\n");
                for query in [
                    script.clone(),
                    bounded_arctic_bv::lower(&script, 5).unwrap(),
                ] {
                    let output = run_smt_script(
                        &query,
                        &DpOptions::default(),
                        Some(Instant::now() + Duration::from_secs(5)),
                    )
                    .unwrap();
                    assert_eq!(output.lines().next(), Some("sat"));
                }
            }
        }
    }
}
