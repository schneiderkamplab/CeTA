use std::collections::BTreeSet;

use crate::core::{CsrTrs, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct DependencyPair {
    pub(super) lhs: Term,
    pub(super) rhs: Term,
    pub(super) source_rule: usize,
}

impl DependencyPair {
    pub(crate) fn new(lhs: Term, rhs: Term, source_rule: usize) -> Self {
        Self {
            lhs,
            rhs,
            source_rule,
        }
    }

    #[cfg(test)]
    pub fn new_for_test(lhs: Term, rhs: Term) -> Self {
        Self {
            lhs,
            rhs,
            source_rule: 0,
        }
    }

    pub fn lhs(&self) -> &Term {
        &self.lhs
    }

    pub fn rhs(&self) -> &Term {
        &self.rhs
    }

    pub(crate) fn new_for_nontermination(lhs: Term, rhs: Term, source_rule: usize) -> Self {
        Self {
            lhs,
            rhs,
            source_rule,
        }
    }

    pub(crate) fn from_rule(rule: RewriteRule, source_rule: usize) -> Self {
        Self {
            lhs: rule.lhs().clone(),
            rhs: rule.rhs().clone(),
            source_rule,
        }
    }

    pub fn source_rule(&self) -> usize {
        self.source_rule
    }

    pub fn as_rule(&self) -> RewriteRule {
        RewriteRule::new(self.lhs.clone(), self.rhs.clone())
    }
}

pub fn dependency_pairs(trs: &Trs) -> Vec<DependencyPair> {
    // Preserve the established complete construction and its oracle keys.
    // The explicitly selected dp-trimmed transformation uses CeTA's smaller
    // DP_list construction instead; never silently change existing states.
    dependency_pairs_with_subterm_omission(trs, false)
}

/// CeTA's DP_Transformation_Impl.DP_list excludes RHS calls which are
/// proper subterms of the original (unmarked) LHS. This is a root
/// transformation, not an arbitrary deletion from an existing DP problem.
pub(crate) fn trimmed_dependency_pairs(trs: &Trs) -> Vec<DependencyPair> {
    dependency_pairs_with_subterm_omission(trs, true)
}

pub(super) fn complete_dependency_pairs(trs: &Trs) -> Vec<DependencyPair> {
    dependency_pairs_with_subterm_omission(trs, false)
}

pub(super) fn dependency_pairs_with_subterm_omission(
    trs: &Trs,
    omit_lhs_proper_subterms: bool,
) -> Vec<DependencyPair> {
    let defined_symbols = trs.defined_symbols();
    let mut pairs = Vec::new();
    for (rule_index, rule) in trs.rules().iter().enumerate() {
        if let Some(lhs_symbol) = rule.lhs().root_symbol() {
            let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
            collect_rhs_calls(
                rule_index,
                &marked_lhs,
                rule.lhs(),
                &defined_symbols,
                rule.rhs(),
                omit_lhs_proper_subterms,
                &mut pairs,
            );
        }
    }
    let mut unique = Vec::with_capacity(pairs.len());
    for pair in pairs {
        if !unique
            .iter()
            .any(|existing: &DependencyPair| existing.lhs == pair.lhs && existing.rhs == pair.rhs)
        {
            unique.push(pair);
        }
    }
    unique
}

pub fn csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    csr_dependency_pairs_with_subterm_omission(csr, true)
}

/// The CS-DPs used by the general usable-rules processor of Gutierrez,
/// Lucas, and Urbain (RTA 2008), including collapsing pairs for variables
/// that migrate from inactive to active positions.
pub(crate) fn rta_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    let mut pairs = csr_dependency_pairs(csr);
    for (rule_index, rule) in csr.rules().iter().enumerate() {
        let Some(lhs_symbol) = rule.lhs().root_symbol() else {
            continue;
        };
        let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        for variable in active_variables_in_term(csr, rule.rhs()).difference(&lhs_active) {
            push_unique_pair(
                &mut pairs,
                DependencyPair {
                    lhs: marked_lhs.clone(),
                    rhs: Term::Var((*variable).clone()),
                    source_rule: rule_index,
                },
            );
        }
    }
    pairs
}

fn rename_muterm_variables(term: &Term, prefix: &str) -> Term {
    match term {
        Term::Var(variable) => Term::var(format!("{prefix}{}", variable.as_str())),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|argument| rename_muterm_variables(argument, prefix))
                .collect(),
        ),
    }
}

fn replace_muterm_variable(term: &Term, variable: &Variable, replacement: &Term) -> Term {
    match term {
        Term::Var(current) if current == variable => replacement.clone(),
        Term::Var(_) => term.clone(),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|argument| replace_muterm_variable(argument, variable, replacement))
                .collect(),
        ),
    }
}

/// Materialize the exact ordinary CSR-DP presentation of a typed MU-TERM
/// macro step. Isabelle's `string_renameN` maps pair variables to `x0_*` and
/// unhiding-rule variables to `y*`; keep this byte-for-byte synchronized with
/// `muterm_expanded_pairs_list` in CeTA-CSR.
pub(crate) fn muterm_expanded_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    let unhiding = muterm_innermost_unhiding_rules(csr);
    muterm_expand_dependency_pairs(&rta_csr_dependency_pairs(csr), &unhiding)
}

/// Expand a materialized typed MU-TERM component into the ordinary pairs
/// checked by `muterm_expanded_pairs_list`.  Keeping this component-local is
/// essential after dependency-graph decomposition: it lets the ordinary
/// graph separate bridge targets that leave the current SCC.
pub(crate) fn muterm_expand_dependency_pairs(
    pairs: &[DependencyPair],
    unhiding: &[RewriteRule],
) -> Vec<DependencyPair> {
    let mut expanded = Vec::new();
    for pair in pairs {
        let lhs = rename_muterm_variables(pair.lhs(), "x0_");
        match pair.rhs() {
            Term::Var(variable) => {
                let renamed_variable = Variable::new(format!("x0_{}", variable.as_str()));
                for rule in unhiding {
                    let unhiding_lhs = rename_muterm_variables(rule.lhs(), "y");
                    let unhiding_rhs = rename_muterm_variables(rule.rhs(), "y");
                    expanded.push(DependencyPair::new(
                        replace_muterm_variable(&lhs, &renamed_variable, &unhiding_lhs),
                        unhiding_rhs,
                        pair.source_rule(),
                    ));
                }
            }
            rhs => expanded.push(DependencyPair::new(
                lhs,
                rename_muterm_variables(rhs, "x0_"),
                pair.source_rule(),
            )),
        }
    }
    expanded
}

/// Construct the specialized unhiding rules used by MU-TERM's four-component
/// context-sensitive DP problems.
///
/// A maximal subterm reached by crossing an inactive edge of a rule RHS is a
/// possible value exposed by a later collapsing pair. From that frozen
/// fragment, every defined call reachable through replacement-map-active
/// positions can become the next marked call. At the certificate boundary we
/// use the proved finite expansion: generic hiding-position projections plus
/// `call -> call#` marking pairs.
///
/// These are *not* ordinary rewrite rules.  Callers must retain them in the
/// dedicated unhiding component until the corresponding CeTA-CSR processor is
/// selected.
pub(crate) fn muterm_innermost_unhiding_rules(csr: &CsrTrs) -> Vec<RewriteRule> {
    fn collect_frozen_roots(csr: &CsrTrs, term: &Term, active: bool, out: &mut Vec<Term>) {
        let Term::App { symbol, args } = term else {
            return;
        };
        for (index, argument) in args.iter().enumerate() {
            let child_active = active && csr.replacement_map().is_allowed(symbol, index);
            if active && !child_active {
                if !out.contains(argument) {
                    out.push(argument.clone());
                }
            } else if child_active {
                collect_frozen_roots(csr, argument, true, out);
            }
        }
    }

    fn collect_active_defined_calls(
        csr: &CsrTrs,
        term: &Term,
        defined: &BTreeSet<Symbol>,
        out: &mut Vec<Term>,
    ) {
        let Term::App { symbol, args } = term else {
            return;
        };
        if defined.contains(symbol) && !out.contains(term) {
            out.push(term.clone());
        }
        for (index, argument) in args.iter().enumerate() {
            if csr.replacement_map().is_allowed(symbol, index) {
                collect_active_defined_calls(csr, argument, defined, out);
            }
        }
    }

    let defined = csr.trs().defined_symbols();
    let mut result = Vec::new();
    for rule in csr.rules() {
        let mut frozen = Vec::new();
        collect_frozen_roots(csr, rule.rhs(), true, &mut frozen);
        for source in frozen {
            let mut calls = Vec::new();
            collect_active_defined_calls(csr, &source, &defined, &mut calls);
            for call in calls {
                let symbol = call
                    .root_symbol()
                    .expect("a collected defined call has a root symbol");
                let rule = RewriteRule::new(source.clone(), mark_root(&call, symbol));
                if !result.contains(&rule) {
                    result.push(rule);
                }
            }
        }
    }
    result
}

/// Executable counterpart of CeTA's `muterm_unhiding_safe_list`.
///
/// Check the four semantic safety clauses directly so that search and CPF
/// applicability agree at the typed MU-TERM transformation boundary.
pub(crate) fn muterm_unhiding_is_safe(csr: &CsrTrs) -> bool {
    fn frozen_roots(csr: &CsrTrs, term: &Term) -> Vec<Term> {
        fn collect(csr: &CsrTrs, term: &Term, active: bool, out: &mut Vec<Term>) {
            let Term::App { symbol, args } = term else {
                return;
            };
            for (index, argument) in args.iter().enumerate() {
                let child_active = active && csr.replacement_map().is_allowed(symbol, index);
                if active && !child_active {
                    if !out.contains(argument) {
                        out.push(argument.clone());
                    }
                } else if child_active {
                    collect(csr, argument, true, out);
                }
            }
        }

        let mut roots = Vec::new();
        collect(csr, term, true, &mut roots);
        roots
    }

    csr.rules().iter().all(|rule| {
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        let rhs_active = active_variables_in_term(csr, rule.rhs());
        let lhs_frozen = frozen_roots(csr, rule.lhs());
        let rhs_frozen = frozen_roots(csr, rule.rhs());

        rhs_frozen.iter().all(|hidden| match hidden {
            Term::Var(variable) => {
                lhs_active.contains(variable) || lhs_frozen.contains(&Term::Var(variable.clone()))
            }
            Term::App { .. } => {
                active_variables_in_term(csr, hidden).is_subset(&lhs_active)
                    && frozen_roots(csr, hidden).is_empty()
            }
        }) && rhs_active
            .difference(&lhs_active)
            .all(|variable| lhs_frozen.contains(&Term::Var(variable.clone())))
    })
}

/// The innermost CS-DP problem of Alarcón and Lucas.  Unlike the full RTA'08
/// problem, migrating variables stay as collapsing pairs; calls hidden below
/// a frozen RHS edge are exposed by auxiliary rules rooted at the complete
/// hidden term.  This is the problem printed by MU-TERM as `Unhiding rules`.
pub(crate) fn innermost_csr_dependency_problem(csr: &CsrTrs) -> (CsrTrs, Vec<DependencyPair>) {
    fn collect_hidden_defined(
        csr: &CsrTrs,
        term: &Term,
        active: bool,
        defined: &BTreeSet<Symbol>,
        out: &mut Vec<Term>,
    ) {
        let Term::App { symbol, args } = term else {
            return;
        };
        if !active && defined.contains(symbol) && !out.contains(term) {
            out.push(term.clone());
        }
        for (index, arg) in args.iter().enumerate() {
            collect_hidden_defined(
                csr,
                arg,
                active && csr.replacement_map().is_allowed(symbol, index),
                defined,
                out,
            );
        }
    }

    let defined = csr.trs().defined_symbols();
    let mut rules = csr.rules().to_vec();
    // Generic projection rules peel every active edge that can occur in an
    // arbitrarily nested hiding context.  The final hidden call is exposed by
    // an explicit dependency pair below, rather than by a weak marking rule.
    for (symbol, arity) in csr.trs().arities() {
        let args = (0..arity)
            .map(|index| Term::var(format!("x{}", index + 1)))
            .collect::<Vec<_>>();
        let lhs = Term::App {
            symbol: symbol.clone(),
            args: args.clone(),
        };
        for (index, rhs) in args.iter().enumerate() {
            if csr.replacement_map().is_allowed(&symbol, index) {
                let projection = RewriteRule::new(lhs.clone(), rhs.clone());
                if !rules.contains(&projection) {
                    rules.push(projection);
                }
            }
        }
    }
    let variables = rules
        .iter()
        .flat_map(|rule| rule.lhs().variables().into_iter())
        .chain(
            rules
                .iter()
                .flat_map(|rule| rule.rhs().variables().into_iter()),
        )
        .collect();
    let trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_owned),
        variables,
        rules,
        RewriteStrategy::Innermost,
    );
    let replacement_map = csr.replacement_map().clone();
    // Innermost CS-DPs deliberately retain calls at proper subterms of other
    // calls. They can belong to distinct SCCs (as `leq#` does in Ex1_GM03),
    // so the ordinary CSR proper-subterm omission is not complete here.
    let mut pairs = csr_dependency_pairs_with_subterm_omission(csr, false);
    for (rule_index, rule) in csr.rules().iter().enumerate() {
        let Some(lhs_symbol) = rule.lhs().root_symbol() else {
            continue;
        };
        let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        for variable in active_variables_in_term(csr, rule.rhs()).difference(&lhs_active) {
            push_unique_pair(
                &mut pairs,
                DependencyPair {
                    lhs: marked_lhs.clone(),
                    rhs: Term::Var((*variable).clone()),
                    source_rule: rule_index,
                },
            );
        }
        let mut hidden = Vec::new();
        collect_hidden_defined(csr, rule.rhs(), true, &defined, &mut hidden);
        for term in hidden {
            let symbol = term
                .root_symbol()
                .expect("a hidden defined call has a root symbol");
            push_unique_pair(
                &mut pairs,
                DependencyPair {
                    lhs: term.clone(),
                    rhs: mark_root(&term, symbol),
                    source_rule: rule_index,
                },
            );
        }
    }
    (
        CsrTrs::new(trs, replacement_map)
            .expect("the original replacement map extends by default to unhiding symbols"),
        pairs,
    )
}

fn complete_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    csr_dependency_pairs_with_subterm_omission(csr, false)
}

fn csr_dependency_pairs_with_subterm_omission(
    csr: &CsrTrs,
    omit_lhs_proper_subterms: bool,
) -> Vec<DependencyPair> {
    let trs = csr.trs();
    let defined_symbols = trs.defined_symbols();
    let mut pairs = Vec::new();
    for (rule_index, rule) in trs.rules().iter().enumerate() {
        if let Some(lhs_symbol) = rule.lhs().root_symbol() {
            let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
            // CeTA's executable mu_CSDP construction excludes precisely the
            // proper subterms reachable through replacement-map positions.
            // Ordinary syntactic subterm exclusion is too broad: it drops a
            // required pair when the same term occurs only below a frozen
            // LHS edge.
            let active_lhs_proper_subterms = omit_lhs_proper_subterms.then(|| {
                csr.replacing_subterms(rule.lhs())
                    .into_iter()
                    .filter(|(position, _)| !position.is_empty())
                    .map(|(_, term)| term)
                    .collect::<Vec<_>>()
            });
            for (_, subterm) in csr.replacing_subterms(rule.rhs()) {
                let Term::App { symbol, .. } = subterm else {
                    continue;
                };
                if defined_symbols.contains(symbol)
                    && active_lhs_proper_subterms
                        .as_ref()
                        .is_none_or(|lhs_subterms| !lhs_subterms.contains(&subterm))
                {
                    pairs.push(DependencyPair {
                        lhs: marked_lhs.clone(),
                        rhs: mark_root(subterm, symbol),
                        source_rule: rule_index,
                    });
                }
            }
        }
    }
    pairs
}

pub fn safe_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    complete_dependency_pairs(csr.trs())
}

pub fn improved_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    let trs = csr.trs();
    let unhiding_symbol = fresh_unhiding_symbol(trs);
    let defined_symbols = trs.defined_symbols();
    // The improved LPAR'08 search problem uses the proper-subterm omission
    // from its own construction.  It is deliberately smaller than CeTA's
    // complete certificate problem, which
    // `certificate_improved_csr_dependency_pairs` reconstructs below.  Do
    // not reuse the native mu-CSDP omission here: that changes SCCs and can
    // turn a search-level SCT closure into an invalid certificate closure.
    let mut pairs = search_improved_csr_dependency_pairs(csr);

    for (rule_index, rule) in trs.rules().iter().enumerate() {
        let Some(lhs_symbol) = rule.lhs().root_symbol() else {
            continue;
        };
        let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        for variable in active_variables_in_term(csr, rule.rhs()).difference(&lhs_active) {
            push_unique_pair(
                &mut pairs,
                DependencyPair {
                    lhs: marked_lhs.clone(),
                    rhs: Term::app(
                        unhiding_symbol.as_str(),
                        vec![Term::Var((*variable).clone())],
                    ),
                    source_rule: rule_index,
                },
            );
        }
    }

    for (symbol, arity) in trs.arities() {
        let variables = (0..arity)
            .map(|index| Term::var(format!("x{}", index + 1)))
            .collect::<Vec<_>>();
        for index in 0..arity {
            if hides_csr_position(csr, &defined_symbols, &symbol, arity, index) {
                push_unique_pair(
                    &mut pairs,
                    DependencyPair {
                        lhs: Term::app(
                            unhiding_symbol.as_str(),
                            vec![Term::app(symbol.as_str(), variables.clone())],
                        ),
                        rhs: Term::app(unhiding_symbol.as_str(), vec![variables[index].clone()]),
                        source_rule: 0,
                    },
                );
            }
        }
    }

    for (rule_index, rule) in trs.rules().iter().enumerate() {
        collect_hidden_csr_pairs(
            rule_index,
            rule.rhs(),
            csr.replacement_map(),
            &defined_symbols,
            &unhiding_symbol,
            true,
            &mut pairs,
        );
    }
    pairs
}

fn search_improved_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    let defined_symbols = csr.trs().defined_symbols();
    let mut pairs = Vec::new();
    for (rule_index, rule) in csr.rules().iter().enumerate() {
        let Some(lhs_symbol) = rule.lhs().root_symbol() else {
            continue;
        };
        let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
        for (_, subterm) in csr.replacing_subterms(rule.rhs()) {
            let Term::App { symbol, .. } = subterm else {
                continue;
            };
            if defined_symbols.contains(symbol) && !subterm.is_proper_subterm_of(rule.lhs()) {
                pairs.push(DependencyPair {
                    lhs: marked_lhs.clone(),
                    rhs: mark_root(subterm, symbol),
                    source_rule: rule_index,
                });
            }
        }
    }
    pairs
}

pub fn certificate_improved_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    let trs = csr.trs();
    let unhiding_symbol = fresh_unhiding_symbol(trs);
    let defined_symbols = trs.defined_symbols();
    let mut pairs = improved_csr_dependency_pairs(csr);

    for (symbol, arity) in trs.arities() {
        let variables = (0..arity)
            .map(|index| Term::var(format!("x{}", index + 1)))
            .collect::<Vec<_>>();
        for index in 0..arity {
            if conservatively_hides_csr_position(csr, &defined_symbols, &symbol, arity, index) {
                push_unique_pair(
                    &mut pairs,
                    DependencyPair {
                        lhs: Term::app(
                            unhiding_symbol.as_str(),
                            vec![Term::app(symbol.as_str(), variables.clone())],
                        ),
                        rhs: Term::app(unhiding_symbol.as_str(), vec![variables[index].clone()]),
                        source_rule: 0,
                    },
                );
            }
        }
    }
    // The search-oriented CS-DP construction may omit a replacement-map
    // pair when its right-hand side is already a proper subterm of the left.
    // The executable improved-CS-DP checker still requires that obligation
    // at the certificate boundary.  Preserve the conservative unhiding
    // closure above and restore these ordinary CS-DPs as well.
    for pair in complete_csr_dependency_pairs(csr) {
        push_unique_pair(&mut pairs, pair);
    }
    pairs
}

fn conservatively_hides_csr_position(
    csr: &CsrTrs,
    defined_symbols: &BTreeSet<Symbol>,
    candidate_symbol: &Symbol,
    candidate_arity: usize,
    candidate_index: usize,
) -> bool {
    csr.rules().iter().any(|rule| {
        conservative_hiding_subterm_has_position(
            rule.rhs(),
            csr.replacement_map(),
            defined_symbols,
            candidate_symbol,
            candidate_arity,
            candidate_index,
            true,
        )
    })
}

fn conservative_hiding_subterm_has_position(
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    defined_symbols: &BTreeSet<Symbol>,
    candidate_symbol: &Symbol,
    candidate_arity: usize,
    candidate_index: usize,
    active: bool,
) -> bool {
    let Term::App { symbol, args } = term else {
        return false;
    };
    if !active
        && symbol == candidate_symbol
        && args.len() == candidate_arity
        && candidate_index < args.len()
        && replacement_map.is_allowed(symbol, candidate_index)
        && contains_active_variable_or_defined(
            &args[candidate_index],
            replacement_map,
            defined_symbols,
        )
    {
        return true;
    }
    args.iter().enumerate().any(|(index, arg)| {
        conservative_hiding_subterm_has_position(
            arg,
            replacement_map,
            defined_symbols,
            candidate_symbol,
            candidate_arity,
            candidate_index,
            active && replacement_map.is_allowed(symbol, index),
        )
    })
}

fn contains_active_variable_or_defined(
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    defined_symbols: &BTreeSet<Symbol>,
) -> bool {
    match term {
        Term::Var(_) => true,
        Term::App { symbol, args } => {
            defined_symbols.contains(symbol)
                || args.iter().enumerate().any(|(index, arg)| {
                    replacement_map.is_allowed(symbol, index)
                        && contains_active_variable_or_defined(
                            arg,
                            replacement_map,
                            defined_symbols,
                        )
                })
        }
    }
}

fn hides_csr_position(
    csr: &CsrTrs,
    defined_symbols: &BTreeSet<Symbol>,
    candidate_symbol: &Symbol,
    candidate_arity: usize,
    candidate_index: usize,
) -> bool {
    csr.rules().iter().any(|rule| {
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        let lhs_inactive = inactive_variables_in_term(csr, rule.lhs());
        let eligible_variables = lhs_inactive
            .iter()
            .filter(|variable| !lhs_active.contains(*variable))
            .cloned()
            .collect::<BTreeSet<_>>();
        hiding_subterm_has_position(
            rule.rhs(),
            csr.replacement_map(),
            defined_symbols,
            &eligible_variables,
            candidate_symbol,
            candidate_arity,
            candidate_index,
            true,
        )
    })
}

fn hiding_subterm_has_position(
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    defined_symbols: &BTreeSet<Symbol>,
    eligible_variables: &BTreeSet<Variable>,
    candidate_symbol: &Symbol,
    candidate_arity: usize,
    candidate_index: usize,
    active: bool,
) -> bool {
    let Term::App { symbol, args } = term else {
        return false;
    };
    if !active
        && symbol == candidate_symbol
        && args.len() == candidate_arity
        && candidate_index < args.len()
        && replacement_map.is_allowed(symbol, candidate_index)
        && contains_active_defined_or_eligible_variable(
            &args[candidate_index],
            replacement_map,
            defined_symbols,
            eligible_variables,
        )
    {
        return true;
    }
    args.iter().enumerate().any(|(index, arg)| {
        hiding_subterm_has_position(
            arg,
            replacement_map,
            defined_symbols,
            eligible_variables,
            candidate_symbol,
            candidate_arity,
            candidate_index,
            active && replacement_map.is_allowed(symbol, index),
        )
    })
}

fn contains_active_defined_or_eligible_variable(
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    defined_symbols: &BTreeSet<Symbol>,
    eligible_variables: &BTreeSet<Variable>,
) -> bool {
    match term {
        Term::Var(variable) => eligible_variables.contains(variable),
        Term::App { symbol, args } => {
            defined_symbols.contains(symbol)
                || args.iter().enumerate().any(|(index, arg)| {
                    replacement_map.is_allowed(symbol, index)
                        && contains_active_defined_or_eligible_variable(
                            arg,
                            replacement_map,
                            defined_symbols,
                            eligible_variables,
                        )
                })
        }
    }
}

pub fn conservative_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    let trs = csr.trs();
    let unhiding_symbol = fresh_unhiding_symbol(trs);
    let defined_symbols = trs.defined_symbols();
    let mut pairs = complete_csr_dependency_pairs(csr);
    for (rule_index, rule) in trs.rules().iter().enumerate() {
        let Some(lhs_symbol) = rule.lhs().root_symbol() else {
            continue;
        };
        let marked_lhs = mark_root(rule.lhs(), lhs_symbol);
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        for variable in active_variables_in_term(csr, rule.rhs()).difference(&lhs_active) {
            push_unique_pair(
                &mut pairs,
                DependencyPair {
                    lhs: marked_lhs.clone(),
                    rhs: Term::app(
                        unhiding_symbol.as_str(),
                        vec![Term::Var((*variable).clone())],
                    ),
                    source_rule: rule_index,
                },
            );
        }
        collect_hidden_csr_pairs(
            rule_index,
            rule.rhs(),
            csr.replacement_map(),
            &defined_symbols,
            &unhiding_symbol,
            true,
            &mut pairs,
        );
    }
    pairs
}

fn collect_hidden_csr_pairs(
    source_rule: usize,
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    defined_symbols: &BTreeSet<Symbol>,
    unhiding_symbol: &Symbol,
    active: bool,
    pairs: &mut Vec<DependencyPair>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if !active && defined_symbols.contains(symbol) {
        push_unique_pair(
            pairs,
            DependencyPair {
                lhs: Term::app(unhiding_symbol.as_str(), vec![term.clone()]),
                rhs: mark_root(term, symbol),
                source_rule,
            },
        );
    }
    for (index, arg) in args.iter().enumerate() {
        collect_hidden_csr_pairs(
            source_rule,
            arg,
            replacement_map,
            defined_symbols,
            unhiding_symbol,
            active && replacement_map.is_allowed(symbol, index),
            pairs,
        );
    }
}

pub fn conservative_csr_dependency_rules(csr: &CsrTrs) -> Vec<RewriteRule> {
    let trs = csr.trs();
    let unhiding_symbol = fresh_unhiding_symbol(trs);
    let defined_symbols = trs.defined_symbols();
    let mut rules = trs.rules().to_vec();
    for (symbol, arity) in trs.arities() {
        let variables = (0..arity)
            .map(|index| Term::var(format!("x{}", index + 1)))
            .collect::<Vec<_>>();
        for index in 0..arity {
            if !csr.replacement_map().is_allowed(&symbol, index) {
                continue;
            }
            let rule = RewriteRule::new(
                Term::app(
                    unhiding_symbol.as_str(),
                    vec![Term::app(symbol.as_str(), variables.clone())],
                ),
                Term::app(unhiding_symbol.as_str(), vec![variables[index].clone()]),
            );
            if !rules.contains(&rule) {
                rules.push(rule);
            }
        }
        if defined_symbols.contains(&symbol) {
            let rule = RewriteRule::new(
                Term::app(
                    unhiding_symbol.as_str(),
                    vec![Term::app(symbol.as_str(), variables.clone())],
                ),
                Term::app(format!("{}#", symbol.as_str()), variables),
            );
            if !rules.contains(&rule) {
                rules.push(rule);
            }
        }
    }
    rules
}

pub(crate) fn conservative_csr_dependency_problem(csr: &CsrTrs) -> (CsrTrs, Vec<DependencyPair>) {
    let rules = conservative_csr_dependency_rules(csr);
    let variables = rules
        .iter()
        .flat_map(|rule| rule.lhs().variables().into_iter())
        .chain(
            rules
                .iter()
                .flat_map(|rule| rule.rhs().variables().into_iter()),
        )
        .collect();
    let trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_owned),
        variables,
        rules,
        csr.trs().strategy(),
    );
    let replacement_map = crate::core::ReplacementMap::full_for_arities(&trs.arities());
    (
        CsrTrs::new(trs, replacement_map)
            .expect("the full replacement map is valid for the conservative CSR-DP rules"),
        conservative_csr_dependency_pairs(csr),
    )
}

pub(crate) fn fresh_unhiding_symbol(trs: &Trs) -> Symbol {
    let arities = trs.arities();
    for index in 0usize.. {
        let candidate = Symbol::new(format!("__CSR_U{index}"));
        if !arities.contains_key(&candidate) {
            return candidate;
        }
    }
    unreachable!()
}

fn push_unique_pair(pairs: &mut Vec<DependencyPair>, pair: DependencyPair) {
    if !pairs.contains(&pair) {
        pairs.push(pair);
    }
}

pub(crate) fn csr_rhs_active_variables_are_active_in_lhs(csr: &CsrTrs) -> bool {
    csr.rules().iter().all(|rule| {
        let lhs_active = active_variables_in_term(csr, rule.lhs());
        let rhs_active = active_variables_in_term(csr, rule.rhs());
        rhs_active.is_subset(&lhs_active)
    })
}

#[cfg(test)]
pub fn certifiable_csr_dependency_pairs(csr: &CsrTrs) -> Vec<DependencyPair> {
    if csr_rhs_active_variables_are_active_in_lhs(csr) {
        csr_dependency_pairs(csr)
    } else {
        safe_csr_dependency_pairs(csr)
    }
}

fn active_variables_in_term(csr: &CsrTrs, term: &Term) -> BTreeSet<Variable> {
    let mut variables = BTreeSet::new();
    collect_active_variables(term, csr.replacement_map(), &mut variables);
    variables
}

fn inactive_variables_in_term(csr: &CsrTrs, term: &Term) -> BTreeSet<Variable> {
    let mut variables = BTreeSet::new();
    collect_inactive_variables(term, csr.replacement_map(), true, &mut variables);
    variables
}

fn collect_inactive_variables(
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    active: bool,
    variables: &mut BTreeSet<Variable>,
) {
    match term {
        Term::Var(variable) if !active => {
            variables.insert(variable.clone());
        }
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            for (index, arg) in args.iter().enumerate() {
                collect_inactive_variables(
                    arg,
                    replacement_map,
                    active && replacement_map.is_allowed(symbol, index),
                    variables,
                );
            }
        }
    }
}

fn collect_active_variables(
    term: &Term,
    replacement_map: &crate::core::ReplacementMap,
    variables: &mut BTreeSet<Variable>,
) {
    match term {
        Term::Var(variable) => {
            variables.insert(variable.clone());
        }
        Term::App { symbol, args } => {
            for (index, arg) in args.iter().enumerate() {
                if replacement_map.is_allowed(symbol, index) {
                    collect_active_variables(arg, replacement_map, variables);
                }
            }
        }
    }
}

fn collect_rhs_calls(
    source_rule: usize,
    marked_lhs: &Term,
    rule_lhs: &Term,
    defined_symbols: &BTreeSet<Symbol>,
    term: &Term,
    omit_lhs_proper_subterms: bool,
    pairs: &mut Vec<DependencyPair>,
) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            if defined_symbols.contains(symbol)
                && (!omit_lhs_proper_subterms || !term.is_proper_subterm_of(rule_lhs))
            {
                pairs.push(DependencyPair {
                    lhs: marked_lhs.clone(),
                    rhs: mark_root(term, symbol),
                    source_rule,
                });
            }
            for arg in args {
                collect_rhs_calls(
                    source_rule,
                    marked_lhs,
                    rule_lhs,
                    defined_symbols,
                    arg,
                    omit_lhs_proper_subterms,
                    pairs,
                );
            }
        }
    }
}

pub(super) fn mark_root(term: &Term, root: &Symbol) -> Term {
    match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { args, .. } => Term::app(format!("{}#", root.as_str()), args.clone()),
    }
}
