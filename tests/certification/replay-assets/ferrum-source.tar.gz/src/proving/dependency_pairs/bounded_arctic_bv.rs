//! Exact bit-vector lowering of the bounded, linear Arctic query fragment.
//!
//! The caller supplies a width covering every intermediate path weight, not
//! merely the coefficients. No multiplication, quantifiers, or optimization
//! commands are accepted. Candidate matrices are independently validated.

/// Sequential Boolean threshold circuit: no arithmetic overflow or enumeration
/// of finite-entry subsets. All names are query-local and independent of symbols.
pub(super) fn at_most(script: &mut String, values: &[String], limit: usize, serial: &mut usize) {
    if limit>=values.len() {return;}
    let mut previous=vec!["false".to_string();limit+2];
    previous[0]="true".to_string();
    for value in values {
        let mut next=vec!["true".to_string()];
        for k in 1..=limit+1 {
            let name=format!("arctic_card_{}",*serial);*serial+=1;
            script.push_str(&format!("(declare-const {name} Bool)\n(assert (= {name} (or {} (and {value} {}))))\n",previous[k],previous[k-1]));
            next.push(name);
        }
        previous=next;
    }
    script.push_str(&format!("(assert (not {}))\n",previous[limit+1]));
}

pub(super) fn lower(script: &str, width: u32) -> Option<String> {
    if !(2..=62).contains(&width) {
        return None;
    }
    let mut out = String::with_capacity(script.len() * 2);
    let separated = script.replace('(', " ( ").replace(')', " ) ");
    for token in separated.split_whitespace() {
        let replacement = match token {
            "QF_LIA" => "QF_BV".to_owned(),
            "Int" => format!("(_ BitVec {width})"),
            "+" => "bvadd".to_owned(),
            ">=" => "bvsge".to_owned(),
            ">" => "bvsgt".to_owned(),
            "<=" => "bvsle".to_owned(),
            "<" => "bvslt".to_owned(),
            "*" | "-" | "div" | "mod" | "maximize" | "minimize" | "forall" | "exists" => {
                return None;
            }
            value => {
                if let Ok(n) = value.parse::<i64>() {
                    let limit = 1i64 << (width - 1);
                    if n < -limit || n >= limit {
                        return None;
                    }
                    format!("(_ bv{} {width})", (n as i128) & ((1i128 << width) - 1))
                } else {
                    value.to_owned()
                }
            }
        };
        out.push_str(&replacement);
        out.push(' ');
    }
    Some(out)
}

pub(super) fn signed(value: i64, width: u32) -> Option<i64> {
    if !(2..=62).contains(&width) || value < 0 || value >= (1i64 << width) {
        return None;
    }
    Some(if value & (1i64 << (width - 1)) != 0 {
        value - (1i64 << width)
    } else {
        value
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn arctic_cardinality_matches_every_small_assignment() {
        use super::super::{command_exists,run_smt_script,DpOptions};
        if !command_exists("z3") {return;}
        for limit in 0..=3 {
            for mask in 0u32..8 {
                let values=(0..3).map(|i|format!("p{i}")).collect::<Vec<_>>();
                let mut script=String::from("(set-logic QF_UF)\n");
                for (i,v) in values.iter().enumerate() {script.push_str(&format!("(declare-const {v} Bool)\n(assert (= {v} {}))\n",if mask&(1<<i)!=0 {"true"} else {"false"}));}
                at_most(&mut script,&values,limit,&mut 0);
                script.push_str("(check-sat)\n");
                let output=run_smt_script(&script,&DpOptions::default(),Some(std::time::Instant::now()+std::time::Duration::from_secs(5))).unwrap();
                assert_eq!(output.lines().next(),Some(if mask.count_ones() as usize<=limit {"sat"} else {"unsat"}));
            }
        }
    }
    #[test]
    fn bounded_arctic_lowering_preserves_signed_constants_and_width() {
        let input = "(set-logic QF_LIA) (declare-const x Int) (assert (>= (+ x -3) 0))";
        let output = lower(input, 5).unwrap();
        assert!(output.contains("QF_BV"));
        assert!(output.contains("(_ BitVec 5)"));
        assert!(output.contains("bvsge ( bvadd x (_ bv29 5)"));
        assert_eq!(signed(29, 5), Some(-3));
        assert_eq!(signed(15, 5), Some(15));
        assert_eq!(signed(16, 5), Some(-16));
        assert!(lower(input, 2).is_none());
        assert!(lower("(maximize x)", 8).is_none());
    }
}
