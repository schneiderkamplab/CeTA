use std::collections::BTreeMap;

use crate::core::{CsrTrs, RelativeTrs, RewriteRule, RewriteStrategy, Symbol, Term, Trs};
use crate::llm::LinearPolynomial;

use super::construction::DependencyPair;
use crate::proving::UncurriedSymbolEntry;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DependencyPairProof {
    pub initial_pairs: usize,
    pub components: usize,
    pub removed_pairs: usize,
    pub usable_rules: usize,
    pub smt_attempted: bool,
    pub smt_solved: bool,
    pub strategy: RewriteStrategy,
    pub pairs: Vec<DependencyPair>,
    pub component_proofs: Vec<DpComponentProof>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpComponentProof {
    pub pairs: Vec<DependencyPair>,
    pub usable_rules: Vec<RewriteRule>,
    pub interpretation: Option<Vec<(String, i64, Vec<i64>)>>,
    pub backend: Option<DpSearchBackend>,
    pub usable_rules_processor: Option<Vec<RewriteRule>>,
    pub innermost_lhss_processor: Option<Vec<Term>>,
    pub reductions: Vec<DpRemovalProof>,
    pub final_acyclic_components: Vec<Vec<DependencyPair>>,
    pub proof_tree: Option<Box<DpProofTree>>,
    pub proved: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DpProofTree {
    Empty,
    /// A complete, self-contained CPF `<dpProof>` continuation retained from
    /// a twice-certified external proof and guarded by its exact source DP
    /// obligation.  This is a terminal state-local proof, not a top-level CPF
    /// replay; the surrounding Ferrum proof is still reconstructed normally.
    ExactXml(String),
    DepGraph {
        components: Vec<DpComponentProof>,
    },
    GeneralRedPairExact {
        payload_xml: String,
        proofs: Vec<Box<DpProofTree>>,
    },
    ReductionPairExact {
        processor_tag: String,
        payload_xml: String,
        removed_count: usize,
        proof: Box<DpProofTree>,
    },
    TransformationExact {
        processor_tag: String,
        payload_xml: String,
        proof: Box<DpProofTree>,
    },
    ComponentContext {
        usable_rules_processor: Option<Vec<RewriteRule>>,
        innermost_lhss_processor: Option<Vec<Term>>,
        proof: Box<DpProofTree>,
    },
    Split {
        selected_pairs: Vec<DependencyPair>,
        selected_rules: Vec<RewriteRule>,
        selected_proof: Box<DpProofTree>,
        residual_proof: Box<DpProofTree>,
    },
    SwitchInnermost {
        wcr_depth: usize,
        innermost_lhss: Vec<Term>,
        proof: Box<DpProofTree>,
    },
    Subterm {
        projection: Vec<DpSubtermProjectionEntry>,
        strict_pairs: Vec<DependencyPair>,
        graphs: Vec<DpSizeChangeGraph>,
        proof: Box<DpProofTree>,
    },
    SizeChange {
        graphs: Vec<DpSizeChangeGraph>,
    },
    SizeChangeRedPair {
        graphs: Vec<DpSizeChangeGraph>,
        reduction_pair: DpReductionPairProof,
        usable_rules: Vec<RewriteRule>,
    },
    Narrowing {
        step: DpNarrowingStep,
        proof: Box<DpProofTree>,
    },
    Instantiation {
        step: DpInstantiationStep,
        proof: Box<DpProofTree>,
    },
    ForwardInstantiation {
        step: DpForwardInstantiationStep,
        proof: Box<DpProofTree>,
    },
    Rewriting {
        step: Box<DpRewritingStep>,
        proof: Box<DpProofTree>,
    },
    RedPair {
        reduction: DpRemovalProof,
        proof: Box<DpProofTree>,
    },
    SemanticLabeling {
        step: Box<DpSemanticLabelingStep>,
        proof: Box<DpProofTree>,
    },
    Uncurry {
        step: Box<DpUncurryingStep>,
        proof: Box<DpProofTree>,
    },
    QdpToSrs {
        generated: Trs,
        removed_count: usize,
        proof: Box<crate::proving::Proof>,
    },
    SwitchToTrs {
        generated: crate::core::RelativeTrs,
        removed_count: usize,
        proof: Box<crate::proving::Proof>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpSubtermProjectionEntry {
    pub symbol: Symbol,
    pub arity: usize,
    pub position: usize,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq, serde::Deserialize, serde::Serialize)]
pub enum SlArithmeticFunction {
    Constant(usize),
    Argument(usize),
    Sum(Vec<SlArithmeticFunction>),
    Product(Vec<SlArithmeticFunction>),
    IfEqual(Box<[SlArithmeticFunction; 4]>),
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct SemanticLabelingModel {
    pub carrier_size: usize,
    pub arities: BTreeMap<Symbol, usize>,
    pub interpretations: BTreeMap<Symbol, SlArithmeticFunction>,
}

#[derive(serde::Deserialize, serde::Serialize)]
pub(super) struct SemanticLabelingModelWire {
    pub(super) carrier_size: usize,
    pub(super) arities: BTreeMap<String, usize>,
    pub(super) interpretations: BTreeMap<String, SlArithmeticFunction>,
}

impl From<&SemanticLabelingModel> for SemanticLabelingModelWire {
    fn from(model: &SemanticLabelingModel) -> Self {
        Self {
            carrier_size: model.carrier_size,
            arities: model
                .arities
                .iter()
                .map(|(symbol, arity)| (symbol.as_str().to_owned(), *arity))
                .collect(),
            interpretations: model
                .interpretations
                .iter()
                .map(|(symbol, function)| (symbol.as_str().to_owned(), function.clone()))
                .collect(),
        }
    }
}

impl From<SemanticLabelingModelWire> for SemanticLabelingModel {
    fn from(model: SemanticLabelingModelWire) -> Self {
        Self {
            carrier_size: model.carrier_size,
            arities: model
                .arities
                .into_iter()
                .map(|(symbol, arity)| (Symbol::new(symbol), arity))
                .collect(),
            interpretations: model
                .interpretations
                .into_iter()
                .map(|(symbol, function)| (Symbol::new(symbol), function))
                .collect(),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpSemanticLabelingStep {
    pub model: SemanticLabelingModel,
    /// Emit CPF's native root-labeling model.  The transformed symbols then
    /// carry symbol labels rather than numeric finite-model labels.
    pub root_labeling: bool,
    pub labeled_pairs: Vec<DependencyPair>,
    pub labeled_rules: Vec<RewriteRule>,
    pub labeled_innermost_lhss: Vec<Term>,
}

pub(crate) struct RelativeSemanticLabeling {
    pub model: SemanticLabelingModel,
    pub labeled_rules: Vec<RewriteRule>,
    pub relative: RelativeTrs,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpUncurryingStep {
    pub app_symbol: Symbol,
    /// `Some(n)` is CPF's applicative-top DP processor; `None` is ordinary
    /// applicative uncurrying below the marked DP root.
    pub applicative_top: Option<usize>,
    pub symbols: Vec<UncurriedSymbolEntry>,
    pub uncurry_rules: Vec<RewriteRule>,
    pub eta_rules: Vec<RewriteRule>,
    pub transformed_pairs: Vec<DependencyPair>,
    pub transformed_rules: Vec<RewriteRule>,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct DpSizeChangeGraph {
    pub pair: DependencyPair,
    pub edges: Vec<DpSizeChangeEdge>,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct DpSizeChangeEdge {
    pub left_position: usize,
    pub strict: bool,
    pub right_position: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpNarrowingStep {
    pub pair: DependencyPair,
    pub position: Vec<usize>,
    pub narrowings: Vec<DependencyPair>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpInstantiationStep {
    pub pair: DependencyPair,
    pub instantiations: Vec<DependencyPair>,
    pub context_sensitive: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpForwardInstantiationStep {
    pub pair: DependencyPair,
    pub instantiations: Vec<DependencyPair>,
    pub usable_rules: Vec<RewriteRule>,
    pub uses_usable_rules: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpRewritingStep {
    pub original_pair: DependencyPair,
    pub rewrite_step: crate::proving::LoopRewriteStep,
    pub rewritten_pair: DependencyPair,
    pub usable_rules: Vec<RewriteRule>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpRemovalProof {
    pub pairs: Vec<DependencyPair>,
    pub usable_rules: Vec<RewriteRule>,
    pub uses_usable_rules: bool,
    /// Keep a monotone interpretation in the non-monotone usable-rule
    /// processor when the surrounding framework certifies only that form.
    pub force_non_mono_usable_rules: bool,
    pub strict_pair_indices: Vec<usize>,
    pub strict_rules: Vec<RewriteRule>,
    pub reduction_pair: DpReductionPairProof,
}

pub type MaxPolynomialAlternative = (i64, Vec<i64>);
pub type MaxPolynomialSummary = Vec<(String, Vec<MaxPolynomialAlternative>)>;

#[derive(Clone, Debug, Eq, Hash, PartialEq, serde::Deserialize, serde::Serialize)]
pub struct DpWpoStatus {
    /// Zero-based argument positions, in status order. Positions may repeat.
    pub positions: Vec<usize>,
    pub multiset: bool,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq, serde::Deserialize, serde::Serialize)]
pub struct DpWpoMaxWitness {
    pub precedence_ranks: BTreeMap<String, usize>,
    pub statuses: BTreeMap<String, DpWpoStatus>,
    #[serde(default)]
    pub argument_filter: DpArgumentFilter,
    pub interpretation: MaxPolynomialSummary,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NaturalPolynomial {
    pub constant: i64,
    pub linear: Vec<i64>,
    /// Upper-triangular quadratic coefficients. Entries below the diagonal
    /// are ignored.
    pub quadratic: Vec<Vec<i64>>,
}

pub type NaturalPolynomialSummary = Vec<(String, NaturalPolynomial)>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ArcticMatrixDomain {
    Naturals,
    Integers,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DpReductionPairProof {
    Polynomial {
        interpretation: Vec<(String, i64, Vec<i64>)>,
        backend: DpSearchBackend,
    },
    NaturalPolynomial {
        interpretation: NaturalPolynomialSummary,
        degree: usize,
        backend: DpSearchBackend,
    },
    MaxPolynomial {
        interpretation: MaxPolynomialSummary,
        backend: DpSearchBackend,
    },
    WeightedPathOrderMax {
        precedence_ranks: BTreeMap<String, usize>,
        statuses: BTreeMap<String, DpWpoStatus>,
        argument_filter: DpArgumentFilter,
        interpretation: MaxPolynomialSummary,
        backend: DpSearchBackend,
    },
    RationalPolynomial {
        denominator: i64,
        interpretation: Vec<(String, i64, Vec<i64>)>,
        backend: DpSearchBackend,
    },
    RationalNaturalPolynomial {
        denominator: i64,
        delta: i64,
        interpretation: NaturalPolynomialSummary,
        degree: usize,
        backend: DpSearchBackend,
    },
    Matrix {
        interpretation: Vec<(String, MatrixInterpretation)>,
        dimension: usize,
        strict_dimension: usize,
        backend: DpSearchBackend,
    },
    IntegerMatrix {
        interpretation: Vec<(String, MatrixInterpretation)>,
        dimension: usize,
        strict_dimension: usize,
        backend: DpSearchBackend,
    },
    ArcticMatrix {
        interpretation: Vec<(String, MatrixInterpretation)>,
        dimension: usize,
        strict_dimension: usize,
        domain: ArcticMatrixDomain,
        backend: DpSearchBackend,
    },
    PathOrder {
        order: DpPathOrderKind,
        statuses: BTreeMap<String, DpPathOrderKind>,
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        argument_filter: DpArgumentFilter,
        backend: DpSearchBackend,
    },
    Kbo {
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        weights: BTreeMap<String, i64>,
        argument_filter: DpArgumentFilter,
        backend: DpSearchBackend,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MatrixInterpretation {
    pub constant: Vec<i64>,
    pub coefficients: Vec<Vec<Vec<i64>>>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MatrixDomain {
    Naturals,
    Integers,
}

pub(crate) struct CsrMatrixRuleRemoval {
    pub interpretations: Vec<(String, MatrixInterpretation)>,
    pub dimension: usize,
    pub strict_dimension: usize,
    pub removed: Vec<RewriteRule>,
    pub remaining: CsrTrs,
}

pub(crate) struct RelativeMatrixRuleRemoval {
    pub interpretations: Vec<(String, MatrixInterpretation)>,
    pub dimension: usize,
    pub strict_dimension: usize,
    pub domain: MatrixDomain,
    pub removed: Vec<RewriteRule>,
    pub remaining: RelativeTrs,
}

pub type DpArgumentFilter = BTreeMap<String, DpArgumentFilterEntry>;

#[derive(Clone, Debug, Eq, Hash, PartialEq, serde::Deserialize, serde::Serialize)]
pub enum DpArgumentFilterEntry {
    NonCollapsing(Vec<usize>),
    Collapsing(usize),
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, serde::Deserialize, serde::Serialize)]
pub enum DpPathOrderKind {
    Lpo,
    Rpo,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DpSearchBackend {
    Llm,
    Enumerative,
    Sat,
    Smt,
    PathOrder,
    Kbo,
}

pub(super) type PolynomialSummary = Vec<(String, i64, Vec<i64>)>;
pub(super) type WeakPolynomialBounds = (i64, i64, i64, Option<usize>, Option<usize>);
pub(super) type MaxPolynomialBounds = (i64, i64, usize, Option<usize>, Option<usize>);
pub(super) type MaxPolynomialInterpretations = BTreeMap<String, Vec<LinearPolynomial>>;
pub(super) type RationalPolynomialBounds = (i64, i64, Option<usize>, Option<usize>, i64, i64);
