//! Shared threshold circuits for small bounded natural Arctic parameters.
//! A cell's kth Boolean means its value is at least k. Matrix multiplication
//! therefore needs only AND/OR gates, not a max-plus arithmetic circuit.
use super::*;

type Source = Option<(Variable, usize)>;
type Row = BTreeMap<Source, Vec<String>>;

pub(super) struct Encoder {
    cache: BTreeMap<Term, Vec<Row>>,
    serial: usize,
    constant_bound: usize,
    coefficient_bound: usize,
    parameter_width: usize,
}

impl Encoder {
    pub(super) fn new(
        constant_bound: usize,
        coefficient_bound: usize,
        parameter_width: usize,
    ) -> Self {
        Self {
            cache: BTreeMap::new(),
            serial: 0,
            constant_bound,
            coefficient_bound,
            parameter_width,
        }
    }

    fn parameter_at(&self, name: &str, k: usize) -> String {
        // Preserve the compact Boolean tests for the common {-inf,0,1}
        // domain. Generic unsigned comparisons caused a substantial solver
        // regression despite denoting the same predicate on bounded inputs.
        if self.constant_bound <= 1 && self.coefficient_bound <= 1 {
            if k == 0 {
                return format!("(distinct {name} #b{})", "0".repeat(self.parameter_width));
            }
            if k == 1 && self.parameter_width == 2 {
                return format!("(= {name} #b10)");
            }
        }
        format!(
            "(bvuge {name} {})",
            bv_literal(k as u128 + 1, self.parameter_width)
        )
    }

    fn bind(&mut self, script: &mut String, expression: String) -> String {
        if expression == "true" || expression == "false" {
            return expression;
        }
        let name = format!("arctic_threshold_{}", self.serial);
        self.serial += 1;
        script.push_str(&format!(
            "(declare-const {name} Bool)\n(assert (= {name} {expression}))\n"
        ));
        name
    }

    fn at(row: &Row, source: &Source, k: usize) -> String {
        row.get(source)
            .and_then(|v| v.get(k))
            .cloned()
            .unwrap_or_else(|| "false".into())
    }

    fn interpret(
        &mut self,
        term: &Term,
        dimension: usize,
        script: &mut String,
        deadline: Option<Instant>,
    ) -> Option<Vec<Row>> {
        if let Some(value) = self.cache.get(term) {
            return Some(value.clone());
        }
        check_smt_build(script, deadline)?;
        let result = match term {
            Term::Var(variable) => (0..dimension)
                .map(|row| BTreeMap::from([(Some((variable.clone(), row)), vec!["true".into()])]))
                .collect(),
            Term::App { symbol, args } => {
                let children = args
                    .iter()
                    .map(|arg| self.interpret(arg, dimension, script, deadline))
                    .collect::<Option<Vec<_>>>()?;
                let sources = std::iter::once(None)
                    .chain(
                        children
                            .iter()
                            .flatten()
                            .flat_map(|row| row.keys().cloned()),
                    )
                    .collect::<BTreeSet<_>>();
                let length = (children
                    .iter()
                    .flatten()
                    .flat_map(|row| row.values().map(Vec::len))
                    .max()
                    .unwrap_or(0)
                    + self.coefficient_bound)
                    .max(self.constant_bound + 1);
                let mut result = Vec::new();
                for row in 0..dimension {
                    let mut values = BTreeMap::new();
                    for source in &sources {
                        let mut thresholds = Vec::new();
                        for k in 0..length {
                            let mut alternatives = Vec::new();
                            if source.is_none() && k <= self.constant_bound {
                                let name = matrix_bv_constant_name(symbol.as_str(), row);
                                alternatives.push(self.parameter_at(&name, k));
                            }
                            for (arg, child) in children.iter().enumerate() {
                                for col in 0..dimension {
                                    let name =
                                        matrix_bv_coefficient_name(symbol.as_str(), arg, row, col);
                                    for weight in 0..=k.min(self.coefficient_bound) {
                                        let suffix = Self::at(&child[col], source, k - weight);
                                        if suffix != "false" {
                                            alternatives.push(format!(
                                                "(and {} {suffix})",
                                                self.parameter_at(&name, weight)
                                            ));
                                        }
                                    }
                                }
                            }
                            thresholds.push(self.bind(script, smt_or(alternatives)));
                        }
                        values.insert(source.clone(), thresholds);
                    }
                    result.push(values);
                    check_smt_build(script, deadline)?;
                }
                result
            }
        };
        self.cache.insert(term.clone(), result.clone());
        Some(result)
    }

    pub(super) fn relation(
        &mut self,
        lhs: &Term,
        rhs: &Term,
        strict: bool,
        dimension: usize,
        script: &mut String,
        deadline: Option<Instant>,
    ) -> Option<String> {
        let left = self.interpret(lhs, dimension, script, deadline)?;
        let right = self.interpret(rhs, dimension, script, deadline)?;
        let mut constraints = Vec::new();
        for row in 0..dimension {
            // Bottom on the right is weakly and strictly below every value,
            // including bottom, exactly as in the independent Arctic checker.
            for (source, thresholds) in &right[row] {
                for (k, threshold) in thresholds.iter().enumerate() {
                    if threshold != "false" {
                        let target = Self::at(&left[row], source, k + usize::from(strict));
                        constraints.push(format!("(=> {threshold} {target})"));
                    }
                }
            }
        }
        Some(smt_and(constraints))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn arctic_encoding_selection_roundtrips_without_global_flags() {
        for atom in [
            "arctic-matrix-cached(dimension=3,max-constant=1,max-coefficient=1,encoding=threshold)",
            "arctic-matrix-cached(dimension=3,max-constant=1,max-coefficient=1,encoding=threshold,candidate=2)",
            "arctic-target-cached(dimension=3,max-constant=-1,max-coefficient=1,encoding=threshold,strict=all)",
            "integer-arctic-matrix(dimension=3,min-value=-1,max-value=1,encoding=threshold,strict=all)",
            "integer-arctic-matrix(dimension=3,min-value=-1,max-value=1,encoding=threshold,candidate=2)",
        ] {
            let strategy = DpStrategy::parse(atom).unwrap();
            let text = strategy.to_strategy_atom();
            assert!(text.contains("encoding=threshold"));
            assert_eq!(DpStrategy::parse(&text).unwrap(), strategy);
        }
        assert!(DpStrategy::parse(
            "arctic-matrix(dimension=2,max-constant=1,max-coefficient=1,encoding=typo)"
        )
        .is_err());
    }

    #[test]
    fn threshold_circuits_agree_with_exact_arctic_orders() {
        if !command_exists("z3") {
            return;
        }
        let x = Term::var("x");
        let f = Term::app("f", vec![x.clone()]);
        let ff = Term::app("f", vec![f.clone()]);
        for bound in [0i64, 1, 3] {
            let width = unsigned_bit_width(bound as u128 + 1);
            for constant in [i64::MIN, 0, bound] {
                for diagonal in [i64::MIN, 0, bound] {
                    let model = BTreeMap::from([(
                        "f".into(),
                        MatrixInterpretation {
                            constant: vec![constant, 0],
                            coefficients: vec![vec![vec![diagonal, bound], vec![i64::MIN, 0]]],
                        },
                    )]);
                    let mut script = String::from("(set-logic QF_BV)\n");
                    for row in 0..2 {
                        let mut values =
                            vec![(matrix_bv_constant_name("f", row), model["f"].constant[row])];
                        for col in 0..2 {
                            values.push((
                                matrix_bv_coefficient_name("f", 0, row, col),
                                model["f"].coefficients[0][row][col],
                            ));
                        }
                        for (name, value) in values {
                            let encoded = if value == i64::MIN {
                                0
                            } else {
                                value as u128 + 1
                            };
                            script.push_str(&format!("(declare-const {name} (_ BitVec {width}))\n(assert (= {name} {}))\n", bv_literal(encoded, width)));
                        }
                    }
                    let mut encoder = Encoder::new(bound as usize, bound as usize, width);
                    for (lhs, rhs) in [(&ff, &f), (&f, &ff), (&f, &x), (&x, &f)] {
                        for strict in [false, true] {
                            let expected = if strict {
                                strictly_decreases_by_arctic_matrix(lhs, rhs, &model, 2)
                            } else {
                                weakly_decreases_by_arctic_matrix(lhs, rhs, &model, 2)
                            };
                            let relation = encoder
                                .relation(lhs, rhs, strict, 2, &mut script, None)
                                .unwrap();
                            script.push_str(&format!(
                                "(assert {})\n",
                                if expected {
                                    relation
                                } else {
                                    format!("(not {relation})")
                                }
                            ));
                        }
                    }
                    let length = script.len();
                    encoder
                        .relation(&ff, &f, true, 2, &mut script, None)
                        .unwrap();
                    assert_eq!(
                        script.len(),
                        length,
                        "repeated terms must reuse their circuit"
                    );
                    script.push_str("(check-sat)\n");
                    let output = run_smt_script(
                        &script,
                        &DpOptions::default(),
                        Some(Instant::now() + Duration::from_secs(5)),
                    )
                    .unwrap();
                    assert_eq!(output.lines().next(), Some("sat"));
                }
            }
        }
    }
}
