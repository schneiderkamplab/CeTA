use std::collections::{BTreeMap, BTreeSet};
use std::fmt::{self, Display};
use std::hash::Hash;

use super::{RewriteRule, Symbol, Term, Trs};

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct ReplacementMap {
    allowed: BTreeMap<Symbol, BTreeSet<usize>>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReplacementMapIssue {
    UnknownSymbol {
        symbol: Symbol,
    },
    PositionOutOfBounds {
        symbol: Symbol,
        position: usize,
        arity: usize,
    },
}

impl Display for ReplacementMapIssue {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnknownSymbol { symbol } => {
                write!(
                    formatter,
                    "replacement map mentions unknown symbol {symbol}"
                )
            }
            Self::PositionOutOfBounds {
                symbol,
                position,
                arity,
            } => write!(
                formatter,
                "replacement map position {position} for symbol {symbol} is outside arity {arity}"
            ),
        }
    }
}

impl ReplacementMap {
    pub fn new(allowed: BTreeMap<Symbol, BTreeSet<usize>>) -> Self {
        Self { allowed }
    }

    pub fn empty_for_arities(arities: &BTreeMap<Symbol, usize>) -> Self {
        Self {
            allowed: arities
                .keys()
                .cloned()
                .map(|symbol| (symbol, BTreeSet::new()))
                .collect(),
        }
    }

    pub fn full_for_arities(arities: &BTreeMap<Symbol, usize>) -> Self {
        Self {
            allowed: arities
                .iter()
                .map(|(symbol, arity)| (symbol.clone(), (0..*arity).collect()))
                .collect(),
        }
    }

    pub fn allowed_positions(&self, symbol: &Symbol) -> Option<&BTreeSet<usize>> {
        self.allowed.get(symbol)
    }

    pub fn is_allowed(&self, symbol: &Symbol, position: usize) -> bool {
        self.allowed
            .get(symbol)
            .is_some_and(|positions| positions.contains(&position))
    }

    pub fn entries(&self) -> &BTreeMap<Symbol, BTreeSet<usize>> {
        &self.allowed
    }

    pub fn validate_for_arities(
        &self,
        arities: &BTreeMap<Symbol, usize>,
    ) -> Vec<ReplacementMapIssue> {
        let mut issues = Vec::new();
        for (symbol, positions) in &self.allowed {
            let Some(arity) = arities.get(symbol) else {
                issues.push(ReplacementMapIssue::UnknownSymbol {
                    symbol: symbol.clone(),
                });
                continue;
            };
            for position in positions {
                if *position >= *arity {
                    issues.push(ReplacementMapIssue::PositionOutOfBounds {
                        symbol: symbol.clone(),
                        position: *position,
                        arity: *arity,
                    });
                }
            }
        }
        issues
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct CsrTrs {
    trs: Trs,
    replacement_map: ReplacementMap,
}

impl CsrTrs {
    /// Extend only the auxiliary DP signature, without adding rewrite rules.
    /// A fresh, explicitly frozen wrapper has no root rewrite rule and its
    /// replacement-map entry must survive CPF materialization.
    pub(crate) fn with_frozen_auxiliary_symbol(mut self, symbol: Symbol) -> Self {
        assert!(!self.trs.arities().contains_key(&symbol));
        self.replacement_map.allowed.insert(symbol, BTreeSet::new());
        self
    }

    pub fn new(
        trs: Trs,
        replacement_map: ReplacementMap,
    ) -> Result<Self, Vec<ReplacementMapIssue>> {
        let issues = replacement_map.validate_for_arities(&trs.arities());
        if issues.is_empty() {
            Ok(Self {
                trs,
                replacement_map,
            })
        } else {
            Err(issues)
        }
    }

    pub fn full(trs: Trs) -> Self {
        let replacement_map = ReplacementMap::full_for_arities(&trs.arities());
        Self {
            trs,
            replacement_map,
        }
    }

    pub fn trs(&self) -> &Trs {
        &self.trs
    }

    pub fn replacement_map(&self) -> &ReplacementMap {
        &self.replacement_map
    }

    pub fn is_replacing_position(&self, position: &[usize], term: &Term) -> bool {
        is_replacing_position(term, &self.replacement_map, position)
    }

    pub fn rewrite_step_allowed(&self, term: &Term, position: &[usize]) -> bool {
        subterm_at(term, position).is_some()
            && is_replacing_position(term, &self.replacement_map, position)
    }

    pub fn replacing_positions(&self, term: &Term) -> Vec<Vec<usize>> {
        replacing_positions(term, &self.replacement_map)
    }

    pub fn replacing_subterms<'a>(&self, term: &'a Term) -> Vec<(Vec<usize>, &'a Term)> {
        replacing_subterms(term, &self.replacement_map)
    }

    pub fn rules(&self) -> &[RewriteRule] {
        self.trs.rules()
    }
}

pub fn is_replacing_position(
    term: &Term,
    replacement_map: &ReplacementMap,
    position: &[usize],
) -> bool {
    let mut current = term;
    for &index in position {
        let Term::App { symbol, args } = current else {
            return false;
        };
        if index >= args.len() || !replacement_map.is_allowed(symbol, index) {
            return false;
        }
        current = &args[index];
    }
    true
}

pub fn subterm_at<'a>(term: &'a Term, position: &[usize]) -> Option<&'a Term> {
    let mut current = term;
    for &index in position {
        let Term::App { args, .. } = current else {
            return None;
        };
        current = args.get(index)?;
    }
    Some(current)
}

pub fn replacing_positions(term: &Term, replacement_map: &ReplacementMap) -> Vec<Vec<usize>> {
    replacing_subterms(term, replacement_map)
        .into_iter()
        .map(|(position, _)| position)
        .collect()
}

pub fn replacing_subterms<'a>(
    term: &'a Term,
    replacement_map: &ReplacementMap,
) -> Vec<(Vec<usize>, &'a Term)> {
    let mut result = Vec::new();
    collect_replacing_subterms(term, replacement_map, &mut Vec::new(), &mut result);
    result
}

fn collect_replacing_subterms<'a>(
    term: &'a Term,
    replacement_map: &ReplacementMap,
    position: &mut Vec<usize>,
    result: &mut Vec<(Vec<usize>, &'a Term)>,
) {
    result.push((position.clone(), term));
    let Term::App { symbol, args } = term else {
        return;
    };
    for (index, arg) in args.iter().enumerate() {
        if replacement_map.is_allowed(symbol, index) {
            position.push(index);
            collect_replacing_subterms(arg, replacement_map, position, result);
            position.pop();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Variable};

    fn unary_rule() -> RewriteRule {
        RewriteRule::new(
            Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            Term::var("x"),
        )
    }

    #[test]
    fn full_replacement_map_contains_all_argument_positions() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![unary_rule()],
        );
        let map = ReplacementMap::full_for_arities(&trs.arities());
        assert!(map.is_allowed(&Symbol::new("f"), 0));
        assert!(map.is_allowed(&Symbol::new("g"), 0));
    }

    #[test]
    fn replacement_map_validation_rejects_unknown_and_out_of_bounds_positions() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![unary_rule()],
        );
        let map = ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::from([1])),
            (Symbol::new("missing"), BTreeSet::from([0])),
        ]));
        let issues = map.validate_for_arities(&trs.arities());
        assert_eq!(issues.len(), 2);
        assert!(matches!(
            issues[0],
            ReplacementMapIssue::PositionOutOfBounds { .. }
        ));
        assert!(matches!(
            issues[1],
            ReplacementMapIssue::UnknownSymbol { .. }
        ));
    }

    #[test]
    fn replacing_positions_stop_at_inactive_arguments() {
        let term = Term::app(
            "f",
            vec![
                Term::app("g", vec![Term::var("x")]),
                Term::app("h", vec![Term::var("y")]),
            ],
        );
        let map = ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::from([0])),
            (Symbol::new("g"), BTreeSet::from([0])),
            (Symbol::new("h"), BTreeSet::from([0])),
        ]));
        assert!(is_replacing_position(&term, &map, &[]));
        assert!(is_replacing_position(&term, &map, &[0, 0]));
        assert!(!is_replacing_position(&term, &map, &[1]));
        assert_eq!(
            replacing_positions(&term, &map),
            vec![vec![], vec![0], vec![0, 0]]
        );
    }

    #[test]
    fn csr_trs_rewrite_eligibility_checks_position_existence_and_map() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![unary_rule()],
        );
        let map = ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::new()),
            (Symbol::new("g"), BTreeSet::from([0])),
        ]));
        let csr = CsrTrs::new(trs, map).unwrap();
        let term = Term::app("f", vec![Term::app("g", vec![Term::var("x")])]);
        assert!(csr.rewrite_step_allowed(&term, &[]));
        assert!(!csr.rewrite_step_allowed(&term, &[0]));
        assert!(!csr.rewrite_step_allowed(&term, &[2]));
    }
}
