use std::collections::BTreeSet;
use std::fmt::{self, Display};
use std::hash::Hash;

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Variable(String);

impl Variable {
    pub fn new(name: impl Into<String>) -> Self {
        Self(name.into())
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl Display for Variable {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Symbol(String);

impl Symbol {
    pub fn new(name: impl Into<String>) -> Self {
        Self(name.into())
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl Display for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum Term {
    Var(Variable),
    App { symbol: Symbol, args: Vec<Term> },
}

impl Term {
    pub fn app(symbol: impl Into<String>, args: Vec<Term>) -> Self {
        Self::App {
            symbol: Symbol::new(symbol),
            args,
        }
    }

    pub fn var(name: impl Into<String>) -> Self {
        Self::Var(Variable::new(name))
    }

    pub fn root_symbol(&self) -> Option<&Symbol> {
        match self {
            Self::Var(_) => None,
            Self::App { symbol, .. } => Some(symbol),
        }
    }

    pub fn variables(&self) -> BTreeSet<Variable> {
        let mut variables = BTreeSet::new();
        self.collect_variables(&mut variables);
        variables
    }

    pub fn is_proper_subterm_of(&self, other: &Term) -> bool {
        match other {
            Term::Var(_) => false,
            Term::App { args, .. } => args
                .iter()
                .any(|arg| self == arg || self.is_proper_subterm_of(arg)),
        }
    }

    fn collect_variables(&self, variables: &mut BTreeSet<Variable>) {
        match self {
            Term::Var(variable) => {
                variables.insert(variable.clone());
            }
            Term::App { args, .. } => {
                for arg in args {
                    arg.collect_variables(variables);
                }
            }
        }
    }
}

impl Display for Term {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Term::Var(variable) => write!(f, "{variable}"),
            Term::App { symbol, args } if args.is_empty() => write!(f, "{symbol}"),
            Term::App { symbol, args } => {
                write!(f, "{symbol}(")?;
                for (index, arg) in args.iter().enumerate() {
                    if index > 0 {
                        f.write_str(", ")?;
                    }
                    write!(f, "{arg}")?;
                }
                f.write_str(")")
            }
        }
    }
}
