use std::collections::BTreeMap;

use super::{Term, Variable};

pub type Substitution = BTreeMap<Variable, Term>;

pub fn match_pattern(pattern: &Term, term: &Term) -> Option<Substitution> {
    let mut substitution = BTreeMap::new();
    if match_into(pattern, term, &mut substitution) {
        Some(substitution)
    } else {
        None
    }
}

fn match_into(pattern: &Term, term: &Term, substitution: &mut Substitution) -> bool {
    match (pattern, term) {
        (Term::Var(variable), _) => match substitution.get(variable) {
            Some(existing) => existing == term,
            None => {
                substitution.insert(variable.clone(), term.clone());
                true
            }
        },
        (
            Term::App {
                symbol: pattern_symbol,
                args: pattern_args,
            },
            Term::App { symbol, args },
        ) => {
            pattern_symbol == symbol
                && pattern_args.len() == args.len()
                && pattern_args
                    .iter()
                    .zip(args)
                    .all(|(pattern_arg, arg)| match_into(pattern_arg, arg, substitution))
        }
        _ => false,
    }
}
