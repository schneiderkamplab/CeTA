use std::collections::{BTreeMap, BTreeSet};
use std::fmt::{self, Display};
use std::hash::Hash;

use super::{Symbol, Term, Variable};

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum RewriteStrategy {
    Full,
    Innermost,
    Outermost,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct RewriteRule {
    lhs: Term,
    rhs: Term,
}

impl RewriteRule {
    pub fn new(lhs: Term, rhs: Term) -> Self {
        Self { lhs, rhs }
    }

    pub fn lhs(&self) -> &Term {
        &self.lhs
    }

    pub fn rhs(&self) -> &Term {
        &self.rhs
    }

    pub fn is_well_formed(&self) -> bool {
        self.rhs.variables().is_subset(&self.lhs.variables())
    }
}

impl Display for RewriteRule {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} -> {}", self.lhs, self.rhs)
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct SrsRule {
    lhs: Vec<Symbol>,
    rhs: Vec<Symbol>,
}

impl SrsRule {
    pub fn from_words(lhs: Vec<Symbol>, rhs: Vec<Symbol>) -> Self {
        Self { lhs, rhs }
    }

    pub fn lhs(&self) -> &[Symbol] {
        &self.lhs
    }

    pub fn rhs(&self) -> &[Symbol] {
        &self.rhs
    }

    #[cfg(test)]
    pub fn new_for_test<L, R, LS, RS>(lhs: L, rhs: R) -> Self
    where
        L: IntoIterator<Item = LS>,
        R: IntoIterator<Item = RS>,
        LS: Into<String>,
        RS: Into<String>,
    {
        Self {
            lhs: lhs.into_iter().map(Symbol::new).collect(),
            rhs: rhs.into_iter().map(Symbol::new).collect(),
        }
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct Trs {
    name: Option<String>,
    variables: BTreeSet<Variable>,
    rules: Vec<RewriteRule>,
    strategy: RewriteStrategy,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct RelativeTrs {
    strict: Trs,
    weak_rules: Vec<RewriteRule>,
}

impl RelativeTrs {
    pub fn new(strict: Trs, weak_rules: Vec<RewriteRule>) -> Self {
        Self { strict, weak_rules }
    }

    pub fn strict(&self) -> &Trs {
        &self.strict
    }

    pub fn weak_rules(&self) -> &[RewriteRule] {
        &self.weak_rules
    }

    pub fn union(&self) -> Trs {
        let rules = self
            .strict
            .rules()
            .iter()
            .cloned()
            .chain(self.weak_rules.iter().cloned())
            .collect();
        Trs::new_with_strategy(
            self.strict.name().map(str::to_string),
            self.strict.variables().clone(),
            rules,
            self.strict.strategy(),
        )
    }

    pub fn is_srs_encoded(&self) -> bool {
        self.strict.srs_rules().is_some()
            && Trs::new_with_strategy(
                self.strict.name().map(str::to_string),
                self.strict.variables().clone(),
                self.weak_rules.clone(),
                self.strict.strategy(),
            )
            .srs_rules()
            .is_some()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TrsIssue {
    EmptySystem,
    LhsIsVariable {
        rule_index: usize,
    },
    ExtraVariablesOnRhs {
        rule_index: usize,
        variables: Vec<Variable>,
    },
    ArityConflict {
        symbol: Symbol,
        arities: Vec<usize>,
    },
}

impl Display for TrsIssue {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::EmptySystem => f.write_str("TRS has no rewrite rules"),
            Self::LhsIsVariable { rule_index } => {
                write!(f, "rule {rule_index} has a variable left-hand side")
            }
            Self::ExtraVariablesOnRhs {
                rule_index,
                variables,
            } => {
                write!(f, "rule {rule_index} has extra RHS variables: ")?;
                for (index, variable) in variables.iter().enumerate() {
                    if index > 0 {
                        f.write_str(", ")?;
                    }
                    write!(f, "{variable}")?;
                }
                Ok(())
            }
            Self::ArityConflict { symbol, arities } => {
                write!(f, "symbol {symbol} occurs with arities {arities:?}")
            }
        }
    }
}

impl Trs {
    pub fn new(
        name: Option<String>,
        variables: BTreeSet<Variable>,
        rules: Vec<RewriteRule>,
    ) -> Self {
        Self::new_with_strategy(name, variables, rules, RewriteStrategy::Full)
    }

    pub fn new_with_strategy(
        name: Option<String>,
        variables: BTreeSet<Variable>,
        rules: Vec<RewriteRule>,
        strategy: RewriteStrategy,
    ) -> Self {
        Self {
            name,
            variables,
            rules,
            strategy,
        }
    }

    pub fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    pub fn variables(&self) -> &BTreeSet<Variable> {
        &self.variables
    }

    pub fn rules(&self) -> &[RewriteRule] {
        &self.rules
    }

    pub fn strategy(&self) -> RewriteStrategy {
        self.strategy
    }

    pub fn is_empty(&self) -> bool {
        self.rules.is_empty()
    }

    pub fn arities(&self) -> BTreeMap<Symbol, usize> {
        let mut arities = BTreeMap::new();
        for rule in &self.rules {
            collect_arities(rule.lhs(), &mut arities);
            collect_arities(rule.rhs(), &mut arities);
        }
        arities
    }

    pub fn validate(&self) -> Vec<TrsIssue> {
        let mut issues = Vec::new();
        if self.rules.is_empty() {
            issues.push(TrsIssue::EmptySystem);
        }
        for (index, rule) in self.rules.iter().enumerate() {
            if matches!(rule.lhs(), Term::Var(_)) {
                issues.push(TrsIssue::LhsIsVariable { rule_index: index });
            }
            let lhs_variables = rule.lhs().variables();
            let extra_variables = rule
                .rhs()
                .variables()
                .difference(&lhs_variables)
                .cloned()
                .collect::<Vec<_>>();
            if !extra_variables.is_empty() {
                issues.push(TrsIssue::ExtraVariablesOnRhs {
                    rule_index: index,
                    variables: extra_variables,
                });
            }
        }
        for (symbol, arities) in self.arity_sets() {
            if arities.len() > 1 {
                issues.push(TrsIssue::ArityConflict {
                    symbol,
                    arities: arities.into_iter().collect(),
                });
            }
        }
        issues
    }

    pub fn defined_symbols(&self) -> BTreeSet<Symbol> {
        self.rules
            .iter()
            .filter_map(|rule| rule.lhs().root_symbol().cloned())
            .collect()
    }

    pub fn srs_rules(&self) -> Option<Vec<SrsRule>> {
        let mut rules = Vec::new();
        for rule in &self.rules {
            let (lhs, lhs_tail) = srs_word(rule.lhs())?;
            let (rhs, rhs_tail) = srs_word(rule.rhs())?;
            if lhs_tail != rhs_tail {
                return None;
            }
            rules.push(SrsRule { lhs, rhs });
        }
        Some(rules)
    }

    pub fn is_srs_encoded(&self) -> bool {
        self.srs_rules().is_some()
    }

    pub fn unary_srs_rules(&self) -> Option<Vec<SrsRule>> {
        let mut rules = Vec::new();
        for rule in &self.rules {
            rules.push(SrsRule {
                lhs: unary_word(rule.lhs())?,
                rhs: unary_word(rule.rhs())?,
            });
        }
        Some(rules)
    }

    pub fn is_unary_signature(&self) -> bool {
        self.unary_srs_rules().is_some()
    }

    fn arity_sets(&self) -> BTreeMap<Symbol, BTreeSet<usize>> {
        let mut arities = BTreeMap::new();
        for rule in &self.rules {
            collect_arity_sets(rule.lhs(), &mut arities);
            collect_arity_sets(rule.rhs(), &mut arities);
        }
        arities
    }
}

fn srs_word(term: &Term) -> Option<(Vec<Symbol>, Variable)> {
    let mut word = Vec::new();
    let mut cursor = term;
    loop {
        match cursor {
            Term::Var(variable) => return Some((word, variable.clone())),
            Term::App { symbol, args } if args.len() == 1 => {
                word.push(symbol.clone());
                cursor = &args[0];
            }
            Term::App { .. } => return None,
        }
    }
}

fn unary_word(term: &Term) -> Option<Vec<Symbol>> {
    match term {
        Term::Var(_) => Some(Vec::new()),
        Term::App { symbol, args } if args.is_empty() => Some(vec![symbol.clone()]),
        Term::App { symbol, args } if args.len() == 1 => {
            let mut word = vec![symbol.clone()];
            word.extend(unary_word(&args[0])?);
            Some(word)
        }
        Term::App { .. } => None,
    }
}

fn collect_arities(term: &Term, arities: &mut BTreeMap<Symbol, usize>) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            arities.insert(symbol.clone(), args.len());
            for arg in args {
                collect_arities(arg, arities);
            }
        }
    }
}

fn collect_arity_sets(term: &Term, arities: &mut BTreeMap<Symbol, BTreeSet<usize>>) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            arities
                .entry(symbol.clone())
                .or_default()
                .insert(args.len());
            for arg in args {
                collect_arity_sets(arg, arities);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_extra_rhs_variables() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("y")]),
            )],
        );
        assert!(matches!(
            trs.validate().first(),
            Some(TrsIssue::ExtraVariablesOnRhs { .. })
        ));
    }

    #[test]
    fn detects_arity_conflicts() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x"), Term::var("x")]),
            )],
        );
        assert!(
            trs.validate()
                .iter()
                .any(|issue| matches!(issue, TrsIssue::ArityConflict { .. }))
        );
    }

    #[test]
    fn recognizes_unary_tail_variable_srs_encoding() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::app("b", vec![Term::var("x")])]),
                Term::app("c", vec![Term::var("x")]),
            )],
        );
        let rules = trs.srs_rules().unwrap();
        assert_eq!(rules[0].lhs().len(), 2);
        assert_eq!(rules[0].rhs().len(), 1);
    }

    #[test]
    fn rejects_non_srs_unary_rules_with_different_tails() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("y")]),
            )],
        );
        assert!(!trs.is_srs_encoded());
    }

    #[test]
    fn transforms_unary_trs_with_constants_to_srs_words() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![Term::app("c", Vec::new())])]),
                    Term::app("d", Vec::new()),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::app("c", Vec::new())]),
                ),
            ],
        );
        let rules = trs.unary_srs_rules().unwrap();
        assert_eq!(rules[0].lhs().len(), 3);
        assert_eq!(rules[0].rhs().len(), 1);
        assert_eq!(rules[1].lhs().len(), 1);
        assert_eq!(rules[1].rhs().len(), 2);
        assert!(trs.is_unary_signature());
    }
}
