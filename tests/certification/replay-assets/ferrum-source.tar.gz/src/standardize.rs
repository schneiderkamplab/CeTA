use std::collections::{BTreeMap, BTreeSet};
use std::fmt;

use crate::core::{RewriteRule, Symbol, Term, Trs, Variable};

const DEFAULT_MAX_EXACT_SYMBOLS: usize = 8;

#[derive(Default)]
struct CanonicalSearchStats {
    trace: bool,
    nodes: usize,
    leaves: usize,
    swaps: usize,
    pruned: usize,
    refinement: std::time::Duration,
    encoding: std::time::Duration,
    last_report: Option<std::time::Instant>,
    // Each permutation is witnessed by two identical complete leaf encodings.
    automorphisms: Vec<Vec<usize>>,
    use_automorphisms: bool,
    occurrences: Vec<Vec<(usize, usize)>>,
    identity_key: Option<String>,
}

impl CanonicalSearchStats {
    fn report(&mut self, finished: bool) {
        if !self.trace || (!finished && self.last_report.is_some_and(|t| t.elapsed().as_secs() < 2))
        {
            return;
        }
        eprintln!(
            "canonical-search finished={finished} nodes={} leaves={} swaps={} pruned={} automorphisms={} refinement={:.3}s encoding={:.3}s",
            self.nodes,
            self.leaves,
            self.swaps,
            self.pruned,
            self.automorphisms.len(),
            self.refinement.as_secs_f64(),
            self.encoding.as_secs_f64()
        );
        self.last_report = Some(std::time::Instant::now());
    }
}

#[cfg(test)]
mod symmetry_tests {
    use super::*;

    #[test]
    fn interchangeable_symbols_keep_exact_canonicalization_and_variable_sharing() {
        fn problem(prefix: &str, reverse: bool, repeated: bool) -> Trs {
            let mut rules = (0..12)
                .map(|i| {
                    let x = Term::var("x");
                    RewriteRule::new(
                        Term::app(
                            format!("{prefix}{i}"),
                            vec![x.clone(), if repeated { x.clone() } else { Term::var("y") }],
                        ),
                        x,
                    )
                })
                .collect::<Vec<_>>();
            if reverse {
                rules.reverse();
            }
            Trs::new(None, Default::default(), rules)
        }
        let original = standardize_trs(&problem("a", false, true)).unwrap();
        assert_eq!(
            original,
            standardize_trs(&problem("z", true, true)).unwrap()
        );
        assert_ne!(
            original,
            standardize_trs(&problem("a", false, false)).unwrap()
        );
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TermPair {
    pub lhs: Term,
    pub rhs: Term,
}

impl TermPair {
    pub fn new(lhs: Term, rhs: Term) -> Self {
        Self { lhs, rhs }
    }

    pub fn from_rule(rule: &RewriteRule) -> Self {
        Self {
            lhs: rule.lhs().clone(),
            rhs: rule.rhs().clone(),
        }
    }

    pub fn into_rule(self) -> RewriteRule {
        RewriteRule::new(self.lhs, self.rhs)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StandardizationGroup {
    pub label: String,
    pub pairs: Vec<TermPair>,
}

impl StandardizationGroup {
    pub fn new(label: impl Into<String>, pairs: Vec<TermPair>) -> Self {
        Self {
            label: label.into(),
            pairs,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StandardizationProblem {
    pub groups: Vec<StandardizationGroup>,
}

impl StandardizationProblem {
    pub fn new(groups: Vec<StandardizationGroup>) -> Self {
        Self { groups }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StandardizationOptions {
    /// Retained for API compatibility and as a future search-tuning hint.
    ///
    /// It is not a semantic cutoff: canonicalization must remain complete
    /// regardless of the size of an unresolved color class.
    pub max_exact_symbols: usize,
}

impl Default for StandardizationOptions {
    fn default() -> Self {
        Self {
            max_exact_symbols: DEFAULT_MAX_EXACT_SYMBOLS,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StandardizationError {
    TooManyFunctionSymbols { count: usize, max_exact: usize },
}

impl fmt::Display for StandardizationError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::TooManyFunctionSymbols { count, max_exact } => write!(
                formatter,
                "exact standardization needs {count}! function-symbol assignments; cap is {max_exact}"
            ),
        }
    }
}

impl std::error::Error for StandardizationError {}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StandardizedTrs {
    pub trs: Trs,
    pub function_bijection: BTreeMap<Symbol, Symbol>,
    pub inverse_function_bijection: BTreeMap<Symbol, Symbol>,
    pub rule_metadata: Vec<PairStandardization>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StandardizedProblem {
    pub problem: StandardizationProblem,
    pub function_bijection: BTreeMap<Symbol, Symbol>,
    pub inverse_function_bijection: BTreeMap<Symbol, Symbol>,
    pub pair_metadata: Vec<PairStandardization>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PairStandardization {
    pub group_label: String,
    pub original_group_index: usize,
    pub original_pair_index: usize,
    pub canonical_group_index: usize,
    pub canonical_pair_index: usize,
    pub variable_bijection: BTreeMap<Variable, Variable>,
    pub inverse_variable_bijection: BTreeMap<Variable, Variable>,
}

#[derive(Clone)]
struct Candidate {
    key: String,
    problem: StandardizationProblem,
    assignment: Vec<usize>,
    pair_metadata: Vec<PairStandardization>,
}

#[derive(Clone)]
struct EncodedPair {
    key: String,
    pair: TermPair,
    original_group_index: usize,
    original_pair_index: usize,
    variable_bijection: BTreeMap<Variable, Variable>,
}

pub fn standardize_trs(trs: &Trs) -> Result<Trs, StandardizationError> {
    Ok(standardize_trs_with_bijection(trs)?.trs)
}

pub fn standardize_trs_with_options(
    trs: &Trs,
    options: &StandardizationOptions,
) -> Result<Trs, StandardizationError> {
    Ok(standardize_trs_with_bijection_and_options(trs, options)?.trs)
}

pub fn standardize_trs_with_bijection(trs: &Trs) -> Result<StandardizedTrs, StandardizationError> {
    standardize_trs_with_bijection_and_options(trs, &StandardizationOptions::default())
}

pub fn standardize_trs_with_bijection_and_options(
    trs: &Trs,
    options: &StandardizationOptions,
) -> Result<StandardizedTrs, StandardizationError> {
    let pairs = trs
        .rules()
        .iter()
        .map(TermPair::from_rule)
        .collect::<Vec<_>>();
    let problem = StandardizationProblem::new(vec![StandardizationGroup::new("rules", pairs)]);
    let standardized = standardize_problem_with_bijection_and_options(&problem, options)?;
    let rules = standardized
        .problem
        .groups
        .into_iter()
        .find(|group| group.label == "rules")
        .map(|group| {
            group
                .pairs
                .into_iter()
                .map(TermPair::into_rule)
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
    let variables = rules
        .iter()
        .flat_map(|rule| {
            let mut variables = rule.lhs().variables();
            variables.extend(rule.rhs().variables());
            variables.into_iter()
        })
        .collect::<BTreeSet<_>>();
    Ok(StandardizedTrs {
        trs: Trs::new_with_strategy(
            trs.name().map(str::to_string),
            variables,
            rules,
            trs.strategy(),
        ),
        function_bijection: standardized.function_bijection,
        inverse_function_bijection: standardized.inverse_function_bijection,
        rule_metadata: standardized.pair_metadata,
    })
}

pub fn standardize_problem(
    problem: &StandardizationProblem,
) -> Result<StandardizationProblem, StandardizationError> {
    Ok(standardize_problem_with_bijection(problem)?.problem)
}

pub fn standardize_problem_with_options(
    problem: &StandardizationProblem,
    options: &StandardizationOptions,
) -> Result<StandardizationProblem, StandardizationError> {
    Ok(standardize_problem_with_bijection_and_options(problem, options)?.problem)
}

pub fn standardize_problem_with_bijection(
    problem: &StandardizationProblem,
) -> Result<StandardizedProblem, StandardizationError> {
    standardize_problem_with_bijection_and_options(problem, &StandardizationOptions::default())
}

pub fn standardize_problem_with_bijection_and_options(
    problem: &StandardizationProblem,
    options: &StandardizationOptions,
) -> Result<StandardizedProblem, StandardizationError> {
    let symbols = collect_problem_symbols(problem);
    let _search_tuning_hint = options.max_exact_symbols;
    let symbol_indices = symbols
        .iter()
        .cloned()
        .enumerate()
        .map(|(index, symbol)| (symbol, index))
        .collect::<BTreeMap<_, _>>();
    let arities = problem_symbol_arities(problem);
    let initial_colors = assign_invariant_colors(
        symbols
            .iter()
            .map(|symbol| format!("arity={}", arities.get(symbol).copied().unwrap_or(0)))
            .collect(),
    );
    let mut best = None;
    let mut stats = CanonicalSearchStats {
        trace: std::env::var_os("FERRUM_CANONICAL_TRACE").is_some(),
        use_automorphisms: true,
        ..Default::default()
    };
    search_refined_assignments(
        problem,
        &symbols,
        &symbol_indices,
        initial_colors,
        &mut best,
        &mut stats,
    );
    stats.report(true);
    let best = best.expect("empty assignment is valid for symbol-free inputs");
    let assigned_bijection = assignment_bijection(&symbols, &best.assignment);
    let (problem, renumbering) = renumber_symbols_by_first_occurrence(&best.problem);
    let function_bijection = compose_bijections(&assigned_bijection, &renumbering);
    let inverse_function_bijection = invert_bijection(&function_bijection);
    Ok(StandardizedProblem {
        problem,
        function_bijection,
        inverse_function_bijection,
        pair_metadata: best.pair_metadata,
    })
}

fn search_refined_assignments(
    problem: &StandardizationProblem,
    symbols: &[Symbol],
    symbol_indices: &BTreeMap<Symbol, usize>,
    colors: Vec<usize>,
    best: &mut Option<Candidate>,
    stats: &mut CanonicalSearchStats,
) {
    if stats.nodes == 0 {
        stats.occurrences = (0..symbols.len())
            .map(|symbol| {
                problem
                    .groups
                    .iter()
                    .enumerate()
                    .flat_map(|(g, group)| {
                        group.pairs.iter().enumerate().filter_map(move |(p, pair)| {
                            pair_contains_symbol_index(pair, symbol, symbol_indices)
                                .then_some((g, p))
                        })
                    })
                    .collect()
            })
            .collect();
    }
    stats.nodes += 1;
    let started = std::time::Instant::now();
    let colors = refine_symbol_colors(problem, symbol_indices, &stats.occurrences, colors);
    stats.refinement += started.elapsed();
    stats.report(false);
    let mut classes = BTreeMap::<usize, Vec<usize>>::new();
    for (index, color) in colors.iter().copied().enumerate() {
        classes.entry(color).or_default().push(index);
    }
    let branch_class = classes
        .values()
        .filter(|class| class.len() > 1)
        .min_by_key(|class| class.len());
    let Some(branch_class) = branch_class else {
        stats.leaves += 1;
        let started = std::time::Instant::now();
        let candidate = encode_problem(problem, symbol_indices, &colors);
        stats.encoding += started.elapsed();
        if let Some(current) = best
            .as_ref()
            .filter(|current| stats.use_automorphisms && current.key == candidate.key)
        {
            let mut inverse = vec![0; symbols.len()];
            for (symbol, &label) in current.assignment.iter().enumerate() {
                inverse[label] = symbol;
            }
            let permutation = candidate
                .assignment
                .iter()
                .map(|&label| inverse[label])
                .collect::<Vec<_>>();
            if permutation.iter().enumerate().any(|(i, &j)| i != j)
                && !stats.automorphisms.contains(&permutation)
            {
                stats.automorphisms.push(permutation);
            }
        }
        if best
            .as_ref()
            .is_none_or(|current| candidate.key < current.key)
        {
            *best = Some(candidate);
        }
        return;
    };

    // Prune only proven automorphisms: swapping two members of this color
    // class must preserve the complete grouped problem, including local
    // variable sharing. Equal refinement fingerprints alone are insufficient.
    // The transposition also fixes every prior individualized color, so its
    // two branches have exactly the same attainable canonical encodings.
    let identity = (0..symbols.len()).collect::<Vec<_>>();
    if stats.identity_key.is_none() {
        let started = std::time::Instant::now();
        stats.identity_key = Some(encode_problem(problem, symbol_indices, &identity).key);
        stats.encoding += started.elapsed();
    }
    let mut representatives = Vec::new();
    for &chosen in branch_class {
        // Previously discovered automorphisms may move several symbols at once.
        // Only use generators preserving this node's entire color partition:
        // in particular they fix every earlier individualized symbol. Their
        // orbit therefore consists of equivalent child searches, with exactly
        // the same attainable complete encodings. Fingerprint equality alone
        // never licenses pruning.
        if same_known_orbit(chosen, &representatives, &colors, &stats.automorphisms) {
            stats.pruned += 1;
            continue;
        }
        if representatives.iter().any(|&previous| {
            stats.swaps += 1;
            let started = std::time::Instant::now();
            let mut swapped = identity.clone();
            swapped.swap(previous, chosen);
            let same = Some(&encode_problem(problem, symbol_indices, &swapped).key)
                == stats.identity_key.as_ref();
            stats.encoding += started.elapsed();
            same
        }) {
            stats.pruned += 1;
            continue;
        }
        representatives.push(chosen);
        let individualized = assign_invariant_colors(
            colors
                .iter()
                .enumerate()
                .map(|(index, color)| {
                    format!(
                        "{color}|{}",
                        if index == chosen { "chosen" } else { "other" }
                    )
                })
                .collect(),
        );
        search_refined_assignments(
            problem,
            symbols,
            symbol_indices,
            individualized,
            best,
            stats,
        );
    }
}

fn same_known_orbit(
    chosen: usize,
    representatives: &[usize],
    colors: &[usize],
    automorphisms: &[Vec<usize>],
) -> bool {
    if representatives.is_empty() {
        return false;
    }
    let generators = automorphisms
        .iter()
        .filter(|permutation| {
            permutation
                .iter()
                .enumerate()
                .all(|(i, &j)| colors[i] == colors[j])
        })
        .collect::<Vec<_>>();
    let mut seen = vec![false; colors.len()];
    seen[chosen] = true;
    let mut pending = vec![chosen];
    while let Some(symbol) = pending.pop() {
        if representatives.contains(&symbol) {
            return true;
        }
        for permutation in &generators {
            let next = permutation[symbol];
            if !seen[next] {
                seen[next] = true;
                pending.push(next);
            }
        }
    }
    false
}

fn refine_symbol_colors(
    problem: &StandardizationProblem,
    symbol_indices: &BTreeMap<Symbol, usize>,
    occurrences: &[Vec<(usize, usize)>],
    mut colors: Vec<usize>,
) -> Vec<usize> {
    loop {
        let fingerprints = occurrences
            .iter()
            .enumerate()
            .map(|(focus_index, positions)| {
                let mut contexts = Vec::new();
                for &(group_index, pair_index) in positions {
                    let group = &problem.groups[group_index];
                    let pair = &group.pairs[pair_index];
                    let mut variables = BTreeMap::new();
                    let lhs = colored_term_signature(
                        &pair.lhs,
                        focus_index,
                        symbol_indices,
                        &colors,
                        &mut variables,
                    );
                    let rhs = colored_term_signature(
                        &pair.rhs,
                        focus_index,
                        symbol_indices,
                        &colors,
                        &mut variables,
                    );
                    contexts.push(format!("{}:{lhs}->{rhs}", group.label));
                }
                contexts.sort();
                format!("{}|{}", colors[focus_index], contexts.join(";"))
            })
            .collect::<Vec<_>>();
        let refined = assign_invariant_colors(fingerprints);
        if same_color_partition(&refined, &colors) {
            colors = refined;
            break;
        }
        colors = refined;
    }

    colors
}

fn same_color_partition(left: &[usize], right: &[usize]) -> bool {
    left.len() == right.len()
        && (0..left.len()).all(|first| {
            (0..left.len())
                .all(|second| (left[first] == left[second]) == (right[first] == right[second]))
        })
}

fn assign_invariant_colors(fingerprints: Vec<String>) -> Vec<usize> {
    let distinct = fingerprints.iter().cloned().collect::<BTreeSet<_>>();
    let colors = distinct
        .into_iter()
        .enumerate()
        .map(|(index, fingerprint)| (fingerprint, index))
        .collect::<BTreeMap<_, _>>();
    fingerprints
        .into_iter()
        .map(|fingerprint| colors[&fingerprint])
        .collect()
}

fn problem_symbol_arities(problem: &StandardizationProblem) -> BTreeMap<Symbol, usize> {
    fn collect(term: &Term, arities: &mut BTreeMap<Symbol, usize>) {
        if let Term::App { symbol, args } = term {
            arities.insert(symbol.clone(), args.len());
            for argument in args {
                collect(argument, arities);
            }
        }
    }

    let mut arities = BTreeMap::new();
    for group in &problem.groups {
        for pair in &group.pairs {
            collect(&pair.lhs, &mut arities);
            collect(&pair.rhs, &mut arities);
        }
    }
    arities
}

fn pair_contains_symbol_index(
    pair: &TermPair,
    focus_index: usize,
    symbol_indices: &BTreeMap<Symbol, usize>,
) -> bool {
    fn contains(term: &Term, focus_index: usize, symbol_indices: &BTreeMap<Symbol, usize>) -> bool {
        match term {
            Term::Var(_) => false,
            Term::App { symbol, args } => {
                symbol_indices[symbol] == focus_index
                    || args
                        .iter()
                        .any(|argument| contains(argument, focus_index, symbol_indices))
            }
        }
    }

    contains(&pair.lhs, focus_index, symbol_indices)
        || contains(&pair.rhs, focus_index, symbol_indices)
}

fn colored_term_signature(
    term: &Term,
    focus_index: usize,
    symbol_indices: &BTreeMap<Symbol, usize>,
    colors: &[usize],
    variables: &mut BTreeMap<Variable, usize>,
) -> String {
    match term {
        Term::Var(variable) => {
            let next = variables.len();
            let index = *variables.entry(variable.clone()).or_insert(next);
            format!("V{index}")
        }
        Term::App { symbol, args } => {
            let symbol_index = symbol_indices[symbol];
            let marker = if symbol_index == focus_index {
                'T'
            } else {
                'C'
            };
            let mut signature = format!("{marker}{}#{}", colors[symbol_index], args.len());
            if !args.is_empty() {
                signature.push('(');
                for (index, argument) in args.iter().enumerate() {
                    if index > 0 {
                        signature.push(',');
                    }
                    signature.push_str(&colored_term_signature(
                        argument,
                        focus_index,
                        symbol_indices,
                        colors,
                        variables,
                    ));
                }
                signature.push(')');
            }
            signature
        }
    }
}

fn encode_problem(
    problem: &StandardizationProblem,
    symbol_indices: &BTreeMap<Symbol, usize>,
    assignment: &[usize],
) -> Candidate {
    let mut groups = problem
        .groups
        .iter()
        .cloned()
        .enumerate()
        .collect::<Vec<_>>();
    groups.sort_by(|(_, left), (_, right)| left.label.cmp(&right.label));
    let mut key = String::new();
    let mut standardized_groups = Vec::new();
    let mut pair_metadata = Vec::new();
    for (canonical_group_index, (original_group_index, group)) in groups.into_iter().enumerate() {
        let mut encoded_pairs = group
            .pairs
            .iter()
            .enumerate()
            .map(|(original_pair_index, pair)| {
                encode_pair(
                    pair,
                    symbol_indices,
                    assignment,
                    original_group_index,
                    original_pair_index,
                )
            })
            .collect::<Vec<_>>();
        encoded_pairs.sort_by(|left, right| left.key.cmp(&right.key));
        key.push_str("G{");
        key.push_str(&group.label);
        key.push_str("}:");
        for pair in &encoded_pairs {
            key.push_str(&pair.key);
            key.push(';');
        }
        pair_metadata.extend(encoded_pairs.iter().enumerate().map(
            |(canonical_pair_index, encoded)| PairStandardization {
                group_label: group.label.clone(),
                original_group_index: encoded.original_group_index,
                original_pair_index: encoded.original_pair_index,
                canonical_group_index,
                canonical_pair_index,
                variable_bijection: encoded.variable_bijection.clone(),
                inverse_variable_bijection: invert_variable_bijection(&encoded.variable_bijection),
            },
        ));
        standardized_groups.push(StandardizationGroup {
            label: group.label,
            pairs: encoded_pairs
                .into_iter()
                .map(|encoded| encoded.pair)
                .collect(),
        });
    }
    Candidate {
        key,
        problem: StandardizationProblem::new(standardized_groups),
        assignment: assignment.to_vec(),
        pair_metadata,
    }
}

fn encode_pair(
    pair: &TermPair,
    symbol_indices: &BTreeMap<Symbol, usize>,
    assignment: &[usize],
    original_group_index: usize,
    original_pair_index: usize,
) -> EncodedPair {
    let mut variables = BTreeMap::new();
    let lhs = canonicalize_term(&pair.lhs, symbol_indices, assignment, &mut variables);
    let rhs = canonicalize_term(&pair.rhs, symbol_indices, assignment, &mut variables);
    let key = format!("{}->{}", encode_term(&lhs), encode_term(&rhs));
    let variable_bijection = variable_bijection(&variables);
    EncodedPair {
        key,
        pair: TermPair::new(lhs, rhs),
        original_group_index,
        original_pair_index,
        variable_bijection,
    }
}

fn canonicalize_term(
    term: &Term,
    symbol_indices: &BTreeMap<Symbol, usize>,
    assignment: &[usize],
    variables: &mut BTreeMap<Variable, usize>,
) -> Term {
    match term {
        Term::Var(variable) => {
            let next = variables.len();
            let index = *variables.entry(variable.clone()).or_insert(next);
            Term::var(canonical_variable_name(index))
        }
        Term::App { symbol, args } => {
            let original_index = symbol_indices[symbol];
            let canonical_index = assignment[original_index];
            Term::app(
                canonical_symbol_name(canonical_index),
                args.iter()
                    .map(|arg| canonicalize_term(arg, symbol_indices, assignment, variables))
                    .collect(),
            )
        }
    }
}

fn variable_bijection(variables: &BTreeMap<Variable, usize>) -> BTreeMap<Variable, Variable> {
    variables
        .iter()
        .map(|(variable, index)| {
            (
                variable.clone(),
                Variable::new(canonical_variable_name(*index)),
            )
        })
        .collect()
}

fn invert_variable_bijection(
    bijection: &BTreeMap<Variable, Variable>,
) -> BTreeMap<Variable, Variable> {
    bijection
        .iter()
        .map(|(original, canonical)| (canonical.clone(), original.clone()))
        .collect()
}

fn renumber_symbols_by_first_occurrence(
    problem: &StandardizationProblem,
) -> (StandardizationProblem, BTreeMap<Symbol, Symbol>) {
    let mut symbols = BTreeMap::new();
    let groups = problem
        .groups
        .iter()
        .map(|group| StandardizationGroup {
            label: group.label.clone(),
            pairs: group
                .pairs
                .iter()
                .map(|pair| {
                    let lhs = renumber_term_symbols(&pair.lhs, &mut symbols);
                    let rhs = renumber_term_symbols(&pair.rhs, &mut symbols);
                    TermPair::new(lhs, rhs)
                })
                .collect(),
        })
        .collect();
    let bijection = symbols
        .into_iter()
        .map(|(symbol, index)| (symbol, Symbol::new(canonical_symbol_name(index))))
        .collect();
    (StandardizationProblem::new(groups), bijection)
}

fn renumber_term_symbols(term: &Term, symbols: &mut BTreeMap<Symbol, usize>) -> Term {
    match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } => {
            let next = symbols.len();
            let index = *symbols.entry(symbol.clone()).or_insert(next);
            Term::app(
                canonical_symbol_name(index),
                args.iter()
                    .map(|arg| renumber_term_symbols(arg, symbols))
                    .collect(),
            )
        }
    }
}

fn assignment_bijection(symbols: &[Symbol], assignment: &[usize]) -> BTreeMap<Symbol, Symbol> {
    symbols
        .iter()
        .cloned()
        .zip(assignment.iter().copied())
        .map(|(symbol, index)| (symbol, Symbol::new(canonical_symbol_name(index))))
        .collect()
}

fn compose_bijections(
    first: &BTreeMap<Symbol, Symbol>,
    second: &BTreeMap<Symbol, Symbol>,
) -> BTreeMap<Symbol, Symbol> {
    first
        .iter()
        .map(|(original, intermediate)| {
            (
                original.clone(),
                second
                    .get(intermediate)
                    .cloned()
                    .unwrap_or_else(|| intermediate.clone()),
            )
        })
        .collect()
}

fn invert_bijection(bijection: &BTreeMap<Symbol, Symbol>) -> BTreeMap<Symbol, Symbol> {
    bijection
        .iter()
        .map(|(original, canonical)| (canonical.clone(), original.clone()))
        .collect()
}

pub fn translate_term_symbols(term: &Term, bijection: &BTreeMap<Symbol, Symbol>) -> Term {
    translate_term(term, bijection, &BTreeMap::new())
}

pub fn translate_term(
    term: &Term,
    function_bijection: &BTreeMap<Symbol, Symbol>,
    variable_bijection: &BTreeMap<Variable, Variable>,
) -> Term {
    match term {
        Term::Var(variable) => Term::Var(
            variable_bijection
                .get(variable)
                .cloned()
                .unwrap_or_else(|| variable.clone()),
        ),
        Term::App { symbol, args } => Term::app(
            function_bijection
                .get(symbol)
                .unwrap_or(symbol)
                .as_str()
                .to_string(),
            args.iter()
                .map(|arg| translate_term(arg, function_bijection, variable_bijection))
                .collect(),
        ),
    }
}

pub fn translate_rule_symbols(
    rule: &RewriteRule,
    bijection: &BTreeMap<Symbol, Symbol>,
) -> RewriteRule {
    RewriteRule::new(
        translate_term_symbols(rule.lhs(), bijection),
        translate_term_symbols(rule.rhs(), bijection),
    )
}

pub fn translate_pair_symbols(pair: &TermPair, bijection: &BTreeMap<Symbol, Symbol>) -> TermPair {
    TermPair::new(
        translate_term_symbols(&pair.lhs, bijection),
        translate_term_symbols(&pair.rhs, bijection),
    )
}

pub fn translate_rule(
    rule: &RewriteRule,
    function_bijection: &BTreeMap<Symbol, Symbol>,
    variable_bijection: &BTreeMap<Variable, Variable>,
) -> RewriteRule {
    RewriteRule::new(
        translate_term(rule.lhs(), function_bijection, variable_bijection),
        translate_term(rule.rhs(), function_bijection, variable_bijection),
    )
}

pub fn translate_pair(
    pair: &TermPair,
    function_bijection: &BTreeMap<Symbol, Symbol>,
    variable_bijection: &BTreeMap<Variable, Variable>,
) -> TermPair {
    TermPair::new(
        translate_term(&pair.lhs, function_bijection, variable_bijection),
        translate_term(&pair.rhs, function_bijection, variable_bijection),
    )
}

fn encode_term(term: &Term) -> String {
    match term {
        Term::Var(variable) => format!("V{}", variable.as_str()),
        Term::App { symbol, args } => {
            let mut encoded = format!("F{}#{}", symbol.as_str(), args.len());
            if !args.is_empty() {
                encoded.push('(');
                for (index, arg) in args.iter().enumerate() {
                    if index > 0 {
                        encoded.push(',');
                    }
                    encoded.push_str(&encode_term(arg));
                }
                encoded.push(')');
            }
            encoded
        }
    }
}

fn collect_problem_symbols(problem: &StandardizationProblem) -> Vec<Symbol> {
    let mut symbols = BTreeSet::new();
    for group in &problem.groups {
        for pair in &group.pairs {
            collect_term_symbols(&pair.lhs, &mut symbols);
            collect_term_symbols(&pair.rhs, &mut symbols);
        }
    }
    symbols.into_iter().collect()
}

fn collect_term_symbols(term: &Term, symbols: &mut BTreeSet<Symbol>) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            symbols.insert(symbol.clone());
            for arg in args {
                collect_term_symbols(arg, symbols);
            }
        }
    }
}

fn canonical_symbol_name(index: usize) -> String {
    alphabetic_name(index, b'a')
}

fn canonical_variable_name(index: usize) -> String {
    match index {
        0 => "x".to_string(),
        1 => "y".to_string(),
        2 => "z".to_string(),
        index => format!("x{}", index - 2),
    }
}

fn alphabetic_name(mut index: usize, base: u8) -> String {
    let mut bytes = Vec::new();
    loop {
        bytes.push(base + (index % 26) as u8);
        index /= 26;
        if index == 0 {
            break;
        }
        index -= 1;
    }
    bytes.reverse();
    String::from_utf8(bytes).expect("generated ASCII name")
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::RewriteStrategy;

    use super::*;

    fn coupled_symbols(count: usize, renamed: bool) -> StandardizationProblem {
        let mut pairs = Vec::new();
        for i in 0..count {
            let (f, g) = if renamed {
                (format!("z{}", count - i), format!("a{}", count - i))
            } else {
                (format!("f{i}"), format!("g{i}"))
            };
            let x = Term::var(if renamed { "other" } else { "x" });
            pairs.push(TermPair::new(
                Term::app(f, vec![x.clone()]),
                Term::app(g.clone(), vec![x.clone()]),
            ));
            pairs.push(TermPair::new(Term::app(g, vec![x.clone()]), x));
        }
        if renamed {
            pairs.reverse();
        }
        StandardizationProblem::new(vec![StandardizationGroup::new("rules", pairs)])
    }

    #[test]
    fn coordinated_symmetries_preserve_exhaustive_canonical_key() {
        for count in 2..=5 {
            let problem = coupled_symbols(count, false);
            let symbols = collect_problem_symbols(&problem);
            let indices = symbols
                .iter()
                .cloned()
                .enumerate()
                .map(|(i, s)| (s, i))
                .collect();
            let colors = vec![0; symbols.len()]; // All symbols are unary.
            let mut reference = None;
            search_refined_assignments(
                &problem,
                &symbols,
                &indices,
                colors.clone(),
                &mut reference,
                &mut CanonicalSearchStats::default(),
            );
            let mut optimized = None;
            let mut stats = CanonicalSearchStats {
                use_automorphisms: true,
                ..Default::default()
            };
            search_refined_assignments(
                &problem,
                &symbols,
                &indices,
                colors,
                &mut optimized,
                &mut stats,
            );
            assert_eq!(reference.unwrap().key, optimized.unwrap().key);
            assert!(!stats.automorphisms.is_empty());
        }
    }

    #[test]
    fn large_coordinated_symmetries_ignore_names_and_rule_order() {
        assert_eq!(
            standardize_problem(&coupled_symbols(12, false)).unwrap(),
            standardize_problem(&coupled_symbols(12, true)).unwrap()
        );
    }

    #[test]
    fn orbit_pruning_must_fix_individualized_colors() {
        let permutations = vec![vec![1, 0, 3, 2]];
        assert!(same_known_orbit(0, &[1], &[0, 0, 1, 1], &permutations));
        assert!(!same_known_orbit(0, &[1], &[0, 0, 1, 2], &permutations));
    }

    #[test]
    fn symmetric_palindrome_inputs_canonicalize_under_renaming() {
        fn rename(term: &Term, names: &BTreeMap<Symbol, usize>) -> Term {
            match term {
                Term::Var(v) => Term::var(format!("renamed_{v}")),
                Term::App { symbol, args } => Term::app(
                    format!("renamed_{}", names.len() - names[symbol]),
                    args.iter().map(|t| rename(t, names)).collect(),
                ),
            }
        }
        for cpf in [
            include_str!("../tests/fixtures/palindrome_symmetric_residual.cpf"),
            include_str!("../tests/fixtures/palindrome_symmetric_root.cpf"),
        ] {
            let crate::parsing::CpfInputProblem::Trs(trs) =
                crate::parsing::parse_cpf_input(None, cpf).unwrap()
            else {
                panic!("expected TRS input")
            };
            let problem = StandardizationProblem::new(vec![StandardizationGroup::new(
                "rules",
                trs.rules().iter().map(TermPair::from_rule).collect(),
            )]);
            let names = collect_problem_symbols(&problem)
                .into_iter()
                .enumerate()
                .map(|(i, s)| (s, i))
                .collect();
            let renamed = StandardizationProblem::new(vec![StandardizationGroup::new(
                "rules",
                problem.groups[0]
                    .pairs
                    .iter()
                    .rev()
                    .map(|p| TermPair::new(rename(&p.lhs, &names), rename(&p.rhs, &names)))
                    .collect(),
            )]);
            assert_eq!(
                standardize_problem(&problem).unwrap(),
                standardize_problem(&renamed).unwrap()
            );
        }
    }

    #[test]
    fn standardizes_trs_independent_of_rule_symbol_and_variable_names() {
        let left = Trs::new(
            None,
            BTreeSet::from([Variable::new("u"), Variable::new("v")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("u")]),
                    Term::app("g", vec![Term::var("u")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("v")]),
                    Term::app("h", vec![Term::var("v")]),
                ),
            ],
        );
        let right = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("r", vec![Term::var("y")]),
                    Term::app("s", vec![Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("q", vec![Term::var("x")]),
                    Term::app("r", vec![Term::var("x")]),
                ),
            ],
        );

        let left_standardized = standardize_trs_with_bijection(&left).unwrap();
        let right_standardized = standardize_trs_with_bijection(&right).unwrap();

        assert_eq!(left_standardized.trs, right_standardized.trs);
        assert_eq!(left_standardized.function_bijection.len(), 3);
        for original in ["f", "g", "h"] {
            let canonical = left_standardized
                .function_bijection
                .get(&Symbol::new(original))
                .expect("canonical symbol");
            assert_eq!(
                left_standardized.inverse_function_bijection.get(canonical),
                Some(&Symbol::new(original))
            );
        }
    }

    #[test]
    fn standardizes_variables_locally_per_pair() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("a"), Variable::new("b")]),
            vec![
                RewriteRule::new(Term::app("f", vec![Term::var("a")]), Term::var("a")),
                RewriteRule::new(Term::app("f", vec![Term::var("b")]), Term::var("b")),
            ],
        );

        let standardized = standardize_trs(&trs).unwrap();
        assert_eq!(standardized.rules()[0].to_string(), "a(x) -> x");
        assert_eq!(standardized.rules()[1].to_string(), "a(x) -> x");
    }

    #[test]
    fn inverse_bijection_translates_canonical_symbols_back_to_input_symbols() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("u")]),
            vec![RewriteRule::new(
                Term::app("foo", vec![Term::var("u")]),
                Term::app("bar", vec![Term::var("u")]),
            )],
        );

        let standardized = standardize_trs_with_bijection(&trs).unwrap();
        let canonical_rule = standardized.trs.rules()[0].clone();
        let concrete_rule =
            translate_rule_symbols(&canonical_rule, &standardized.inverse_function_bijection);

        assert_eq!(canonical_rule.to_string(), "a(x) -> b(x)");
        assert_eq!(concrete_rule.to_string(), "foo(x) -> bar(x)");
    }

    #[test]
    fn metadata_tracks_rule_origin_and_variable_bijections() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("u"), Variable::new("v")]),
            vec![
                RewriteRule::new(
                    Term::app("g", vec![Term::var("v"), Term::var("u")]),
                    Term::app("f", vec![Term::var("u")]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("u")]),
                    Term::app("g", vec![Term::var("u"), Term::var("v")]),
                ),
            ],
        );

        let standardized = standardize_trs_with_bijection(&trs).unwrap();
        assert_eq!(standardized.rule_metadata.len(), 2);
        let metadata = standardized
            .rule_metadata
            .iter()
            .find(|metadata| metadata.original_pair_index == 0)
            .expect("metadata for original rule 0");
        assert_eq!(metadata.group_label, "rules");
        assert_eq!(metadata.original_group_index, 0);
        assert_eq!(
            metadata
                .variable_bijection
                .get(&Variable::new("v"))
                .map(Variable::as_str),
            Some("x")
        );
        assert_eq!(
            metadata
                .variable_bijection
                .get(&Variable::new("u"))
                .map(Variable::as_str),
            Some("y")
        );

        let canonical_rule = standardized.trs.rules()[metadata.canonical_pair_index].clone();
        let concrete_rule = translate_rule(
            &canonical_rule,
            &standardized.inverse_function_bijection,
            &metadata.inverse_variable_bijection,
        );
        assert_eq!(concrete_rule, trs.rules()[0]);
    }

    #[test]
    fn rule_metadata_round_trips_all_original_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("u"), Variable::new("v"), Variable::new("w")]),
            vec![
                RewriteRule::new(
                    Term::app("h", vec![Term::var("w")]),
                    Term::app("f", vec![Term::var("w")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("v"), Term::var("u")]),
                    Term::app("h", vec![Term::var("u")]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("u")]),
                    Term::app("g", vec![Term::var("u"), Term::var("v")]),
                ),
            ],
        );

        let standardized = standardize_trs_with_bijection(&trs).unwrap();
        for metadata in &standardized.rule_metadata {
            let canonical_rule = &standardized.trs.rules()[metadata.canonical_pair_index];
            let recovered = translate_rule(
                canonical_rule,
                &standardized.inverse_function_bijection,
                &metadata.inverse_variable_bijection,
            );
            assert_eq!(recovered, trs.rules()[metadata.original_pair_index]);
        }
    }

    #[test]
    fn standardizes_grouped_qdp_style_inputs() {
        let first = StandardizationProblem::new(vec![
            StandardizationGroup::new(
                "rules",
                vec![TermPair::new(
                    Term::app("f", vec![Term::var("u")]),
                    Term::app("g", vec![Term::var("u")]),
                )],
            ),
            StandardizationGroup::new(
                "dps",
                vec![TermPair::new(
                    Term::app("f#", vec![Term::var("v")]),
                    Term::app("g#", vec![Term::var("v")]),
                )],
            ),
        ]);
        let second = StandardizationProblem::new(vec![
            StandardizationGroup::new(
                "dps",
                vec![TermPair::new(
                    Term::app("q#", vec![Term::var("x")]),
                    Term::app("r#", vec![Term::var("x")]),
                )],
            ),
            StandardizationGroup::new(
                "rules",
                vec![TermPair::new(
                    Term::app("q", vec![Term::var("y")]),
                    Term::app("r", vec![Term::var("y")]),
                )],
            ),
        ]);

        let standardized_first = standardize_problem_with_bijection(&first).unwrap();
        let standardized_second = standardize_problem_with_bijection(&second).unwrap();

        assert_eq!(standardized_first.problem, standardized_second.problem);
        assert_eq!(standardized_first.function_bijection.len(), 4);
        assert!(
            standardized_first
                .function_bijection
                .contains_key(&Symbol::new("f"))
        );
        assert!(
            standardized_first
                .function_bijection
                .contains_key(&Symbol::new("f#"))
        );
    }

    #[test]
    fn qdp_metadata_round_trips_all_original_pairs() {
        let problem = StandardizationProblem::new(vec![
            StandardizationGroup::new(
                "rules",
                vec![
                    TermPair::new(
                        Term::app("f", vec![Term::var("u")]),
                        Term::app("g", vec![Term::var("u")]),
                    ),
                    TermPair::new(
                        Term::app("g", vec![Term::var("v"), Term::var("u")]),
                        Term::app("h", vec![Term::var("u")]),
                    ),
                ],
            ),
            StandardizationGroup::new(
                "dps",
                vec![
                    TermPair::new(
                        Term::app("f#", vec![Term::var("p")]),
                        Term::app("g#", vec![Term::var("p"), Term::var("q")]),
                    ),
                    TermPair::new(
                        Term::app("g#", vec![Term::var("r"), Term::var("s")]),
                        Term::app("h#", vec![Term::var("s")]),
                    ),
                ],
            ),
        ]);

        let standardized = standardize_problem_with_bijection(&problem).unwrap();
        assert_eq!(standardized.pair_metadata.len(), 4);
        for metadata in &standardized.pair_metadata {
            let canonical_pair = &standardized.problem.groups[metadata.canonical_group_index].pairs
                [metadata.canonical_pair_index];
            let recovered = translate_pair(
                canonical_pair,
                &standardized.inverse_function_bijection,
                &metadata.inverse_variable_bijection,
            );
            assert_eq!(
                recovered,
                problem.groups[metadata.original_group_index].pairs[metadata.original_pair_index]
            );
        }
    }

    #[test]
    fn structurally_standardizes_large_symbol_sets() {
        let rules = (0..3)
            .map(|index| {
                RewriteRule::new(
                    Term::app(format!("f{index}"), Vec::new()),
                    Term::app(format!("g{index}"), Vec::new()),
                )
            })
            .collect::<Vec<_>>();
        let trs = Trs::new_with_strategy(None, BTreeSet::new(), rules, RewriteStrategy::Full);
        let standardized = standardize_trs_with_bijection_and_options(
            &trs,
            &StandardizationOptions {
                max_exact_symbols: 2,
            },
        )
        .unwrap();

        assert_eq!(standardized.trs.rules().len(), 3);
        for metadata in &standardized.rule_metadata {
            let canonical_rule = &standardized.trs.rules()[metadata.canonical_pair_index];
            let recovered = translate_rule(
                canonical_rule,
                &standardized.inverse_function_bijection,
                &metadata.inverse_variable_bijection,
            );
            assert_eq!(recovered, trs.rules()[metadata.original_pair_index]);
        }
    }

    #[test]
    fn refinement_exactly_canonicalizes_large_renamed_symbol_sets() {
        fn chain(names: &[String], cycle: bool) -> Trs {
            let mut rules = names
                .windows(2)
                .map(|symbols| {
                    RewriteRule::new(
                        Term::app(&symbols[0], vec![Term::var("x")]),
                        Term::app(&symbols[1], vec![Term::var("x")]),
                    )
                })
                .collect::<Vec<_>>();
            if cycle {
                rules.push(RewriteRule::new(
                    Term::app(names.last().unwrap(), vec![Term::var("x")]),
                    Term::app(&names[0], vec![Term::var("x")]),
                ));
            }
            Trs::new(None, BTreeSet::from([Variable::new("x")]), rules)
        }

        let left_names = (0..12).map(|index| format!("f{index}")).collect::<Vec<_>>();
        let right_names = (0..12)
            .map(|index| format!("renamed{}", (index * 5) % 12))
            .collect::<Vec<_>>();
        let options = StandardizationOptions {
            max_exact_symbols: 2,
        };
        let left = standardize_trs_with_bijection_and_options(&chain(&left_names, false), &options)
            .unwrap();
        let right =
            standardize_trs_with_bijection_and_options(&chain(&right_names, false), &options)
                .unwrap();
        let cycle =
            standardize_trs_with_bijection_and_options(&chain(&right_names, true), &options)
                .unwrap();

        assert_eq!(left.trs, right.trs);
        assert_ne!(left.trs, cycle.trs);
    }
}
