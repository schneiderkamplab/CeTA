use std::collections::{BTreeMap, BTreeSet};

use roxmltree::{Document, Node};

use crate::core::{
    CsrTrs, RelativeTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable,
};

use super::ParseError;

#[derive(Clone, Debug)]
pub enum CpfInputProblem {
    Trs(Trs),
    Relative(RelativeTrs),
    Csr {
        csr: CsrTrs,
        boundary: crate::proving::CsrProofBoundary,
    },
    Dp {
        trs: Trs,
        pairs: Vec<RewriteRule>,
        pair_source_rules: Option<Vec<usize>>,
        weak_pairs: Vec<RewriteRule>,
        weak_pair_source_rules: Option<Vec<usize>>,
        strict_rules: Vec<RewriteRule>,
        active_rules: Option<Vec<RewriteRule>>,
        minimal: bool,
        normal_form_substitutions: bool,
        innermost_lhss: Option<Vec<Term>>,
        clear_innermost_lhss: bool,
        graph_rules: Option<Vec<RewriteRule>>,
        transformation_rules: Option<Vec<RewriteRule>>,
        active_rules_are_residual: bool,
        ordinary_reduction_started: bool,
        ordinary_bridge_loses_minimality: bool,
    },
    CsrDp {
        csr: CsrTrs,
        pairs: Vec<RewriteRule>,
        pair_source_rules: Option<Vec<usize>>,
        weak_pairs: Vec<RewriteRule>,
        weak_pair_source_rules: Option<Vec<usize>>,
        strict_rules: Vec<RewriteRule>,
        active_rules: Option<Vec<RewriteRule>>,
        minimal: bool,
        construction: String,
        graph_estimator: String,
        use_qcs_usable_rules: bool,
        innermost_lhss: Option<Vec<Term>>,
        clear_innermost_lhss: bool,
        graph_rules: Option<Vec<RewriteRule>>,
        transformation_rules: Option<Vec<RewriteRule>>,
        active_rules_are_residual: bool,
        ordinary_reduction_started: bool,
        ordinary_bridge_loses_minimality: bool,
        semantic_csr_continuation: bool,
    },
}

pub fn parse_cpf_input(
    source_name: Option<String>,
    input: &str,
) -> Result<CpfInputProblem, ParseError> {
    let document = Document::parse(input)
        .map_err(|error| ParseError::Unsupported(format!("invalid CPF XML: {error}")))?;
    let root = document.root_element();
    let problem = if matches!(local_name(root), "trsInput" | "dpInput" | "relativeDpInput") {
        root
    } else {
        root.descendants()
            .find(|node| node.is_element() && matches!(local_name(*node), "trsInput" | "dpInput" | "relativeDpInput"))
            .ok_or_else(|| {
                ParseError::Unsupported("CPF contains neither trsInput nor dpInput".to_string())
            })?
    };
    let strategy = if problem
        .descendants()
        .any(|node| node.is_element() && local_name(node) == "outermost")
    {
        RewriteStrategy::Outermost
    } else if problem
        .descendants()
        .any(|node| node.is_element() && local_name(node) == "innermost")
    {
        RewriteStrategy::Innermost
    } else {
        RewriteStrategy::Full
    };
    let name = source_name;
    match local_name(problem) {
        "trsInput" => {
            let rules = parse_rule_container(required_child(problem, "trs")?)?;
            let trs = build_trs(name, rules, strategy);
            if let Some(context_sensitive) = problem
                .descendants()
                .find(|node| node.is_element() && local_name(*node) == "contextSensitive")
            {
                let replacement_map = parse_replacement_map(context_sensitive)?;
                let csr = CsrTrs::new(trs, replacement_map).map_err(|issues| {
                    ParseError::Unsupported(format!(
                        "invalid CPF context-sensitive replacement map: {}",
                        issues
                            .into_iter()
                            .map(|issue| issue.to_string())
                            .collect::<Vec<_>>()
                            .join("; ")
                    ))
                })?;
                let boundary = problem
                    .children()
                    .find(|node| node.is_element() && local_name(*node) == "ferrumCsrBoundary")
                    .and_then(|node| node.text())
                    .map(|value| match value.trim() {
                        "root-rule-removal-continuation" => {
                            crate::proving::CsrProofBoundary::RootRuleRemovalContinuation
                        }
                        "nested" => crate::proving::CsrProofBoundary::Nested,
                        _ => crate::proving::CsrProofBoundary::Root,
                    })
                    .unwrap_or(crate::proving::CsrProofBoundary::Root);
                Ok(CpfInputProblem::Csr { csr, boundary })
            } else if let Some(relative_rules) = problem
                .children()
                .find(|node| node.is_element() && local_name(*node) == "relativeRules")
            {
                let weak_rules = parse_rule_container(relative_rules)?;
                Ok(CpfInputProblem::Relative(RelativeTrs::new(trs, weak_rules)))
            } else {
                Ok(CpfInputProblem::Trs(trs))
            }
        }
        "dpInput" | "relativeDpInput" => {
            let rules = parse_rule_container(required_child(problem, "trs")?)?;
            let mut pairs = parse_rule_container(required_child(problem, "dps")?)?;
            let mut weak_pairs = problem
                .children()
                .find(|node| node.is_element() && matches!(local_name(*node), "ferrumWeakDps" | "weakDps"))
                .map(parse_rule_container)
                .transpose()?
                .unwrap_or_default();
            if local_name(problem) == "relativeDpInput" {
                // CPF separates strict and weak pairs; the runtime worklist
                // stores their union and marks the weak subset explicitly.
                if weak_pairs.iter().any(|weak| pairs.contains(weak)) {
                    return Err(ParseError::Unsupported(
                        "overlapping strict/weak CPF pairs require distinct runtime roles".into(),
                    ));
                }
                pairs.extend(weak_pairs.iter().cloned());
            }
            let mut trs = build_trs(name, rules, strategy);
            let mut active_rules = problem
                .children()
                .find(|node| node.is_element() && local_name(*node) == "usableRules")
                .map(parse_rule_container)
                .transpose()?;
            let minimal = problem
                .children()
                .find(|node| node.is_element() && local_name(*node) == "minimal")
                .and_then(|node| node.text())
                .is_some_and(|value| value.trim().eq_ignore_ascii_case("true"));
            let normal_form_substitutions = problem
                .descendants()
                .find(|node| node.is_element() && local_name(*node) == "nfs")
                .and_then(|node| node.text())
                .is_some_and(|value| value.trim().eq_ignore_ascii_case("true"));
            let runtime_context = problem
                .children()
                .find(|node| node.is_element() && local_name(*node) == "ferrumDpStateContext");
            let strict_rules = runtime_context
                .and_then(|context| {
                    context
                        .children()
                        .find(|node| node.is_element() && local_name(*node) == "strictRules")
                })
                .or_else(|| problem.children().find(|node| node.is_element()
                    && local_name(*node) == "strictRules"))
                .map(parse_rule_container)
                .transpose()?
                .unwrap_or_default();
            if local_name(problem) == "relativeDpInput" {
                if strict_rules.iter().any(|strict| trs.rules().iter().any(|weak|
                    crate::proving::alpha_equivalent_rules(strict, weak))) {
                    return Err(ParseError::Unsupported(
                        "overlapping strict/weak CPF rules require distinct runtime roles".into()));
                }
                // CPF stores strict R and weak Rw separately. Runtime
                // processors consume their union and the strict subset.
                let mut all_rules = trs.rules().to_vec();
                all_rules.extend(strict_rules.iter().cloned());
                trs = build_trs(trs.name().map(str::to_owned), all_rules, strategy);
                if let Some(active) = &mut active_rules {
                    for rule in &strict_rules {
                        if !active.contains(rule) { active.push(rule.clone()); }
                    }
                }
            }
            let parse_source_rules = |container_name: &str| {
                runtime_context
                    .and_then(|context| {
                        context
                            .children()
                            .find(|node| node.is_element() && local_name(*node) == container_name)
                    })
                    .map(|container| {
                        container
                            .children()
                            .filter(|node| node.is_element() && local_name(*node) == "sourceRule")
                            .map(|node| {
                                node.text()
                                    .ok_or_else(|| {
                                        ParseError::Unsupported(
                                            "empty DP source-rule provenance".to_string(),
                                        )
                                    })?
                                    .trim()
                                    .parse::<usize>()
                                    .map_err(|_| {
                                        ParseError::Unsupported(
                                            "invalid DP source-rule provenance".to_string(),
                                        )
                                    })
                            })
                            .collect::<Result<Vec<_>, _>>()
                    })
                    .transpose()
            };
            let pair_source_rules = parse_source_rules("pairSourceRules")?;
            let weak_pair_source_rules = parse_source_rules("weakPairSourceRules")?;
            let runtime_innermost_lhss = runtime_context
                .and_then(|context| {
                    context
                        .children()
                        .find(|node| node.is_element() && local_name(*node) == "innermostLhss")
                })
                .map(|container| {
                    container
                        .children()
                        .filter(|node| node.is_element())
                        .map(parse_term)
                        .collect::<Result<Vec<_>, _>>()
                })
                .transpose()?;
            let strategy_innermost_lhss = problem
                .children()
                .find(|node| node.is_element() && local_name(*node) == "strategy")
                .and_then(|strategy| {
                    strategy
                        .children()
                        .find(|node| node.is_element() && local_name(*node) == "innermostLhss")
                })
                .map(|container| {
                    container
                        .children()
                        .filter(|node| node.is_element() && local_name(*node) != "nfs")
                        .map(parse_term)
                        .collect::<Result<Vec<_>, _>>()
                })
                .transpose()?;
            let mut innermost_lhss = runtime_innermost_lhss.or(strategy_innermost_lhss);
            let clear_innermost_lhss = runtime_context.is_some_and(|context| {
                context
                    .children()
                    .any(|node| node.is_element() && local_name(node) == "noInnermostLhss")
            });
            let mut graph_rules = runtime_context
                .and_then(|context| {
                    context
                        .children()
                        .find(|node| node.is_element() && local_name(*node) == "graphRules")
                })
                .map(parse_rule_container)
                .transpose()?;
            let mut transformation_rules = runtime_context
                .and_then(|context| {
                    context.children().find(|node| {
                        node.is_element() && local_name(*node) == "transformationRules"
                    })
                })
                .map(parse_rule_container)
                .transpose()?;
            let active_rules_are_residual = runtime_context
                .and_then(|context| {
                    context.children().find(|node| {
                        node.is_element() && local_name(*node) == "activeRulesAreResidual"
                    })
                })
                .and_then(|node| node.text())
                .is_some_and(|value| value.trim().eq_ignore_ascii_case("true"));
            let ordinary_reduction_started = runtime_context
                .and_then(|context| {
                    context.children().find(|node| {
                        node.is_element() && local_name(*node) == "ordinaryReductionStarted"
                    })
                })
                .and_then(|node| node.text())
                .is_some_and(|value| value.trim().eq_ignore_ascii_case("true"));
            let ordinary_bridge_loses_minimality = runtime_context
                .and_then(|context| {
                    context.children().find(|node| {
                        node.is_element() && local_name(*node) == "ordinaryBridgeLosesMinimality"
                    })
                })
                .and_then(|node| node.text())
                .is_some_and(|value| value.trim().eq_ignore_ascii_case("true"));
            let runtime_innermost_strategy = runtime_context
                .and_then(|context| {
                    context
                        .children()
                        .find(|node| node.is_element() && local_name(*node) == "rewriteStrategy")
                })
                .and_then(|node| node.text())
                .is_some_and(|value| value.trim().eq_ignore_ascii_case("innermost"));
            if runtime_innermost_strategy && trs.strategy() != RewriteStrategy::Innermost {
                trs = Trs::new_with_strategy(
                    trs.name().map(str::to_owned),
                    trs.variables().clone(),
                    trs.rules().to_vec(),
                    RewriteStrategy::Innermost,
                );
            }
            if let Some(context_sensitive) = problem
                .descendants()
                .find(|node| node.is_element() && local_name(*node) == "contextSensitive")
            {
                let construction =
                    optional_nested_text(problem, "ferrumCsrDpContext", "construction")
                        .unwrap_or_else(|| "native".to_string());
                let mut replacement_map = parse_replacement_map(context_sensitive)?;
                let mut frozen_auxiliary = None;
                if construction == "improved" {
                    if let Some(alias) = frozen_unhiding_alias(
                        context_sensitive,
                        &trs,
                        &replacement_map,
                        &pairs,
                        &weak_pairs,
                    )? {
                        let fresh = fresh_csr_unhiding_symbol(&trs);
                        frozen_auxiliary = Some(fresh.clone());
                        let bijection = BTreeMap::from([(alias.clone(), fresh)]);
                        translate_dp_runtime_symbols(
                            &mut pairs,
                            &mut weak_pairs,
                            &mut active_rules,
                            &mut innermost_lhss,
                            &mut graph_rules,
                            &mut transformation_rules,
                            &bijection,
                        );
                        replacement_map = ReplacementMap::new(
                            replacement_map
                                .entries()
                                .iter()
                                .filter(|(symbol, _)| *symbol != &alias)
                                .map(|(symbol, positions)| (symbol.clone(), positions.clone()))
                                .collect(),
                        );
                    }
                }
                let marked_aliases = marked_dp_aliases(
                    &trs,
                    &pairs,
                    pair_source_rules.as_deref(),
                    &weak_pairs,
                    weak_pair_source_rules.as_deref(),
                )?;
                translate_dp_marked_roots(&mut pairs, &marked_aliases);
                translate_dp_marked_roots(&mut weak_pairs, &marked_aliases);
                let csr = CsrTrs::new(trs, replacement_map).map_err(|issues| {
                    ParseError::Unsupported(format!(
                        "invalid CPF context-sensitive DP replacement map: {}",
                        issues
                            .into_iter()
                            .map(|issue| issue.to_string())
                            .collect::<Vec<_>>()
                            .join("; ")
                    ))
                })?;
                let csr = frozen_auxiliary.map_or_else(|| csr.clone(), |symbol| {
                    csr.clone().with_frozen_auxiliary_symbol(symbol)
                });
                Ok(CpfInputProblem::CsrDp {
                    csr,
                    pairs,
                    pair_source_rules,
                    weak_pairs,
                    weak_pair_source_rules,
                    strict_rules,
                    active_rules,
                    minimal,
                    construction,
                    graph_estimator: optional_nested_text(
                        problem,
                        "ferrumCsrDpContext",
                        "graphEstimator",
                    )
                    .unwrap_or_else(|| "context-sensitive".to_string()),
                    use_qcs_usable_rules: optional_nested_text(
                        problem,
                        "ferrumCsrDpContext",
                        "qcsUsableRules",
                    )
                    .is_some_and(|value| value.eq_ignore_ascii_case("true")),
                    innermost_lhss,
                    clear_innermost_lhss,
                    graph_rules,
                    transformation_rules,
                    active_rules_are_residual,
                    ordinary_reduction_started,
                    ordinary_bridge_loses_minimality,
                    semantic_csr_continuation: optional_nested_text(
                        problem,
                        "ferrumDpStateContext",
                        "semanticCsrContinuation",
                    )
                    .is_some_and(|value| value.eq_ignore_ascii_case("true")),
                })
            } else {
                Ok(CpfInputProblem::Dp {
                    trs,
                    pairs,
                    pair_source_rules,
                    weak_pairs,
                    weak_pair_source_rules,
                    strict_rules,
                    active_rules,
                    minimal,
                    normal_form_substitutions,
                    innermost_lhss,
                    clear_innermost_lhss,
                    graph_rules,
                    transformation_rules,
                    active_rules_are_residual,
                    ordinary_reduction_started,
                    ordinary_bridge_loses_minimality,
                })
            }
        }
        _ => unreachable!("problem node filtered above"),
    }
}

/// Parse a named CPF rule container from an otherwise self-contained proof
/// fragment.  Exact oracle processors use this to retain certified residual
/// contexts (notably the `usableRules` selected by `redPairUrProc`) instead of
/// recomputing a potentially different approximation.
pub(crate) fn parse_cpf_rule_container_fragment(
    input: &str,
    container_name: &str,
) -> Result<Option<Vec<RewriteRule>>, ParseError> {
    // Processor payloads are the children of the CPF processor node and can
    // therefore contain several sibling elements.  Give roxmltree the single
    // synthetic root required by XML without changing the payload itself.
    let wrapped = format!("<ferrumCpfFragment>{input}</ferrumCpfFragment>");
    let document = Document::parse(&wrapped)
        .map_err(|error| ParseError::Unsupported(format!("invalid CPF XML: {error}")))?;
    document
        .descendants()
        .find(|node| node.is_element() && local_name(*node) == container_name)
        .map(parse_rule_container)
        .transpose()
}

pub(crate) fn parse_cpf_term_container_fragment(
    input: &str,
    container_name: &str,
) -> Result<Option<Vec<Term>>, ParseError> {
    let wrapped = format!("<ferrumCpfFragment>{input}</ferrumCpfFragment>");
    let document = Document::parse(&wrapped)
        .map_err(|error| ParseError::Unsupported(format!("invalid CPF XML: {error}")))?;
    document
        .descendants()
        .find(|node| node.is_element() && local_name(*node) == container_name)
        .map(|container| {
            container
                .children()
                .filter(|node| node.is_element() && local_name(*node) != "nfs")
                .map(parse_term)
                .collect::<Result<Vec<_>, _>>()
        })
        .transpose()
}

fn optional_nested_text(node: Node<'_, '_>, parent_name: &str, child_name: &str) -> Option<String> {
    node.children()
        .find(|child| child.is_element() && local_name(*child) == parent_name)?
        .children()
        .find(|child| child.is_element() && local_name(*child) == child_name)?
        .text()
        .map(str::trim)
        .map(str::to_string)
}

fn parse_replacement_map(context_sensitive: Node<'_, '_>) -> Result<ReplacementMap, ParseError> {
    let mut entries = BTreeMap::new();
    for entry in context_sensitive
        .children()
        .filter(|node| node.is_element() && local_name(*node) == "replacementMapEntry")
    {
        let symbol_node = entry
            .children()
            .find(|node| {
                node.is_element() && matches!(local_name(*node), "name" | "sharp" | "labeledSymbol")
            })
            .ok_or_else(|| {
                ParseError::Unsupported(
                    "CPF replacement-map entry has no function symbol".to_string(),
                )
            })?;
        let symbol = Symbol::new(parse_symbol(symbol_node)?);
        let mut positions = BTreeSet::new();
        for position in entry
            .children()
            .filter(|node| node.is_element() && local_name(*node) == "position")
        {
            let raw = position.text().unwrap_or_default().trim();
            let parsed = raw.parse::<usize>().map_err(|_| {
                ParseError::Unsupported(format!("invalid CPF replacement-map position {raw:?}"))
            })?;
            let zero_based = parsed.checked_sub(1).ok_or_else(|| {
                ParseError::Unsupported(
                    "CPF replacement-map positions must be one-based".to_string(),
                )
            })?;
            positions.insert(zero_based);
        }
        if entries.insert(symbol.clone(), positions).is_some() {
            return Err(ParseError::Unsupported(format!(
                "duplicate CPF replacement-map entry for {symbol}"
            )));
        }
    }
    Ok(ReplacementMap::new(entries))
}

/// Recover the distinguished fresh wrapper from old canonical CSR-DP inputs.
///
/// Improved CS-DPs add one unary symbol which is absent from the source TRS
/// and frozen by the extended replacement map.  Older canonicalization renamed
/// that symbol like an ordinary function, leaving an otherwise invalid map
/// entry.  Accept only that exact, semantically redundant shape; all other
/// unknown replacement-map symbols remain errors in `CsrTrs::new`.
fn frozen_unhiding_alias(
    context_sensitive: Node<'_, '_>,
    trs: &Trs,
    replacement_map: &ReplacementMap,
    pairs: &[RewriteRule],
    weak_pairs: &[RewriteRule],
) -> Result<Option<Symbol>, ParseError> {
    let source_arities = trs.arities();
    let unknown = replacement_map
        .entries()
        .iter()
        .filter(|(symbol, _)| !source_arities.contains_key(*symbol))
        .collect::<Vec<_>>();
    if unknown.is_empty() {
        return Ok(None);
    }
    if unknown.len() != 1 {
        return Ok(None);
    }
    let (symbol, positions) = unknown[0];
    if !positions.is_empty() {
        return Ok(None);
    }
    let declared_unary = context_sensitive
        .children()
        .filter(|node| node.is_element() && local_name(*node) == "replacementMapEntry")
        .find(|entry| {
            entry.children().any(|node| {
                node.is_element()
                    && matches!(local_name(node), "name" | "sharp" | "labeledSymbol")
                    && parse_symbol(node).ok().as_deref() == Some(symbol.as_str())
            })
        })
        .and_then(|entry| {
            entry
                .children()
                .find(|node| node.is_element() && local_name(*node) == "arity")
        })
        .and_then(|arity| arity.text())
        .is_some_and(|arity| arity.trim() == "1");
    if !declared_unary {
        return Ok(None);
    }
    let mut occurrence_arities = BTreeSet::new();
    for rule in pairs.iter().chain(weak_pairs) {
        collect_symbol_arities(rule.lhs(), symbol, &mut occurrence_arities);
        collect_symbol_arities(rule.rhs(), symbol, &mut occurrence_arities);
    }
    if occurrence_arities != BTreeSet::from([1]) {
        return Err(ParseError::Unsupported(format!(
            "improved CSR-DP frozen wrapper {symbol} is not consistently unary"
        )));
    }
    Ok(Some(symbol.clone()))
}

fn collect_symbol_arities(term: &Term, symbol: &Symbol, arities: &mut BTreeSet<usize>) {
    if let Term::App {
        symbol: current,
        args,
    } = term
    {
        if current == symbol {
            arities.insert(args.len());
        }
        for argument in args {
            collect_symbol_arities(argument, symbol, arities);
        }
    }
}

fn fresh_csr_unhiding_symbol(trs: &Trs) -> Symbol {
    let arities = trs.arities();
    for index in 0usize.. {
        let candidate = Symbol::new(format!("__CSR_U{index}"));
        if !arities.contains_key(&candidate) {
            return candidate;
        }
    }
    unreachable!("the finite TRS signature cannot contain every fresh symbol")
}

/// Reconstruct marked-symbol identity in canonical CSR-DP inputs produced by
/// the older all-symbol renamer.  Pair provenance identifies the source rule,
/// hence the unique unmarked companion of every dependency-pair lhs root.
fn marked_dp_aliases(
    trs: &Trs,
    pairs: &[RewriteRule],
    pair_sources: Option<&[usize]>,
    weak_pairs: &[RewriteRule],
    weak_pair_sources: Option<&[usize]>,
) -> Result<BTreeMap<Symbol, Symbol>, ParseError> {
    let source_arities = trs.arities();
    let fresh_unhiding = fresh_csr_unhiding_symbol(trs);
    let mut aliases = BTreeMap::new();
    for (rules, sources) in [(pairs, pair_sources), (weak_pairs, weak_pair_sources)] {
        let Some(sources) = sources else {
            continue;
        };
        if sources.len() != rules.len() {
            return Err(ParseError::Unsupported(
                "CSR-DP pair provenance length does not match its pair set".to_string(),
            ));
        }
        for (pair, source) in rules.iter().zip(sources) {
            let Some(alias) = pair.lhs().root_symbol() else {
                continue;
            };
            // A semantic label may wrap a sharp symbol, in which case the
            // trailing marker is intentionally inside the byte encoding.
            // It is already a marked DP root and must not be "repaired" from
            // source provenance (whose index space can differ after semantic
            // labeling).
            let semantically_marked = crate::proving::semantic_label_unmarked_companion(alias).is_some();
            if alias == &fresh_unhiding || alias.as_str().ends_with('#') || semantically_marked {
                continue;
            }
            let source_rule = trs.rules().get(*source).ok_or_else(|| {
                ParseError::Unsupported(format!(
                    "CSR-DP source-rule provenance {source} is out of range"
                ))
            })?;
            let source_root = source_rule.lhs().root_symbol().ok_or_else(|| {
                ParseError::Unsupported(format!("CSR-DP source rule {source} has no function root"))
            })?;
            let pair_arity = match pair.lhs() {
                Term::App { args, .. } => args.len(),
                Term::Var(_) => 0,
            };
            // Native CSR-DP inputs can contain generated unhiding bridge
            // pairs whose lhs root is deliberately *unmarked* (for example
            // `p(x) -> p#(x)`).  Such a root is already a genuine symbol of
            // the source TRS and must not be interpreted as an alias created
            // by the legacy all-symbol marked-root encoding.  Besides making
            // the distinction syntactic and deterministic, checking the
            // source arity prevents a malformed bridge from bypassing the
            // provenance validation below.
            if source_arities.get(alias).copied() == Some(pair_arity) {
                continue;
            }
            if source_arities.get(source_root).copied() != Some(pair_arity) {
                return Err(ParseError::Unsupported(format!(
                    "CSR-DP marked alias {alias} has arity {pair_arity}, but source root {source_root} does not"
                )));
            }
            let marked = Symbol::new(format!("{source_root}#"));
            if aliases
                .insert(alias.clone(), marked.clone())
                .is_some_and(|previous| previous != marked)
            {
                return Err(ParseError::Unsupported(format!(
                    "CSR-DP marked alias {alias} has inconsistent source provenance"
                )));
            }
        }
    }
    Ok(aliases)
}

fn translate_dp_marked_roots(pairs: &mut Vec<RewriteRule>, aliases: &BTreeMap<Symbol, Symbol>) {
    if aliases.is_empty() {
        return;
    }
    let translate_root = |term: &Term| match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } => {
            Term::app(aliases.get(symbol).unwrap_or(symbol).as_str(), args.clone())
        }
    };
    *pairs = pairs
        .iter()
        .map(|pair| RewriteRule::new(translate_root(pair.lhs()), translate_root(pair.rhs())))
        .collect();
}

fn translate_dp_runtime_symbols(
    pairs: &mut Vec<RewriteRule>,
    weak_pairs: &mut Vec<RewriteRule>,
    active_rules: &mut Option<Vec<RewriteRule>>,
    innermost_lhss: &mut Option<Vec<Term>>,
    graph_rules: &mut Option<Vec<RewriteRule>>,
    transformation_rules: &mut Option<Vec<RewriteRule>>,
    bijection: &BTreeMap<Symbol, Symbol>,
) {
    if bijection.is_empty() {
        return;
    }
    let translate_rules = |rules: &[RewriteRule]| {
        rules
            .iter()
            .map(|rule| crate::standardize::translate_rule_symbols(rule, bijection))
            .collect::<Vec<_>>()
    };
    *pairs = translate_rules(pairs);
    *weak_pairs = translate_rules(weak_pairs);
    *active_rules = active_rules.as_deref().map(&translate_rules);
    *innermost_lhss = innermost_lhss.as_deref().map(|terms| {
        terms
            .iter()
            .map(|term| crate::standardize::translate_term_symbols(term, bijection))
            .collect()
    });
    *graph_rules = graph_rules.as_deref().map(&translate_rules);
    *transformation_rules = transformation_rules.as_deref().map(translate_rules);
}

fn build_trs(name: Option<String>, rules: Vec<RewriteRule>, strategy: RewriteStrategy) -> Trs {
    let variables = rules
        .iter()
        .flat_map(|rule| {
            rule.lhs()
                .variables()
                .into_iter()
                .chain(rule.rhs().variables())
        })
        .collect::<BTreeSet<_>>();
    Trs::new_with_strategy(name, variables, rules, strategy)
}

fn parse_rule_container(container: Node<'_, '_>) -> Result<Vec<RewriteRule>, ParseError> {
    let rules = if local_name(container) == "rules" {
        container
    } else {
        required_child(container, "rules")?
    };
    rules
        .children()
        .filter(|node| node.is_element() && local_name(*node) == "rule")
        .map(parse_rule)
        .collect()
}

fn parse_rule(rule: Node<'_, '_>) -> Result<RewriteRule, ParseError> {
    let terms = rule
        .children()
        .filter(|node| node.is_element())
        .collect::<Vec<_>>();
    if terms.len() != 2 {
        return Err(ParseError::Unsupported(format!(
            "CPF rule has {} terms instead of two",
            terms.len()
        )));
    }
    Ok(RewriteRule::new(
        parse_term(terms[0])?,
        parse_term(terms[1])?,
    ))
}

fn parse_term(node: Node<'_, '_>) -> Result<Term, ParseError> {
    match local_name(node) {
        "var" => Ok(Term::Var(Variable::new(node.text().unwrap_or_default()))),
        "funapp" => {
            let mut children = node.children().filter(|child| child.is_element());
            let symbol = children
                .next()
                .ok_or_else(|| ParseError::Unsupported("CPF funapp has no symbol".to_string()))?;
            let symbol = parse_symbol(symbol)?;
            let arguments = children.map(parse_term).collect::<Result<Vec<_>, _>>()?;
            Ok(Term::app(symbol, arguments))
        }
        name => Err(ParseError::Unsupported(format!(
            "unsupported CPF term element {name}"
        ))),
    }
}

fn parse_symbol(node: Node<'_, '_>) -> Result<String, ParseError> {
    match local_name(node) {
        "name" => Ok(node.text().unwrap_or_default().to_string()),
        "sharp" => {
            let base_node = node
                .children()
                .find(|child| {
                    child.is_element()
                        && matches!(local_name(*child), "name" | "sharp" | "labeledSymbol")
                })
                .ok_or_else(|| {
                    ParseError::Unsupported("CPF sharp has no base symbol".to_string())
                })?;
            Ok(format!("{}#", parse_symbol(base_node)?))
        }
        "labeledSymbol" => {
            let base_node = node
                .children()
                .find(|child| {
                    child.is_element()
                        && matches!(local_name(*child), "name" | "sharp" | "labeledSymbol")
                })
                .ok_or_else(|| {
                    ParseError::Unsupported("CPF labeledSymbol has no base symbol".to_string())
                })?;
            let base = parse_symbol(base_node)?;
            if let Some(symbol_label) = node
                .children()
                .find(|child| child.is_element() && local_name(*child) == "symbolLabel")
            {
                let labels = symbol_label
                    .children()
                    .filter(|child| child.is_element())
                    .map(parse_symbol)
                    .collect::<Result<Vec<_>, _>>()?
                    .into_iter()
                    .map(|label| {
                        label
                            .as_bytes()
                            .iter()
                            .map(|byte| format!("{byte:02x}"))
                            .collect::<String>()
                    })
                    .collect::<Vec<_>>()
                    .join("_");
                return Ok(format!(
                    "__ferrum_rl__{}__{labels}",
                    base.as_bytes()
                        .iter()
                        .map(|byte| format!("{byte:02x}"))
                        .collect::<String>()
                ));
            }
            let labels = node
                .descendants()
                .filter(|child| child.is_element() && local_name(*child) == "number")
                .map(|child| child.text().unwrap_or_default().to_string())
                .collect::<Vec<_>>()
                .join("_");
            Ok(format!(
                "__ferrum_sl__{}__{labels}",
                base.as_bytes()
                    .iter()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>()
            ))
        }
        name => Err(ParseError::Unsupported(format!(
            "unsupported CPF symbol element {name}"
        ))),
    }
}

fn required_child<'a, 'input>(
    node: Node<'a, 'input>,
    name: &str,
) -> Result<Node<'a, 'input>, ParseError> {
    node.children()
        .find(|child| child.is_element() && local_name(*child) == name)
        .ok_or_else(|| ParseError::Unsupported(format!("CPF element is missing {name}")))
}

fn local_name<'a, 'input>(node: Node<'a, 'input>) -> &'input str {
    node.tag_name().name()
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};

    use crate::cert::{
        write_csr_dp_input_cpf4, write_csr_input_cpf4, write_dp_input_cpf3,
        write_relative_dp_state_input_cpf3, write_relative_trs_input_cpf3, write_trs_input_cpf3,
    };
    use crate::core::{
        CsrTrs, RelativeTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs,
        Variable,
    };
    use crate::proving::dependency_pairs;

    use super::{CpfInputProblem, marked_dp_aliases, parse_cpf_input, parse_symbol};

    #[test]
    fn parses_marked_semantic_label_symbols_without_losing_either_layer() {
        let document = roxmltree::Document::parse(
            r#"<sharp><labeledSymbol><name>f</name><numberLabel><number>0</number><number>1</number></numberLabel></labeledSymbol></sharp>"#,
        )
        .unwrap();

        assert_eq!(
            parse_symbol(document.root_element()).unwrap(),
            "__ferrum_sl__66__0_1#"
        );
    }

    #[test]
    fn parses_semantic_label_around_sharp_without_hiding_the_marker() {
        let document = roxmltree::Document::parse(
            r#"<labeledSymbol><sharp><name>f</name></sharp><numberLabel><number>0</number><number>1</number></numberLabel></labeledSymbol>"#,
        )
        .unwrap();

        assert_eq!(
            parse_symbol(document.root_element()).unwrap(),
            "__ferrum_sl__6623__0_1"
        );
    }

    #[test]
    fn parses_root_symbol_labels_without_collapsing_distinct_roots() {
        let document = roxmltree::Document::parse(
            r#"<labeledSymbol><sharp><name>f</name></sharp><symbolLabel><name>a</name><name>f</name></symbolLabel></labeledSymbol>"#,
        )
        .unwrap();

        assert_eq!(
            parse_symbol(document.root_element()).unwrap(),
            "__ferrum_rl__6623__61_66"
        );
    }

    #[test]
    fn provenance_does_not_rewrite_a_semantically_labeled_sharp_root() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("isNat", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let labeled_sharp = "__ferrum_sl__6c656e67746823__0";
        let pair = RewriteRule::new(
            Term::app(labeled_sharp, vec![Term::var("x")]),
            Term::app(labeled_sharp, vec![Term::var("x")]),
        );

        assert!(
            marked_dp_aliases(&trs, &[pair], Some(&[0]), &[], Some(&[]))
                .unwrap()
                .is_empty()
        );
    }

    #[test]
    fn provenance_preserves_native_unmarked_csr_unhiding_bridge_roots() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("diff", vec![Term::var("x"), Term::var("y")]),
                    Term::var("x"),
                ),
                RewriteRule::new(Term::app("p", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let bridge = RewriteRule::new(
            Term::app("p", vec![Term::var("x")]),
            Term::app("p#", vec![Term::var("x")]),
        );

        assert!(
            marked_dp_aliases(&trs, &[bridge], Some(&[0]), &[], Some(&[]))
                .unwrap()
                .is_empty()
        );
    }

    #[test]
    fn round_trips_ferrum_trs_input() {
        let trs = Trs::new_with_strategy(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let parsed = parse_cpf_input(None, &write_trs_input_cpf3(&trs)).unwrap();
        let CpfInputProblem::Trs(parsed) = parsed else {
            panic!("expected TRS input");
        };
        assert_eq!(parsed.rules(), trs.rules());
        assert_eq!(parsed.strategy(), RewriteStrategy::Innermost);
    }

    #[test]
    fn round_trips_outermost_trs_input() {
        let trs = Trs::new_with_strategy(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
            RewriteStrategy::Outermost,
        );
        let parsed = parse_cpf_input(None, &write_trs_input_cpf3(&trs)).unwrap();
        let CpfInputProblem::Trs(parsed) = parsed else {
            panic!("expected TRS input");
        };
        assert_eq!(parsed.strategy(), RewriteStrategy::Outermost);
    }

    #[test]
    fn round_trips_relative_rules_without_collapsing_them_into_the_strict_trs() {
        let strict_rule = RewriteRule::new(Term::app("f", vec![]), Term::app("a", vec![]));
        let weak_rule = RewriteRule::new(Term::app("g", vec![]), Term::app("b", vec![]));
        let relative = RelativeTrs::new(
            Trs::new(None, BTreeSet::new(), vec![strict_rule.clone()]),
            vec![weak_rule.clone()],
        );
        let parsed = parse_cpf_input(None, &write_relative_trs_input_cpf3(&relative)).unwrap();
        let CpfInputProblem::Relative(parsed) = parsed else {
            panic!("expected relative TRS input");
        };
        assert_eq!(parsed.strict().rules(), &[strict_rule]);
        assert_eq!(parsed.weak_rules(), &[weak_rule]);
    }

    #[test]
    fn round_trips_ferrum_dp_input() {
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let parsed = parse_cpf_input(None, &write_dp_input_cpf3(&trs, &pairs)).unwrap();
        let CpfInputProblem::Dp {
            trs: parsed_trs,
            pairs: parsed_pairs,
            active_rules,
            minimal,
            normal_form_substitutions,
            ..
        } = parsed
        else {
            panic!("expected DP input");
        };
        assert_eq!(parsed_trs.rules(), trs.rules());
        assert_eq!(active_rules, None);
        assert!(minimal);
        assert!(normal_form_substitutions);
        assert_eq!(
            parsed_pairs,
            pairs.iter().map(|pair| pair.as_rule()).collect::<Vec<_>>()
        );
    }

    #[test]
    fn round_trips_full_dp_input_without_inventing_q_normal_forms() {
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("a", vec![])]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let cpf = crate::cert::write_dp_state_input_cpf3(&trs, &pairs, None, true, false);
        let CpfInputProblem::Dp {
            normal_form_substitutions,
            ..
        } = parse_cpf_input(None, &cpf).unwrap()
        else {
            panic!("expected DP input");
        };
        assert!(!normal_form_substitutions);
    }

    #[test]
    fn round_trips_relative_dp_weak_pairs_without_merging_them_into_strict_pairs() {
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("a", vec![])]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let input = write_relative_dp_state_input_cpf3(&trs, &pairs, &pairs, None, true, false);
        let CpfInputProblem::Dp {
            pairs: parsed_pairs,
            weak_pairs,
            ..
        } = parse_cpf_input(None, &input).unwrap()
        else {
            panic!("expected DP input");
        };
        let expected = pairs.iter().map(|pair| pair.as_rule()).collect::<Vec<_>>();
        assert_eq!(parsed_pairs, expected);
        assert_eq!(weak_pairs, expected);
    }

    #[test]
    fn round_trips_context_sensitive_dp_input_without_losing_active_rules() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::app("a", vec![])]),
        );
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![rule.clone()],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let pairs = dependency_pairs(csr.trs());
        let input = write_csr_dp_input_cpf4(
            &csr,
            &pairs,
            Some(&[]),
            true,
            "improved",
            "context-sensitive",
            false,
        );
        let CpfInputProblem::CsrDp {
            csr: parsed,
            pairs: parsed_pairs,
            active_rules,
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
            ..
        } = parse_cpf_input(None, &input).unwrap()
        else {
            panic!("expected context-sensitive DP input");
        };
        assert_eq!(parsed.replacement_map(), csr.replacement_map());
        assert_eq!(parsed_pairs.len(), pairs.len());
        assert_eq!(active_rules, Some(Vec::new()));
        assert!(minimal);
        assert_eq!(construction, "improved");
        assert_eq!(graph_estimator, "context-sensitive");
        assert!(!use_qcs_usable_rules);
    }

    #[test]
    fn recovers_only_the_frozen_unary_improved_csr_dp_wrapper_alias() {
        let input = r#"<dpInput>
  <trs><rules><rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule></rules></trs>
  <dps><rules><rule><funapp><name>u</name><funapp><name>f</name><var>x</var></funapp></funapp><funapp><name>u</name><var>x</var></funapp></rule></rules></dps>
  <strategy><contextSensitive>
    <replacementMapEntry><name>f</name><arity>1</arity><position>1</position></replacementMapEntry>
    <replacementMapEntry><name>u</name><arity>1</arity></replacementMapEntry>
  </contextSensitive></strategy>
  <minimal>true</minimal>
  <ferrumCsrDpContext><construction>improved</construction><graphEstimator>context-sensitive</graphEstimator><qcsUsableRules>true</qcsUsableRules></ferrumCsrDpContext>
</dpInput>"#;
        let CpfInputProblem::CsrDp { csr, pairs, .. } =
            parse_cpf_input(None, input).expect("legacy improved state must parse")
        else {
            panic!("expected improved CSR-DP input");
        };
        assert!(
            !csr.replacement_map()
                .entries()
                .contains_key(&Symbol::new("u"))
        );
        assert_eq!(pairs[0].lhs().root_symbol(), Some(&Symbol::new("__CSR_U0")));
        assert_eq!(pairs[0].rhs().root_symbol(), Some(&Symbol::new("__CSR_U0")));

        let native = input.replace(
            "<construction>improved</construction>",
            "<construction>native</construction>",
        );
        assert!(parse_cpf_input(None, &native).is_err());
    }

    #[test]
    fn recovers_marked_csr_dp_roots_from_pair_source_provenance() {
        let input = r#"<dpInput>
  <trs><rules>
    <rule><funapp><name>f</name><var>x</var></funapp><funapp><name>g</name><var>x</var></funapp></rule>
    <rule><funapp><name>g</name><var>x</var></funapp><var>x</var></rule>
  </rules></trs>
  <dps><rules>
    <rule><funapp><name>a</name><var>x</var></funapp><funapp><name>b</name><var>x</var></funapp></rule>
    <rule><funapp><name>b</name><var>x</var></funapp><funapp><name>b</name><var>x</var></funapp></rule>
  </rules></dps>
  <strategy><contextSensitive>
    <replacementMapEntry><name>f</name><arity>1</arity><position>1</position></replacementMapEntry>
    <replacementMapEntry><name>g</name><arity>1</arity><position>1</position></replacementMapEntry>
  </contextSensitive></strategy>
  <minimal>true</minimal>
  <ferrumCsrDpContext><construction>safe</construction><graphEstimator>context-sensitive</graphEstimator><qcsUsableRules>false</qcsUsableRules></ferrumCsrDpContext>
  <ferrumDpStateContext><pairSourceRules><sourceRule>0</sourceRule><sourceRule>1</sourceRule></pairSourceRules></ferrumDpStateContext>
</dpInput>"#;
        let CpfInputProblem::CsrDp { pairs, .. } = parse_cpf_input(None, input).unwrap() else {
            panic!("expected CSR-DP input");
        };
        assert_eq!(pairs[0].lhs().root_symbol(), Some(&Symbol::new("f#")));
        assert_eq!(pairs[0].rhs().root_symbol(), Some(&Symbol::new("g#")));
        assert_eq!(pairs[1].lhs().root_symbol(), Some(&Symbol::new("g#")));
        assert_eq!(pairs[1].rhs().root_symbol(), Some(&Symbol::new("g#")));
    }

    #[test]
    fn round_trips_ferrum_csr_input_without_losing_the_replacement_map() {
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![Term::var("x"), Term::app("g", vec![Term::var("x")])],
                ),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([1])),
                (Symbol::new("g"), BTreeSet::new()),
            ])),
        )
        .unwrap();

        let parsed = parse_cpf_input(None, &write_csr_input_cpf4(&csr)).unwrap();
        let CpfInputProblem::Csr {
            csr: parsed,
            boundary: crate::proving::CsrProofBoundary::Root,
        } = parsed
        else {
            panic!("expected CSR input");
        };
        assert_eq!(parsed.rules(), csr.rules());
        assert_eq!(parsed.replacement_map(), csr.replacement_map());
    }

    #[test]
    fn round_trips_nested_csr_worklist_boundary() {
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .unwrap();
        let input =
            crate::cert::write_csr_state_input_cpf4(&csr, crate::proving::CsrProofBoundary::Nested);
        let CpfInputProblem::Csr { boundary, .. } = parse_cpf_input(None, &input).unwrap() else {
            panic!("expected CSR input");
        };
        assert_eq!(boundary, crate::proving::CsrProofBoundary::Nested);
    }

    #[test]
    fn round_trips_root_rule_removal_csr_worklist_boundary() {
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .unwrap();
        let input = crate::cert::write_csr_state_input_cpf4(
            &csr,
            crate::proving::CsrProofBoundary::RootRuleRemovalContinuation,
        );
        let CpfInputProblem::Csr { boundary, .. } = parse_cpf_input(None, &input).unwrap() else {
            panic!("expected CSR input");
        };
        assert_eq!(
            boundary,
            crate::proving::CsrProofBoundary::RootRuleRemovalContinuation
        );
    }
}
