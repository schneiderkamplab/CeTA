use std::collections::BTreeSet;

use crate::core::{RewriteRule, RewriteStrategy, Term, Trs, Variable};

use super::ParseError;

#[derive(Clone, Debug, Eq, PartialEq)]
enum Token {
    Ident(String),
    LParen,
    RParen,
    Comma,
    Arrow,
}

pub fn parse_text_trs(source_name: Option<String>, input: &str) -> Result<Trs, ParseError> {
    let tokens = tokenize(input)?;
    let mut parser = Parser::new(tokens);
    parser.parse(source_name)
}

fn tokenize(input: &str) -> Result<Vec<(Token, usize)>, ParseError> {
    let mut tokens = Vec::new();
    let mut index = 0;
    let bytes = input.as_bytes();
    while index < bytes.len() {
        let ch = input[index..].chars().next().unwrap_or_default();
        if ch.is_whitespace() {
            index += ch.len_utf8();
        } else if input[index..].starts_with("->") {
            tokens.push((Token::Arrow, index));
            index += 2;
        } else if ch == '(' {
            tokens.push((Token::LParen, index));
            index += 1;
        } else if ch == ')' {
            tokens.push((Token::RParen, index));
            index += 1;
        } else if ch == ',' {
            tokens.push((Token::Comma, index));
            index += 1;
        } else if ch == '#' || ch == ';' {
            while index < bytes.len() {
                let next = input[index..].chars().next().unwrap_or_default();
                index += next.len_utf8();
                if next == '\n' {
                    break;
                }
            }
        } else if is_ident_start(ch) {
            let start = index;
            index += ch.len_utf8();
            while index < bytes.len() {
                let next = input[index..].chars().next().unwrap_or_default();
                if !is_ident_continue(next) {
                    break;
                }
                index += next.len_utf8();
            }
            tokens.push((Token::Ident(input[start..index].to_string()), start));
        } else {
            return Err(ParseError::Syntax {
                message: format!("unexpected character `{ch}`"),
                offset: index,
            });
        }
    }
    Ok(tokens)
}

fn is_ident_start(ch: char) -> bool {
    ch.is_ascii_alphanumeric() || "_$+*-/<>=!?.".contains(ch)
}

fn is_ident_continue(ch: char) -> bool {
    is_ident_start(ch) || ch == '\''
}

struct Parser {
    tokens: Vec<(Token, usize)>,
    cursor: usize,
    variables: BTreeSet<Variable>,
    strategy: RewriteStrategy,
}

impl Parser {
    fn new(tokens: Vec<(Token, usize)>) -> Self {
        Self {
            tokens,
            cursor: 0,
            variables: BTreeSet::new(),
            strategy: RewriteStrategy::Full,
        }
    }

    fn parse(&mut self, source_name: Option<String>) -> Result<Trs, ParseError> {
        let mut rules = Vec::new();
        while !self.is_done() {
            self.expect_lparen()?;
            let section = self.expect_ident()?;
            match section.as_str() {
                "VAR" => self.parse_var_section()?,
                "RULES" => rules.extend(self.parse_rules_section()?),
                "STRATEGY" => self.parse_strategy_section()?,
                "COMMENT" | "THEORY" => self.skip_balanced_body()?,
                other => {
                    return Err(self.error(format!("unsupported TPDB text section `{other}`")));
                }
            }
        }
        Ok(Trs::new_with_strategy(
            source_name,
            self.variables.clone(),
            rules,
            self.strategy,
        ))
    }

    fn parse_var_section(&mut self) -> Result<(), ParseError> {
        while !self.consume_rparen() {
            let name = self.expect_ident()?;
            self.variables.insert(Variable::new(name));
        }
        Ok(())
    }

    fn parse_rules_section(&mut self) -> Result<Vec<RewriteRule>, ParseError> {
        let mut rules = Vec::new();
        while !self.consume_rparen() {
            let lhs = self.parse_term()?;
            self.expect_arrow()?;
            let rhs = self.parse_term()?;
            rules.push(RewriteRule::new(lhs, rhs));
        }
        Ok(rules)
    }

    fn parse_strategy_section(&mut self) -> Result<(), ParseError> {
        let mut words = Vec::new();
        while !self.consume_rparen() {
            match self.next() {
                Some((Token::Ident(word), _)) => words.push(word.to_ascii_uppercase()),
                Some((Token::LParen, _)) => self.skip_balanced_body()?,
                Some((_, offset)) => {
                    return Err(ParseError::Syntax {
                        message: "expected strategy identifier".to_string(),
                        offset,
                    });
                }
                None => return Err(self.error("unterminated strategy section".to_string())),
            }
        }
        if words.iter().any(|word| word == "OUTERMOST") {
            self.strategy = RewriteStrategy::Outermost;
        } else if words.iter().any(|word| word == "INNERMOST") {
            self.strategy = RewriteStrategy::Innermost;
        }
        Ok(())
    }

    fn parse_term(&mut self) -> Result<Term, ParseError> {
        let name = self.expect_ident()?;
        if self.variables.contains(&Variable::new(name.clone())) {
            return Ok(Term::var(name));
        }
        if !self.consume_lparen() {
            return Ok(Term::app(name, Vec::new()));
        }
        let mut args = Vec::new();
        if self.consume_rparen() {
            return Ok(Term::app(name, args));
        }
        loop {
            args.push(self.parse_term()?);
            if self.consume_rparen() {
                break;
            }
            self.expect_comma()?;
        }
        Ok(Term::app(name, args))
    }

    fn skip_balanced_body(&mut self) -> Result<(), ParseError> {
        let mut depth = 1usize;
        while let Some((token, _)) = self.next() {
            match token {
                Token::LParen => depth += 1,
                Token::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        return Ok(());
                    }
                }
                _ => {}
            }
        }
        Err(self.error("unterminated section".to_string()))
    }

    fn is_done(&self) -> bool {
        self.cursor >= self.tokens.len()
    }

    fn next(&mut self) -> Option<(Token, usize)> {
        let token = self.tokens.get(self.cursor).cloned();
        self.cursor += usize::from(token.is_some());
        token
    }

    fn consume_lparen(&mut self) -> bool {
        self.consume(|token| matches!(token, Token::LParen))
    }

    fn consume_rparen(&mut self) -> bool {
        self.consume(|token| matches!(token, Token::RParen))
    }

    fn consume(&mut self, predicate: impl FnOnce(&Token) -> bool) -> bool {
        if let Some((token, _)) = self.tokens.get(self.cursor)
            && predicate(token)
        {
            self.cursor += 1;
            return true;
        }
        false
    }

    fn expect_lparen(&mut self) -> Result<(), ParseError> {
        self.expect(|token| matches!(token, Token::LParen), "`(`")
            .map(drop)
    }

    fn expect_arrow(&mut self) -> Result<(), ParseError> {
        self.expect(|token| matches!(token, Token::Arrow), "`->`")
            .map(drop)
    }

    fn expect_comma(&mut self) -> Result<(), ParseError> {
        self.expect(|token| matches!(token, Token::Comma), "`,`")
            .map(drop)
    }

    fn expect_ident(&mut self) -> Result<String, ParseError> {
        match self.next() {
            Some((Token::Ident(name), _)) => Ok(name),
            Some((_, offset)) => Err(ParseError::Syntax {
                message: "expected identifier".to_string(),
                offset,
            }),
            None => Err(self.error("expected identifier".to_string())),
        }
    }

    fn expect(
        &mut self,
        predicate: impl FnOnce(&Token) -> bool,
        expected: &str,
    ) -> Result<Token, ParseError> {
        match self.next() {
            Some((token, _)) if predicate(&token) => Ok(token),
            Some((_, offset)) => Err(ParseError::Syntax {
                message: format!("expected {expected}"),
                offset,
            }),
            None => Err(self.error(format!("expected {expected}"))),
        }
    }

    fn error(&self, message: String) -> ParseError {
        ParseError::Syntax {
            message,
            offset: self
                .tokens
                .get(self.cursor)
                .map(|(_, offset)| *offset)
                .unwrap_or(0),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_text_trs() {
        let trs = parse_text_trs(
            Some("toy.trs".to_string()),
            "(VAR x y)\n(RULES\n  f(x) -> g(x)\n  g(y) -> y\n)",
        )
        .unwrap();
        assert_eq!(trs.rules().len(), 2);
        assert_eq!(trs.variables().len(), 2);
    }

    #[test]
    fn parses_innermost_strategy() {
        let trs = parse_text_trs(
            Some("toy.trs".to_string()),
            "(VAR x)\n(STRATEGY INNERMOST)\n(RULES\n  f(x) -> x\n)",
        )
        .unwrap();
        assert_eq!(trs.strategy(), RewriteStrategy::Innermost);
    }

    #[test]
    fn parses_outermost_strategy() {
        let trs = parse_text_trs(
            Some("toy.trs".to_string()),
            "(VAR x)\n(STRATEGY OUTERMOST)\n(RULES\n  f(x) -> x\n)",
        )
        .unwrap();
        assert_eq!(trs.strategy(), RewriteStrategy::Outermost);
    }
}
