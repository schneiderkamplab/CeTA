use std::collections::{BTreeMap, BTreeSet};

use crate::core::{
    CsrTrs, RelativeTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable,
};

use super::ParseError;

#[derive(Clone, Debug, Eq, PartialEq)]
enum Sexp {
    Atom(String),
    List(Vec<Sexp>),
}

pub fn parse_ari_trs(source_name: Option<String>, input: &str) -> Result<Trs, ParseError> {
    let sexps = parse_sexps(input)?;
    let Some(format) = ari_format(&sexps) else {
        return Err(ParseError::Unsupported(
            "ARI input without `(format ...)` declaration".to_string(),
        ));
    };
    if format != "TRS" {
        return Err(ParseError::Unsupported(format!(
            "ARI format `{format}` is not a first-order TRS"
        )));
    }
    let symbols = declared_symbols(&sexps);
    let mut variables = BTreeSet::new();
    let mut rules = Vec::new();
    let mut weak_rules = Vec::new();
    for sexp in &sexps {
        collect_rule_partitioned(sexp, &symbols, &mut variables, &mut rules, &mut weak_rules)?;
    }
    if !weak_rules.is_empty() {
        return Err(ParseError::Unsupported(
            "relative ARI input must be parsed as a relative TRS".to_string(),
        ));
    }
    if rules.is_empty() {
        return Err(ParseError::Unsupported(
            "no first-order `rule` forms found in ARI input".to_string(),
        ));
    }
    let strategy = strategy_from_source_name(source_name.as_deref());
    Ok(Trs::new_with_strategy(
        source_name,
        variables,
        rules,
        strategy,
    ))
}

pub fn parse_ari_relative_trs(
    source_name: Option<String>,
    input: &str,
) -> Result<RelativeTrs, ParseError> {
    let sexps = parse_sexps(input)?;
    let Some(format) = ari_format(&sexps) else {
        return Err(ParseError::Unsupported(
            "ARI input without `(format ...)` declaration".to_string(),
        ));
    };
    if format != "TRS" && format != "SRS" {
        return Err(ParseError::Unsupported(format!(
            "ARI format `{format}` is not a relative TRS or SRS"
        )));
    }
    let symbols = declared_symbols(&sexps);
    let mut variables = BTreeSet::new();
    let mut strict_rules = Vec::new();
    let mut weak_rules = Vec::new();
    if format == "SRS" {
        let tail = Variable::new("__srs_tail");
        variables.insert(tail.clone());
        for sexp in &sexps {
            collect_srs_rule_partitioned(
                sexp,
                &symbols,
                &tail,
                &mut strict_rules,
                &mut weak_rules,
            )?;
        }
    } else {
        for sexp in &sexps {
            collect_rule_partitioned(
                sexp,
                &symbols,
                &mut variables,
                &mut strict_rules,
                &mut weak_rules,
            )?;
        }
    }
    if strict_rules.is_empty() && weak_rules.is_empty() {
        return Err(ParseError::Unsupported(
            "no first-order `rule` forms found in ARI input".to_string(),
        ));
    }
    let strategy = strategy_from_source_name(source_name.as_deref());
    let strict = Trs::new_with_strategy(source_name, variables, strict_rules, strategy);
    Ok(RelativeTrs::new(strict, weak_rules))
}

fn collect_srs_rule_partitioned(
    sexp: &Sexp,
    symbols: &BTreeSet<String>,
    tail: &Variable,
    strict_rules: &mut Vec<RewriteRule>,
    weak_rules: &mut Vec<RewriteRule>,
) -> Result<(), ParseError> {
    match sexp {
        Sexp::Atom(_) => Ok(()),
        Sexp::List(items) => {
            if matches!(items.first(), Some(Sexp::Atom(head)) if head == "rule") && items.len() >= 3
            {
                let lhs = ari_srs_word(&items[1], symbols, tail)?;
                let rhs = ari_srs_word(&items[2], symbols, tail)?;
                let rule = RewriteRule::new(lhs, rhs);
                if rule_cost(items)? == 0 {
                    weak_rules.push(rule);
                } else {
                    strict_rules.push(rule);
                }
                return Ok(());
            }
            for item in items {
                collect_srs_rule_partitioned(item, symbols, tail, strict_rules, weak_rules)?;
            }
            Ok(())
        }
    }
}

fn ari_srs_word(
    sexp: &Sexp,
    symbols: &BTreeSet<String>,
    tail: &Variable,
) -> Result<Term, ParseError> {
    let Sexp::List(letters) = sexp else {
        return Err(ParseError::Unsupported(
            "ARI SRS rule sides must be parenthesized words".to_string(),
        ));
    };
    let mut term = Term::Var(tail.clone());
    for letter in letters.iter().rev() {
        let Sexp::Atom(symbol) = letter else {
            return Err(ParseError::Unsupported(
                "ARI SRS words must contain only declared symbols".to_string(),
            ));
        };
        if !symbols.contains(symbol) {
            return Err(ParseError::Unsupported(format!(
                "undeclared symbol `{symbol}` in ARI SRS word"
            )));
        }
        term = Term::App {
            symbol: Symbol::new(symbol),
            args: vec![term],
        };
    }
    Ok(term)
}

pub fn is_relative_ari(input: &str) -> Result<bool, ParseError> {
    let sexps = parse_sexps(input)?;
    for sexp in &sexps {
        if sexp_contains_weak_rule(sexp)? {
            return Ok(true);
        }
    }
    Ok(false)
}

fn sexp_contains_weak_rule(sexp: &Sexp) -> Result<bool, ParseError> {
    match sexp {
        Sexp::Atom(_) => Ok(false),
        Sexp::List(items) => {
            if matches!(items.first(), Some(Sexp::Atom(head)) if head == "rule")
                && items.len() >= 3
                && rule_cost(items)? == 0
            {
                return Ok(true);
            }
            for item in items {
                if sexp_contains_weak_rule(item)? {
                    return Ok(true);
                }
            }
            Ok(false)
        }
    }
}

pub fn parse_ari_cstrs(source_name: Option<String>, input: &str) -> Result<CsrTrs, ParseError> {
    let sexps = parse_sexps(input)?;
    let Some(format) = ari_format(&sexps) else {
        return Err(ParseError::Unsupported(
            "ARI input without `(format ...)` declaration".to_string(),
        ));
    };
    if format != "CSTRS" {
        return Err(ParseError::Unsupported(format!(
            "ARI format `{format}` is not a context-sensitive TRS"
        )));
    }
    let symbols = declared_symbols(&sexps);
    let mut variables = BTreeSet::new();
    let mut rules = Vec::new();
    for sexp in &sexps {
        collect_rule(sexp, &symbols, &mut variables, &mut rules)?;
    }
    if rules.is_empty() {
        return Err(ParseError::Unsupported(
            "no first-order `rule` forms found in ARI input".to_string(),
        ));
    }
    let strategy = strategy_from_source_name(source_name.as_deref());
    let trs = Trs::new_with_strategy(source_name, variables, rules, strategy);
    let arities = trs.arities();
    let replacement_map = ReplacementMap::new(
        declared_replacement_map(&sexps)?
            .into_iter()
            // ARI signatures may contain constructor symbols unused by every
            // rule. `Trs` derives its operational signature from the rules,
            // so these semantically inert entries must not invalidate the
            // replacement map.
            .filter(|(symbol, _)| arities.contains_key(symbol))
            .collect(),
    );
    CsrTrs::new(trs, replacement_map).map_err(|issues| {
        ParseError::Unsupported(format!(
            "invalid context-sensitive replacement map: {}",
            issues
                .into_iter()
                .map(|issue| issue.to_string())
                .collect::<Vec<_>>()
                .join("; ")
        ))
    })
}

fn ari_format(sexps: &[Sexp]) -> Option<String> {
    for sexp in sexps {
        if let Sexp::List(items) = sexp
            && let [Sexp::Atom(head), Sexp::Atom(format), ..] = items.as_slice()
            && head == "format"
        {
            return Some(format.clone());
        }
    }
    None
}

fn strategy_from_source_name(source_name: Option<&str>) -> RewriteStrategy {
    if source_name.is_some_and(|name| name.to_ascii_lowercase().contains("outermost")) {
        RewriteStrategy::Outermost
    } else if source_name.is_some_and(|name| name.to_ascii_lowercase().contains("innermost")) {
        RewriteStrategy::Innermost
    } else {
        RewriteStrategy::Full
    }
}

fn collect_rule(
    sexp: &Sexp,
    symbols: &BTreeSet<String>,
    variables: &mut BTreeSet<Variable>,
    rules: &mut Vec<RewriteRule>,
) -> Result<(), ParseError> {
    let mut weak_rules = Vec::new();
    collect_rule_partitioned(sexp, symbols, variables, rules, &mut weak_rules)?;
    if weak_rules.is_empty() {
        Ok(())
    } else {
        Err(ParseError::Unsupported(
            "relative rules are not supported in this input format".to_string(),
        ))
    }
}

fn collect_rule_partitioned(
    sexp: &Sexp,
    symbols: &BTreeSet<String>,
    variables: &mut BTreeSet<Variable>,
    strict_rules: &mut Vec<RewriteRule>,
    weak_rules: &mut Vec<RewriteRule>,
) -> Result<(), ParseError> {
    match sexp {
        Sexp::Atom(_) => Ok(()),
        Sexp::List(items) => {
            if let Some(Sexp::Atom(head)) = items.first()
                && head == "rule"
                && items.len() >= 3
            {
                let lhs = ari_term(&items[1], symbols, variables)?;
                let rhs = ari_term(&items[2], symbols, variables)?;
                let rule = RewriteRule::new(lhs, rhs);
                if rule_cost(items)? == 0 {
                    weak_rules.push(rule);
                } else {
                    strict_rules.push(rule);
                }
                return Ok(());
            }
            for item in items {
                collect_rule_partitioned(item, symbols, variables, strict_rules, weak_rules)?;
            }
            Ok(())
        }
    }
}

fn rule_cost(items: &[Sexp]) -> Result<u64, ParseError> {
    let mut cost = 1;
    let mut index = 3;
    while index < items.len() {
        match items.get(index) {
            Some(Sexp::Atom(label)) if label == ":cost" => {
                let Some(Sexp::Atom(raw_cost)) = items.get(index + 1) else {
                    return Err(ParseError::Unsupported(
                        "ARI rule `:cost` must be followed by a non-negative integer".to_string(),
                    ));
                };
                cost = raw_cost.parse().map_err(|_| {
                    ParseError::Unsupported(format!(
                        "ARI rule cost `{raw_cost}` is not a non-negative integer"
                    ))
                })?;
                index += 2;
            }
            Some(Sexp::Atom(label)) if label.starts_with(':') => {
                index += 2;
            }
            _ => index += 1,
        }
    }
    Ok(cost)
}

fn declared_symbols(sexps: &[Sexp]) -> BTreeSet<String> {
    let mut symbols = BTreeSet::new();
    for sexp in sexps {
        collect_declared_symbols(sexp, &mut symbols);
    }
    symbols
}

fn collect_declared_symbols(sexp: &Sexp, symbols: &mut BTreeSet<String>) {
    match sexp {
        Sexp::Atom(_) => {}
        Sexp::List(items) => {
            if let [Sexp::Atom(head), Sexp::Atom(symbol), ..] = items.as_slice()
                && head == "fun"
            {
                symbols.insert(symbol.clone());
            }
            for item in items {
                collect_declared_symbols(item, symbols);
            }
        }
    }
}

fn declared_replacement_map(
    sexps: &[Sexp],
) -> Result<BTreeMap<Symbol, BTreeSet<usize>>, ParseError> {
    let mut replacement_map = BTreeMap::new();
    for sexp in sexps {
        collect_declared_replacement_map(sexp, &mut replacement_map)?;
    }
    Ok(replacement_map)
}

fn collect_declared_replacement_map(
    sexp: &Sexp,
    replacement_map: &mut BTreeMap<Symbol, BTreeSet<usize>>,
) -> Result<(), ParseError> {
    match sexp {
        Sexp::Atom(_) => Ok(()),
        Sexp::List(items) => {
            if let [
                Sexp::Atom(head),
                Sexp::Atom(symbol),
                Sexp::Atom(raw_arity),
                ..,
            ] = items.as_slice()
                && head == "fun"
            {
                let arity = raw_arity.parse::<usize>().map_err(|_| {
                    ParseError::Unsupported(format!("function arity `{raw_arity}` is not numeric"))
                })?;
                // The ARI CSTRS format defines an omitted replacement map as
                // the full map (1, ..., arity), not as the empty map.
                let mut positions = (0..arity).collect::<BTreeSet<_>>();
                let mut index = 3usize;
                while index < items.len() {
                    if let Sexp::Atom(label) = &items[index]
                        && label == ":replacement-map"
                        && let Some(Sexp::List(raw_positions)) = items.get(index + 1)
                    {
                        positions.clear();
                        for raw_position in raw_positions {
                            let Sexp::Atom(raw_position) = raw_position else {
                                return Err(ParseError::Unsupported(
                                    "replacement-map position must be numeric".to_string(),
                                ));
                            };
                            let position = raw_position.parse::<usize>().map_err(|_| {
                                ParseError::Unsupported(format!(
                                    "replacement-map position `{raw_position}` is not numeric"
                                ))
                            })?;
                            if position == 0 {
                                return Err(ParseError::Unsupported(
                                    "replacement-map positions are 1-based in ARI".to_string(),
                                ));
                            }
                            positions.insert(position - 1);
                        }
                        index += 2;
                        continue;
                    }
                    index += 1;
                }
                replacement_map.insert(Symbol::new(symbol.clone()), positions);
            }
            for item in items {
                collect_declared_replacement_map(item, replacement_map)?;
            }
            Ok(())
        }
    }
}

fn ari_term(
    sexp: &Sexp,
    symbols: &BTreeSet<String>,
    variables: &mut BTreeSet<Variable>,
) -> Result<Term, ParseError> {
    match sexp {
        Sexp::Atom(atom) if atom.starts_with('?') => {
            let variable = atom.trim_start_matches('?').to_string();
            variables.insert(Variable::new(variable.clone()));
            Ok(Term::var(variable))
        }
        Sexp::Atom(atom) if symbols.contains(atom) => Ok(Term::app(atom.clone(), Vec::new())),
        Sexp::Atom(atom) => {
            variables.insert(Variable::new(atom.clone()));
            Ok(Term::var(atom.clone()))
        }
        Sexp::List(items) if items.is_empty() => Err(ParseError::Unsupported(
            "empty ARI term application".to_string(),
        )),
        Sexp::List(items) => {
            let Sexp::Atom(symbol) = &items[0] else {
                return Err(ParseError::Unsupported(
                    "higher-order ARI term head".to_string(),
                ));
            };
            let mut args = Vec::new();
            for item in &items[1..] {
                args.push(ari_term(item, symbols, variables)?);
            }
            Ok(Term::app(symbol.clone(), args))
        }
    }
}

fn parse_sexps(input: &str) -> Result<Vec<Sexp>, ParseError> {
    let mut parser = SexpParser { input, cursor: 0 };
    let mut sexps = Vec::new();
    while parser.skip_ws_and_comments() {
        sexps.push(parser.parse_one()?);
    }
    Ok(sexps)
}

struct SexpParser<'a> {
    input: &'a str,
    cursor: usize,
}

impl SexpParser<'_> {
    fn parse_one(&mut self) -> Result<Sexp, ParseError> {
        self.skip_ws_and_comments();
        if self.consume('(') {
            let mut items = Vec::new();
            while self.skip_ws_and_comments() && !self.consume(')') {
                items.push(self.parse_one()?);
            }
            Ok(Sexp::List(items))
        } else {
            self.parse_atom().map(Sexp::Atom)
        }
    }

    fn parse_atom(&mut self) -> Result<String, ParseError> {
        let start = self.cursor;
        while let Some(ch) = self.peek() {
            if ch.is_whitespace() || ch == '(' || ch == ')' || ch == ';' {
                break;
            }
            self.cursor += ch.len_utf8();
        }
        if start == self.cursor {
            return Err(ParseError::Syntax {
                message: "expected ARI atom".to_string(),
                offset: self.cursor,
            });
        }
        Ok(self.input[start..self.cursor].to_string())
    }

    fn skip_ws_and_comments(&mut self) -> bool {
        loop {
            while let Some(ch) = self.peek()
                && ch.is_whitespace()
            {
                self.cursor += ch.len_utf8();
            }
            if self.peek() != Some(';') {
                break;
            }
            while let Some(ch) = self.peek() {
                self.cursor += ch.len_utf8();
                if ch == '\n' {
                    break;
                }
            }
        }
        self.cursor < self.input.len()
    }

    fn consume(&mut self, expected: char) -> bool {
        if self.peek() == Some(expected) {
            self.cursor += expected.len_utf8();
            true
        } else {
            false
        }
    }

    fn peek(&self) -> Option<char> {
        self.input[self.cursor..].chars().next()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_ari_rule_forms() {
        let trs = parse_ari_trs(
            None,
            "(format TRS)\n(fun f 1)\n(fun g 1)\n(rule (f x) (g x))\n(rule (g x) x)",
        )
        .unwrap();
        assert_eq!(trs.rules().len(), 2);
        assert_eq!(trs.variables().len(), 1);
    }

    #[test]
    fn infers_outermost_strategy_from_category_path() {
        let trs = parse_ari_trs(
            Some("TPDB-ARI/TRS_Outermost/example.ari".to_string()),
            "(format TRS)\n(fun f 1)\n(rule (f x) x)",
        )
        .unwrap();
        assert_eq!(trs.strategy(), RewriteStrategy::Outermost);
    }

    #[test]
    fn infers_innermost_from_tpdb_ari_path() {
        let trs = parse_ari_trs(
            Some("../TPDB-ARI/TRS_Innermost/foo.ari".to_string()),
            "(format TRS)\n(fun f 1)\n(rule (f x) x)",
        )
        .unwrap();
        assert_eq!(trs.strategy(), RewriteStrategy::Innermost);
    }

    #[test]
    fn parses_context_sensitive_replacement_maps() {
        let csr = parse_ari_cstrs(
            None,
            "(format CSTRS)\n(fun f 2 :replacement-map (1))\n(fun a 0 :replacement-map ())\n(rule (f a x) x)",
        )
        .unwrap();
        assert!(csr.replacement_map().is_allowed(&Symbol::new("f"), 0));
        assert!(!csr.replacement_map().is_allowed(&Symbol::new("f"), 1));
    }

    #[test]
    fn omitted_context_sensitive_replacement_map_is_full_and_unused_symbols_are_safe() {
        let csr = parse_ari_cstrs(
            None,
            "(format CSTRS)\n\
             (fun unused 2)\n\
             (fun f 1)\n\
             (fun a 0)\n\
             (rule (f a) a)",
        )
        .unwrap();
        assert!(csr.replacement_map().is_allowed(&Symbol::new("f"), 0));
        assert!(
            !csr.replacement_map()
                .entries()
                .contains_key(&Symbol::new("unused"))
        );
    }

    #[test]
    fn parses_gutierrez_secret_replacement_map_distinction() {
        let frozen = parse_ari_cstrs(
            None,
            include_str!("../../../TPDB-ARI/TRS_Contextsensitive/Gutierrez_26/secret2.ari"),
        )
        .unwrap();
        let active = parse_ari_cstrs(
            None,
            include_str!("../../../TPDB-ARI/TRS_Contextsensitive/Gutierrez_26/secret4.ari"),
        )
        .unwrap();
        let f = Symbol::new("f");
        assert!(!frozen.replacement_map().is_allowed(&f, 0));
        assert!(active.replacement_map().is_allowed(&f, 0));
    }

    #[test]
    fn partitions_relative_rules_by_zero_cost() {
        let input = "(format TRS)\n(fun a 1)\n(fun b 1)\n(rule (a x) x)\n(rule x (b x) :cost 0)";
        assert!(is_relative_ari(input).unwrap());
        assert!(parse_ari_trs(None, input).is_err());
        let relative = parse_ari_relative_trs(None, input).unwrap();
        assert_eq!(relative.strict().rules().len(), 1);
        assert_eq!(relative.weak_rules().len(), 1);
        assert_eq!(relative.union().rules().len(), 2);
        assert!(relative.is_srs_encoded());
    }

    #[test]
    fn treats_positive_cost_as_strict() {
        let input = "(format TRS)\n(fun a 1)\n(rule (a x) x :cost 2)";
        assert!(!is_relative_ari(input).unwrap());
        assert_eq!(parse_ari_trs(None, input).unwrap().rules().len(), 1);
    }

    #[test]
    fn parses_native_relative_srs_words() {
        let input =
            "(format SRS)\n(fun a 1)\n(fun b 1)\n(rule (a b) (b))\n(rule (b) (a b) :cost 0)";
        let relative = parse_ari_relative_trs(None, input).unwrap();
        assert_eq!(relative.strict().rules().len(), 1);
        assert_eq!(relative.weak_rules().len(), 1);
        assert_eq!(
            relative.strict().rules()[0].lhs().to_string(),
            "a(b(__srs_tail))"
        );
        assert_eq!(
            relative.strict().rules()[0].rhs().to_string(),
            "b(__srs_tail)"
        );
        assert!(relative.is_srs_encoded());
    }
}
