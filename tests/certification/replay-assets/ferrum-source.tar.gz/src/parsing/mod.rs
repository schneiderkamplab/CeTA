mod ari;
mod cpf_input;
mod text_trs;

pub use ari::{is_relative_ari, parse_ari_cstrs, parse_ari_relative_trs, parse_ari_trs};
pub use cpf_input::{CpfInputProblem, parse_cpf_input};
pub(crate) use cpf_input::{parse_cpf_rule_container_fragment, parse_cpf_term_container_fragment};
pub use text_trs::parse_text_trs;

use thiserror::Error;

#[derive(Debug, Error)]
pub enum ParseError {
    #[error("{message} at byte {offset}")]
    Syntax { message: String, offset: usize },

    #[error("unsupported input: {0}")]
    Unsupported(String),
}

pub fn parse_trs(source_name: Option<String>, input: &str) -> Result<crate::core::Trs, ParseError> {
    if input.contains("(format ") || input.contains("(problem") {
        parse_ari_trs(source_name, input)
    } else {
        parse_text_trs(source_name, input)
    }
}
