use thiserror::Error;

use std::collections::{BTreeMap, BTreeSet};

use crate::core::{CsrTrs, RelativeTrs, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};
use crate::proving::{
    ArcticMatrixDomain, BoundsProof, BoundsType, DependencyPairProof, DpArgumentFilter,
    DpArgumentFilterEntry, DpNonterminationProof, DpPathOrderKind, DpReductionPairProof,
    DpRewriteProof, LoopProof, LoopRewriteStep, MatrixDomain, MatrixInterpretation,
    MaxPolynomialSummary, NaturalPolynomial, NonLoopProof, NonterminationProof, PatternEquivalence,
    PatternEquivalenceSide, PatternInstantiationTarget, PatternRule, PatternRuleProof, Proof,
    ProofStep, SrsDerivationPattern, SrsDerivationPatternProof, SrsDerivationPatternStep,
    SrsOverlapClosure, SrsWordPattern, Status, TreeAutomaton, TreeAutomatonTransitionLhs,
    UncurryProof, certificate_improved_csr_dependency_pairs, conservative_csr_dependency_problem,
    csr_dp_proof_requires_minimality, fresh_unhiding_symbol, improved_csr_dependency_pairs,
    is_rta_marking_obligation, muterm_expanded_dependency_pairs, qcs_certificate_usable_rules,
    rewrite_rules_are_variants, rta_csr_dependency_pairs, safe_csr_dependency_pairs,
};

use crate::proving::muterm_innermost_unhiding_rules;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CpfMode {
    Auto,
    Cpf21,
    Cpf30,
    Cpf40,
}

#[derive(Debug, Error)]
pub enum CpfError {
    #[error("CPF 2.1 output is only supported for terminating proofs")]
    Cpf21NonTerminatingProof,

    #[error("CPF output does not yet support proof step: {0}")]
    UnsupportedProofStep(String),
}

pub fn write_cpf(trs: &Trs, proof: &Proof, mode: CpfMode) -> Result<String, CpfError> {
    let requires_cpf4 = proof_requires_cpf4(proof);
    let mode = match mode {
        CpfMode::Auto if requires_cpf4 => CpfMode::Cpf40,
        CpfMode::Auto => CpfMode::Cpf30,
        CpfMode::Cpf30 if requires_cpf4 => {
            return Err(CpfError::UnsupportedProofStep(
                "proof uses CSR or RFC processors that require CPF 4.0".to_string(),
            ));
        }
        mode => mode,
    };
    if matches!(mode, CpfMode::Cpf30 | CpfMode::Cpf40) {
        return write_cpf_document(trs, proof, mode);
    }
    if proof.status() != &Status::Terminating {
        return Err(CpfError::Cpf21NonTerminatingProof);
    }
    let mut xml = String::new();
    write_header(&mut xml);
    write_input(&mut xml, trs);
    xml.push_str("  <cpfVersion>2.1</cpfVersion>\n");
    xml.push_str("  <proof>\n");
    write_trs_termination_proof(&mut xml, trs, proof.steps())?;
    xml.push_str("  </proof>\n");
    write_origin(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

pub fn write_cpf_csr(csr: &CsrTrs, proof: &Proof, mode: CpfMode) -> Result<String, CpfError> {
    let mode = match mode {
        CpfMode::Auto => CpfMode::Cpf40,
        mode => mode,
    };
    if mode != CpfMode::Cpf40 {
        return Err(CpfError::UnsupportedProofStep(
            "CSR proof output requires CPF 4.0".to_string(),
        ));
    }
    if proof.status() == &Status::Unknown {
        return Err(CpfError::UnsupportedProofStep(
            "cannot export an unknown CSR proof".to_string(),
        ));
    }
    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, mode);
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <trsInput>\n");
    write_trs_cpf3(&mut xml, csr.trs(), 6);
    write_context_sensitive_strategy_with_frozen_symbol_cpf3(
        &mut xml,
        csr,
        Some((&fresh_unhiding_symbol(csr.trs()), 1)),
        proof_uses_muterm_typed_replacement_map(proof),
        6,
    );
    xml.push_str("    </trsInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    match proof.status() {
        Status::Terminating => xml.push_str("  <answer><yes/></answer>\n"),
        Status::Nonterminating => xml.push_str("  <answer><no/></answer>\n"),
        Status::Unknown => unreachable!(),
    }
    xml.push_str("  <proof>\n");
    match proof.status() {
        Status::Terminating => write_csr_termination_proof_cpf3(&mut xml, csr, proof, 4)?,
        Status::Nonterminating => {
            xml.push_str("    <trsNonterminationProof>\n");
            write_trs_nontermination_proof_cpf3(&mut xml, proof, 6)?;
            xml.push_str("    </trsNonterminationProof>\n");
        }
        Status::Unknown => unreachable!(),
    }
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

pub fn write_cpf_csr_fragment(csr: &CsrTrs, proof: &Proof) -> Result<String, CpfError> {
    if proof.status() != &Status::Unknown {
        return write_cpf_csr(csr, proof, CpfMode::Cpf40);
    }
    if !proof
        .steps()
        .iter()
        .any(|step| !matches!(step, ProofStep::Unsupported { .. }))
    {
        return Err(CpfError::UnsupportedProofStep(
            "partial CSR proof contains no checkable processor step".to_string(),
        ));
    }

    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, CpfMode::Cpf40);
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <trsInput>\n");
    write_trs_cpf3(&mut xml, csr.trs(), 6);
    write_context_sensitive_strategy_with_frozen_symbol_cpf3(
        &mut xml,
        csr,
        Some((&fresh_unhiding_symbol(csr.trs()), 1)),
        proof_uses_muterm_typed_replacement_map(proof),
        6,
    );
    xml.push_str("    </trsInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    xml.push_str("  <answer><yes/></answer>\n");
    xml.push_str("  <proof>\n");
    write_csr_termination_proof_cpf3(&mut xml, csr, proof, 4)?;
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

pub fn write_trs_input_cpf3(trs: &Trs) -> String {
    let mut xml = String::new();
    xml.push_str("<trsInput>\n");
    write_trs_cpf3(&mut xml, trs, 2);
    write_strategy_cpf3(&mut xml, trs.strategy(), 2);
    xml.push_str("</trsInput>\n");
    xml
}

pub fn write_csr_input_cpf4(csr: &CsrTrs) -> String {
    write_csr_state_input_cpf4(csr, crate::proving::CsrProofBoundary::Root)
}

pub(crate) fn write_csr_state_input_cpf4(
    csr: &CsrTrs,
    boundary: crate::proving::CsrProofBoundary,
) -> String {
    let mut xml = String::new();
    xml.push_str("<trsInput>\n");
    write_trs_cpf3(&mut xml, csr.trs(), 2);
    write_context_sensitive_strategy_cpf3(&mut xml, csr, 2);
    match boundary {
        crate::proving::CsrProofBoundary::Root => {}
        crate::proving::CsrProofBoundary::RootRuleRemovalContinuation => xml
            .push_str("  <ferrumCsrBoundary>root-rule-removal-continuation</ferrumCsrBoundary>\n"),
        crate::proving::CsrProofBoundary::Nested => {
            xml.push_str("  <ferrumCsrBoundary>nested</ferrumCsrBoundary>\n");
        }
    }
    xml.push_str("</trsInput>\n");
    xml
}

pub fn write_dp_input_cpf3(trs: &Trs, pairs: &[crate::proving::DependencyPair]) -> String {
    write_dp_input_with_context_cpf3(trs, pairs, true)
}

pub fn write_relative_trs_input_cpf3(relative: &RelativeTrs) -> String {
    let mut xml = String::new();
    xml.push_str("<trsInput>\n");
    write_trs_cpf3(&mut xml, relative.strict(), 2);
    write_strategy_cpf3(&mut xml, relative.strict().strategy(), 2);
    if !relative.weak_rules().is_empty() {
        xml.push_str("  <relativeRules>\n");
        write_rules_cpf3(&mut xml, relative.weak_rules(), 4);
        xml.push_str("  </relativeRules>\n");
    }
    xml.push_str("</trsInput>\n");
    xml
}

pub fn write_cpf_relative(
    relative: &RelativeTrs,
    proof: &crate::proving::Proof,
    mode: CpfMode,
) -> Result<String, CpfError> {
    if proof.status() != &Status::Terminating && proof.status() != &Status::Nonterminating {
        return Err(CpfError::UnsupportedProofStep(
            "relative proof status unknown".to_string(),
        ));
    }
    let requires_cpf4 = proof_requires_cpf4(proof);
    let mode = match mode {
        CpfMode::Auto if requires_cpf4 => CpfMode::Cpf40,
        CpfMode::Auto => CpfMode::Cpf30,
        CpfMode::Cpf30 if requires_cpf4 => {
            return Err(CpfError::UnsupportedProofStep(
                "relative proof uses CPF 4.0-only features".to_string(),
            ));
        }
        CpfMode::Cpf21 => {
            return Err(CpfError::Cpf21NonTerminatingProof);
        }
        mode => mode,
    };
    if matches!(mode, CpfMode::Cpf30 | CpfMode::Cpf40) {
        return write_cpf_relative_with_mode(relative, proof, mode);
    }
    unreachable!()
}

fn write_cpf_relative_with_mode(
    relative: &RelativeTrs,
    proof: &crate::proving::Proof,
    mode: CpfMode,
) -> Result<String, CpfError> {
    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, mode);
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <trsInput>\n");
    write_trs_cpf3(&mut xml, relative.strict(), 6);
    write_strategy_cpf3(&mut xml, relative.strict().strategy(), 6);
    if !relative.weak_rules().is_empty() {
        xml.push_str("      <relativeRules>\n");
        write_rules_cpf3(&mut xml, relative.weak_rules(), 8);
        xml.push_str("      </relativeRules>\n");
    }
    xml.push_str("    </trsInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    match proof.status() {
        Status::Terminating => xml.push_str("  <answer><yes/></answer>\n"),
        Status::Nonterminating => xml.push_str("  <answer><no/></answer>\n"),
        Status::Unknown => unreachable!(),
    }
    xml.push_str("  <proof>\n");
    match proof.status() {
        Status::Terminating => {
            if let [ProofStep::RelativeAnnotatedDependencyPairProof { proof }] = proof.steps() {
                write_relative_adp_termination_proof_cpf3(&mut xml, relative, proof, 4)?;
            } else {
                xml.push_str("    <trsTerminationProof>\n");
                write_relative_trs_termination_proof_cpf3(&mut xml, relative, proof, 6)?;
                xml.push_str("    </trsTerminationProof>\n");
            }
        }
        Status::Nonterminating => {
            xml.push_str("    <relativeNonterminationProof>\n");
            write_relative_nontermination_proof_cpf3(&mut xml, relative, proof, 6)?;
            xml.push_str("    </relativeNonterminationProof>\n");
        }
        Status::Unknown => unreachable!(),
    }
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

fn write_relative_adp_termination_proof_cpf3(
    xml: &mut String,
    relative: &RelativeTrs,
    proof: &crate::proving::RelativeAdpProof,
    indent: usize,
) -> Result<(), CpfError> {
    write_relative_adp_tree_cpf3(xml, relative, &proof.canonical, &proof.proof, indent)
}

fn write_relative_adp_tree_cpf3(
    xml: &mut String,
    relative: &RelativeTrs,
    problem: &crate::proving::RelativeAdpProblem,
    proof: &crate::proving::RelativeAdpProofTree,
    indent: usize,
) -> Result<(), CpfError> {
    use crate::proving::RelativeAdpProofTree;

    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<relativeAdpTerminationProof>\n"));
    match proof {
        RelativeAdpProofTree::Empty if problem.main.is_empty() => {
            xml.push_str(&format!("{pad}  <relativeAdpEmpty/>\n"));
        }
        RelativeAdpProofTree::ErasureReductionPair {
            step,
            residual,
            proof,
        } => {
            xml.push_str(&format!("{pad}  <relativeAdpErasureReductionPair>\n"));
            write_polynomial_interpretation_for_arities_cpf3(
                xml,
                relative.union().arities(),
                &step.interpretations,
                indent + 4,
            );
            xml.push_str(&format!("{pad}    <mainIndices>\n"));
            for index in &step.strict_main {
                xml.push_str(&format!("{pad}      <index>{index}</index>\n"));
            }
            xml.push_str(&format!("{pad}    </mainIndices>\n"));
            xml.push_str(&format!("{pad}    <baseIndices>\n"));
            for index in &step.strict_base {
                xml.push_str(&format!("{pad}      <index>{index}</index>\n"));
            }
            xml.push_str(&format!("{pad}    </baseIndices>\n"));
            write_relative_adp_tree_cpf3(xml, relative, residual, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </relativeAdpErasureReductionPair>\n"));
        }
        RelativeAdpProofTree::DependencyGraph { children } => {
            xml.push_str(&format!("{pad}  <relativeAdpDependencyGraph>\n"));
            for (child, child_proof) in children {
                write_relative_adp_tree_cpf3(
                    xml,
                    relative,
                    &child.problem,
                    child_proof,
                    indent + 4,
                )?;
            }
            xml.push_str(&format!("{pad}  </relativeAdpDependencyGraph>\n"));
        }
        RelativeAdpProofTree::Polynomial {
            step,
            residual,
            proof,
        } => {
            xml.push_str(&format!("{pad}  <relativeAdpComReductionPair>\n"));
            write_relative_adp_com_polynomial_interpretation_cpf3(
                xml,
                &step.interpretations,
                indent + 4,
            );
            xml.push_str(&format!("{pad}    <mainIndices>\n"));
            for index in &step.strict_main {
                xml.push_str(&format!("{pad}      <index>{index}</index>\n"));
            }
            xml.push_str(&format!("{pad}    </mainIndices>\n"));
            xml.push_str(&format!("{pad}    <baseIndices>\n"));
            for index in &step.strict_base {
                xml.push_str(&format!("{pad}      <index>{index}</index>\n"));
            }
            xml.push_str(&format!("{pad}    </baseIndices>\n"));
            write_relative_adp_tree_cpf3(xml, relative, residual, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </relativeAdpComReductionPair>\n"));
        }
        RelativeAdpProofTree::Derelatify { proof, .. } => {
            xml.push_str(&format!("{pad}  <relativeAdpDerelatification>\n"));
            write_dp_proof_cpf3(xml, proof, indent + 4);
            xml.push_str(&format!("{pad}  </relativeAdpDerelatification>\n"));
        }
        RelativeAdpProofTree::Empty => {
            return Err(CpfError::UnsupportedProofStep(
                "relative ADP empty proof has a nonempty main component".to_string(),
            ));
        }
    }
    xml.push_str(&format!("{pad}</relativeAdpTerminationProof>\n"));
    Ok(())
}

fn write_relative_nontermination_proof_cpf3(
    xml: &mut String,
    relative: &RelativeTrs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    match proof.steps() {
        [
            ProofStep::StringReversal {
                reversed_rules,
                reversed_weak_rules,
                proof,
            },
        ] if proof.status() == &Status::Nonterminating => {
            let pad = " ".repeat(indent);
            let reversed = RelativeTrs::new(
                Trs::new_with_strategy(
                    relative.strict().name().map(str::to_string),
                    relative.strict().variables().clone(),
                    reversed_rules.clone(),
                    relative.strict().strategy(),
                ),
                reversed_weak_rules.clone(),
            );
            xml.push_str(&format!("{pad}<stringReversal>\n"));
            write_rules_trs_cpf3(xml, reversed_rules, indent + 2, "trs");
            write_rules_trs_cpf3(xml, reversed_weak_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <relativeNonterminationProof>\n"));
            write_relative_nontermination_proof_cpf3(xml, &reversed, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </relativeNonterminationProof>\n"));
            xml.push_str(&format!("{pad}</stringReversal>\n"));
            Ok(())
        }
        [
            ProofStep::Nontermination {
                proof: NonterminationProof::Loop(loop_proof),
            },
        ] => {
            let pad = " ".repeat(indent);
            xml.push_str(&format!("{pad}<loop>\n"));
            xml.push_str(&format!("{pad}  <rewriteSequence>\n"));
            xml.push_str(&format!("{pad}    <startTerm>\n"));
            write_term_cpf3(xml, &loop_proof.start, indent + 6);
            xml.push_str(&format!("{pad}    </startTerm>\n"));
            for step in &loop_proof.steps {
                xml.push_str(&format!("{pad}    <rewriteStep>\n"));
                write_position_in_term_cpf3(xml, &step.position, indent + 6);
                write_unindexed_rule_cpf3(xml, &step.rule, indent + 6);
                if relative
                    .weak_rules()
                    .iter()
                    .any(|rule| rewrite_rules_are_variants(rule, &step.rule))
                {
                    xml.push_str(&format!("{pad}      <relative/>\n"));
                }
                write_term_cpf3(xml, &step.result, indent + 6);
                xml.push_str(&format!("{pad}    </rewriteStep>\n"));
            }
            xml.push_str(&format!("{pad}  </rewriteSequence>\n"));
            write_substitution_cpf3(xml, &loop_proof.substitution, indent + 2);
            if let Some(last_step) = loop_proof.steps.last() {
                write_context_cpf3(
                    xml,
                    &last_step.result,
                    &loop_proof.context_position,
                    indent + 2,
                );
            } else {
                xml.push_str(&format!("{pad}  <box/>\n"));
            }
            xml.push_str(&format!("{pad}</loop>\n"));
            Ok(())
        }
        _ => write_trs_nontermination_proof_cpf3(xml, proof, indent),
    }
}

fn relative_without_rules(relative: &RelativeTrs, removed: &[RewriteRule]) -> RelativeTrs {
    let weak = Trs::new_with_strategy(
        relative.strict().name().map(str::to_string),
        relative.strict().variables().clone(),
        relative.weak_rules().to_vec(),
        relative.strict().strategy(),
    );
    RelativeTrs::new(
        trs_without_rules(relative.strict(), removed),
        trs_without_rules(&weak, removed).rules().to_vec(),
    )
}

fn write_relative_trs_termination_proof_cpf3(
    xml: &mut String,
    relative: &RelativeTrs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    match proof.steps() {
        [ProofStep::RelativeBounds { proof: bounds, removed, proof_after_removal }] => {
            let mut weak = relative.weak_rules().to_vec();
            weak.extend(removed.iter().cloned());
            let remaining = RelativeTrs::new(trs_without_rules(relative.strict(), removed), weak);
            xml.push_str(&format!("{pad}<relativeBounds>\n"));
            write_bounds_cpf3(xml, bounds, indent + 2);
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &remaining, proof_after_removal, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n{pad}</relativeBounds>\n"));
        }
        [ProofStep::EmptySystem] if relative.strict().is_empty() => {
            xml.push_str(&format!("{pad}<rIsEmpty/>\n"));
        }
        [
            ProofStep::StringReversal {
                reversed_rules,
                reversed_weak_rules,
                proof,
            },
        ] => {
            let reversed = RelativeTrs::new(
                Trs::new_with_strategy(
                    relative.strict().name().map(str::to_string),
                    relative.strict().variables().clone(),
                    reversed_rules.clone(),
                    relative.strict().strategy(),
                ),
                reversed_weak_rules.clone(),
            );
            xml.push_str(&format!("{pad}<stringReversal>\n"));
            write_rules_trs_cpf3(xml, reversed_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &reversed, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</stringReversal>\n"));
        }
        [
            ProofStep::PolynomialRuleRemoval {
                interpretations,
                removed,
                proof,
            },
        ] => {
            let remaining = relative_without_rules(relative, removed);
            xml.push_str(&format!("{pad}<ruleRemoval>\n"));
            write_polynomial_interpretation_for_arities_cpf3(
                xml,
                relative.union().arities(),
                interpretations,
                indent + 2,
            );
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &remaining, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</ruleRemoval>\n"));
        }
        [
            ProofStep::MatrixRuleRemoval {
                interpretations,
                dimension,
                strict_dimension,
                domain,
                removed,
                proof,
            },
        ] => {
            let remaining = relative_without_rules(relative, removed);
            write_matrix_rule_removal_with_relative_proof_cpf3(
                xml,
                relative.union().arities(),
                interpretations,
                *dimension,
                *strict_dimension,
                *domain,
                removed,
                &remaining,
                proof,
                indent,
            )?;
        }
        // These processors already carry relative-specific CPF witnesses, or
        // transform the relative obligation into the explicit TRS stored in
        // the proof step.  Their existing writer therefore remains the
        // authoritative serializer.
        _ => write_trs_termination_proof_cpf3(xml, relative.strict(), proof, indent)?,
    }
    Ok(())
}

#[cfg(test)]
pub(crate) fn write_csr_dp_input_cpf4(
    csr: &CsrTrs,
    pairs: &[crate::proving::DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    construction: &str,
    graph_estimator: &str,
    use_qcs_usable_rules: bool,
) -> String {
    write_csr_dp_state_input_cpf4(
        csr,
        pairs,
        &[],
        active_rules,
        minimal,
        construction,
        graph_estimator,
        use_qcs_usable_rules,
    )
}

pub(crate) fn write_csr_dp_state_input_cpf4(
    csr: &CsrTrs,
    pairs: &[crate::proving::DependencyPair],
    weak_pairs: &[crate::proving::DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    construction: &str,
    graph_estimator: &str,
    use_qcs_usable_rules: bool,
) -> String {
    let mut xml = String::new();
    xml.push_str("<dpInput>\n");
    write_rules_trs_cpf3(&mut xml, csr.trs().rules(), 2, "trs");
    write_dependency_pairs_trs_cpf3(&mut xml, pairs, 2, "dps");
    if !weak_pairs.is_empty() {
        write_dependency_pairs_trs_cpf3(&mut xml, weak_pairs, 2, "ferrumWeakDps");
    }
    if let Some(active_rules) = active_rules {
        write_rules_trs_cpf3(&mut xml, active_rules, 2, "usableRules");
    }
    let unhiding_symbol = fresh_unhiding_symbol(csr.trs());
    let has_improved_unhiding_pair = construction == "improved"
        && pairs.iter().chain(weak_pairs).any(|pair| {
            pair.lhs().root_symbol() == Some(&unhiding_symbol)
                || pair.rhs().root_symbol() == Some(&unhiding_symbol)
        });
    if has_improved_unhiding_pair {
        // Improved CS-DPs use the fresh U symbol to expose hidden calls, but
        // rewriting below that wrapper remains frozen.  The symbol is absent
        // from the original TRS signature, so it must be written explicitly
        // instead of being lost by the generic CSR map serializer.
        write_context_sensitive_strategy_with_extra_symbol_cpf3(
            &mut xml,
            csr,
            Some((&unhiding_symbol, 1, false)),
            false,
            2,
        );
    } else {
        write_context_sensitive_strategy_cpf3(&mut xml, csr, 2);
    }
    xml.push_str(&format!("  <minimal>{minimal}</minimal>\n"));
    xml.push_str("  <ferrumCsrDpContext>\n");
    xml.push_str(&format!(
        "    <construction>{}</construction>\n",
        escape_xml(construction)
    ));
    xml.push_str(&format!(
        "    <graphEstimator>{}</graphEstimator>\n",
        escape_xml(graph_estimator)
    ));
    xml.push_str(&format!(
        "    <qcsUsableRules>{use_qcs_usable_rules}</qcsUsableRules>\n"
    ));
    xml.push_str("  </ferrumCsrDpContext>\n");
    xml.push_str("</dpInput>\n");
    xml
}

pub(crate) fn write_dp_input_with_context_cpf3(
    trs: &Trs,
    pairs: &[crate::proving::DependencyPair],
    normal_form_substitutions: bool,
) -> String {
    write_dp_state_input_cpf3(trs, pairs, None, true, normal_form_substitutions)
}

pub(crate) fn write_dp_state_input_cpf3(
    trs: &Trs,
    pairs: &[crate::proving::DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    normal_form_substitutions: bool,
) -> String {
    write_relative_dp_state_input_cpf3(
        trs,
        pairs,
        &[],
        active_rules,
        minimal,
        normal_form_substitutions,
    )
}

pub(crate) fn write_relative_dp_state_input_cpf3(
    trs: &Trs,
    pairs: &[crate::proving::DependencyPair],
    weak_pairs: &[crate::proving::DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    normal_form_substitutions: bool,
) -> String {
    let mut xml = String::new();
    xml.push_str("<dpInput>\n");
    write_rules_trs_cpf3(&mut xml, trs.rules(), 2, "trs");
    write_dependency_pairs_trs_cpf3(&mut xml, pairs, 2, "dps");
    if !weak_pairs.is_empty() {
        write_dependency_pairs_trs_cpf3(&mut xml, weak_pairs, 2, "ferrumWeakDps");
    }
    if let Some(active_rules) = active_rules {
        write_rules_trs_cpf3(&mut xml, active_rules, 2, "usableRules");
    }
    if trs.strategy() == RewriteStrategy::Full && normal_form_substitutions {
        write_empty_q_innermost_lhss_strategy_cpf3(&mut xml, true, 2);
    } else {
        write_dp_strategy_cpf3(&mut xml, trs.strategy(), normal_form_substitutions, 2);
    }
    xml.push_str(&format!("  <minimal>{minimal}</minimal>\n"));
    xml.push_str("</dpInput>\n");
    xml
}

/// Add Ferrum's executable DP-state context to a standard CPF assumption.
///
/// CPF's `dpInput` records the mathematical DP problem, but it has no input
/// fields for the current Q left-hand sides or the distinct graph and
/// transformation rule sets.  Those values affect later processor
/// applicability, so oracle/campaign states must retain them.  Complete
/// certificates strip this metadata before presenting assumptions to CeTA.
pub(crate) fn append_ferrum_dp_state_context(
    mut xml: String,
    pair_source_rules: &[usize],
    weak_pair_source_rules: &[usize],
    strict_rules: &[RewriteRule],
    innermost_lhss: Option<&[Term]>,
    clear_innermost_lhss: bool,
    graph_rules: Option<&[RewriteRule]>,
    transformation_rules: Option<&[RewriteRule]>,
    active_rules_are_residual: bool,
    ordinary_reduction_started: bool,
    ordinary_bridge_loses_minimality: bool,
    innermost_rewrite_strategy: bool,
    semantic_csr_continuation: bool,
) -> String {
    if pair_source_rules.is_empty()
        && weak_pair_source_rules.is_empty()
        && strict_rules.is_empty()
        && innermost_lhss.is_none()
        && !clear_innermost_lhss
        && graph_rules.is_none()
        && transformation_rules.is_none()
        && !active_rules_are_residual
        && !ordinary_reduction_started
        && !ordinary_bridge_loses_minimality
        && !innermost_rewrite_strategy
        && !semantic_csr_continuation
    {
        return xml;
    }
    let Some(position) = xml.rfind("</dpInput>") else {
        return xml;
    };
    let mut context = String::new();
    context.push_str("  <ferrumDpStateContext>\n");
    if innermost_rewrite_strategy {
        context.push_str("    <rewriteStrategy>innermost</rewriteStrategy>\n");
    }
    if !pair_source_rules.is_empty() {
        context.push_str("    <pairSourceRules>");
        for source_rule in pair_source_rules {
            context.push_str(&format!("<sourceRule>{source_rule}</sourceRule>"));
        }
        context.push_str("</pairSourceRules>\n");
    }
    if !weak_pair_source_rules.is_empty() {
        context.push_str("    <weakPairSourceRules>");
        for source_rule in weak_pair_source_rules {
            context.push_str(&format!("<sourceRule>{source_rule}</sourceRule>"));
        }
        context.push_str("</weakPairSourceRules>\n");
    }
    if !strict_rules.is_empty() {
        write_rules_trs_cpf3(&mut context, strict_rules, 4, "strictRules");
    }
    if let Some(lhss) = innermost_lhss {
        context.push_str("    <innermostLhss>\n");
        for lhs in lhss {
            write_term_cpf3(&mut context, lhs, 6);
        }
        context.push_str("    </innermostLhss>\n");
    } else if clear_innermost_lhss {
        context.push_str("    <noInnermostLhss/>\n");
    }
    if let Some(rules) = graph_rules {
        write_rules_trs_cpf3(&mut context, rules, 4, "graphRules");
    }
    if let Some(rules) = transformation_rules {
        write_rules_trs_cpf3(&mut context, rules, 4, "transformationRules");
    }
    if active_rules_are_residual {
        context.push_str("    <activeRulesAreResidual>true</activeRulesAreResidual>\n");
    }
    context.push_str(&format!(
        "    <ordinaryReductionStarted>{ordinary_reduction_started}</ordinaryReductionStarted>\n"
    ));
    if ordinary_bridge_loses_minimality {
        context
            .push_str("    <ordinaryBridgeLosesMinimality>true</ordinaryBridgeLosesMinimality>\n");
    }
    if semantic_csr_continuation {
        context.push_str("    <semanticCsrContinuation>true</semanticCsrContinuation>\n");
    }
    context.push_str("  </ferrumDpStateContext>\n");
    xml.insert_str(position, &context);
    xml
}

pub fn write_cpf_fragment(trs: &Trs, proof: &Proof) -> Result<String, CpfError> {
    let mode = if proof_requires_cpf4(proof) {
        CpfMode::Cpf40
    } else {
        CpfMode::Cpf30
    };
    write_cpf_fragment_with_mode(trs, proof, mode)
}

pub fn write_cpf3_fragment(trs: &Trs, proof: &Proof) -> Result<String, CpfError> {
    if proof_requires_cpf4(proof) {
        return Err(CpfError::UnsupportedProofStep(
            "partial proof uses extension processors that require CPF 4.0".to_string(),
        ));
    }
    write_cpf_fragment_with_mode(trs, proof, CpfMode::Cpf30)
}

fn write_cpf_fragment_with_mode(
    trs: &Trs,
    proof: &Proof,
    mode: CpfMode,
) -> Result<String, CpfError> {
    if proof.status() != &Status::Unknown {
        return write_cpf_document(trs, proof, mode);
    }
    if !proof
        .steps()
        .iter()
        .any(|step| !matches!(step, ProofStep::Unsupported { .. }))
    {
        return Err(CpfError::UnsupportedProofStep(
            "partial proof contains no checkable processor step".to_string(),
        ));
    }

    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, mode);
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <trsInput>\n");
    write_trs_cpf3(&mut xml, trs, 6);
    write_strategy_cpf3(&mut xml, trs.strategy(), 6);
    xml.push_str("    </trsInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    xml.push_str("  <answer><yes/></answer>\n");
    xml.push_str("  <proof>\n");
    xml.push_str("    <trsTerminationProof>\n");
    write_trs_termination_proof_cpf3(&mut xml, trs, proof, 6)?;
    xml.push_str("    </trsTerminationProof>\n");
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

pub fn write_cpf3_dp_problem(
    trs: &Trs,
    pairs: &[crate::proving::DependencyPair],
    proof: &crate::proving::DependencyPairProof,
) -> String {
    let mut xml = String::new();
    xml.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    xml.push_str("<certificationProblem xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"cpf3.xsd\">\n");
    xml.push_str("  <cpfVersion>3.0</cpfVersion>\n");
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <dpInput>\n");
    write_trs_cpf3(&mut xml, trs, 6);
    write_dependency_pairs_trs_cpf3(&mut xml, pairs, 6, "dps");
    write_strategy_cpf3(&mut xml, trs.strategy(), 6);
    xml.push_str("      <minimal>true</minimal>\n");
    xml.push_str("    </dpInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    xml.push_str("  <answer><yes/></answer>\n");
    xml.push_str("  <proof>\n");
    write_dp_proof_cpf3(&mut xml, proof, 4);
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    xml
}

/// Export precisely the independently materialized ordinary DP obligation.
/// Original rules are provenance, not a replacement for the active R. Q and
/// normal-form substitutions are explicit to avoid implicitly recomputing Q
/// from the (possibly reduced or empty) active rules.
pub(crate) fn write_cpf3_dp_termination_state(
    state: &crate::proving::DpProblemState,
    proof: &crate::proving::DependencyPairProof,
) -> Result<String, CpfError> {
    use crate::proving::{DependencyPair, DpComponentProof, DpProofTree};
    if !matches!(state.stats.problem, crate::proving::DpProblemContext::Ordinary)
        || state.stats.semantic_csr_context.is_some()
        || state.trs.strategy() == RewriteStrategy::Outermost
    {
        return Err(CpfError::UnsupportedProofStep(
            "standalone ordinary DP export cannot discard CSR or outermost context".into(),
        ));
    }
    let relative = !state.stats.weak_pairs.is_empty() || !state.stats.strict_rules.is_empty();
    // A standalone input carries literal live rules. An enclosing generated
    // transformation may instead reconstruct alpha-equivalent helper rules.
    // Bind direct processor witnesses to this input, not that absent parent.
    let mut proof = proof.clone();
    fn bind_component(component: &mut DpComponentProof, rules: &[RewriteRule]) -> Result<(), CpfError> {
        let rules = component.usable_rules_processor.as_deref().unwrap_or(rules);
        fn bind_tree(tree: &mut DpProofTree, pairs: &[DependencyPair], rules: &[RewriteRule]) -> Result<(), CpfError> {
            match tree {
                DpProofTree::DepGraph { components } => {
                    for component in components { bind_component(component, rules)?; }
                }
                DpProofTree::ComponentContext { usable_rules_processor, proof, .. } => {
                    bind_tree(proof, pairs, usable_rules_processor.as_deref().unwrap_or(rules))?;
                }
                DpProofTree::ReductionPairExact { payload_xml, .. } => {
                    let live_pairs = pairs.iter().map(|p| p.as_rule()).collect::<Vec<_>>();
                    *payload_xml = crate::proving::rebind_standalone_rule_variables(
                        payload_xml, &live_pairs, rules).map_err(CpfError::UnsupportedProofStep)?;
                    // This is the processor at this state. Its continuation
                    // has its own state and must not inherit these bindings.
                }
                _ => {}
            }
            Ok(())
        }
        if let Some(tree) = &mut component.proof_tree {
            bind_tree(tree, &component.pairs, rules)?;
        }
        Ok(())
    }
    for component in &mut proof.component_proofs {
        bind_component(component, state.stats.active_rules.as_deref().unwrap_or(state.trs.rules()))?;
    }
    let mut xml = write_cpf3_dp_problem(&state.trs, &state.pairs, &proof);
    let input_tag = if relative { "relativeDpInput" } else { "dpInput" };
    let mut input = format!("<input>\n<{input_tag}>\n");
    let active_rules = state.stats.active_rules.as_deref().unwrap_or_else(|| state.trs.rules());
    // Runtime R is the complete rule universe with a strict subset, just
    // as runtime P includes its weak subset. CPF separates R and Rw.
    // Duplicating a strict rule in Rw makes semantic labeling classify all
    // its images as weak, leaving the strict obligation unrepresented.
    let weak_rules = active_rules.iter().filter(|rule| !state.stats.strict_rules.iter()
        .any(|strict| crate::proving::alpha_equivalent_rules(rule, strict)))
        .cloned().collect::<Vec<_>>();
    write_rules_trs_cpf3(&mut input, &weak_rules, 2, "trs");
    // Runtime pairs are the union of strict and weak pairs. They must not be
    // copied into both CPF components: doing so strengthens a weak-only
    // residual back into a strict obligation.
    let strict_pairs = state.pairs.iter().filter(|pair| !state.stats.pair_is_weak(pair))
        .cloned().collect::<Vec<_>>();
    write_dependency_pairs_trs_cpf3(&mut input, &strict_pairs, 2, "dps");
    if relative {
        write_dependency_pairs_trs_cpf3(&mut input, &state.stats.weak_pairs, 2, "weakDps");
        write_rules_trs_cpf3(&mut input, &state.stats.strict_rules, 2, "strictRules");
    }
    input.push_str("  <strategy><innermostLhss>\n");
    input.push_str(&format!("    <nfs>{}</nfs>\n", state.stats.normal_form_substitutions));
    for term in state.innermost_lhss.as_deref().unwrap_or(&[]) {
        write_term_cpf3(&mut input, term, 4);
    }
    input.push_str("  </innermostLhss></strategy>\n");
    input.push_str(&format!("  <minimal>{}</minimal>\n</{input_tag}>\n</input>", state.stats.minimal));
    let start = xml.find("<input>").expect("generated CPF input");
    let end = xml.find("</input>").expect("generated CPF input end") + "</input>".len();
    xml.replace_range(start..end, &input);
    if relative {
        xml = xml.replacen("<proof>", "<proof><relativeDpProof>", 1);
        let end = xml.rfind("</proof>").expect("generated CPF proof end");
        xml.insert_str(end, "</relativeDpProof>");
    }
    Ok(canonicalize_cpf_numeric_symbol_names(lift_gm04_source_bridges(xml)?))
}

/// Certify a CSR residual in its own chain semantics, never as ordinary DPs.
pub(crate) fn write_cpf4_csr_dp_termination_state(
    state: &crate::proving::DpProblemState,
    proof: &crate::proving::DependencyPairProof,
) -> Result<String, CpfError> {
    use crate::proving::DpProblemContext;
    let context = match &state.stats.problem {
        DpProblemContext::ContextSensitive(context) if state.stats.semantic_csr_context.is_none() => context,
        // A semantic-labeling continuation retains a CSR chain obligation,
        // despite using the ordinary processor vocabulary at runtime. Export
        // it with its map and nonminimal flag, never as an ordinary DP input.
        // The existing nonminimal CSR checker must still accept the proof;
        // this does not grant standalone support to every semantic tail.
        DpProblemContext::Ordinary if !state.stats.minimal => {
            state.stats.semantic_csr_context.as_ref().ok_or_else(||
                CpfError::UnsupportedProofStep("expected a CSR-DP residual".into()))?
        }
        _ => return Err(CpfError::UnsupportedProofStep("expected a CSR-DP residual".into())),
    };
    // Safe CS-DPs are deliberately an ordinary minimal DP obligation:
    // safe_csr_dependency_pairs_tt_finite_safe_CSDP_on establishes precisely
    // finite_dpp (False, True, P, {}, {}, {}, R). This is not the minimal
    // CSR-chain obligation used by the native/improved constructions.
    if context.construction.as_str() == "safe"
        && !state.stats.normal_form_substitutions
        && state.innermost_lhss.as_ref().is_none_or(|q| q.is_empty())
        && context.innermost_q_lhss.as_ref().is_none_or(|q| q.is_empty())
        && state.stats.semantic_csr_context.is_none()
    {
        let mut ordinary = state.clone();
        ordinary.stats.problem = DpProblemContext::Ordinary;
        return write_cpf3_dp_termination_state(&ordinary, proof);
    }
    if context.construction.as_str() == "muterm-unhiding"
        && state.pairs.iter().any(|pair| matches!(pair.rhs(), Term::Var(_)))
        && state.stats.minimal
        && !state.stats.normal_form_substitutions
        && state.stats.weak_pairs.is_empty()
        && state.stats.strict_rules.is_empty()
        && state.innermost_lhss.as_ref().is_none_or(|q| q.is_empty())
        && context.innermost_q_lhss.as_ref().is_none_or(|q| q.is_empty())
        && state.stats.semantic_csr_context.is_none()
        && state.stats.active_rules.as_deref().is_none_or(|r| r == context.csr.rules())
    {
        return write_cpf4_muterm_typed_dp_problem(&context.csr, &state.pairs, proof);
    }
    // Noncollapsing typed MU-TERM components admit a CSR-chain proof directly:
    // finite_min_csr_dpp_imp_finite_muterm_min_typed_noncollapsing.
    // Collapsing pairs require their separate unhiding component and must
    // never pass through this entry merely by forgetting that component.
    let noncollapsing_muterm = context.construction.as_str() == "muterm-unhiding"
        && state.pairs.iter().all(|pair| matches!(pair.rhs(), Term::App { .. }));
    if !(matches!(context.construction.as_str(), "improved" | "native") || noncollapsing_muterm)
        || state.stats.normal_form_substitutions
        || !state.stats.weak_pairs.is_empty()
        || !state.stats.strict_rules.is_empty()
        || state.innermost_lhss.as_ref().is_some_and(|q| !q.is_empty())
        || context.innermost_q_lhss.as_ref().is_some_and(|q| !q.is_empty())
        || (state.stats.semantic_csr_context.is_some() && state.stats.minimal)
    {
        if context.construction.as_str() == "muterm-unhiding" {
            return Err(CpfError::UnsupportedProofStep(
                "standalone typed MU-TERM residual requires a source-relative local obligation: preserve source CSR, replacement map, local unhiding bridges and usable rules; the existing minimal typed input cannot encode this context".into(),
            ));
        }
        return Err(CpfError::UnsupportedProofStep(
            "standalone CSR-DP certification requires a native/improved residual with empty Q and no relative constraints".into(),
        ));
    }
    Ok(write_cpf4_csr_dp_problem(&context.csr, &state.pairs,
        state.stats.active_rules.as_deref(), state.stats.minimal, proof))
}

fn write_cpf4_muterm_typed_dp_problem(
    csr: &CsrTrs,
    pairs: &[crate::proving::DependencyPair],
    proof: &crate::proving::DependencyPairProof,
) -> Result<String, CpfError> {
    let unhiding_rules = muterm_innermost_unhiding_rules(csr);
    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, CpfMode::Cpf40);
    xml.push_str("  <lookupTables/>\n  <input><csrMutermTypedDpInput>\n");
    write_rules_trs_cpf3(&mut xml, csr.rules(), 4, "trs");
    write_dependency_pairs_trs_cpf3(&mut xml, pairs, 4, "dps");
    write_rules_trs_cpf3(&mut xml, &unhiding_rules, 4, "unhidingRules");
    // Preserve every residual symbol and lift the source map to Sharp.
    let mut rules = csr.rules().to_vec();
    rules.extend(unhiding_rules.iter().cloned());
    rules.extend(pairs.iter().map(|p| RewriteRule::new(p.lhs().clone(), p.rhs().clone())));
    let mut signature = Trs::new(None, BTreeSet::new(), rules).arities();
    for (symbol, arity) in signature.clone() {
        if !symbol.as_str().ends_with('#') {
            signature.entry(Symbol::new(format!("{symbol}#"))).or_insert(arity);
        }
    }
    xml.push_str("    <strategy><contextSensitive>\n");
    for (symbol, arity) in signature {
        xml.push_str("      <replacementMapEntry>\n");
        write_symbol_cpf3(&mut xml, symbol.as_str(), 8);
        xml.push_str(&format!("        <arity>{arity}</arity>\n"));
        let unmarked = symbol.as_str().strip_suffix('#').map(Symbol::new);
        let positions = csr.replacement_map().allowed_positions(&symbol)
            .or_else(|| unmarked.as_ref().and_then(|base| csr.replacement_map().allowed_positions(base)));
        if let Some(positions) = positions {
            for position in positions {
                xml.push_str(&format!("        <position>{}</position>\n", position + 1));
            }
        }
        xml.push_str("      </replacementMapEntry>\n");
    }
    xml.push_str("    </contextSensitive></strategy>\n    <minimal>true</minimal>\n");
    xml.push_str("  </csrMutermTypedDpInput></input>\n");
    xml.push_str("  <property><termination/></property>\n  <answer><yes/></answer>\n");
    xml.push_str("  <proof><csrMutermTypedDpProof>\n");
    let mut typed_proof = proof.clone();
    normalize_muterm_redundant_splits(&mut typed_proof);
    // A materialized worklist proof is wrapped in one component covering P.
    // If its first action is graph decomposition, export that actual action
    // directly, not a redundant outer graph around an identical obligation.
    // No pairs, rules, or contextual processor boundary may be crossed here.
    while typed_proof.component_proofs.len() == 1
        && typed_proof.component_proofs[0].pairs == typed_proof.pairs
    {
        let Some(crate::proving::DpProofTree::DepGraph { components }) =
            typed_proof.component_proofs[0].proof_tree.as_deref()
        else { break };
        typed_proof.component_proofs = components.clone();
        typed_proof.components = typed_proof.component_proofs.len();
    }
    write_muterm_typed_dp_proof_cpf3(&mut xml, &typed_proof, csr, &unhiding_rules, 4)?;
    xml.push_str("  </csrMutermTypedDpProof></proof>\n</certificationProblem>\n");
    Ok(xml)
}

pub(crate) fn write_cpf4_csr_dp_problem(
    csr: &CsrTrs,
    pairs: &[crate::proving::DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    proof: &crate::proving::DependencyPairProof,
) -> String {
    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, CpfMode::Cpf40);
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <csrImprovedDpInput>\n");
    write_rules_trs_cpf3(
        &mut xml,
        active_rules.unwrap_or_else(|| csr.trs().rules()),
        6,
        "trs",
    );
    write_dependency_pairs_trs_cpf3(&mut xml, pairs, 6, "dps");
    let source_arities = csr.trs().arities();
    let unhiding = csr.replacement_map().entries().keys()
        .find(|symbol| !source_arities.contains_key(*symbol) && !symbol.as_str().ends_with('#'))
        .cloned().unwrap_or_else(|| fresh_unhiding_symbol(csr.trs()));
    // R can have lost every occurrence of a symbol still present in P.
    // Derive arities from both, retaining the source map rather than silently
    // freezing those symbols or omitting an auxiliary wrapper after renaming.
    let mut signature_rules = csr.rules().to_vec();
    signature_rules.extend(pairs.iter().map(|p| RewriteRule::new(p.lhs().clone(), p.rhs().clone())));
    let mut signature = Trs::new(None, BTreeSet::new(), signature_rules).arities();
    signature.entry(unhiding.clone()).or_insert(1);
    // Sharp side steps use the lifted source map, including symbols that
    // survive only in R. This is the same extension as the root CSR exporter.
    for (symbol, arity) in signature.clone() {
        if !symbol.as_str().ends_with('#') {
            signature.entry(Symbol::new(format!("{symbol}#"))).or_insert(arity);
        }
    }
    xml.push_str("      <strategy><contextSensitive>\n");
    for (symbol, arity) in signature {
        xml.push_str("        <replacementMapEntry>\n");
        write_symbol_cpf3(&mut xml, symbol.as_str(), 10);
        xml.push_str(&format!("          <arity>{arity}</arity>\n"));
        let unmarked = symbol.as_str().strip_suffix('#').map(Symbol::new);
        let positions = csr.replacement_map().allowed_positions(&symbol)
            .or_else(|| unmarked.as_ref().and_then(|base| csr.replacement_map().allowed_positions(base)));
        if let Some(positions) = positions {
            for position in positions {
                xml.push_str(&format!("          <position>{}</position>\n", position + 1));
            }
        }
        xml.push_str("        </replacementMapEntry>\n");
    }
    xml.push_str("      </contextSensitive></strategy>\n");
    xml.push_str(&format!("      <minimal>{minimal}</minimal>\n"));
    xml.push_str("      <unhidingSymbol>\n");
    write_symbol_cpf3(&mut xml, unhiding.as_str(), 8);
    xml.push_str("      </unhidingSymbol>\n");
    xml.push_str("    </csrImprovedDpInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    xml.push_str("  <answer><yes/></answer>\n");
    xml.push_str("  <proof>\n");
    // The continuation must see the active R, not provenance rules.
    let active_trs = Trs::new_with_strategy(csr.trs().name().map(str::to_owned),
        csr.trs().variables().clone(), active_rules.unwrap_or_else(|| csr.rules()).to_vec(),
        RewriteStrategy::Full);
    // CsrTrs validates only symbols in R. The input above retains the full
    // residual map, including fresh symbols that occur solely in P.
    let active_arities = active_trs.arities();
    let active_map = crate::core::ReplacementMap::new(csr.replacement_map().entries()
        .iter().filter(|(symbol, _)| active_arities.contains_key(*symbol))
        .map(|(symbol, positions)| (symbol.clone(), positions.clone())).collect());
    let active_csr = CsrTrs::new(active_trs, active_map)
        .expect("deleting rules preserves replacement-map validity");
    let mut proof = proof.clone();
    convert_complete_subterm_closures_to_csr_size_change(&mut proof);
    xml.push_str("    <csrImprovedDpProof>\n");
    if !minimal {
        // A nonminimal ordinary DP proof is a sound stronger obligation for
        // CSR chains (plain_csr_dpp_finite_dpp_imp_finite_csr_dpp). In
        // particular, do not relabel an ordinary redPairUrProc as CSR U3.
        fn write_nonminimal_graph(
            xml: &mut String, components: &[crate::proving::DpComponentProof],
            strategy: RewriteStrategy, indent: usize,
        ) {
            let pad = " ".repeat(indent);
            xml.push_str(&format!("{pad}<csrDpProof><depGraphProc>\n"));
            for component in components {
                xml.push_str(&format!("{pad}  <component>\n"));
                write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 4, "dps");
                if component.proved {
                    if let Some(crate::proving::DpProofTree::DepGraph { components }) =
                        component.proof_tree.as_deref()
                    {
                        write_nonminimal_graph(xml, components, strategy, indent + 4);
                    } else {
                        xml.push_str(&format!("{pad}    <csrDpProof><ordinaryDpProof><dpProof>\n"));
                        write_dp_reduction_trace_cpf3(xml, component, strategy, indent + 6);
                        xml.push_str(&format!("{pad}    </dpProof></ordinaryDpProof></csrDpProof>\n"));
                    }
                }
                xml.push_str(&format!("{pad}  </component>\n"));
            }
            xml.push_str(&format!("{pad}</depGraphProc></csrDpProof>\n"));
        }
        // Graph edges still use the supplied replacement map. Only the
        // terminal ordinary processors use the stronger full-DP obligation.
        write_nonminimal_graph(&mut xml, &proof.component_proofs, proof.strategy, 6);
    } else if proof.component_proofs.iter().any(|component| {
        component.proof_tree.as_deref().is_some_and(csr_dp_tree_contains_guarded_list_terminal)
    }) {
        write_guarded_csr_dp_proof_cpf3(&mut xml, &proof, active_csr.rules(), 6);
    } else {
        write_csr_dp_proof_cpf3(&mut xml, &proof, &active_csr, false, 6);
    }
    xml.push_str("    </csrImprovedDpProof>\n");
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    canonicalize_cpf_numeric_symbol_names(xml)
}

pub(crate) fn write_cpf3_dp_nontermination_state(
    state: &crate::proving::DpProblemState,
    proof: &DpNonterminationProof,
) -> Result<String, CpfError> {
    if !matches!(state.stats.problem, crate::proving::DpProblemContext::Ordinary)
        || state.stats.semantic_csr_context.is_some()
        || state.trs.strategy() == crate::core::RewriteStrategy::Outermost
        || !state.stats.weak_pairs.is_empty() || !state.stats.strict_rules.is_empty()
    {
        return Err(CpfError::UnsupportedProofStep(
            "standalone DP nontermination export cannot discard CSR, outermost, or relative context".into()));
    }
    // Runtime provenance is not a CPF input field. Preserve the mathematical
    // active R, minimality, Q and NFS using the standard innermostLhss input,
    // without serializing Ferrum-only provenance metadata.
    let trs = Trs::new_with_strategy(state.trs.name().map(str::to_owned),
        state.trs.variables().clone(), state.stats.active_rules.clone()
            .unwrap_or_else(|| state.trs.rules().to_vec()), state.trs.strategy());
    let mut xml = write_cpf3_dp_nontermination_problem(&trs, &state.pairs, proof)?;
    let mut input = String::from("<dpInput>\n");
    write_rules_trs_cpf3(&mut input, trs.rules(), 2, "trs");
    write_dependency_pairs_trs_cpf3(&mut input, &state.pairs, 2, "dps");
    input.push_str("  <strategy><innermostLhss>\n");
    input.push_str(&format!("    <nfs>{}</nfs>\n", state.stats.normal_form_substitutions));
    for term in state.innermost_lhss.as_deref().unwrap_or(&[]) {
        write_term_cpf3(&mut input, term, 4);
    }
    input.push_str("  </innermostLhss></strategy>\n");
    input.push_str(&format!("  <minimal>{}</minimal>\n</dpInput>\n", state.stats.minimal));
    let start = xml.find("<input>").expect("generated CPF input");
    let end = xml.find("</input>").expect("generated CPF input end") + "</input>".len();
    xml.replace_range(start..end, &format!("<input>\n{input}\n</input>"));
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

pub fn write_cpf3_dp_nontermination_problem(
    trs: &Trs,
    pairs: &[crate::proving::DependencyPair],
    proof: &DpNonterminationProof,
) -> Result<String, CpfError> {
    let mut xml = String::new();
    xml.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    xml.push_str("<certificationProblem xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"cpf3.xsd\">\n");
    xml.push_str("  <cpfVersion>3.0</cpfVersion>\n");
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <dpInput>\n");
    write_trs_cpf3(&mut xml, trs, 6);
    write_dependency_pairs_trs_cpf3(&mut xml, pairs, 6, "dps");
    write_strategy_cpf3(&mut xml, trs.strategy(), 6);
    xml.push_str("      <minimal>true</minimal>\n");
    xml.push_str("    </dpInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    xml.push_str("  <answer><no/></answer>\n");
    xml.push_str("  <proof>\n");
    xml.push_str("    <dpNonterminationProof>\n");
    write_dp_nontermination_proof_cpf3(&mut xml, proof, pairs, 6)?;
    xml.push_str("    </dpNonterminationProof>\n");
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(xml))
}

fn write_meta_information_cpf3(xml: &mut String) {
    xml.push_str("  <metaInformation>\n");
    xml.push_str("    <toolInfos>\n");
    xml.push_str("      <toolInfo>Ferrum ");
    xml.push_str(env!("CARGO_PKG_VERSION"));
    xml.push_str("</toolInfo>\n");
    xml.push_str("    </toolInfos>\n");
    xml.push_str("  </metaInformation>\n");
}

pub(crate) fn gm04_source_dp_context_xml(
    inverse: &crate::proving::Gm04InverseCsr,
    top_sharp: &Symbol,
    source: &Proof,
    state: &crate::proving::DpProblemState,
) -> Result<String, CpfError> {
    let mut xml = String::from("<gm04StandaloneDpProof><sourceReplacementMap><contextSensitive>\n");
    let empty = BTreeSet::new();
    for (symbol, arity) in &inverse.source_signature {
        xml.push_str("<replacementMapEntry>");
        write_symbol_cpf3(&mut xml, symbol.as_str(), 0);
        xml.push_str(&format!("<arity>{arity}</arity>"));
        for position in inverse.source_replacement_map.allowed_positions(symbol).unwrap_or(&empty) {
            xml.push_str(&format!("<position>{}</position>", position + 1));
        }
        xml.push_str("</replacementMapEntry>\n");
    }
    xml.push_str("</contextSensitive></sourceReplacementMap><sourceTrs>\n");
    write_rules_cpf3(&mut xml, inverse.csr.rules(), 0);
    xml.push_str("</sourceTrs>\n");
    for (tag, symbol) in [
        ("activeSymbol", &inverse.active_symbol), ("markSymbol", &inverse.mark_symbol),
        ("properSymbol", &inverse.proper_symbol), ("okSymbol", &inverse.ok_symbol),
        ("topSymbol", &inverse.top_symbol), ("topSharpSymbol", top_sharp),
    ] {
        xml.push_str(&format!("<{tag}>"));
        write_symbol_cpf3(&mut xml, symbol.as_str(), 0);
        xml.push_str(&format!("</{tag}>\n"));
    }
    xml.push_str("<transformedProof><dpProof><finitenessAssumption>\n");
    // Q belongs to the live obligation, not to its possibly reduced R.
    // In particular, do not reconstruct it from an innermost strategy tag.
    xml.push_str("<dpInput>\n");
    write_rules_trs_cpf3(&mut xml, state.stats.active_rules.as_deref().unwrap_or(state.trs.rules()), 0, "trs");
    write_dependency_pairs_trs_cpf3(&mut xml, &state.pairs, 0, "dps");
    xml.push_str("<strategy><innermostLhss><nfs>true</nfs>\n");
    for term in state.innermost_lhss.as_deref().unwrap_or(&[]) {
        write_term_cpf3(&mut xml, term, 0);
    }
    xml.push_str("</innermostLhss></strategy><minimal>true</minimal></dpInput>\n");
    xml.push_str("</finitenessAssumption></dpProof></transformedProof><sourceProof>\n");
    write_gm_extended_csr_termination_proof_cpf3(&mut xml, &inverse.csr, source, 0)?;
    xml.push_str("</sourceProof></gm04StandaloneDpProof>\n");
    Ok(xml)
}

/// Lift a native DP-to-CSR child justification across the ordinary CPF grammar.
/// The outer checker verifies the unchanged root and every intermediate step;
/// the inner premise is discharged only by this independently checked CSR child.
fn lift_gm04_source_bridges(mut xml: String) -> Result<String, CpfError> {
    if !xml.contains("<__gm04SourceCsr>") { return Ok(xml); }
    let fail = |message: &str| CpfError::UnsupportedProofStep(message.to_owned());
    let document = roxmltree::Document::parse(&xml).map_err(|e| fail(&e.to_string()))?;
    let markers = document.descendants().filter(|n| n.has_tag_name("__gm04SourceCsr")).collect::<Vec<_>>();
    if markers.len() != 1 { return Err(fail("multiple independent GM04 CSR bridges need separate discharge")); }
    let marker = markers[0];
    let context = marker.children().find(|n| n.has_tag_name("gm04StandaloneDpProof"))
        .ok_or_else(|| fail("GM04 source context is missing"))?;
    let context_xml = xml[context.range()].to_owned();
    let transformed = context.children().find(|n| n.has_tag_name("transformedProof"))
        .ok_or_else(|| fail("GM04 source premise is missing"))?;
    let premise = transformed.descendants().find(|n| n.has_tag_name("finitenessAssumption"))
        .ok_or_else(|| fail("GM04 source premise is not a finiteness assumption"))?;
    let premise_xml = xml[premise.range()].to_owned();
    let range = marker.range();
    drop(document);
    xml.replace_range(range, &premise_xml);
    let document = roxmltree::Document::parse(&xml).map_err(|e| fail(&e.to_string()))?;
    let proof = document.root_element().children().find(|n| n.has_tag_name("proof"))
        .ok_or_else(|| fail("GM04 enclosing root proof is missing"))?;
    let children = proof.children().filter(|n| n.is_element()).collect::<Vec<_>>();
    if children.len() != 1 { return Err(fail("GM04 enclosing proof is ambiguous")); }
    let child = children[0];
    let child_xml = &xml[child.range()];
    let replacement = if child.has_tag_name("dpProof") {
        let context_doc = roxmltree::Document::parse(&context_xml).map_err(|e| fail(&e.to_string()))?;
        let transformed = context_doc.root_element().children().find(|n| n.has_tag_name("transformedProof")).unwrap();
        let mut lifted = context_xml.clone();
        lifted.replace_range(transformed.range(), &format!("<transformedProof>{child_xml}</transformedProof>"));
        lifted
    } else if child.has_tag_name("trsTerminationProof") {
        format!("<gm04StandaloneTrsProof>{context_xml}{child_xml}</gm04StandaloneTrsProof>")
    } else { return Err(fail("GM04 bridge requires an ordinary DP or TRS root proof")); };
    let range = child.range();
    drop(document);
    xml.replace_range(range, &replacement);
    Ok(xml)
}

#[cfg(test)]
mod gm04_bridge_export_tests {
    use super::lift_gm04_source_bridges;

    #[test]
    fn gm04_lift_preserves_root_and_places_the_csr_justification_outside_dp_grammar() {
        let marker = "<__gm04SourceCsr><gm04StandaloneDpProof><sourceTrs/><transformedProof><dpProof><finitenessAssumption><dpInput/></finitenessAssumption></dpProof></transformedProof><sourceProof/></gm04StandaloneDpProof><dpProof><pIsEmpty/></dpProof></__gm04SourceCsr>";
        for root in ["dpProof", "trsTerminationProof"] {
            let xml = format!("<certificationProblem><input><dpInput><minimal>false</minimal></dpInput></input><proof><{root}>{marker}</{root}></proof></certificationProblem>");
            let lifted = lift_gm04_source_bridges(xml).unwrap();
            assert!(!lifted.contains("__gm04SourceCsr"));
            let doc = roxmltree::Document::parse(&lifted).unwrap();
            assert_eq!(doc.descendants().find(|n| n.has_tag_name("minimal")).unwrap().text(), Some("false"));
            let proof = doc.root_element().children().find(|n| n.has_tag_name("proof")).unwrap();
            let child = proof.children().find(|n| n.is_element()).unwrap();
            assert_eq!(child.tag_name().name(), if root == "dpProof" { "gm04StandaloneDpProof" } else { "gm04StandaloneTrsProof" });
            assert_eq!(child.descendants().filter(|n| n.has_tag_name("sourceProof")).count(), 1);
        }
        let ambiguous = format!("<certificationProblem><proof><dpProof>{marker}{marker}</dpProof></proof></certificationProblem>");
        assert!(lift_gm04_source_bridges(ambiguous).is_err());
    }
}

fn write_cpf_document(trs: &Trs, proof: &Proof, mode: CpfMode) -> Result<String, CpfError> {
    if mode == CpfMode::Cpf30 && proof_requires_cpf4(proof) {
        return Err(CpfError::UnsupportedProofStep(
            "proof uses extension processors that require CPF 4.0".to_string(),
        ));
    }
    if proof
        .steps()
        .iter()
        .any(|step| matches!(step, ProofStep::SwitchContextSensitive { .. }))
    {
        return Err(CpfError::UnsupportedProofStep(
            "native IsaFoR/CeTA export for switch-csr proofs is not implemented; refusing to replace the original CPF input with the child CSR"
                .to_string(),
        ));
    }

    let mut xml = String::new();
    write_cpf3_or_4_header(&mut xml, mode);
    xml.push_str("  <lookupTables/>\n");
    xml.push_str("  <input>\n");
    xml.push_str("    <trsInput>\n");
    write_trs_cpf3(&mut xml, trs, 6);
    write_strategy_cpf3(&mut xml, trs.strategy(), 6);
    xml.push_str("    </trsInput>\n");
    xml.push_str("  </input>\n");
    xml.push_str("  <property><termination/></property>\n");
    match proof.status() {
        Status::Terminating => xml.push_str("  <answer><yes/></answer>\n"),
        Status::Nonterminating => xml.push_str("  <answer><no/></answer>\n"),
        Status::Unknown => {
            return Err(CpfError::UnsupportedProofStep(
                "unknown proof status".to_string(),
            ));
        }
    }
    xml.push_str("  <proof>\n");
    match proof.status() {
        Status::Terminating => {
            xml.push_str("    <trsTerminationProof>\n");
            write_trs_termination_proof_cpf3(&mut xml, trs, proof, 6)?;
            xml.push_str("    </trsTerminationProof>\n");
        }
        Status::Nonterminating => {
            xml.push_str("    <trsNonterminationProof>\n");
            write_trs_nontermination_proof_cpf3(&mut xml, proof, 6)?;
            xml.push_str("    </trsNonterminationProof>\n");
        }
        Status::Unknown => unreachable!(),
    }
    xml.push_str("  </proof>\n");
    write_meta_information_cpf3(&mut xml);
    xml.push_str("</certificationProblem>\n");
    Ok(canonicalize_cpf_numeric_symbol_names(lift_gm04_source_bridges(xml)?))
}

/// Convert ARI's quoting of all-digit identifiers at the completed CPF
/// document boundary.  State-input serializers intentionally retain the live
/// ARI spelling because it is part of existing oracle keys; a finished CPF,
/// however, must use CPF's numeric-symbol spelling.
fn canonicalize_cpf_numeric_symbol_names(xml: String) -> String {
    const OPEN: &str = "<name>";
    const CLOSE: &str = "</name>";
    let mut canonical = String::with_capacity(xml.len());
    let mut offset = 0usize;
    while let Some(relative_start) = xml[offset..].find(OPEN) {
        let start = offset + relative_start;
        let content_start = start + OPEN.len();
        let Some(relative_end) = xml[content_start..].find(CLOSE) else {
            break;
        };
        let content_end = content_start + relative_end;
        let content = &xml[content_start..content_end];
        canonical.push_str(&xml[offset..start]);
        if content.len() > 2
            && content.starts_with('|')
            && content.ends_with('|')
            && content.as_bytes()[1..content.len() - 1]
                .iter()
                .all(u8::is_ascii_digit)
        {
            canonical.push_str("<name>");
            canonical.push_str(&content[1..content.len() - 1]);
            canonical.push_str("</name>");
        } else {
            canonical.push_str(&xml[start..content_end + CLOSE.len()]);
        }
        offset = content_end + CLOSE.len();
    }
    canonical.push_str(&xml[offset..]);
    canonical
}

fn write_cpf3_or_4_header(xml: &mut String, mode: CpfMode) {
    let (schema, version) = match mode {
        CpfMode::Cpf30 => ("cpf3.xsd", "3.0"),
        CpfMode::Cpf40 => ("cpf4.xsd", "4.0"),
        CpfMode::Auto | CpfMode::Cpf21 => {
            unreachable!("CPF3/4 header requested for incompatible mode")
        }
    };
    xml.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    xml.push_str("<certificationProblem xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"");
    xml.push_str(schema);
    xml.push_str("\">\n");
    xml.push_str("  <cpfVersion>");
    xml.push_str(version);
    xml.push_str("</cpfVersion>\n");
}

fn proof_requires_cpf4(proof: &Proof) -> bool {
    proof.steps().iter().any(|step| match step {
        ProofStep::SwitchContextSensitive { .. }
        | ProofStep::Gm04InverseContextSensitive { .. }
        | ProofStep::Gm04InverseContextSensitiveFull { .. }
        | ProofStep::Gm04InverseContextSensitiveNontermination { .. }
        | ProofStep::ContextSensitivePolynomialRuleRemoval { .. }
        | ProofStep::ContextSensitiveMatrixRuleRemoval { .. }
        | ProofStep::ContextSensitiveInnermostEquivalence { .. }
        | ProofStep::ContextSensitiveInnermostDependencyPairProof { .. }
        | ProofStep::ContextSensitiveGmTransformation { .. }
        | ProofStep::RfcBounds { .. }
        | ProofStep::RfcAutomatonClosedBounds { .. }
        | ProofStep::RfcRelativeBounds { .. }
        | ProofStep::RfcAutomatonClosedRelativeBounds { .. }
        | ProofStep::RfcMatchboxRelativeBounds { .. }
        | ProofStep::RfcNativeMatchboxRelativeBounds { .. }
        | ProofStep::RuleStrengthening { .. } => true,
        ProofStep::PolynomialRuleRemoval { proof, .. }
        | ProofStep::KboRuleRemoval { proof, .. }
        | ProofStep::PathOrderRuleRemoval { proof, .. }
        | ProofStep::RemoveNonApplicableRules { proof, .. }
        | ProofStep::SwitchInnermost { proof, .. }
        | ProofStep::AaeccInnermost { proof, .. }
        | ProofStep::StringReversal { proof, .. }
        | ProofStep::ConstantToUnary { proof, .. }
        | ProofStep::RelativeBounds {
            proof_after_removal: proof,
            ..
        } => proof_requires_cpf4(proof),
        ProofStep::Uncurry { proof } => proof_requires_cpf4(&proof.proof),
        _ => false,
    })
}

fn write_trs_nontermination_proof_cpf3(
    xml: &mut String,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    match proof.steps() {
        [ProofStep::Nontermination { proof }] => match proof {
            NonterminationProof::RuleRemoval { removed_rules, proof } => {
                xml.push_str(&format!("{pad}<ruleRemoval>\n"));
                write_rules_trs_cpf3(xml, removed_rules, indent + 2, "trs");
                xml.push_str(&format!("{pad}  <trsNonterminationProof>\n"));
                write_trs_nontermination_proof_cpf3(xml, proof, indent + 4)?;
                xml.push_str(&format!("{pad}  </trsNonterminationProof>\n{pad}</ruleRemoval>\n"));
            }
            NonterminationProof::ExactXml(fragment) => {
                xml.push_str(fragment);
                if !fragment.ends_with('\n') {
                    xml.push('\n');
                }
            }
            NonterminationProof::VariableConditionViolated => {
                xml.push_str(&format!("{pad}<variableConditionViolated/>\n"));
            }
            NonterminationProof::Loop(loop_proof) => {
                write_loop_cpf3(xml, loop_proof, indent);
            }
            NonterminationProof::NotWnTreeAutomaton {
                automaton,
                state_compatibility,
            } => {
                xml.push_str(&format!("{pad}<notWNTreeAutomaton>\n"));
                write_tree_automaton_cpf3(xml, automaton, indent + 2);
                xml.push_str(&format!("{pad}  <criterion>\n"));
                if state_compatibility.is_empty() {
                    xml.push_str(&format!("{pad}    <decisionProcedure/>\n"));
                } else {
                    xml.push_str(&format!("{pad}    <stateCompatibility>\n"));
                    xml.push_str(&format!("{pad}      <relation>\n"));
                    for (source, target) in state_compatibility {
                        xml.push_str(&format!("{pad}        <entry>\n"));
                        write_state_cpf3(xml, source, indent + 10);
                        write_state_cpf3(xml, target, indent + 10);
                        xml.push_str(&format!("{pad}        </entry>\n"));
                    }
                    xml.push_str(&format!("{pad}      </relation>\n"));
                    xml.push_str(&format!("{pad}    </stateCompatibility>\n"));
                }
                xml.push_str(&format!("{pad}  </criterion>\n"));
                xml.push_str(&format!("{pad}</notWNTreeAutomaton>\n"));
            }
            NonterminationProof::SrsDerivationPatterns(proof) => {
                write_srs_derivation_pattern_proof_cpf3(xml, proof, indent);
            }
            NonterminationProof::SwitchFullStrategy { wcr_depth, proof } => {
                xml.push_str(&format!("{pad}<switchFullStrategy>\n"));
                xml.push_str(&format!("{pad}  <wcrProof>\n"));
                xml.push_str(&format!(
                    "{pad}    <joinAutoBfs>{wcr_depth}</joinAutoBfs>\n"
                ));
                xml.push_str(&format!("{pad}  </wcrProof>\n"));
                xml.push_str(&format!("{pad}  <trsNonterminationProof>\n"));
                let nested = Proof::nonterminating((**proof).clone());
                write_trs_nontermination_proof_cpf3(xml, &nested, indent + 4)?;
                xml.push_str(&format!("{pad}  </trsNonterminationProof>\n"));
                xml.push_str(&format!("{pad}</switchFullStrategy>\n"));
            }
            NonterminationProof::DependencyPairs { pairs, proof } => {
                xml.push_str(&format!("{pad}<dpTrans>\n"));
                write_dependency_pairs_trs_cpf3(xml, pairs, indent + 2, "dps");
                xml.push_str(&format!("{pad}  <dpNonterminationProof>\n"));
                write_dp_nontermination_proof_cpf3(xml, proof, pairs, indent + 4)?;
                xml.push_str(&format!("{pad}  </dpNonterminationProof>\n"));
                xml.push_str(&format!("{pad}</dpTrans>\n"));
            }
            NonterminationProof::InnermostLhssDependencyPairs {
                innermost_lhss,
                pairs,
                proof,
            } => {
                xml.push_str(&format!("{pad}<innermostLhssIncrease>\n"));
                write_innermost_lhss_cpf3(xml, innermost_lhss, indent + 2);
                xml.push_str(&format!("{pad}  <trsNonterminationProof>\n"));
                xml.push_str(&format!("{pad}    <dpTrans>\n"));
                write_dependency_pairs_trs_cpf3(xml, pairs, indent + 6, "dps");
                xml.push_str(&format!("{pad}      <dpNonterminationProof>\n"));
                write_dp_nontermination_proof_cpf3(xml, proof, pairs, indent + 8)?;
                xml.push_str(&format!("{pad}      </dpNonterminationProof>\n"));
                xml.push_str(&format!("{pad}    </dpTrans>\n"));
                xml.push_str(&format!("{pad}  </trsNonterminationProof>\n"));
                xml.push_str(&format!("{pad}</innermostLhssIncrease>\n"));
            }
        },
        [
            ProofStep::StringReversal {
                reversed_rules,
                reversed_weak_rules: _,
                proof,
            },
        ] if proof.status() == &Status::Nonterminating => {
            xml.push_str(&format!("{pad}<stringReversal>\n"));
            write_rules_trs_cpf3(xml, reversed_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsNonterminationProof>\n"));
            write_trs_nontermination_proof_cpf3(xml, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsNonterminationProof>\n"));
            xml.push_str(&format!("{pad}</stringReversal>\n"));
        }
        [ProofStep::Uncurry { proof }] if proof.proof.status() == &Status::Nonterminating => {
            write_uncurry_cpf3(
                xml,
                &Trs::new(None, BTreeSet::new(), Vec::new()),
                proof,
                indent,
            )?;
        }
        [
            ProofStep::Gm04InverseContextSensitiveNontermination {
                source_csr,
                source_signature,
                source_replacement_map,
                active_symbol,
                mark_symbol,
                proper_symbol,
                ok_symbol,
                top_symbol,
                source_proof,
            },
        ] if source_proof.status() == &Status::Nonterminating => {
            xml.push_str(&format!(
                "{pad}<gm04CompleteNonterminationTransformation>\n"
            ));
            xml.push_str(&format!("{pad}  <sourceReplacementMap>\n"));
            xml.push_str(&format!("{pad}    <contextSensitive>\n"));
            let empty_positions = BTreeSet::new();
            for (symbol, arity) in source_signature {
                let positions = source_replacement_map
                    .allowed_positions(symbol)
                    .unwrap_or(&empty_positions);
                xml.push_str(&format!("{pad}      <replacementMapEntry>\n"));
                write_symbol_cpf3(xml, symbol.as_str(), indent + 8);
                xml.push_str(&format!("{pad}        <arity>{arity}</arity>\n"));
                for position in positions {
                    xml.push_str(&format!(
                        "{pad}        <position>{}</position>\n",
                        position + 1
                    ));
                }
                xml.push_str(&format!("{pad}      </replacementMapEntry>\n"));
            }
            xml.push_str(&format!("{pad}    </contextSensitive>\n"));
            xml.push_str(&format!("{pad}  </sourceReplacementMap>\n"));
            xml.push_str(&format!("{pad}  <sourceTrs>\n"));
            write_rules_cpf3(xml, source_csr.rules(), indent + 4);
            xml.push_str(&format!("{pad}  </sourceTrs>\n"));
            for (tag, symbol) in [
                ("activeSymbol", active_symbol),
                ("markSymbol", mark_symbol),
                ("properSymbol", proper_symbol),
                ("okSymbol", ok_symbol),
                ("topSymbol", top_symbol),
            ] {
                xml.push_str(&format!("{pad}  <{tag}>\n"));
                write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
                xml.push_str(&format!("{pad}  </{tag}>\n"));
            }
            xml.push_str(&format!("{pad}  <sourceProof>\n"));
            write_trs_nontermination_proof_cpf3(xml, source_proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </sourceProof>\n"));
            xml.push_str(&format!(
                "{pad}</gm04CompleteNonterminationTransformation>\n"
            ));
        }
        [step] => return Err(CpfError::UnsupportedProofStep(format!("{step:?}"))),
        [] => return Err(CpfError::UnsupportedProofStep("empty proof".to_string())),
        steps => {
            return Err(CpfError::UnsupportedProofStep(format!(
                "multi-step nontermination proof with {} steps",
                steps.len()
            )));
        }
    }
    Ok(())
}

fn write_srs_derivation_pattern_proof_cpf3(
    xml: &mut String,
    proof: &SrsDerivationPatternProof,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<nonterminatingSRS>\n"));
    xml.push_str(&format!("{pad}  <derivationPatterns>\n"));
    for step in &proof.steps {
        write_srs_derivation_pattern_step_cpf3(xml, step, indent + 4);
    }
    xml.push_str(&format!("{pad}  </derivationPatterns>\n"));
    xml.push_str(&format!("{pad}  <selfEmbeddingDP>\n"));
    write_srs_derivation_pattern_cpf3(xml, &proof.self_embedding, indent + 4);
    write_srs_string_cpf3(xml, &proof.left_context, indent + 4);
    write_srs_string_cpf3(xml, &proof.right_context, indent + 4);
    xml.push_str(&format!("{pad}  </selfEmbeddingDP>\n"));
    xml.push_str(&format!("{pad}</nonterminatingSRS>\n"));
}

fn write_srs_derivation_pattern_step_cpf3(
    xml: &mut String,
    step: &SrsDerivationPatternStep,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<derivationPatternProof>\n"));
    match step {
        SrsDerivationPatternStep::ComposeClosures { result, first, second, left, right, overlap } => {
            let tag = if overlap.is_some() { "OC2" } else { "OC3" };
            xml.push_str(&format!("{pad}  <{tag}>\n"));
            write_srs_overlap_closure_cpf3(xml, result, indent + 4);
            write_srs_overlap_closure_cpf3(xml, first, indent + 4);
            write_srs_overlap_closure_cpf3(xml, second, indent + 4);
            write_srs_string_cpf3(xml, left, indent + 4);
            if let Some(overlap) = overlap { write_srs_string_cpf3(xml, overlap, indent + 4); }
            write_srs_string_cpf3(xml, right, indent + 4);
            xml.push_str(&format!("{pad}  </{tag}>\n"));
        }
        SrsDerivationPatternStep::Lift { result, premise } => {
            xml.push_str(&format!("{pad}  <lift>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, premise, indent + 4);
            xml.push_str(&format!("{pad}  </lift>\n"));
        }
        SrsDerivationPatternStep::Rewrite { result, premise, closure, region, left, right } => {
            let tag = match region { 0 => "DP_OC_1_1", 1 => "DP_OC_2", 2 => "DP_OC_3_1", _ => panic!("invalid derivation-pattern region") };
            xml.push_str(&format!("{pad}  <{tag}>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, premise, indent + 4);
            write_srs_overlap_closure_cpf3(xml, closure, indent + 4);
            write_srs_string_cpf3(xml, left, indent + 4);
            write_srs_string_cpf3(xml, right, indent + 4);
            xml.push_str(&format!("{pad}  </{tag}>\n"));
        }
        SrsDerivationPatternStep::Compose { result, first, second, kind, left, right } => {
            assert!((1..=2).contains(&kind.0) && (1..=2).contains(&kind.1));
            let tag = format!("DP_DP_{}_{}", kind.0, kind.1);
            xml.push_str(&format!("{pad}  <{tag}>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, first, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, second, indent + 4);
            write_srs_string_cpf3(xml, left, indent + 4);
            write_srs_string_cpf3(xml, right, indent + 4);
            xml.push_str(&format!("{pad}  </{tag}>\n"));
        }
        SrsDerivationPatternStep::Original { closure, is_pair } => {
            xml.push_str(&format!("{pad}  <OC1>\n"));
            write_srs_overlap_closure_cpf3(xml, closure, indent + 4);
            xml.push_str(&format!("{pad}    <isPair>{is_pair}</isPair>\n"));
            xml.push_str(&format!("{pad}  </OC1>\n"));
        }
        SrsDerivationPatternStep::OverlapIntoPatternLeft { pattern, closure } => {
            xml.push_str(&format!("{pad}  <OCintoDP1>\n"));
            write_srs_derivation_pattern_cpf3(xml, pattern, indent + 4);
            write_srs_overlap_closure_cpf3(xml, closure, indent + 4);
            xml.push_str(&format!("{pad}  </OCintoDP1>\n"));
        }
        SrsDerivationPatternStep::OverlapIntoPatternRight { pattern, closure } => {
            xml.push_str(&format!("{pad}  <OCintoDP2>\n"));
            write_srs_derivation_pattern_cpf3(xml, pattern, indent + 4);
            write_srs_overlap_closure_cpf3(xml, closure, indent + 4);
            xml.push_str(&format!("{pad}  </OCintoDP2>\n"));
        }
        SrsDerivationPatternStep::PatternOverlapSuffix {
            result,
            pattern,
            closure,
            left,
            right,
            overlap,
        } => {
            xml.push_str(&format!("{pad}  <DP_OC_3_2>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, pattern, indent + 4);
            write_srs_overlap_closure_cpf3(xml, closure, indent + 4);
            write_srs_string_cpf3(xml, left, indent + 4);
            write_srs_string_cpf3(xml, right, indent + 4);
            write_srs_string_cpf3(xml, overlap, indent + 4);
            xml.push_str(&format!("{pad}  </DP_OC_3_2>\n"));
        }
        SrsDerivationPatternStep::PatternCompositionPrefix {
            result,
            first,
            second,
            left,
            right,
        } => {
            xml.push_str(&format!("{pad}  <DP_DP_2_1>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, first, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, second, indent + 4);
            write_srs_string_cpf3(xml, left, indent + 4);
            write_srs_string_cpf3(xml, right, indent + 4);
            xml.push_str(&format!("{pad}  </DP_DP_2_1>\n"));
        }
        SrsDerivationPatternStep::Equivalent { result, premise } => {
            xml.push_str(&format!("{pad}  <equivalent>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, premise, indent + 4);
            xml.push_str(&format!("{pad}  </equivalent>\n"));
        }
        SrsDerivationPatternStep::OverlapPatternPrefix {
            result,
            pattern,
            closure,
            left,
            right,
            overlap,
        } => {
            xml.push_str(&format!("{pad}  <DP_OC_1_2>\n"));
            write_srs_derivation_pattern_cpf3(xml, result, indent + 4);
            write_srs_derivation_pattern_cpf3(xml, pattern, indent + 4);
            write_srs_overlap_closure_cpf3(xml, closure, indent + 4);
            write_srs_string_cpf3(xml, left, indent + 4);
            write_srs_string_cpf3(xml, right, indent + 4);
            write_srs_string_cpf3(xml, overlap, indent + 4);
            xml.push_str(&format!("{pad}  </DP_OC_1_2>\n"));
        }
    }
    xml.push_str(&format!("{pad}</derivationPatternProof>\n"));
}

fn write_srs_derivation_pattern_cpf3(
    xml: &mut String,
    pattern: &SrsDerivationPattern,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<derivationPattern>\n"));
    write_srs_word_pattern_cpf3(xml, &pattern.lhs, indent + 2);
    write_srs_word_pattern_cpf3(xml, &pattern.rhs, indent + 2);
    xml.push_str(&format!("{pad}</derivationPattern>\n"));
}

fn write_srs_word_pattern_cpf3(xml: &mut String, pattern: &SrsWordPattern, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<wordPattern>\n"));
    write_srs_string_cpf3(xml, &pattern.prefix, indent + 2);
    write_srs_string_cpf3(xml, &pattern.repeated, indent + 2);
    xml.push_str(&format!("{pad}  <factor>{}</factor>\n", pattern.factor));
    xml.push_str(&format!(
        "{pad}  <constant>{}</constant>\n",
        pattern.constant
    ));
    write_srs_string_cpf3(xml, &pattern.suffix, indent + 2);
    xml.push_str(&format!("{pad}</wordPattern>\n"));
}

fn write_srs_overlap_closure_cpf3(xml: &mut String, closure: &SrsOverlapClosure, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<overlapClosureSRS>\n"));
    write_srs_string_cpf3(xml, &closure.lhs, indent + 2);
    write_srs_string_cpf3(xml, &closure.rhs, indent + 2);
    xml.push_str(&format!("{pad}</overlapClosureSRS>\n"));
}

fn write_srs_string_cpf3(xml: &mut String, word: &[Symbol], indent: usize) {
    let pad = " ".repeat(indent);
    if word.is_empty() {
        xml.push_str(&format!("{pad}<string/>\n"));
        return;
    }
    xml.push_str(&format!("{pad}<string>\n"));
    for symbol in word {
        xml.push_str(&format!(
            "{pad}  <name>{}</name>\n",
            escape_xml(symbol.as_str())
        ));
    }
    xml.push_str(&format!("{pad}</string>\n"));
}

fn write_dp_nontermination_proof_cpf3(
    xml: &mut String,
    proof: &DpNonterminationProof,
    active_pairs: &[crate::proving::DependencyPair],
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    match proof {
        DpNonterminationProof::Loop(loop_proof) => {
            write_dp_loop_cpf3(xml, loop_proof, active_pairs, indent)
        }
        DpNonterminationProof::InnermostLhssRemoval { remaining_lhss, proof } => {
            xml.push_str(&format!("{pad}<innermostLhssRemovalProc>\n{pad}  <innermostLhss>\n"));
            for term in remaining_lhss { write_term_cpf3(xml, term, indent + 4); }
            xml.push_str(&format!("{pad}  </innermostLhss>\n{pad}  <dpNonterminationProof>\n"));
            write_dp_nontermination_proof_cpf3(xml, proof, active_pairs, indent + 4)?;
            xml.push_str(&format!("{pad}  </dpNonterminationProof>\n{pad}</innermostLhssRemovalProc>\n"));
        }
        DpNonterminationProof::Narrowing { step, proof } => {
            xml.push_str(&format!("{pad}<narrowingProc>\n"));
            write_unindexed_rule_cpf3(xml, &step.pair.as_rule(), indent + 2);
            write_position_in_term_cpf3(xml, &step.position, indent + 2);
            xml.push_str(&format!("{pad}  <narrowings>\n"));
            write_dependency_pairs_rules_cpf3(xml, &step.narrowings, indent + 4);
            xml.push_str(&format!("{pad}  </narrowings>\n"));
            xml.push_str(&format!("{pad}  <dpNonterminationProof>\n"));
            let mut narrowed_active = active_pairs
                .iter()
                .filter(|pair| {
                    !crate::proving::rewrite_rules_are_variants(
                        &pair.as_rule(),
                        &step.pair.as_rule(),
                    )
                })
                .cloned()
                .collect::<Vec<_>>();
            narrowed_active.extend(step.narrowings.iter().cloned());
            write_dp_nontermination_proof_cpf3(xml, proof, &narrowed_active, indent + 4)?;
            xml.push_str(&format!("{pad}  </dpNonterminationProof>\n"));
            xml.push_str(&format!("{pad}</narrowingProc>\n"));
        }
        DpNonterminationProof::InnermostLhssIncrease { added_lhss, child_pairs, proof } => {
            xml.push_str(&format!("{pad}<innermostLhssIncreaseProc>\n{pad}  <innermostLhss>\n"));
            for term in added_lhss {
                write_term_cpf3(xml, term, indent + 4);
            }
            xml.push_str(&format!("{pad}  </innermostLhss>\n{pad}  <dpNonterminationProof>\n"));
            write_dp_nontermination_proof_cpf3(xml, proof, child_pairs, indent + 4)?;
            xml.push_str(&format!("{pad}  </dpNonterminationProof>\n{pad}</innermostLhssIncreaseProc>\n"));
        }
        DpNonterminationProof::SwitchFullStrategy { wcr_depth, proof } => {
            xml.push_str(&format!("{pad}<switchFullStrategyProc>\n"));
            xml.push_str(&format!("{pad}  <wcrProof>\n"));
            xml.push_str(&format!(
                "{pad}    <joinAutoBfs>{wcr_depth}</joinAutoBfs>\n"
            ));
            xml.push_str(&format!("{pad}  </wcrProof>\n"));
            xml.push_str(&format!("{pad}  <dpNonterminationProof>\n"));
            write_dp_nontermination_proof_cpf3(xml, proof, active_pairs, indent + 4)?;
            xml.push_str(&format!("{pad}  </dpNonterminationProof>\n"));
            xml.push_str(&format!("{pad}</switchFullStrategyProc>\n"));
        }
        DpNonterminationProof::DpRuleRemoval {
            removed_pairs,
            removed_rules,
            proof,
        } => {
            xml.push_str(&format!("{pad}<dpRuleRemoval>\n"));
            write_dependency_pairs_trs_cpf3(xml, removed_pairs, indent + 2, "dps");
            write_rules_trs_cpf3(xml, removed_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <dpNonterminationProof>\n"));
            let remaining_pairs = active_pairs
                .iter()
                .filter(|pair| {
                    !removed_pairs.iter().any(|removed| {
                        crate::proving::rewrite_rules_are_variants(
                            &pair.as_rule(),
                            &removed.as_rule(),
                        )
                    })
                })
                .cloned()
                .collect::<Vec<_>>();
            write_dp_nontermination_proof_cpf3(xml, proof, &remaining_pairs, indent + 4)?;
            xml.push_str(&format!("{pad}  </dpNonterminationProof>\n"));
            xml.push_str(&format!("{pad}</dpRuleRemoval>\n"));
        }
        DpNonterminationProof::Rewriting { step } => {
            write_dp_rewriting_proc_nontermination_cpf3(xml, step, active_pairs, indent)?;
        }
        DpNonterminationProof::Instantiation {
            instantiated_pairs,
            proof,
        } => {
            xml.push_str(&format!("{pad}<instantiationProc>\n"));
            write_dependency_pairs_trs_cpf3(xml, instantiated_pairs, indent + 2, "dps");
            xml.push_str(&format!("{pad}  <dpNonterminationProof>\n"));
            write_dp_nontermination_proof_cpf3(xml, proof, instantiated_pairs, indent + 4)?;
            xml.push_str(&format!("{pad}  </dpNonterminationProof>\n"));
            xml.push_str(&format!("{pad}</instantiationProc>\n"));
        }
        DpNonterminationProof::NonLoop(proof) => write_non_loop_cpf3(xml, proof, indent),
        DpNonterminationProof::ExactLoopXml(fragment) => {
            let pad = " ".repeat(indent);
            for line in fragment.trim().lines() {
                xml.push_str(&pad);
                xml.push_str(line.trim());
                xml.push('\n');
            }
        }
        DpNonterminationProof::ExactNonLoopXml(fragment) => {
            let pad = " ".repeat(indent);
            for line in fragment.trim().lines() {
                xml.push_str(&pad);
                xml.push_str(line.trim());
                xml.push('\n');
            }
        }
        DpNonterminationProof::ExactProofXml(fragment) => {
            let document = fragment.trim();
            let inner = document
                .strip_prefix("<dpNonterminationProof>")
                .and_then(|value| value.strip_suffix("</dpNonterminationProof>"))
                .ok_or_else(|| {
                    CpfError::UnsupportedProofStep(
                        "malformed exact DP nontermination proof".to_owned(),
                    )
                })?;
            for line in inner.trim().lines() {
                xml.push_str(&pad);
                xml.push_str(line.trim());
                xml.push('\n');
            }
        }
    }
    Ok(())
}

fn write_dp_rewriting_proc_nontermination_cpf3(
    xml: &mut String,
    step: &DpRewriteProof,
    active_pairs: &[crate::proving::DependencyPair],
    indent: usize,
) -> Result<(), CpfError> {
    let mut output = String::new();
    let pad = " ".repeat(indent);
    output.push_str(&format!("{pad}<rewritingProc>\n"));
    write_unindexed_rule_cpf3(&mut output, &step.original_pair.as_rule(), indent + 2);
    output.push_str(&format!("{pad}  <rewriteStep>\n"));
    write_position_in_term_cpf3(&mut output, &step.rewrite_step.position, indent + 4);
    write_unindexed_rule_cpf3(&mut output, &step.rewrite_step.rule, indent + 4);
    write_term_cpf3(&mut output, &step.rewrite_step.result, indent + 4);
    output.push_str(&format!("{pad}  </rewriteStep>\n"));
    write_unindexed_rule_cpf3(&mut output, &step.rewritten_pair.as_rule(), indent + 2);
    write_rules_trs_cpf3(&mut output, &step.usable_rules, indent + 2, "usableRules");
    output.push_str(&format!("{pad}  <dpNonterminationProof>\n"));
    let mut rewritten_active = active_pairs
        .iter()
        .filter(|pair| {
            !crate::proving::rewrite_rules_are_variants(
                &pair.as_rule(),
                &step.original_pair.as_rule(),
            )
        })
        .cloned()
        .collect::<Vec<_>>();
    rewritten_active.push(step.rewritten_pair.clone());
    write_dp_nontermination_proof_cpf3(&mut output, &step.proof, &rewritten_active, indent + 4)?;
    output.push_str(&format!("{pad}  </dpNonterminationProof>\n"));
    output.push_str(&format!("{pad}</rewritingProc>\n"));
    xml.push_str(&output);
    Ok(())
}

fn write_non_loop_cpf3(xml: &mut String, proof: &NonLoopProof, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<nonLoop>\n"));
    write_pattern_rule_cpf3(xml, proof, indent + 2);
    write_substitution_cpf3(xml, &proof.pumping_substitution, indent + 2);
    write_substitution_cpf3(xml, &proof.closing_substitution, indent + 2);
    xml.push_str(&format!(
        "{pad}  <natural>{}</natural>\n",
        proof.pumping_decomposition
    ));
    xml.push_str(&format!(
        "{pad}  <natural>{}</natural>\n",
        proof.subterm_index
    ));
    write_position_in_term_cpf3(xml, &proof.position, indent + 2);
    xml.push_str(&format!("{pad}</nonLoop>\n"));
}

fn write_pattern_rule_cpf3(xml: &mut String, proof: &NonLoopProof, indent: usize) {
    write_pattern_rule_object_cpf3(xml, &proof.pattern_rule, indent);
}

fn write_pattern_rule_object_cpf3(xml: &mut String, rule: &PatternRule, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<patternRule>\n"));
    write_pattern_term_cpf3(
        xml,
        &rule.lhs,
        &rule.pumping_substitution,
        &rule.closing_substitution,
        indent + 2,
    );
    write_pattern_term_cpf3(
        xml,
        &rule.rhs,
        rule.rhs_pumping_substitution
            .as_ref()
            .unwrap_or(&rule.pumping_substitution),
        rule.rhs_closing_substitution
            .as_ref()
            .unwrap_or(&rule.closing_substitution),
        indent + 2,
    );
    write_pattern_rule_proof_cpf3(xml, &rule.proof, indent + 2);
    xml.push_str(&format!("{pad}</patternRule>\n"));
}

fn write_pattern_rule_proof_cpf3(xml: &mut String, proof: &PatternRuleProof, indent: usize) {
    let pad = " ".repeat(indent);
    match proof {
        PatternRuleProof::OriginalRule { rule, is_pair } => {
            xml.push_str(&format!("{pad}<originalRule>\n"));
            write_unindexed_rule_cpf3(xml, rule, indent + 2);
            xml.push_str(&format!("{pad}  <isPair>{is_pair}</isPair>\n"));
            xml.push_str(&format!("{pad}</originalRule>\n"));
        }
        PatternRuleProof::InitialPumping {
            pattern_rule,
            pumping_substitution,
            closing_substitution,
        } => {
            xml.push_str(&format!("{pad}<initialPumping>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            write_substitution_cpf3(xml, pumping_substitution, indent + 2);
            write_substitution_cpf3(xml, closing_substitution, indent + 2);
            xml.push_str(&format!("{pad}</initialPumping>\n"));
        }
        PatternRuleProof::InitialPumpingContext {
            pattern_rule,
            pumping_substitution,
            position,
            variable,
        } => {
            xml.push_str(&format!("{pad}<initialPumpingContext>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            write_substitution_cpf3(xml, pumping_substitution, indent + 2);
            write_position_in_term_cpf3(xml, position, indent + 2);
            xml.push_str(&format!(
                "{pad}  <var>{}</var>\n",
                escape_xml(variable.as_str())
            ));
            xml.push_str(&format!("{pad}</initialPumpingContext>\n"));
        }
        PatternRuleProof::Instantiation {
            pattern_rule,
            substitution,
            target,
        } => {
            xml.push_str(&format!("{pad}<instantiation>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            write_substitution_cpf3(xml, substitution, indent + 2);
            match target {
                PatternInstantiationTarget::Base => {
                    xml.push_str(&format!("{pad}  <base/>\n"));
                }
                PatternInstantiationTarget::Pumping => {
                    xml.push_str(&format!("{pad}  <pumping/>\n"));
                }
                PatternInstantiationTarget::Closing => {
                    xml.push_str(&format!("{pad}  <closing/>\n"));
                }
            }
            xml.push_str(&format!("{pad}</instantiation>\n"));
        }
        PatternRuleProof::InstantiationPumping {
            pattern_rule,
            power,
        } => {
            xml.push_str(&format!("{pad}<instantiationPumping>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            xml.push_str(&format!("{pad}  <power>{power}</power>\n"));
            xml.push_str(&format!("{pad}</instantiationPumping>\n"));
        }
        PatternRuleProof::Narrowing {
            pattern_rule,
            narrowing_rule,
            position,
        } => {
            xml.push_str(&format!("{pad}<narrowing>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            write_pattern_rule_object_cpf3(xml, narrowing_rule, indent + 2);
            write_position_in_term_cpf3(xml, position, indent + 2);
            xml.push_str(&format!("{pad}</narrowing>\n"));
        }
        PatternRuleProof::Rewriting {
            pattern_rule,
            start,
            steps,
            target,
            variable,
        } => {
            xml.push_str(&format!("{pad}<rewriting>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            write_rewrite_sequence_cpf3(xml, start, steps, indent + 2);
            match target {
                PatternInstantiationTarget::Base => {
                    xml.push_str(&format!("{pad}  <base/>\n"));
                }
                PatternInstantiationTarget::Pumping => {
                    let variable = variable
                        .as_ref()
                        .expect("pattern pumping rewrite requires a substitution variable");
                    xml.push_str(&format!("{pad}  <pumping>\n"));
                    xml.push_str(&format!(
                        "{pad}    <var>{}</var>\n",
                        escape_xml(variable.as_str())
                    ));
                    xml.push_str(&format!("{pad}  </pumping>\n"));
                }
                PatternInstantiationTarget::Closing => {
                    let variable = variable
                        .as_ref()
                        .expect("pattern closing rewrite requires a substitution variable");
                    xml.push_str(&format!("{pad}  <closing>\n"));
                    xml.push_str(&format!(
                        "{pad}    <var>{}</var>\n",
                        escape_xml(variable.as_str())
                    ));
                    xml.push_str(&format!("{pad}  </closing>\n"));
                }
            }
            xml.push_str(&format!("{pad}</rewriting>\n"));
        }
        PatternRuleProof::Equivalence {
            pattern_rule,
            side,
            equivalence,
        } => {
            xml.push_str(&format!("{pad}<equivalence>\n"));
            write_pattern_rule_object_cpf3(xml, pattern_rule, indent + 2);
            match side {
                PatternEquivalenceSide::Left => xml.push_str(&format!("{pad}  <left/>\n")),
                PatternEquivalenceSide::Right => xml.push_str(&format!("{pad}  <right/>\n")),
            }
            write_pattern_equivalence_cpf3(xml, equivalence, indent + 2);
            xml.push_str(&format!("{pad}</equivalence>\n"));
        }
    }
}

fn write_pattern_equivalence_cpf3(
    xml: &mut String,
    equivalence: &PatternEquivalence,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<patternEquivalence>\n"));
    match equivalence {
        PatternEquivalence::DomainRenaming { substitution } => {
            xml.push_str(&format!("{pad}  <domainRenaming>\n"));
            write_substitution_cpf3(xml, substitution, indent + 4);
            xml.push_str(&format!("{pad}  </domainRenaming>\n"));
        }
        PatternEquivalence::Irrelevant {
            base_substitution,
            pumping_substitution,
        } => {
            xml.push_str(&format!("{pad}  <irrelevant>\n"));
            write_substitution_cpf3(xml, base_substitution, indent + 4);
            write_substitution_cpf3(xml, pumping_substitution, indent + 4);
            xml.push_str(&format!("{pad}  </irrelevant>\n"));
        }
        PatternEquivalence::Simplification {
            first_substitution,
            second_substitution,
        } => {
            xml.push_str(&format!("{pad}  <simplification>\n"));
            write_substitution_cpf3(xml, first_substitution, indent + 4);
            write_substitution_cpf3(xml, second_substitution, indent + 4);
            xml.push_str(&format!("{pad}  </simplification>\n"));
        }
    }
    xml.push_str(&format!("{pad}</patternEquivalence>\n"));
}

fn write_rewrite_sequence_cpf3(
    xml: &mut String,
    start: &Term,
    steps: &[LoopRewriteStep],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let mut output = String::new();
    output.push_str(&format!("{pad}<rewriteSequence>\n"));
    output.push_str(&format!("{pad}  <startTerm>\n"));
    write_term_cpf3(&mut output, start, indent + 4);
    output.push_str(&format!("{pad}  </startTerm>\n"));
    for step in steps {
        output.push_str(&format!("{pad}  <rewriteStep>\n"));
        write_position_in_term_cpf3(&mut output, &step.position, indent + 4);
        write_unindexed_rule_cpf3(&mut output, &step.rule, indent + 4);
        write_term_cpf3(&mut output, &step.result, indent + 4);
        output.push_str(&format!("{pad}  </rewriteStep>\n"));
    }
    output.push_str(&format!("{pad}</rewriteSequence>\n"));
    xml.push_str(&output);
}

fn write_pattern_term_cpf3(
    xml: &mut String,
    term: &Term,
    base: &BTreeMap<crate::core::Variable, Term>,
    pumping: &BTreeMap<crate::core::Variable, Term>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<patternTerm>\n"));
    write_term_cpf3(xml, term, indent + 2);
    write_substitution_cpf3(xml, base, indent + 2);
    write_substitution_cpf3(xml, pumping, indent + 2);
    xml.push_str(&format!("{pad}</patternTerm>\n"));
}

fn write_loop_cpf3(xml: &mut String, proof: &LoopProof, indent: usize) {
    let pad = " ".repeat(indent);
    let mut output = String::new();
    output.push_str(&format!("{pad}<loop>\n"));
    output.push_str(&format!("{pad}  <rewriteSequence>\n"));
    output.push_str(&format!("{pad}    <startTerm>\n"));
    write_loop_term_cpf3(&mut output, &proof.start, indent + 6);
    output.push_str(&format!("{pad}    </startTerm>\n"));
    for step in &proof.steps {
        output.push_str(&format!("{pad}    <rewriteStep>\n"));
        write_position_in_term_cpf3(&mut output, &step.position, indent + 6);
        write_unindexed_rule_cpf3(&mut output, &step.rule, indent + 6);
        write_loop_term_cpf3(&mut output, &step.result, indent + 6);
        output.push_str(&format!("{pad}    </rewriteStep>\n"));
    }
    output.push_str(&format!("{pad}  </rewriteSequence>\n"));
    write_substitution_cpf3(&mut output, &proof.substitution, indent + 2);
    if let Some(last_step) = proof.steps.last() {
        write_context_cpf3(
            &mut output,
            &last_step.result,
            &proof.context_position,
            indent + 2,
        );
    } else {
        output.push_str(&format!("{pad}  <context>\n"));
        output.push_str(&format!("{pad}    <box/>\n"));
        output.push_str(&format!("{pad}  </context>\n"));
    }
    output.push_str(&format!("{pad}</loop>\n"));
    xml.push_str(&output);
}

// A long unary loop can contain millions of term nodes. Unbounded indentation
// makes its XML quadratic in word length (several GiB of whitespace). Only
// loop proof terms use this writer: root/state serialization and oracle keys
// are unchanged. Element structure and symbol encoding are identical to the
// ordinary writer; indentation saturates at 32 spaces.
fn write_loop_term_cpf3(xml: &mut String, term: &Term, indent: usize) {
    let mut stack = vec![(term, indent.min(32), false)];
    while let Some((term, indent, closing)) = stack.pop() {
        let pad = " ".repeat(indent);
        if closing {
            xml.push_str(&format!("{pad}</funapp>\n"));
            continue;
        }
        match term {
            Term::Var(variable) => {
                xml.push_str(&format!(
                    "{pad}<var>{}</var>\n",
                    escape_xml(variable.as_str())
                ));
            }
            Term::App { symbol, args } => {
                xml.push_str(&format!("{pad}<funapp>\n"));
                write_symbol_cpf3(xml, symbol.as_str(), (indent + 2).min(32));
                stack.push((term, indent, true));
                for arg in args.iter().rev() {
                    stack.push((arg, (indent + 2).min(32), false));
                }
            }
        }
    }
}

fn write_dp_loop_cpf3(
    xml: &mut String,
    proof: &LoopProof,
    active_pairs: &[crate::proving::DependencyPair],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let mut output = String::new();
    output.push_str(&format!("{pad}<loop>\n"));
    output.push_str(&format!("{pad}  <rewriteSequence>\n"));
    output.push_str(&format!("{pad}    <startTerm>\n"));
    write_term_cpf3(&mut output, &proof.start, indent + 6);
    output.push_str(&format!("{pad}    </startTerm>\n"));
    for step in &proof.steps {
        output.push_str(&format!("{pad}    <rewriteStep>\n"));
        write_position_in_term_cpf3(&mut output, &step.position, indent + 6);
        write_unindexed_rule_cpf3(&mut output, &step.rule, indent + 6);
        let is_dependency_pair = active_pairs
            .iter()
            .any(|pair| crate::proving::rewrite_rules_are_variants(&step.rule, &pair.as_rule()));
        if !is_dependency_pair {
            output.push_str(&format!("{pad}      <relative/>\n"));
        }
        write_term_cpf3(&mut output, &step.result, indent + 6);
        output.push_str(&format!("{pad}    </rewriteStep>\n"));
    }
    output.push_str(&format!("{pad}  </rewriteSequence>\n"));
    write_substitution_cpf3(&mut output, &proof.substitution, indent + 2);
    if let Some(last_step) = proof.steps.last() {
        write_context_cpf3(
            &mut output,
            &last_step.result,
            &proof.context_position,
            indent + 2,
        );
    } else {
        output.push_str(&format!("{pad}  <context>\n"));
        output.push_str(&format!("{pad}    <box/>\n"));
        output.push_str(&format!("{pad}  </context>\n"));
    }
    output.push_str(&format!("{pad}</loop>\n"));
    xml.push_str(&output);
}

fn write_substitution_cpf3(
    xml: &mut String,
    substitution: &BTreeMap<crate::core::Variable, Term>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<substitution>\n"));
    for (variable, term) in substitution {
        xml.push_str(&format!("{pad}  <substEntry>\n"));
        xml.push_str(&format!("{pad}    <var>"));
        xml.push_str(&escape_xml(variable.as_str()));
        xml.push_str("</var>\n");
        write_term_cpf3(xml, term, indent + 4);
        xml.push_str(&format!("{pad}  </substEntry>\n"));
    }
    xml.push_str(&format!("{pad}</substitution>\n"));
}

fn write_gm04_source_map_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    signature: &BTreeMap<Symbol, usize>,
    replacement_map: &crate::core::ReplacementMap,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let empty_positions = BTreeSet::new();
    // Match standalone CSR export and native graph estimation. The fresh
    // improved-DP wrapper is frozen; no source-symbol position changes.
    let mut signature = signature.clone();
    signature.entry(fresh_unhiding_symbol(csr.trs())).or_insert(1);
    xml.push_str(&format!("{pad}<sourceReplacementMap>\n{pad}  <contextSensitive>\n"));
    for (symbol, arity) in signature {
        let positions = replacement_map.allowed_positions(&symbol).unwrap_or(&empty_positions);
        xml.push_str(&format!("{pad}    <replacementMapEntry>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
        for position in positions {
            xml.push_str(&format!("{pad}      <position>{}</position>\n", position + 1));
        }
        xml.push_str(&format!("{pad}    </replacementMapEntry>\n"));
    }
    xml.push_str(&format!("{pad}  </contextSensitive>\n{pad}</sourceReplacementMap>\n"));
}

fn write_trs_termination_proof_cpf3(
    xml: &mut String,
    trs: &Trs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    let steps = if matches!(proof.steps().last(), Some(ProofStep::Unsupported { .. })) {
        &proof.steps()[..proof.steps().len() - 1]
    } else {
        proof.steps()
    };
    if proof.status() == &Status::Unknown && steps.is_empty() {
        xml.push_str(&format!("{pad}<terminationAssumption>\n"));
        xml.push_str(&format!("{pad}  <trsInput>\n"));
        write_trs_cpf3(xml, trs, indent + 4);
        write_strategy_cpf3(xml, trs.strategy(), indent + 4);
        xml.push_str(&format!("{pad}  </trsInput>\n"));
        xml.push_str(&format!("{pad}</terminationAssumption>\n"));
        return Ok(());
    }
    match steps {
        [ProofStep::ExactTerminationXml(fragment)] => {
            for line in fragment.lines() {
                xml.push_str(&format!("{pad}{line}\n"));
            }
        }
        [ProofStep::EmptySystem] => {
            xml.push_str(&format!("{pad}<rIsEmpty/>\n"));
        }
        [
            ProofStep::LlmLinearPolynomial { interpretations }
            | ProofStep::SynthesizedLinearPolynomial { interpretations },
        ] => {
            write_polynomial_rule_removal_cpf3(xml, trs, interpretations, indent);
        }
        [
            ProofStep::PolynomialRuleRemoval {
                interpretations,
                removed,
                proof,
            },
        ] => {
            let remaining = trs_without_rules(trs, removed);
            write_polynomial_rule_removal_with_proof_cpf3(
                xml,
                interpretations,
                removed,
                &remaining,
                proof,
                indent,
            )?;
        }
        [
            ProofStep::MatrixRuleRemoval {
                interpretations,
                dimension,
                strict_dimension,
                domain,
                removed,
                proof,
            },
        ] => {
            let remaining = trs_without_rules(trs, removed);
            let relative_remaining = RelativeTrs::new(remaining, Vec::new());
            write_matrix_rule_removal_with_relative_proof_cpf3(
                xml,
                trs.arities(),
                interpretations,
                *dimension,
                *strict_dimension,
                *domain,
                removed,
                &relative_remaining,
                proof,
                indent,
            )?;
        }
        [
            ProofStep::SynthesizedKbo {
                precedence,
                precedence_ranks,
                weights,
            },
        ] => {
            let weights = weights.iter().cloned().collect::<BTreeMap<_, _>>();
            write_kbo_rule_removal_cpf3(xml, trs, precedence, precedence_ranks, &weights, indent);
        }
        [
            ProofStep::KboRuleRemoval {
                precedence,
                precedence_ranks,
                weights,
                removed,
                proof,
            },
        ] => {
            let weights = weights.iter().cloned().collect::<BTreeMap<_, _>>();
            let remaining = trs_without_rules(trs, removed);
            write_kbo_rule_removal_with_proof_cpf3(
                xml,
                precedence,
                precedence_ranks,
                &weights,
                removed,
                &remaining,
                proof,
                indent,
            )?;
        }
        [
            ProofStep::PathOrderRuleRemoval {
                statuses,
                precedence,
                precedence_ranks,
                argument_filter,
                removed,
                proof,
            },
        ] => {
            let remaining = trs_without_rules(trs, removed);
            write_path_order_rule_removal_with_proof_cpf3(
                xml,
                PathOrderRuleRemovalCpf {
                    statuses,
                    precedence,
                    precedence_ranks,
                    argument_filter,
                    removed,
                    remaining: &remaining,
                    proof,
                },
                indent,
            )?;
        }
        [
            ProofStep::SemanticLabeling {
                root_labeling,
                model,
                labeled_rules,
                proof,
            },
        ] => {
            let labeled = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                labeled_rules.clone(),
                trs.strategy(),
            );
            xml.push_str(&format!("{pad}<semlab>\n"));
            if *root_labeling {
                xml.push_str(&format!("{pad}  <model><rootLabeling/></model>\n"));
            } else {
                write_semantic_labeling_model_cpf3(xml, model, indent + 2);
            }
            write_rules_trs_cpf3(xml, labeled_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &labeled, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</semlab>\n"));
        }
        [
            ProofStep::FlatContextClosure {
                contexts,
                transformed_rules,
                proof,
            },
        ] => {
            let transformed = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                transformed_rules.clone(),
                trs.strategy(),
            );
            xml.push_str(&format!("{pad}<flatContextClosure>\n"));
            xml.push_str(&format!("{pad}  <flatContexts>\n"));
            for context in contexts {
                xml.push_str(&format!("{pad}    <funContext>\n"));
                write_symbol_cpf3(xml, context.symbol.as_str(), indent + 6);
                xml.push_str(&format!("{pad}      <before>\n"));
                for term in &context.before {
                    write_term_cpf3(xml, term, indent + 8);
                }
                xml.push_str(&format!("{pad}      </before>\n"));
                xml.push_str(&format!("{pad}      <box/>\n"));
                xml.push_str(&format!("{pad}      <after>\n"));
                for term in &context.after {
                    write_term_cpf3(xml, term, indent + 8);
                }
                xml.push_str(&format!("{pad}      </after>\n"));
                xml.push_str(&format!("{pad}    </funContext>\n"));
            }
            xml.push_str(&format!("{pad}  </flatContexts>\n"));
            write_rules_trs_cpf3(xml, transformed_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &transformed, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</flatContextClosure>\n"));
        }
        [ProofStep::DependencyPairProof { proof }] => {
            write_dp_trans_cpf3(xml, proof, indent);
        }
        [ProofStep::RemoveNonApplicableRules { removed, proof }] => {
            let remaining = trs_without_rules(trs, removed);
            xml.push_str(&format!("{pad}<removeNonApplicableRules>\n"));
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &remaining, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</removeNonApplicableRules>\n"));
        }
        [ProofStep::SwitchInnermost { wcr_depth, proof }] => {
            let innermost = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                trs.rules().to_vec(),
                RewriteStrategy::Innermost,
            );
            xml.push_str(&format!("{pad}<switchInnermost>\n"));
            xml.push_str(&format!("{pad}  <wcrProof>\n"));
            xml.push_str(&format!(
                "{pad}    <joinAutoBfs>{wcr_depth}</joinAutoBfs>\n"
            ));
            xml.push_str(&format!("{pad}  </wcrProof>\n"));
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &innermost, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</switchInnermost>\n"));
        }
        [
            ProofStep::AaeccInnermost {
                r1,
                r2,
                sigma,
                wcr_depth,
                proof,
            },
        ] => {
            let innermost = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                trs.rules().to_vec(),
                RewriteStrategy::Innermost,
            );
            xml.push_str(&format!("{pad}<aaeccInnermost>\n"));
            write_rules_trs_cpf3(xml, r1, indent + 2, "r1");
            write_rules_trs_cpf3(xml, r2, indent + 2, "r2");
            xml.push_str(&format!("{pad}  <sigma>\n"));
            for symbol in sigma {
                xml.push_str(&format!("{pad}    <symbol>\n"));
                write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
                xml.push_str(&format!("{pad}    </symbol>\n"));
            }
            xml.push_str(&format!("{pad}  </sigma>\n"));
            xml.push_str(&format!("{pad}  <wcrProof>\n"));
            xml.push_str(&format!(
                "{pad}    <joinAutoBfs>{wcr_depth}</joinAutoBfs>\n"
            ));
            xml.push_str(&format!("{pad}  </wcrProof>\n"));
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &innermost, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</aaeccInnermost>\n"));
        }
        [ProofStep::SwitchContextSensitive { .. }] => {
            return Err(CpfError::UnsupportedProofStep(
                "native IsaFoR/CeTA export for switch-csr proofs is not implemented".to_string(),
            ));
        }
        [
            ProofStep::Gm04InverseContextSensitive {
                source_csr,
                source_signature,
                source_replacement_map,
                active_symbol,
                mark_symbol,
                proper_symbol,
                ok_symbol,
                top_symbol,
                top_sharp_symbol,
                transformed_proof,
                source_proof,
            },
        ] => {
            xml.push_str(&format!("{pad}<gm04CompleteTransformation>\n"));
            write_gm04_source_map_cpf3(xml, source_csr, source_signature, source_replacement_map, indent + 2);
            xml.push_str(&format!("{pad}  <sourceTrs>\n"));
            write_rules_cpf3(xml, source_csr.rules(), indent + 4);
            xml.push_str(&format!("{pad}  </sourceTrs>\n"));
            for (tag, symbol) in [
                ("activeSymbol", active_symbol),
                ("markSymbol", mark_symbol),
                ("properSymbol", proper_symbol),
                ("okSymbol", ok_symbol),
                ("topSymbol", top_symbol),
                ("topSharpSymbol", top_sharp_symbol),
            ] {
                xml.push_str(&format!("{pad}  <{tag}>\n"));
                write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
                xml.push_str(&format!("{pad}  </{tag}>\n"));
            }
            xml.push_str(&format!("{pad}  <transformedProof>\n"));
            write_trs_termination_proof_cpf3(xml, trs, transformed_proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </transformedProof>\n"));
            xml.push_str(&format!("{pad}  <sourceProof>\n"));
            write_gm_extended_csr_termination_proof_cpf3(
                xml,
                source_csr,
                source_proof,
                indent + 4,
            )?;
            xml.push_str(&format!("{pad}  </sourceProof>\n"));
            xml.push_str(&format!("{pad}</gm04CompleteTransformation>\n"));
        }
        [
            ProofStep::Gm04InverseContextSensitiveFull {
                source_csr,
                source_signature,
                source_replacement_map,
                active_symbol,
                mark_symbol,
                proper_symbol,
                ok_symbol,
                top_symbol,
                top_sharp_symbol,
                administrative_rules,
                wcr_depth,
                administrative_proof,
                source_proof,
            },
        ] => {
            xml.push_str(&format!("{pad}<gm04CompleteFullTransformation>\n"));
            write_gm04_source_map_cpf3(xml, source_csr, source_signature, source_replacement_map, indent + 2);
            xml.push_str(&format!("{pad}  <sourceTrs>\n"));
            write_rules_cpf3(xml, source_csr.rules(), indent + 4);
            xml.push_str(&format!("{pad}  </sourceTrs>\n"));
            for (tag, symbol) in [
                ("activeSymbol", active_symbol),
                ("markSymbol", mark_symbol),
                ("properSymbol", proper_symbol),
                ("okSymbol", ok_symbol),
                ("topSymbol", top_symbol),
                ("topSharpSymbol", top_sharp_symbol),
            ] {
                xml.push_str(&format!("{pad}  <{tag}>\n"));
                write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
                xml.push_str(&format!("{pad}  </{tag}>\n"));
            }
            xml.push_str(&format!("{pad}  <wcrProof>\n"));
            xml.push_str(&format!(
                "{pad}    <joinAutoBfs>{wcr_depth}</joinAutoBfs>\n"
            ));
            xml.push_str(&format!("{pad}  </wcrProof>\n"));
            let administrative_trs = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                administrative_rules.clone(),
                RewriteStrategy::Full,
            );
            xml.push_str(&format!("{pad}  <administrativeProof>\n"));
            write_trs_termination_proof_cpf3(
                xml,
                &administrative_trs,
                administrative_proof,
                indent + 4,
            )?;
            xml.push_str(&format!("{pad}  </administrativeProof>\n"));
            xml.push_str(&format!("{pad}  <sourceProof>\n"));
            write_gm_extended_csr_termination_proof_cpf3(
                xml,
                source_csr,
                source_proof,
                indent + 4,
            )?;
            xml.push_str(&format!("{pad}  </sourceProof>\n"));
            xml.push_str(&format!("{pad}</gm04CompleteFullTransformation>\n"));
        }
        [
            ProofStep::StringReversal {
                reversed_rules,
                reversed_weak_rules: _,
                proof,
            },
        ] => {
            let reversed = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                reversed_rules.clone(),
                trs.strategy(),
            );
            xml.push_str(&format!("{pad}<stringReversal>\n"));
            write_rules_trs_cpf3(xml, reversed_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &reversed, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</stringReversal>\n"));
        }
        [ProofStep::RuleStrengthening {
            strengthened_rules,
            proof,
        }] => {
            if trs.strategy() != crate::core::RewriteStrategy::Full
                || proof.status() != &Status::Terminating
            {
                return Err(CpfError::UnsupportedProofStep(
                    "rule strengthening requires full termination".into(),
                ));
            }
            let strengthened = Trs::new_with_strategy(
                trs.name().map(str::to_owned),
                trs.variables().clone(),
                strengthened_rules.clone(),
                crate::core::RewriteStrategy::Full,
            );
            xml.push_str(&format!("{pad}<ruleStrengthening>\n"));
            write_rules_trs_cpf3(xml, strengthened_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &strengthened, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n{pad}</ruleStrengthening>\n"));
        }
        [ProofStep::Uncurry { proof }] => {
            write_uncurry_cpf3(xml, trs, proof, indent)?;
        }
        [
            ProofStep::ConstantToUnary {
                variable,
                renaming,
                transformed_rules,
                proof,
            },
        ] => {
            let mut variables = trs.variables().clone();
            variables.insert(variable.clone());
            let transformed = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                variables,
                transformed_rules.clone(),
                trs.strategy(),
            );
            xml.push_str(&format!("{pad}<constantToUnary>\n"));
            xml.push_str(&format!(
                "{pad}  <var>{}</var>\n",
                escape_xml(variable.as_str())
            ));
            xml.push_str(&format!("{pad}  <renaming>\n"));
            for (source, target) in renaming {
                xml.push_str(&format!("{pad}    <renamingEntry>\n"));
                write_symbol_cpf3(xml, source.as_str(), indent + 6);
                write_symbol_cpf3(xml, target.as_str(), indent + 6);
                xml.push_str(&format!("{pad}    </renamingEntry>\n"));
            }
            xml.push_str(&format!("{pad}  </renaming>\n"));
            write_rules_trs_cpf3(xml, transformed_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &transformed, proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</constantToUnary>\n"));
        }
        [ProofStep::Bounds { proof }] => {
            write_bounds_cpf3(xml, proof, indent);
        }
        [
            ProofStep::RelativeBounds {
                proof,
                removed,
                proof_after_removal,
            },
        ] => {
            let remaining = trs_without_rules(trs, removed);
            xml.push_str(&format!("{pad}<relativeBounds>\n"));
            write_bounds_cpf3(xml, proof, indent + 2);
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &RelativeTrs::new(remaining, removed.clone()), proof_after_removal, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</relativeBounds>\n"));
        }
        [
            ProofStep::RfcBounds {
                proof,
                initial_words,
            },
        ] => {
            let Some(tail) = common_srs_tail_variable(trs) else {
                return Err(CpfError::UnsupportedProofStep(
                    "RfcBounds CPF output currently requires strict unary SRS rules with one common tail variable"
                        .to_string(),
                ));
            };
            xml.push_str(&format!("{pad}<rfcBounds>\n"));
            write_initial_terms_cpf3(xml, initial_words, &tail, indent + 2);
            write_bounds_cpf3(xml, proof, indent + 2);
            xml.push_str(&format!("{pad}</rfcBounds>\n"));
        }
        [
            ProofStep::RfcAutomatonClosedBounds {
                proof,
                initial_words,
            },
        ] => {
            let Some(tail) = common_srs_tail_variable(trs) else {
                return Err(CpfError::UnsupportedProofStep(
                    "RfcAutomatonClosedBounds CPF output currently requires strict unary SRS rules with one common tail variable"
                        .to_string(),
                ));
            };
            xml.push_str(&format!("{pad}<rfcAutomatonClosedBounds>\n"));
            write_initial_terms_cpf3(xml, initial_words, &tail, indent + 2);
            write_bounds_cpf3(xml, proof, indent + 2);
            xml.push_str(&format!("{pad}</rfcAutomatonClosedBounds>\n"));
        }
        [
            ProofStep::RfcRelativeBounds {
                proof,
                initial_words,
                removed,
                proof_after_removal,
            },
        ] => {
            let Some(tail) = common_srs_tail_variable(trs) else {
                return Err(CpfError::UnsupportedProofStep(
                    "RfcRelativeBounds CPF output currently requires strict unary SRS rules with one common tail variable"
                        .to_string(),
                ));
            };
            let remaining = trs_without_rules(trs, removed);
            xml.push_str(&format!("{pad}<rfcRelativeBounds>\n"));
            write_initial_terms_cpf3(xml, initial_words, &tail, indent + 2);
            write_bounds_cpf3(xml, proof, indent + 2);
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &RelativeTrs::new(remaining, removed.clone()), proof_after_removal, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</rfcRelativeBounds>\n"));
        }
        [
            ProofStep::RfcAutomatonClosedRelativeBounds {
                proof,
                initial_words,
                removed,
                proof_after_removal,
            },
        ] => {
            let Some(tail) = common_srs_tail_variable(trs) else {
                return Err(CpfError::UnsupportedProofStep(
                    "RfcAutomatonClosedRelativeBounds CPF output currently requires strict unary SRS rules with one common tail variable"
                        .to_string(),
                ));
            };
            let remaining = trs_without_rules(trs, removed);
            xml.push_str(&format!("{pad}<rfcAutomatonClosedRelativeBounds>\n"));
            write_initial_terms_cpf3(xml, initial_words, &tail, indent + 2);
            write_bounds_cpf3(xml, proof, indent + 2);
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &RelativeTrs::new(remaining, removed.clone()), proof_after_removal, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</rfcAutomatonClosedRelativeBounds>\n"));
        }
        [
            ProofStep::RfcMatchboxRelativeBounds {
                absolute_residual,
                proof,
                initial_words,
                removed,
                proof_after_removal,
            },
        ] => {
            let Some(tail) = common_srs_tail_variable(trs) else {
                return Err(CpfError::UnsupportedProofStep(
                    "RfcMatchboxRelativeBounds CPF output currently requires strict unary SRS rules with one common tail variable"
                        .to_string(),
                ));
            };
            let remaining = trs_without_rules(trs, removed);
            xml.push_str(&format!("{pad}<rfcMatchboxRelativeBounds>\n"));
            write_initial_terms_cpf3(xml, initial_words, &tail, indent + 2);
            write_bounds_cpf3(xml, proof, indent + 2);
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            if *absolute_residual {
                write_trs_termination_proof_cpf3(xml, &remaining, proof_after_removal, indent + 4)?;
            } else {
                write_relative_trs_termination_proof_cpf3(xml, &RelativeTrs::new(remaining, removed.clone()), proof_after_removal, indent + 4)?;
            }
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</rfcMatchboxRelativeBounds>\n"));
        }
        [
            ProofStep::RfcNativeMatchboxRelativeBounds {
                proof,
                initial_words,
                removed,
                proof_after_removal,
            },
        ] => {
            let Some(tail) = common_srs_tail_variable(trs) else {
                return Err(CpfError::UnsupportedProofStep(
                    "RfcNativeMatchboxRelativeBounds CPF output currently requires strict unary SRS rules with one common tail variable"
                        .to_string(),
                ));
            };
            let remaining = trs_without_rules(trs, removed);
            xml.push_str(&format!("{pad}<rfcNativeMatchboxRelativeBounds>\n"));
            write_initial_terms_cpf3(xml, initial_words, &tail, indent + 2);
            write_bounds_cpf3(xml, proof, indent + 2);
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, &RelativeTrs::new(remaining, removed.clone()), proof_after_removal, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</rfcNativeMatchboxRelativeBounds>\n"));
        }
        [step] => return Err(CpfError::UnsupportedProofStep(format!("{step:?}"))),
        [] => return Err(CpfError::UnsupportedProofStep("empty proof".to_string())),
        steps => {
            return Err(CpfError::UnsupportedProofStep(format!(
                "multi-step proof with {} steps",
                steps.len()
            )));
        }
    }
    Ok(())
}

fn csr_dp_tree_contains_guarded_list_terminal(tree: &crate::proving::DpProofTree) -> bool {
    use crate::proving::DpProofTree;
    match tree {
        DpProofTree::TransformationExact { processor_tag, .. } => {
            processor_tag == "csrGuardedListTerminal" || processor_tag == "csrGuardedOvConsTerminal"
        }
        DpProofTree::DepGraph { components } => components.iter().any(|component| {
            component
                .proof_tree
                .as_deref()
                .is_some_and(csr_dp_tree_contains_guarded_list_terminal)
        }),
        DpProofTree::GeneralRedPairExact { proofs, .. } => proofs
            .iter()
            .any(|proof| csr_dp_tree_contains_guarded_list_terminal(proof)),
        DpProofTree::ReductionPairExact { proof, .. }
        | DpProofTree::ComponentContext { proof, .. }
        | DpProofTree::SwitchInnermost { proof, .. }
        | DpProofTree::Subterm { proof, .. }
        | DpProofTree::Narrowing { proof, .. }
        | DpProofTree::Instantiation { proof, .. }
        | DpProofTree::ForwardInstantiation { proof, .. }
        | DpProofTree::Rewriting { proof, .. }
        | DpProofTree::RedPair { proof, .. }
        | DpProofTree::SemanticLabeling { proof, .. }
        | DpProofTree::Uncurry { proof, .. } => csr_dp_tree_contains_guarded_list_terminal(proof),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            csr_dp_tree_contains_guarded_list_terminal(selected_proof)
                || csr_dp_tree_contains_guarded_list_terminal(residual_proof)
        }
        DpProofTree::ExactXml(_)
        | DpProofTree::QdpToSrs { .. }
        | DpProofTree::SwitchToTrs { .. }
        | DpProofTree::Empty
        | DpProofTree::SizeChange { .. }
        | DpProofTree::SizeChangeRedPair { .. } => false,
    }
}

fn csr_dp_proof_contains_guarded_list_terminal(
    proof: &crate::proving::DependencyPairProof,
) -> bool {
    proof.component_proofs.iter().any(|component| {
        component
            .proof_tree
            .as_deref()
            .is_some_and(csr_dp_tree_contains_guarded_list_terminal)
    })
}

fn csr_proof_contains_guarded_list_terminal(proof: &Proof) -> bool {
    match proof.steps() {
        [ProofStep::ContextSensitivePolynomialRuleRemoval { proof, .. }]
        | [ProofStep::ContextSensitiveMatrixRuleRemoval { proof, .. }] => {
            csr_proof_contains_guarded_list_terminal(proof)
        }
        [ProofStep::ContextSensitiveDependencyPairProof { proof, .. }]
        | [ProofStep::DependencyPairProof { proof }] => {
            csr_dp_proof_contains_guarded_list_terminal(proof)
        }
        _ => false,
    }
}

fn write_guarded_csr_dp_tree_cpf3(
    xml: &mut String,
    tree: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    rules: &[RewriteRule],
    indent: usize,
) {
    use crate::proving::DpProofTree;
    let pad = " ".repeat(indent);
    match tree {
        DpProofTree::TransformationExact {
            processor_tag,
            payload_xml,
            proof,
        } if (processor_tag == "csrGuardedListTerminal"
            || processor_tag == "csrGuardedOvConsTerminal")
            && matches!(proof.as_ref(), DpProofTree::Empty) =>
        {
            xml.push_str(&format!("{pad}<csrGuardedListTerminal>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            xml.push_str(&format!("{pad}</csrGuardedListTerminal>\n"));
        }
        DpProofTree::DepGraph { components } => {
            xml.push_str(&format!("{pad}<csrGuardedDepGraphProc>\n"));
            for component in components {
                xml.push_str(&format!("{pad}  <component>\n"));
                write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 4, "dps");
                if component.proved
                    && let Some(child) = component.proof_tree.as_deref()
                {
                    write_guarded_csr_dp_tree_cpf3(xml, child, strategy, rules, indent + 4);
                }
                xml.push_str(&format!("{pad}  </component>\n"));
            }
            xml.push_str(&format!("{pad}</csrGuardedDepGraphProc>\n"));
        }
        _ => {
            xml.push_str(&format!("{pad}<csrGuardedExistingDpProof>\n"));
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, tree, strategy, rules, None, indent + 4);
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</csrGuardedExistingDpProof>\n"));
        }
    }
}

fn write_guarded_csr_dp_proof_cpf3(
    xml: &mut String,
    proof: &crate::proving::DependencyPairProof,
    rules: &[RewriteRule],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<csrGuardedDepGraphProc>\n"));
    for component in &proof.component_proofs {
        xml.push_str(&format!("{pad}  <component>\n"));
        write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 4, "dps");
        if component.proved
            && let Some(tree) = component.proof_tree.as_deref()
        {
            write_guarded_csr_dp_tree_cpf3(xml, tree, proof.strategy, rules, indent + 4);
        }
        xml.push_str(&format!("{pad}  </component>\n"));
    }
    xml.push_str(&format!("{pad}</csrGuardedDepGraphProc>\n"));
}

fn write_guarded_csr_termination_body_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    match proof.steps() {
        [
            ProofStep::ContextSensitivePolynomialRuleRemoval {
                interpretations,
                removed,
                proof,
            },
        ] => {
            let remaining = trs_without_rules(csr.trs(), removed);
            let remaining_map =
                replacement_map_for_arities(csr.replacement_map(), &remaining.arities());
            let remaining_csr = CsrTrs::new(remaining, remaining_map).map_err(|issues| {
                CpfError::UnsupportedProofStep(format!(
                    "invalid guarded CSR rule-removal residual: {issues:?}"
                ))
            })?;
            let mut arities = remaining_csr.trs().arities();
            for rule in removed {
                collect_term_arities(rule.lhs(), &mut arities);
                collect_term_arities(rule.rhs(), &mut arities);
            }
            xml.push_str(&format!("{pad}<csrGuardedRuleRemoval>\n"));
            write_polynomial_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretations,
                indent + 2,
            );
            write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
            write_guarded_csr_termination_body_cpf3(xml, &remaining_csr, proof, indent + 2)?;
            xml.push_str(&format!("{pad}</csrGuardedRuleRemoval>\n"));
        }
        [
            ProofStep::ContextSensitiveDependencyPairProof {
                construction: crate::proving::ContextSensitiveDependencyPairConstruction::Improved,
                proof,
                ..
            },
        ] => {
            xml.push_str(&format!("{pad}<csrGuardedImprovedDependencyPairs>\n"));
            xml.push_str(&format!("{pad}  <unhidingSymbol>\n"));
            write_symbol_cpf3(xml, fresh_unhiding_symbol(csr.trs()).as_str(), indent + 4);
            xml.push_str(&format!("{pad}  </unhidingSymbol>\n"));
            write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 2, "dps");
            write_guarded_csr_dp_proof_cpf3(xml, proof, csr.rules(), indent + 2);
            xml.push_str(&format!("{pad}</csrGuardedImprovedDependencyPairs>\n"));
        }
        [ProofStep::DependencyPairProof { proof }] => {
            xml.push_str(&format!("{pad}<csrGuardedDependencyPairs>\n"));
            write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 2, "dps");
            write_guarded_csr_dp_proof_cpf3(xml, proof, csr.rules(), indent + 2);
            xml.push_str(&format!("{pad}</csrGuardedDependencyPairs>\n"));
        }
        _ => {
            return Err(CpfError::UnsupportedProofStep(
                "guarded CSR proof contains an unsupported enclosing step".to_string(),
            ));
        }
    }
    Ok(())
}

fn write_csr_termination_proof_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    write_csr_termination_proof_with_boundary_cpf3(xml, csr, proof, indent, false)
}

fn write_gm_extended_csr_termination_proof_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    write_csr_termination_proof_with_boundary_cpf3(xml, csr, proof, indent, true)
}

fn write_csr_termination_proof_with_boundary_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    proof: &Proof,
    indent: usize,
    allow_extended_root: bool,
) -> Result<(), CpfError> {
    if let [ProofStep::ExactTerminationXml(fragment)] = proof.steps() {
        let pad = " ".repeat(indent);
        for line in fragment.lines() {
            xml.push_str(&format!("{pad}{line}\n"));
        }
        return Ok(());
    }
    if csr_proof_contains_guarded_list_terminal(proof) {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<csrGuardedTerminationProof>\n"));
        write_guarded_csr_termination_body_cpf3(xml, csr, proof, indent + 2)?;
        xml.push_str(&format!("{pad}</csrGuardedTerminationProof>\n"));
        return Ok(());
    }
    if let [
        ProofStep::ContextSensitiveInnermostDependencyPairProof {
            auxiliary_rules,
            proof,
        },
    ] = proof.steps()
    {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<csrOrthogonalityCheck>\n"));
        write_csr_innermost_dependency_pairs_cpf3(xml, csr, auxiliary_rules, proof, indent + 2)?;
        xml.push_str(&format!("{pad}</csrOrthogonalityCheck>\n"));
        return Ok(());
    }

    if let [ProofStep::ContextSensitiveInnermostEquivalence { proof }] = proof.steps() {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<csrOrthogonalityCheck>\n"));
        if let [
            ProofStep::ContextSensitiveInnermostDependencyPairProof {
                auxiliary_rules,
                proof,
            },
        ] = proof.steps()
        {
            write_csr_innermost_dependency_pairs_cpf3(
                xml,
                csr,
                auxiliary_rules,
                proof,
                indent + 2,
            )?;
        } else {
            write_csr_termination_proof_cpf3(xml, csr, proof, indent + 2)?;
        }
        xml.push_str(&format!("{pad}</csrOrthogonalityCheck>\n"));
        return Ok(());
    }

    if let Some(nested) = write_csr_rule_removals_then_improved_cpf3(csr, proof, indent)? {
        xml.push_str(&nested);
        return Ok(());
    }

    if let [
        ProofStep::ContextSensitiveGmTransformation {
            mark_symbol,
            active_symbols,
            transformed_rules,
            proof: continuation,
        },
    ] = proof.steps()
    {
        let pad = " ".repeat(indent);
        let ground_constant = csr
            .trs()
            .arities()
            .into_iter()
            .find_map(|(symbol, arity)| (arity == 0).then_some(symbol))
            .ok_or_else(|| {
                CpfError::UnsupportedProofStep(
                    "Giesl-Middeldorp CSR transformation requires a source constant".to_string(),
                )
            })?;
        let transformed = Trs::new_with_strategy(
            csr.trs().name().map(str::to_string),
            csr.trs().variables().clone(),
            transformed_rules.clone(),
            RewriteStrategy::Full,
        );
        let arities = csr.trs().arities();
        xml.push_str(&format!("{pad}<csrGmTransformation>\n"));
        xml.push_str(&format!("{pad}  <markSymbol>\n"));
        write_symbol_cpf3(xml, mark_symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}  </markSymbol>\n"));
        xml.push_str(&format!("{pad}  <groundConstant>\n"));
        write_symbol_cpf3(xml, ground_constant.as_str(), indent + 4);
        xml.push_str(&format!("{pad}  </groundConstant>\n"));
        for (source, target) in active_symbols {
            let arity = arities.get(source).copied().ok_or_else(|| {
                CpfError::UnsupportedProofStep(format!(
                    "GM active-symbol source {source} is absent from the source signature"
                ))
            })?;
            xml.push_str(&format!("{pad}  <activeSymbol>\n"));
            xml.push_str(&format!("{pad}    <sourceSymbol>\n"));
            write_symbol_cpf3(xml, source.as_str(), indent + 6);
            xml.push_str(&format!("{pad}    </sourceSymbol>\n"));
            xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
            xml.push_str(&format!("{pad}    <targetSymbol>\n"));
            write_symbol_cpf3(xml, target.as_str(), indent + 6);
            xml.push_str(&format!("{pad}    </targetSymbol>\n"));
            xml.push_str(&format!("{pad}  </activeSymbol>\n"));
        }
        xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
        write_trs_termination_proof_cpf3(xml, &transformed, continuation, indent + 4)?;
        xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
        xml.push_str(&format!("{pad}</csrGmTransformation>\n"));
        return Ok(());
    }

    let pad = " ".repeat(indent);
    let steps = if matches!(proof.steps().last(), Some(ProofStep::Unsupported { .. })) {
        &proof.steps()[..proof.steps().len() - 1]
    } else {
        proof.steps()
    };
    if proof.status() == &Status::Unknown && steps.is_empty() {
        // CPF 4.0 has no CSR assumption constructor.  This Ferrum-only
        // reconstruction marker is never submitted as a certificate: the
        // campaign replaces it with a complete certified csrTerminationProof
        // and checks the assembled document with production CeTA.
        xml.push_str(&format!("{pad}<csrTerminationAssumption>\n"));
        xml.push_str(&format!("{pad}  <trsInput>\n"));
        write_trs_cpf3(xml, csr.trs(), indent + 4);
        write_context_sensitive_strategy_cpf3(xml, csr, indent + 4);
        xml.push_str(&format!("{pad}  </trsInput>\n"));
        xml.push_str(&format!("{pad}</csrTerminationAssumption>\n"));
        return Ok(());
    }
    if let [
        ProofStep::ContextSensitiveDependencyPairProof {
            construction,
            auxiliary_rules,
            proof,
        },
    ] = steps
    {
        use crate::proving::ContextSensitiveDependencyPairConstruction as Construction;
        match construction {
            Construction::Improved => {
                if indent > 4 && !allow_extended_root {
                    return Err(CpfError::UnsupportedProofStep(
                        "improved CSR dependency pairs are not a native csrTerminationProof continuation"
                            .to_string(),
                    ));
                }
                let certificate_pairs = certificate_improved_csr_dependency_pairs(csr);
                let mut normalized_proof = (**proof).clone();
                convert_complete_subterm_closures_to_csr_size_change(&mut normalized_proof);
                let certificate_proof = improved_csr_certificate_proof(
                    &normalized_proof,
                    &certificate_pairs,
                    &fresh_unhiding_symbol(csr.trs()),
                );
                let emitted_proof = certificate_proof.as_ref().unwrap_or(&normalized_proof);
                xml.push_str(&format!("{pad}<csrImprovedDependencyPairs>\n"));
                xml.push_str(&format!("{pad}  <unhidingSymbol>\n"));
                write_symbol_cpf3(xml, fresh_unhiding_symbol(csr.trs()).as_str(), indent + 4);
                xml.push_str(&format!("{pad}  </unhidingSymbol>\n"));
                write_dependency_pairs_trs_cpf3(xml, &emitted_proof.pairs, indent + 2, "dps");
                write_csr_dp_proof_cpf3(xml, emitted_proof, csr, false, indent + 2);
                xml.push_str(&format!("{pad}</csrImprovedDependencyPairs>\n"));
                return Ok(());
            }
            Construction::Rta08 => {
                if indent > 4 && !allow_extended_root {
                    return Err(CpfError::UnsupportedProofStep(
                        "RTA'08 CSR dependency pairs are not a native csrTerminationProof continuation"
                            .to_string(),
                    ));
                }
                xml.push_str(&format!("{pad}<csrRta08DependencyPairs>\n"));
                write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 2, "dps");
                write_csr_dp_proof_cpf3(xml, proof, csr, false, indent + 2);
                xml.push_str(&format!("{pad}</csrRta08DependencyPairs>\n"));
                return Ok(());
            }
            Construction::MutermExpandedInnermost => {
                if indent > 4 && !allow_extended_root {
                    return Err(CpfError::UnsupportedProofStep(
                        "expanded innermost MU-TERM pairs are only valid at the CSR root"
                            .to_string(),
                    ));
                }
                let original_pairs = rta_csr_dependency_pairs(csr);
                let expanded_pairs = muterm_expanded_dependency_pairs(csr);
                if !same_dependency_pair_rules(&proof.pairs, &expanded_pairs) {
                    return Err(CpfError::UnsupportedProofStep(
                        "expanded innermost MU-TERM proof does not match the reconstructed pairs"
                            .to_string(),
                    ));
                }
                let mut expanded_proof = (**proof).clone();
                normalize_muterm_redundant_splits(&mut expanded_proof);
                let mut local_usable = None;
                let one_boundary = expanded_proof.component_proofs.iter().all(|component| {
                    component.proof_tree.as_deref().is_none_or(|tree| {
                        collect_muterm_ordinary_usable_boundary(tree, &mut local_usable)
                    })
                });
                if one_boundary && let Some(local_usable) = local_usable {
                    for component in &mut expanded_proof.component_proofs {
                        if let Some(tree) = component.proof_tree.as_deref_mut() {
                            promote_muterm_usable_reductions_to_full(tree);
                        }
                    }
                    xml.push_str(&format!(
                        "{pad}<csrMutermExpandedInnermostUsableDependencyPairs>\n"
                    ));
                    write_dependency_pairs_trs_cpf3(xml, &original_pairs, indent + 2, "dps");
                    write_rules_trs_cpf3(xml, auxiliary_rules, indent + 2, "unhidingRules");
                    write_rules_trs_cpf3(xml, &local_usable, indent + 2, "usableRules");
                    write_dp_proof_cpf3(xml, &expanded_proof, indent + 2);
                    xml.push_str(&format!(
                        "{pad}</csrMutermExpandedInnermostUsableDependencyPairs>\n"
                    ));
                } else {
                    xml.push_str(&format!(
                        "{pad}<csrMutermExpandedInnermostDependencyPairs>\n"
                    ));
                    write_dependency_pairs_trs_cpf3(xml, &original_pairs, indent + 2, "dps");
                    write_rules_trs_cpf3(xml, auxiliary_rules, indent + 2, "unhidingRules");
                    write_csr_dp_proof_cpf3(xml, &expanded_proof, csr, false, indent + 2);
                    xml.push_str(&format!(
                        "{pad}</csrMutermExpandedInnermostDependencyPairs>\n"
                    ));
                }
                return Ok(());
            }
            Construction::MutermUnhiding => {
                if indent > 4 && !allow_extended_root {
                    return Err(CpfError::UnsupportedProofStep(
                        "MU-TERM innermost CSR dependency pairs are not a nested csrTerminationProof continuation"
                            .to_string(),
                    ));
                }
                let original_pairs = rta_csr_dependency_pairs(csr);
                let expanded_pairs = muterm_expanded_dependency_pairs(csr);
                if same_dependency_pair_rules(&proof.pairs, &expanded_pairs) {
                    let mut expanded_proof = (**proof).clone();
                    normalize_muterm_redundant_splits(&mut expanded_proof);
                    promote_muterm_instantiations_to_csr(&mut expanded_proof);
                    xml.push_str(&format!("{pad}<csrMutermTypedDependencyPairs>\n"));
                    write_dependency_pairs_trs_cpf3(xml, &original_pairs, indent + 2, "dps");
                    write_rules_trs_cpf3(xml, auxiliary_rules, indent + 2, "unhidingRules");
                    // Preserve the typed recursive boundary even when Ferrum
                    // searches the checker's exact expanded state.  Emitting
                    // this as one ordinary CSR proof loses the local usable-
                    // rule obligations carried by each typed component.
                    write_muterm_typed_dp_proof_cpf3(
                        xml,
                        &expanded_proof,
                        csr,
                        auxiliary_rules,
                        indent + 2,
                    )?;
                    xml.push_str(&format!("{pad}</csrMutermTypedDependencyPairs>\n"));
                    return Ok(());
                }
                let mut typed_proof = (**proof).clone();
                normalize_muterm_redundant_splits(&mut typed_proof);
                let requires_usable_boundary = csr_dp_proof_requires_minimality(&typed_proof);
                let tag = if requires_usable_boundary {
                    "csrMutermTypedDependencyPairs"
                } else {
                    "csrMutermInnermostDependencyPairs"
                };
                xml.push_str(&format!("{pad}<{tag}>\n"));
                write_dependency_pairs_trs_cpf3(xml, &typed_proof.pairs, indent + 2, "dps");
                write_rules_trs_cpf3(xml, auxiliary_rules, indent + 2, "unhidingRules");
                if requires_usable_boundary {
                    write_muterm_typed_dp_proof_cpf3(
                        xml,
                        &typed_proof,
                        csr,
                        auxiliary_rules,
                        indent + 2,
                    )?;
                } else {
                    let mut rules = csr.rules().to_vec();
                    for rule in auxiliary_rules {
                        if !rules.contains(rule) {
                            rules.push(rule.clone());
                        }
                    }
                    let proof_trs = Trs::new_with_strategy(
                        csr.trs().name().map(str::to_owned),
                        csr.trs().variables().clone(),
                        rules,
                        RewriteStrategy::Innermost,
                    );
                    let proof_csr = CsrTrs::new(proof_trs, csr.replacement_map().clone()).map_err(
                        |issues| {
                            CpfError::UnsupportedProofStep(format!(
                                "invalid MU-TERM auxiliary-rule replacement map: {issues:?}"
                            ))
                        },
                    )?;
                    write_csr_dp_proof_cpf3(xml, &typed_proof, &proof_csr, false, indent + 2);
                }
                xml.push_str(&format!("{pad}</{tag}>\n"));
                return Ok(());
            }
            Construction::Conservative => {
                if indent > 4 && !allow_extended_root {
                    return Err(CpfError::UnsupportedProofStep(
                        "conservative CSR dependency pairs are not a native csrTerminationProof continuation"
                            .to_string(),
                    ));
                }
                let (conservative_csr, _) = conservative_csr_dependency_problem(csr);
                xml.push_str(&format!("{pad}<conservativeCsrTerminationProof>\n"));
                xml.push_str(&format!("{pad}  <csrConservativeDependencyPairs>\n"));
                xml.push_str(&format!("{pad}    <unhidingSymbol>\n"));
                write_symbol_cpf3(xml, fresh_unhiding_symbol(csr.trs()).as_str(), indent + 6);
                xml.push_str(&format!("{pad}    </unhidingSymbol>\n"));
                write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 4, "dps");
                write_rules_trs_cpf3(xml, auxiliary_rules, indent + 4, "auxiliaryRules");
                write_csr_dp_proof_cpf3(xml, proof, &conservative_csr, false, indent + 4);
                xml.push_str(&format!("{pad}  </csrConservativeDependencyPairs>\n"));
                xml.push_str(&format!("{pad}</conservativeCsrTerminationProof>\n"));
                return Ok(());
            }
            Construction::Native | Construction::Safe => {}
        }
    }
    if let [ProofStep::DependencyPairProof { proof }] = steps {
        let exact_pairs = improved_csr_dependency_pairs(csr);
        let certificate_pairs = certificate_improved_csr_dependency_pairs(csr);
        let safe_pairs = safe_csr_dependency_pairs(csr);
        let rta_pairs = rta_csr_dependency_pairs(csr);
        if same_dependency_pair_rules(&proof.pairs, &rta_pairs)
            && proof.component_proofs.len() == 1
            && proof.component_proofs[0].proved
            && same_dependency_pair_rules(&proof.component_proofs[0].pairs, &proof.pairs)
            && matches!(
                proof.component_proofs[0].proof_tree.as_deref(),
                Some(crate::proving::DpProofTree::RedPair { .. })
            )
        {
            xml.push_str(&format!("{pad}<csrRta08DependencyPairs>\n"));
            write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 2, "dps");
            write_csr_dp_component_proof_cpf3(
                xml,
                &proof.component_proofs[0],
                proof.strategy,
                csr.rules(),
                None,
                indent + 2,
            );
            xml.push_str(&format!("{pad}</csrRta08DependencyPairs>\n"));
            return Ok(());
        }
        // CeTA admits the native improved-DP constructor only as a top-level
        // CSR proof alternative.  A csrRuleRemoval continuation is an
        // ordinary csrTerminationProof and must use csrSafeDependencyPairs or
        // csrDependencyPairs instead.
        if indent <= 4
            && (same_dependency_pair_rules(&proof.pairs, &exact_pairs)
                || same_dependency_pair_rules(&proof.pairs, &certificate_pairs))
            && !(csr_dp_proof_requires_minimality(proof)
                && same_dependency_pair_rules(&proof.pairs, &safe_pairs))
        {
            let mut normalized_proof = proof.clone();
            convert_complete_subterm_closures_to_csr_size_change(&mut normalized_proof);
            let certificate_proof = improved_csr_certificate_proof(
                &normalized_proof,
                &certificate_pairs,
                &fresh_unhiding_symbol(csr.trs()),
            );
            let emitted_proof = certificate_proof.as_ref().unwrap_or(&normalized_proof);
            xml.push_str(&format!("{pad}<csrImprovedDependencyPairs>\n"));
            xml.push_str(&format!("{pad}  <unhidingSymbol>\n"));
            write_symbol_cpf3(xml, fresh_unhiding_symbol(csr.trs()).as_str(), indent + 4);
            xml.push_str(&format!("{pad}  </unhidingSymbol>\n"));
            write_dependency_pairs_trs_cpf3(xml, &emitted_proof.pairs, indent + 2, "dps");
            write_csr_dp_proof_cpf3(xml, emitted_proof, csr, false, indent + 2);
            xml.push_str(&format!("{pad}</csrImprovedDependencyPairs>\n"));
            return Ok(());
        }

        let (conservative_csr, conservative_pairs) = conservative_csr_dependency_problem(csr);
        if !same_dependency_pair_rules(&proof.pairs, &safe_pairs)
            && same_dependency_pair_rules(&proof.pairs, &conservative_pairs)
        {
            xml.push_str(&format!("{pad}<conservativeCsrTerminationProof>\n"));
            xml.push_str(&format!("{pad}  <csrConservativeDependencyPairs>\n"));
            let body_indent = indent + 2;
            let body_pad = " ".repeat(body_indent);
            xml.push_str(&format!("{body_pad}  <unhidingSymbol>\n"));
            write_symbol_cpf3(
                xml,
                fresh_unhiding_symbol(csr.trs()).as_str(),
                body_indent + 4,
            );
            xml.push_str(&format!("{body_pad}  </unhidingSymbol>\n"));
            write_dependency_pairs_trs_cpf3(xml, &proof.pairs, body_indent + 2, "dps");
            write_rules_trs_cpf3(
                xml,
                conservative_csr.rules(),
                body_indent + 2,
                "auxiliaryRules",
            );
            write_csr_dp_proof_cpf3(xml, proof, &conservative_csr, false, body_indent + 2);
            xml.push_str(&format!("{pad}  </csrConservativeDependencyPairs>\n"));
            xml.push_str(&format!("{pad}</conservativeCsrTerminationProof>\n"));
            return Ok(());
        }
    }
    if let [
        ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations,
            removed,
            proof: continuation,
        },
    ] = steps
    {
        let remaining = trs_without_rules(csr.trs(), removed);
        let remaining_replacement_map =
            replacement_map_for_arities(csr.replacement_map(), &remaining.arities());
        let remaining_csr =
            CsrTrs::new(remaining, remaining_replacement_map).map_err(|issues| {
                CpfError::UnsupportedProofStep(format!(
                    "remaining CSR replacement map is invalid for CPF export: {}",
                    issues
                        .into_iter()
                        .map(|issue| issue.to_string())
                        .collect::<Vec<_>>()
                        .join("; ")
                ))
            })?;
        if let [
            ProofStep::ContextSensitiveDependencyPairProof {
                construction: crate::proving::ContextSensitiveDependencyPairConstruction::Improved,
                auxiliary_rules: _,
                proof: dp_proof,
            },
        ] = continuation.steps()
        {
            let exact_pairs = improved_csr_dependency_pairs(&remaining_csr);
            let certificate_pairs = certificate_improved_csr_dependency_pairs(&remaining_csr);
            let safe_pairs = safe_csr_dependency_pairs(&remaining_csr);
            // This constructor is a top-level conservative CSR proof
            // alternative.  Emitting it as the continuation of an ordinary
            // <csrRuleRemoval> produces a document outside the parser grammar.
            if indent <= 4
                && (same_dependency_pair_rules(&dp_proof.pairs, &exact_pairs)
                    || same_dependency_pair_rules(&dp_proof.pairs, &certificate_pairs))
                && !(csr_dp_proof_requires_minimality(dp_proof)
                    && same_dependency_pair_rules(&dp_proof.pairs, &safe_pairs))
            {
                let mut normalized_proof = (**dp_proof).clone();
                convert_complete_subterm_closures_to_csr_size_change(&mut normalized_proof);
                let certificate_proof = improved_csr_certificate_proof(
                    &normalized_proof,
                    &certificate_pairs,
                    &fresh_unhiding_symbol(remaining_csr.trs()),
                );
                let emitted_proof = certificate_proof.as_ref().unwrap_or(&normalized_proof);
                let mut arities = remaining_csr.trs().arities();
                for rule in removed {
                    collect_term_arities(rule.lhs(), &mut arities);
                    collect_term_arities(rule.rhs(), &mut arities);
                }
                xml.push_str(&format!("{pad}<csrRuleRemovalThenImproved>\n"));
                write_polynomial_interpretation_for_arities_cpf3(
                    xml,
                    arities,
                    interpretations,
                    indent + 2,
                );
                write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
                xml.push_str(&format!("{pad}  <unhidingSymbol>\n"));
                write_symbol_cpf3(
                    xml,
                    fresh_unhiding_symbol(remaining_csr.trs()).as_str(),
                    indent + 4,
                );
                xml.push_str(&format!("{pad}  </unhidingSymbol>\n"));
                write_dependency_pairs_trs_cpf3(xml, &emitted_proof.pairs, indent + 2, "dps");
                write_csr_dp_proof_cpf3(xml, emitted_proof, &remaining_csr, false, indent + 2);
                xml.push_str(&format!("{pad}</csrRuleRemovalThenImproved>\n"));
                return Ok(());
            }
        }
    }
    xml.push_str(&format!("{pad}<csrTerminationProof>\n"));
    let body_indent = indent + 2;
    let body_pad = " ".repeat(body_indent);
    match steps {
        [ProofStep::EmptySystem] => {
            xml.push_str(&format!("{body_pad}<rIsEmpty/>\n"));
        }
        [
            ProofStep::ContextSensitivePolynomialRuleRemoval {
                interpretations,
                removed,
                proof,
            },
        ] => {
            let remaining = trs_without_rules(csr.trs(), removed);
            let remaining_replacement_map =
                replacement_map_for_arities(csr.replacement_map(), &remaining.arities());
            let remaining_csr =
                CsrTrs::new(remaining, remaining_replacement_map).map_err(|issues| {
                    CpfError::UnsupportedProofStep(format!(
                        "remaining CSR replacement map is invalid for CPF export: {}",
                        issues
                            .into_iter()
                            .map(|issue| issue.to_string())
                            .collect::<Vec<_>>()
                            .join("; ")
                    ))
                })?;
            let mut arities = remaining_csr.trs().arities();
            for rule in removed {
                collect_term_arities(rule.lhs(), &mut arities);
                collect_term_arities(rule.rhs(), &mut arities);
            }
            xml.push_str(&format!("{body_pad}<csrRuleRemoval>\n"));
            write_polynomial_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretations,
                body_indent + 2,
            );
            write_rules_trs_cpf3(xml, removed, body_indent + 2, "trs");
            write_csr_termination_proof_cpf3(xml, &remaining_csr, proof, body_indent + 2)?;
            xml.push_str(&format!("{body_pad}</csrRuleRemoval>\n"));
        }
        [
            ProofStep::ContextSensitiveMatrixRuleRemoval {
                interpretations,
                dimension,
                strict_dimension,
                removed,
                proof,
            },
        ] => {
            let remaining = trs_without_rules(csr.trs(), removed);
            let remaining_replacement_map =
                replacement_map_for_arities(csr.replacement_map(), &remaining.arities());
            let remaining_csr =
                CsrTrs::new(remaining, remaining_replacement_map).map_err(|issues| {
                    CpfError::UnsupportedProofStep(format!(
                        "remaining CSR replacement map is invalid for CPF export: {}",
                        issues
                            .into_iter()
                            .map(|issue| issue.to_string())
                            .collect::<Vec<_>>()
                            .join("; ")
                    ))
                })?;
            let mut arities = remaining_csr.trs().arities();
            for rule in removed {
                collect_term_arities(rule.lhs(), &mut arities);
                collect_term_arities(rule.rhs(), &mut arities);
            }
            xml.push_str(&format!("{body_pad}<csrRuleRemoval>\n"));
            write_matrix_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretations,
                *dimension,
                *strict_dimension,
                "naturals",
                body_indent + 2,
            );
            write_rules_trs_cpf3(xml, removed, body_indent + 2, "trs");
            write_csr_termination_proof_cpf3(xml, &remaining_csr, proof, body_indent + 2)?;
            xml.push_str(&format!("{body_pad}</csrRuleRemoval>\n"));
        }
        [
            ProofStep::ContextSensitiveDependencyPairProof {
                construction,
                auxiliary_rules: _,
                proof,
            },
        ] => {
            let tag = match construction {
                crate::proving::ContextSensitiveDependencyPairConstruction::Native => {
                    "csrDependencyPairs"
                }
                crate::proving::ContextSensitiveDependencyPairConstruction::Safe => {
                    "csrSafeDependencyPairs"
                }
                crate::proving::ContextSensitiveDependencyPairConstruction::Improved
                | crate::proving::ContextSensitiveDependencyPairConstruction::MutermUnhiding
                | crate::proving::ContextSensitiveDependencyPairConstruction::MutermExpandedInnermost
                | crate::proving::ContextSensitiveDependencyPairConstruction::Rta08
                | crate::proving::ContextSensitiveDependencyPairConstruction::Conservative => {
                    unreachable!(
                        "extension CSR-DP constructors are emitted before csrTerminationProof"
                    )
                }
            };
            xml.push_str(&format!("{body_pad}<{tag}>\n"));
            write_dependency_pairs_trs_cpf3(xml, &proof.pairs, body_indent + 2, "dps");
            write_csr_dp_proof_cpf3(
                xml,
                proof,
                csr,
                tag == "csrDependencyPairs",
                body_indent + 2,
            );
            xml.push_str(&format!("{body_pad}</{tag}>\n"));
        }
        [ProofStep::DependencyPairProof { proof }] => {
            xml.push_str(&format!("{body_pad}<csrDependencyPairs>\n"));
            write_dependency_pairs_trs_cpf3(xml, &proof.pairs, body_indent + 2, "dps");
            write_csr_dp_proof_cpf3(xml, proof, csr, true, body_indent + 2);
            xml.push_str(&format!("{body_pad}</csrDependencyPairs>\n"));
        }
        [step] => Err(CpfError::UnsupportedProofStep(format!(
            "native IsaFoR/CeTA CSR proof output does not support proof step: {step:?}"
        )))?,
        [] => Err(CpfError::UnsupportedProofStep(
            "empty CSR proof".to_string(),
        ))?,
        steps => Err(CpfError::UnsupportedProofStep(format!(
            "native IsaFoR/CeTA CSR proof output does not support multi-step proof with {} steps",
            steps.len()
        )))?,
    };
    xml.push_str(&format!("{pad}</csrTerminationProof>\n"));
    Ok(())
}

/// Flatten a compositional CSR rule-removal chain whose final residual is
/// discharged by improved CS-DPs.  The ordinary CPF nesting cannot express
/// the extension-level improved transformation below a `csrRuleRemoval`, so
/// the production checker accepts the equivalent list of individually
/// checked removal steps and reconstructs every intermediate residual.
fn write_csr_rule_removals_then_improved_cpf3(
    csr: &CsrTrs,
    proof: &Proof,
    indent: usize,
) -> Result<Option<String>, CpfError> {
    let pad = " ".repeat(indent);
    let mut body = String::new();
    let mut current_csr = csr.clone();
    let mut current_proof = proof;
    let mut removal_count = 0usize;

    loop {
        match current_proof.steps() {
            [
                ProofStep::ContextSensitivePolynomialRuleRemoval {
                    interpretations,
                    removed,
                    proof: continuation,
                },
            ] => {
                let remaining = trs_without_rules(current_csr.trs(), removed);
                let remaining_map = replacement_map_for_arities(
                    current_csr.replacement_map(),
                    &remaining.arities(),
                );
                let remaining_csr = CsrTrs::new(remaining, remaining_map).map_err(|issues| {
                    CpfError::UnsupportedProofStep(format!(
                        "remaining CSR replacement map is invalid after nested rule removal: {}",
                        issues
                            .into_iter()
                            .map(|issue| issue.to_string())
                            .collect::<Vec<_>>()
                            .join("; ")
                    ))
                })?;
                let mut arities = remaining_csr.trs().arities();
                for rule in removed {
                    collect_term_arities(rule.lhs(), &mut arities);
                    collect_term_arities(rule.rhs(), &mut arities);
                }
                body.push_str(&format!("{pad}  <ruleRemoval>\n"));
                write_polynomial_interpretation_for_arities_cpf3(
                    &mut body,
                    arities,
                    interpretations,
                    indent + 4,
                );
                write_rules_trs_cpf3(&mut body, removed, indent + 4, "trs");
                body.push_str(&format!("{pad}  </ruleRemoval>\n"));
                removal_count += 1;
                current_csr = remaining_csr;
                current_proof = continuation;
            }
            [
                ProofStep::ContextSensitiveMatrixRuleRemoval {
                    interpretations,
                    dimension,
                    strict_dimension,
                    removed,
                    proof: continuation,
                },
            ] => {
                let remaining = trs_without_rules(current_csr.trs(), removed);
                let remaining_map = replacement_map_for_arities(
                    current_csr.replacement_map(),
                    &remaining.arities(),
                );
                let remaining_csr = CsrTrs::new(remaining, remaining_map).map_err(|issues| {
                    CpfError::UnsupportedProofStep(format!(
                        "remaining CSR replacement map is invalid after nested rule removal: {}",
                        issues
                            .into_iter()
                            .map(|issue| issue.to_string())
                            .collect::<Vec<_>>()
                            .join("; ")
                    ))
                })?;
                let mut arities = remaining_csr.trs().arities();
                for rule in removed {
                    collect_term_arities(rule.lhs(), &mut arities);
                    collect_term_arities(rule.rhs(), &mut arities);
                }
                body.push_str(&format!("{pad}  <ruleRemoval>\n"));
                write_matrix_interpretation_for_arities_cpf3(
                    &mut body,
                    arities,
                    interpretations,
                    *dimension,
                    *strict_dimension,
                    "naturals",
                    indent + 4,
                );
                write_rules_trs_cpf3(&mut body, removed, indent + 4, "trs");
                body.push_str(&format!("{pad}  </ruleRemoval>\n"));
                removal_count += 1;
                current_csr = remaining_csr;
                current_proof = continuation;
            }
            [
                ProofStep::ContextSensitiveDependencyPairProof {
                    construction:
                        crate::proving::ContextSensitiveDependencyPairConstruction::Improved,
                    auxiliary_rules: _,
                    proof: dp_proof,
                },
            ] if removal_count > 0 => {
                let exact_pairs = improved_csr_dependency_pairs(&current_csr);
                let certificate_pairs = certificate_improved_csr_dependency_pairs(&current_csr);
                let mut normalized_proof = (**dp_proof).clone();
                convert_complete_subterm_closures_to_csr_size_change(&mut normalized_proof);
                let unhiding = fresh_unhiding_symbol(current_csr.trs());
                let certificate_proof = improved_csr_certificate_proof(
                    &normalized_proof,
                    &certificate_pairs,
                    &unhiding,
                );
                if certificate_proof.is_none()
                    && !same_dependency_pair_rules(&dp_proof.pairs, &exact_pairs)
                    && !same_dependency_pair_rules(&dp_proof.pairs, &certificate_pairs)
                {
                    return Ok(None);
                }
                let emitted = certificate_proof.as_ref().unwrap_or(&normalized_proof);
                body.push_str(&format!("{pad}  <unhidingSymbol>\n"));
                write_symbol_cpf3(&mut body, unhiding.as_str(), indent + 4);
                body.push_str(&format!("{pad}  </unhidingSymbol>\n"));
                write_dependency_pairs_trs_cpf3(&mut body, &emitted.pairs, indent + 2, "dps");
                write_csr_dp_proof_cpf3(&mut body, emitted, &current_csr, false, indent + 2);
                let mut xml = format!("{pad}<csrRuleRemovalsThenImproved>\n");
                xml.push_str(&body);
                xml.push_str(&format!("{pad}</csrRuleRemovalsThenImproved>\n"));
                return Ok(Some(xml));
            }
            _ => return Ok(None),
        }
    }
}

fn write_csr_innermost_dependency_pairs_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    auxiliary_rules: &[RewriteRule],
    proof: &DependencyPairProof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    let mut rules = csr.rules().to_vec();
    for rule in auxiliary_rules {
        if !rules.contains(rule) {
            rules.push(rule.clone());
        }
    }
    let problem_trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_string),
        csr.trs().variables().clone(),
        rules,
        RewriteStrategy::Innermost,
    );
    let problem_csr =
        CsrTrs::new(problem_trs, csr.replacement_map().clone()).map_err(|issues| {
            CpfError::UnsupportedProofStep(format!(
                "innermost CSR auxiliary problem has an invalid replacement map: {}",
                issues
                    .into_iter()
                    .map(|issue| issue.to_string())
                    .collect::<Vec<_>>()
                    .join("; ")
            ))
        })?;
    xml.push_str(&format!("{pad}<csrInnermostDependencyPairs>\n"));
    write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 2, "dps");
    write_rules_trs_cpf3(xml, auxiliary_rules, indent + 2, "auxiliaryRules");
    write_csr_dp_proof_cpf3(xml, proof, &problem_csr, false, indent + 2);
    xml.push_str(&format!("{pad}</csrInnermostDependencyPairs>\n"));
    Ok(())
}

fn same_dependency_pair_rules(
    left: &[crate::proving::DependencyPair],
    right: &[crate::proving::DependencyPair],
) -> bool {
    left.len() == right.len()
        && left.iter().all(|pair| {
            right
                .iter()
                .any(|other| pair.lhs() == other.lhs() && pair.rhs() == other.rhs())
        })
}

fn improved_csr_certificate_proof(
    proof: &crate::proving::DependencyPairProof,
    certificate_pairs: &[crate::proving::DependencyPair],
    unhiding_symbol: &Symbol,
) -> Option<crate::proving::DependencyPairProof> {
    if same_dependency_pair_rules(&proof.pairs, certificate_pairs) {
        let mut proof = proof.clone();
        convert_complete_subterm_closures_to_csr_size_change(&mut proof);
        return Some(proof);
    }
    if !proof.pairs.iter().all(|pair| {
        certificate_pairs
            .iter()
            .any(|other| pair.lhs() == other.lhs() && pair.rhs() == other.rhs())
    }) {
        return None;
    }

    let projection_pairs = certificate_pairs
        .iter()
        .filter(|pair| is_unhiding_projection_pair(pair, unhiding_symbol))
        .cloned()
        .collect::<Vec<_>>();
    let mut merged_at = None;
    let mut components = Vec::new();
    for component in &proof.component_proofs {
        let contains_projection = component
            .pairs
            .iter()
            .any(|pair| is_unhiding_projection_pair(pair, unhiding_symbol));
        if contains_projection
            && !component
                .pairs
                .iter()
                .all(|pair| is_unhiding_projection_pair(pair, unhiding_symbol))
        {
            return None;
        }
        if contains_projection {
            merged_at.get_or_insert(components.len());
        } else {
            components.push(component.clone());
        }
    }

    // The search problem may use the refined improved pair set and therefore
    // contain no conservative U(f(...))->U(x_i) projection component at all.
    // CPF certification still has to add CeTA's complete projection
    // obligation.  In that case append the independently closing SCT
    // component instead of abandoning certificate reconstruction.
    let merged_at = merged_at.unwrap_or_else(|| {
        components
            .iter()
            .position(|component| {
                component
                    .pairs
                    .iter()
                    .any(|pair| pair.lhs().root_symbol() == Some(unhiding_symbol))
            })
            .unwrap_or(components.len())
    });
    let projection_graphs = projection_pairs
        .iter()
        .cloned()
        .map(|pair| crate::proving::DpSizeChangeGraph {
            pair,
            edges: vec![crate::proving::DpSizeChangeEdge {
                left_position: 1,
                right_position: 1,
                strict: true,
            }],
        })
        .collect();
    components.insert(
        merged_at,
        crate::proving::DpComponentProof {
            pairs: projection_pairs,
            usable_rules: Vec::new(),
            interpretation: None,
            backend: None,
            usable_rules_processor: None,
            innermost_lhss_processor: None,
            reductions: Vec::new(),
            final_acyclic_components: Vec::new(),
            proof_tree: Some(Box::new(crate::proving::DpProofTree::SizeChange {
                graphs: projection_graphs,
            })),
            proved: true,
        },
    );

    let mut certificate_proof = proof.clone();
    certificate_proof.initial_pairs = certificate_pairs.len();
    certificate_proof.components = components.len();
    certificate_proof.pairs = certificate_pairs.to_vec();
    certificate_proof.component_proofs = components;
    convert_complete_subterm_closures_to_csr_size_change(&mut certificate_proof);
    Some(certificate_proof)
}

fn convert_complete_subterm_closures_to_csr_size_change(
    proof: &mut crate::proving::DependencyPairProof,
) {
    for component in &mut proof.component_proofs {
        let Some(tree) = component.proof_tree.as_deref_mut() else {
            continue;
        };
        convert_complete_subterm_tree_to_csr_size_change(tree);
    }
}

fn convert_complete_subterm_tree_to_csr_size_change(tree: &mut crate::proving::DpProofTree) {
    match tree {
        crate::proving::DpProofTree::Subterm {
            strict_pairs,
            graphs,
            proof,
            ..
        } if matches!(proof.as_ref(), crate::proving::DpProofTree::Empty)
            && strict_pairs.len() == graphs.len()
            && graphs.iter().all(|graph| {
                let (
                    Term::App {
                        symbol: lhs_root,
                        args: lhs_args,
                    },
                    Term::App {
                        symbol: rhs_root,
                        args: rhs_args,
                    },
                ) = (graph.pair.lhs(), graph.pair.rhs())
                else {
                    return false;
                };
                // Only the fresh unary unhiding component may be represented
                // equivalently as a bare size-change proof.  Marked/mixed
                // projections must retain `<subtermProc>` so CeTA checks the
                // selected arguments with its improved-CS-DP criterion.
                !lhs_root.as_str().ends_with('#')
                    && lhs_root == rhs_root
                    && lhs_args.len() == 1
                    && rhs_args.len() == 1
                    && graph.edges.iter().all(|edge| {
                        edge.strict && edge.left_position == 1 && edge.right_position == 1
                    })
            }) =>
        {
            *tree = crate::proving::DpProofTree::SizeChange {
                graphs: graphs.clone(),
            };
        }
        crate::proving::DpProofTree::DepGraph { components } => {
            for component in components {
                if let Some(tree) = component.proof_tree.as_deref_mut() {
                    convert_complete_subterm_tree_to_csr_size_change(tree);
                }
            }
        }
        crate::proving::DpProofTree::GeneralRedPairExact { proofs, .. } => {
            for proof in proofs {
                convert_complete_subterm_tree_to_csr_size_change(proof);
            }
        }
        crate::proving::DpProofTree::ReductionPairExact { proof, .. } => {
            convert_complete_subterm_tree_to_csr_size_change(proof);
        }
        crate::proving::DpProofTree::TransformationExact { proof, .. } => {
            convert_complete_subterm_tree_to_csr_size_change(proof);
        }
        crate::proving::DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            convert_complete_subterm_tree_to_csr_size_change(selected_proof);
            convert_complete_subterm_tree_to_csr_size_change(residual_proof);
        }
        crate::proving::DpProofTree::Instantiation { proof, .. }
        | crate::proving::DpProofTree::SwitchInnermost { proof, .. }
        | crate::proving::DpProofTree::ForwardInstantiation { proof, .. }
        | crate::proving::DpProofTree::Narrowing { proof, .. }
        | crate::proving::DpProofTree::Rewriting { proof, .. }
        | crate::proving::DpProofTree::RedPair { proof, .. }
        | crate::proving::DpProofTree::SemanticLabeling { proof, .. }
        | crate::proving::DpProofTree::Uncurry { proof, .. }
        | crate::proving::DpProofTree::Subterm { proof, .. }
        | crate::proving::DpProofTree::ComponentContext { proof, .. } => {
            convert_complete_subterm_tree_to_csr_size_change(proof);
        }
        crate::proving::DpProofTree::ExactXml(_)
        | crate::proving::DpProofTree::QdpToSrs { .. }
        | crate::proving::DpProofTree::SwitchToTrs { .. }
        | crate::proving::DpProofTree::Empty
        | crate::proving::DpProofTree::SizeChange { .. }
        | crate::proving::DpProofTree::SizeChangeRedPair { .. } => {}
    }
}

fn is_unhiding_projection_pair(
    pair: &crate::proving::DependencyPair,
    unhiding_symbol: &Symbol,
) -> bool {
    let (
        Term::App {
            symbol: lhs_symbol,
            args: lhs_args,
        },
        Term::App {
            symbol: rhs_symbol,
            args: rhs_args,
        },
    ) = (pair.lhs(), pair.rhs())
    else {
        return false;
    };
    if lhs_symbol != unhiding_symbol
        || rhs_symbol != unhiding_symbol
        || lhs_args.len() != 1
        || rhs_args.len() != 1
    {
        return false;
    }
    let Term::App { args, .. } = &lhs_args[0] else {
        return false;
    };
    args.iter().any(|argument| argument == &rhs_args[0])
}

fn write_csr_dp_proof_cpf3(
    xml: &mut String,
    proof: &crate::proving::DependencyPairProof,
    csr: &CsrTrs,
    use_qcs_usable_rules: bool,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    if proof.pairs.is_empty() {
        xml.push_str(&format!("{pad}<csrDpProof>\n"));
        xml.push_str(&format!("{pad}  <pIsEmpty/>\n"));
        xml.push_str(&format!("{pad}</csrDpProof>\n"));
    } else {
        // Export the same conservative closure that proof validation uses.
        // The search-oriented ECap approximation may be smaller, but it is
        // not itself the executable CeTA QCS closure and can therefore turn a
        // sound internal proof into a checker-rejected CPF.
        let usable_rules = use_qcs_usable_rules
            .then(|| qcs_certificate_usable_rules(csr, &proof.pairs))
            .filter(|usable| usable.as_slice() != csr.rules());
        xml.push_str(&format!("{pad}<csrDpProof>\n"));
        let body_indent = indent + 2;
        if let Some(usable) = &usable_rules {
            xml.push_str(&format!("{pad}  <usableRulesProc>\n"));
            write_rules_trs_cpf3(xml, usable, indent + 4, "usableRules");
            xml.push_str(&format!("{pad}    <csrDpProof>\n"));
            write_csr_dp_graph_cpf3(
                xml,
                proof,
                usable,
                use_qcs_usable_rules,
                use_qcs_usable_rules.then_some(csr),
                indent + 6,
            );
            xml.push_str(&format!("{pad}    </csrDpProof>\n"));
            xml.push_str(&format!("{pad}  </usableRulesProc>\n"));
        } else {
            write_csr_dp_graph_cpf3(
                xml,
                proof,
                csr.rules(),
                use_qcs_usable_rules,
                use_qcs_usable_rules.then_some(csr),
                body_indent,
            );
        }
        xml.push_str(&format!("{pad}</csrDpProof>\n"));
    }
}

fn same_rule_set(left: &[RewriteRule], right: &[RewriteRule]) -> bool {
    left.iter().all(|rule| right.contains(rule)) && right.iter().all(|rule| left.contains(rule))
}

fn collect_muterm_ordinary_usable_boundary(
    tree: &crate::proving::DpProofTree,
    boundary: &mut Option<Vec<RewriteRule>>,
) -> bool {
    let mut record = |rules: &[RewriteRule]| {
        if let Some(existing) = boundary.as_mut() {
            for rule in rules {
                if !existing.contains(rule) {
                    existing.push(rule.clone());
                }
            }
            true
        } else {
            *boundary = Some(rules.to_vec());
            true
        }
    };
    match tree {
        crate::proving::DpProofTree::ExactXml(_)
        | crate::proving::DpProofTree::QdpToSrs { .. }
        | crate::proving::DpProofTree::SwitchToTrs { .. }
        | crate::proving::DpProofTree::GeneralRedPairExact { .. }
        | crate::proving::DpProofTree::ReductionPairExact { .. }
        | crate::proving::DpProofTree::TransformationExact { .. } => false,
        crate::proving::DpProofTree::RedPair { reduction, proof } => {
            (!reduction.uses_usable_rules || record(&reduction.usable_rules))
                && collect_muterm_ordinary_usable_boundary(proof, boundary)
        }
        crate::proving::DpProofTree::DepGraph { components } => {
            components.iter().all(|component| {
                component
                    .proof_tree
                    .as_deref()
                    .is_none_or(|proof| collect_muterm_ordinary_usable_boundary(proof, boundary))
            })
        }
        crate::proving::DpProofTree::ComponentContext { proof, .. }
        | crate::proving::DpProofTree::SwitchInnermost { proof, .. }
        | crate::proving::DpProofTree::Subterm { proof, .. }
        | crate::proving::DpProofTree::Narrowing { proof, .. }
        | crate::proving::DpProofTree::Instantiation { proof, .. }
        | crate::proving::DpProofTree::ForwardInstantiation { proof, .. }
        | crate::proving::DpProofTree::Rewriting { proof, .. }
        | crate::proving::DpProofTree::SemanticLabeling { proof, .. }
        | crate::proving::DpProofTree::Uncurry { proof, .. } => {
            collect_muterm_ordinary_usable_boundary(proof, boundary)
        }
        crate::proving::DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            collect_muterm_ordinary_usable_boundary(selected_proof, boundary)
                && collect_muterm_ordinary_usable_boundary(residual_proof, boundary)
        }
        crate::proving::DpProofTree::SizeChangeRedPair { usable_rules, .. } => record(usable_rules),
        crate::proving::DpProofTree::Empty | crate::proving::DpProofTree::SizeChange { .. } => true,
    }
}

fn normalize_muterm_local_usable_boundary(
    tree: &mut crate::proving::DpProofTree,
    boundary: &[RewriteRule],
) -> bool {
    match tree {
        crate::proving::DpProofTree::ExactXml(_)
        | crate::proving::DpProofTree::QdpToSrs { .. }
        | crate::proving::DpProofTree::SwitchToTrs { .. }
        | crate::proving::DpProofTree::GeneralRedPairExact { .. }
        | crate::proving::DpProofTree::ReductionPairExact { .. }
        | crate::proving::DpProofTree::TransformationExact { .. } => false,
        crate::proving::DpProofTree::RedPair { reduction, proof } => {
            if reduction.uses_usable_rules {
                if !reduction
                    .usable_rules
                    .iter()
                    .all(|rule| boundary.contains(rule))
                {
                    return false;
                }
                reduction.usable_rules = boundary.to_vec();
                // The enclosing localUsableRulesProc has already replaced
                // the ordinary DPP's rule component by this exact boundary.
                // Its child reduction pair is therefore a full-rule step,
                // not a second nested usable-rules processor.
                reduction.uses_usable_rules = false;
                // The verified recursive MU-TERM checker deliberately has a
                // single Redpair_Proc constructor.  A monotone witness also
                // satisfies that more general processor, so emit it without
                // changing the interpreted relation.
                reduction.force_non_mono_usable_rules = true;
            }
            normalize_muterm_local_usable_boundary(proof, boundary)
        }
        crate::proving::DpProofTree::DepGraph { components } => {
            components.iter_mut().all(|component| {
                component
                    .proof_tree
                    .as_deref_mut()
                    .is_none_or(|proof| normalize_muterm_local_usable_boundary(proof, boundary))
            })
        }
        crate::proving::DpProofTree::ComponentContext { proof, .. }
        | crate::proving::DpProofTree::SwitchInnermost { proof, .. }
        | crate::proving::DpProofTree::Subterm { proof, .. }
        | crate::proving::DpProofTree::Narrowing { proof, .. }
        | crate::proving::DpProofTree::Instantiation { proof, .. }
        | crate::proving::DpProofTree::ForwardInstantiation { proof, .. }
        | crate::proving::DpProofTree::Rewriting { proof, .. }
        | crate::proving::DpProofTree::SemanticLabeling { proof, .. }
        | crate::proving::DpProofTree::Uncurry { proof, .. } => {
            normalize_muterm_local_usable_boundary(proof, boundary)
        }
        crate::proving::DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            normalize_muterm_local_usable_boundary(selected_proof, boundary)
                && normalize_muterm_local_usable_boundary(residual_proof, boundary)
        }
        crate::proving::DpProofTree::SizeChangeRedPair { usable_rules, .. } => {
            if !usable_rules.iter().all(|rule| boundary.contains(rule)) {
                return false;
            }
            *usable_rules = boundary.to_vec();
            true
        }
        crate::proving::DpProofTree::Empty | crate::proving::DpProofTree::SizeChange { .. } => true,
    }
}

fn muterm_tree_is_recursive_redpair_chain(tree: &crate::proving::DpProofTree) -> bool {
    match tree {
        crate::proving::DpProofTree::Empty => true,
        crate::proving::DpProofTree::RedPair { proof, .. }
        | crate::proving::DpProofTree::ComponentContext { proof, .. } => {
            muterm_tree_is_recursive_redpair_chain(proof)
        }
        crate::proving::DpProofTree::DepGraph { components } => components
            .iter()
            .all(|component| !component.proved && component.proof_tree.is_none()),
        _ => false,
    }
}

fn promote_muterm_usable_reductions_to_full(tree: &mut crate::proving::DpProofTree) {
    match tree {
        crate::proving::DpProofTree::ExactXml(_)
        | crate::proving::DpProofTree::QdpToSrs { .. }
        | crate::proving::DpProofTree::SwitchToTrs { .. }
        | crate::proving::DpProofTree::GeneralRedPairExact { .. }
        | crate::proving::DpProofTree::ReductionPairExact { .. }
        | crate::proving::DpProofTree::TransformationExact { .. } => {}
        crate::proving::DpProofTree::RedPair { reduction, proof } => {
            reduction.uses_usable_rules = false;
            reduction.force_non_mono_usable_rules = false;
            promote_muterm_usable_reductions_to_full(proof);
        }
        crate::proving::DpProofTree::DepGraph { components } => {
            for component in components {
                if let Some(proof) = component.proof_tree.as_deref_mut() {
                    promote_muterm_usable_reductions_to_full(proof);
                }
            }
        }
        crate::proving::DpProofTree::ComponentContext { proof, .. }
        | crate::proving::DpProofTree::SwitchInnermost { proof, .. }
        | crate::proving::DpProofTree::Subterm { proof, .. }
        | crate::proving::DpProofTree::Narrowing { proof, .. }
        | crate::proving::DpProofTree::Instantiation { proof, .. }
        | crate::proving::DpProofTree::ForwardInstantiation { proof, .. }
        | crate::proving::DpProofTree::Rewriting { proof, .. }
        | crate::proving::DpProofTree::SemanticLabeling { proof, .. }
        | crate::proving::DpProofTree::Uncurry { proof, .. } => {
            promote_muterm_usable_reductions_to_full(proof);
        }
        crate::proving::DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            promote_muterm_usable_reductions_to_full(selected_proof);
            promote_muterm_usable_reductions_to_full(residual_proof);
        }
        crate::proving::DpProofTree::Empty
        | crate::proving::DpProofTree::SizeChange { .. }
        | crate::proving::DpProofTree::SizeChangeRedPair { .. } => {}
    }
}

/// A split may retain a reduction-pair witness whose checked input is the
/// complete component.  Its child already proves the residual, so the split
/// is only a search bookkeeping node.  Removing precisely that shape lets the
/// CSR serializer expose the usable-rule processor at the semantic boundary.
fn normalize_muterm_redundant_splits(proof: &mut crate::proving::DependencyPairProof) {
    for component in &mut proof.component_proofs {
        let Some(crate::proving::DpProofTree::Split { selected_proof, .. }) =
            component.proof_tree.as_deref()
        else {
            continue;
        };
        let crate::proving::DpProofTree::RedPair { reduction, .. } = selected_proof.as_ref() else {
            continue;
        };
        let component_rules = component
            .pairs
            .iter()
            .map(crate::proving::DependencyPair::as_rule)
            .collect::<Vec<_>>();
        let reduction_rules = reduction
            .pairs
            .iter()
            .map(crate::proving::DependencyPair::as_rule)
            .collect::<Vec<_>>();
        if same_rule_set(&component_rules, &reduction_rules) {
            component.proof_tree = Some(selected_proof.clone());
        }
    }
}

/// The exact expanded MU-TERM problem remains a minimal CSR-DP problem.
/// Preserve that boundary across instantiation so CeTA checks the
/// replacement-map-aware coverage condition and can continue with the
/// specialized extended-basic reduction triple on the residual state.
fn promote_muterm_instantiations_to_csr(proof: &mut crate::proving::DependencyPairProof) {
    fn visit(tree: &mut crate::proving::DpProofTree) {
        match tree {
            crate::proving::DpProofTree::Instantiation { step, proof } => {
                step.context_sensitive = true;
                visit(proof);
            }
            crate::proving::DpProofTree::DepGraph { components } => {
                for component in components {
                    if let Some(tree) = component.proof_tree.as_deref_mut() {
                        visit(tree);
                    }
                }
            }
            crate::proving::DpProofTree::Split {
                selected_proof,
                residual_proof,
                ..
            } => {
                visit(selected_proof);
                visit(residual_proof);
            }
            crate::proving::DpProofTree::RedPair { proof, .. }
            | crate::proving::DpProofTree::Subterm { proof, .. }
            | crate::proving::DpProofTree::Rewriting { proof, .. }
            | crate::proving::DpProofTree::Narrowing { proof, .. }
            | crate::proving::DpProofTree::ForwardInstantiation { proof, .. }
            | crate::proving::DpProofTree::ComponentContext { proof, .. }
            | crate::proving::DpProofTree::SwitchInnermost { proof, .. }
            | crate::proving::DpProofTree::Uncurry { proof, .. }
            | crate::proving::DpProofTree::SemanticLabeling { proof, .. } => visit(proof),
            _ => {}
        }
    }

    for component in &mut proof.component_proofs {
        if let Some(tree) = component.proof_tree.as_deref_mut() {
            visit(tree);
        }
    }
}

fn write_muterm_typed_dp_proof_cpf3(
    xml: &mut String,
    proof: &crate::proving::DependencyPairProof,
    csr: &CsrTrs,
    unhiding_rules: &[RewriteRule],
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<mutermTypedDpProof>\n"));
    if proof.pairs.is_empty() {
        xml.push_str(&format!("{pad}  <pIsEmpty/>\n"));
        xml.push_str(&format!("{pad}</mutermTypedDpProof>\n"));
        return Ok(());
    }
    xml.push_str(&format!("{pad}  <depGraphProc>\n"));
    for component in &proof.component_proofs {
        xml.push_str(&format!("{pad}    <component>\n"));
        write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 6, "dps");
        if component.proved {
            let tree = component.proof_tree.as_deref().ok_or_else(|| {
                CpfError::UnsupportedProofStep(
                    "proved MU-TERM component has no reconstructed proof tree".to_string(),
                )
            })?;
            if let Some(usable_rules) = component.usable_rules_processor.as_ref() {
                if muterm_component_has_general_usable_redpair(tree, usable_rules, csr) {
                    // This is the exact boundary of CeTA-CSR's general
                    // RTA'08 MU-TERM usable-rule processor: the first
                    // reduction pair was checked against the component's
                    // complete local closure, including every unhiding
                    // bridge, and it deletes pairs only.  Keeping it behind
                    // localUsableRulesProc would select the strictly weaker
                    // recursive-pair theorem and reject sound collapsing
                    // pairs such as emmes' two IF projections.
                    write_muterm_typed_tree_cpf3(
                        xml,
                        tree,
                        proof.strategy,
                        csr,
                        unhiding_rules,
                        indent + 6,
                    )?;
                    xml.push_str(&format!("{pad}    </component>\n"));
                    continue;
                }
                // localUsableRulesProc changes the active ordinary-rule
                // component for the whole nested proof.  Preserve this
                // first-class worklist transition exactly; flattening it
                // into the first reduction pair changes the MU-TERM
                // orientation obligation and can yield a rejected CPF.
                xml.push_str(&format!("{pad}      <mutermTypedDpProof>\n"));
                xml.push_str(&format!("{pad}        <localUsableRulesProc>\n"));
                write_rules_trs_cpf3(xml, usable_rules, indent + 10, "usableRules");
                xml.push_str(&format!("{pad}          <dpProof>\n"));
                write_dp_proof_tree_cpf3(xml, tree, proof.strategy, indent + 12);
                xml.push_str(&format!("{pad}          </dpProof>\n"));
                xml.push_str(&format!("{pad}        </localUsableRulesProc>\n"));
                xml.push_str(&format!("{pad}      </mutermTypedDpProof>\n"));
                xml.push_str(&format!("{pad}    </component>\n"));
                continue;
            }
            if muterm_component_has_general_usable_redpair(
                tree,
                tree_first_redpair_usable_rules(tree).unwrap_or_default(),
                csr,
            ) {
                write_muterm_typed_tree_cpf3(
                    xml,
                    tree,
                    proof.strategy,
                    csr,
                    unhiding_rules,
                    indent + 6,
                )?;
                xml.push_str(&format!("{pad}    </component>\n"));
                continue;
            }
            let mut boundary = None;
            let ordinary_local = muterm_tree_is_recursive_redpair_chain(tree)
                && collect_muterm_ordinary_usable_boundary(tree, &mut boundary);
            if ordinary_local && let Some(mut boundary) = boundary {
                for rule in unhiding_rules {
                    if !boundary.contains(rule) {
                        boundary.push(rule.clone());
                    }
                }
                let mut ordinary_tree = tree.clone();
                if !normalize_muterm_local_usable_boundary(&mut ordinary_tree, &boundary) {
                    return Err(CpfError::UnsupportedProofStep(
                        "could not normalize MU-TERM local usable-rule proof".to_string(),
                    ));
                }
                xml.push_str(&format!("{pad}      <mutermTypedDpProof>\n"));
                xml.push_str(&format!("{pad}        <localUsableRulesProc>\n"));
                write_rules_trs_cpf3(xml, &boundary, indent + 10, "usableRules");
                xml.push_str(&format!("{pad}          <dpProof>\n"));
                write_dp_proof_tree_cpf3(xml, &ordinary_tree, proof.strategy, indent + 12);
                xml.push_str(&format!("{pad}          </dpProof>\n"));
                xml.push_str(&format!("{pad}        </localUsableRulesProc>\n"));
                xml.push_str(&format!("{pad}      </mutermTypedDpProof>\n"));
            } else {
                write_muterm_typed_tree_cpf3(
                    xml,
                    tree,
                    proof.strategy,
                    csr,
                    unhiding_rules,
                    indent + 6,
                )?;
            }
        }
        xml.push_str(&format!("{pad}    </component>\n"));
    }
    xml.push_str(&format!("{pad}  </depGraphProc>\n"));
    xml.push_str(&format!("{pad}</mutermTypedDpProof>\n"));
    Ok(())
}

fn muterm_component_has_general_usable_redpair(
    tree: &crate::proving::DpProofTree,
    component_usable_rules: &[RewriteRule],
    csr: &CsrTrs,
) -> bool {
    let crate::proving::DpProofTree::RedPair { reduction, .. } = tree else {
        return false;
    };
    reduction.uses_usable_rules
        && reduction.strict_rules.is_empty()
        && same_rule_set(&reduction.usable_rules, component_usable_rules)
        && reduction
            .pairs
            .iter()
            .any(|pair| matches!(pair.rhs(), Term::Var(_)))
        // The fallback general MU-TERM theorem requires every collapsing
        // target variable to occur actively in its source.  RTA'08 can also
        // handle an inactive target, but only when its additional projection
        // obligations are present in the reduction triple.  Generic DP
        // polynomial search does not validate those obligations, so keep
        // such a proof behind the independently checked local/invariant
        // boundary instead of serializing a checker-rejected general step.
        && reduction.pairs.iter().all(|pair| match pair.rhs() {
            Term::Var(variable) => muterm_active_variables(csr, pair.lhs()).contains(variable),
            Term::App { .. } => true,
        })
}

fn muterm_active_variables(csr: &CsrTrs, term: &Term) -> BTreeSet<Variable> {
    fn collect(csr: &CsrTrs, term: &Term, variables: &mut BTreeSet<Variable>) {
        match term {
            Term::Var(variable) => {
                variables.insert(variable.clone());
            }
            Term::App { symbol, args } => {
                let base = symbol
                    .as_str()
                    .strip_suffix('#')
                    .map(Symbol::new)
                    .unwrap_or_else(|| symbol.clone());
                for (index, argument) in args.iter().enumerate() {
                    if csr.replacement_map().is_allowed(&base, index) {
                        collect(csr, argument, variables);
                    }
                }
            }
        }
    }

    let mut variables = BTreeSet::new();
    collect(csr, term, &mut variables);
    variables
}

fn tree_first_redpair_usable_rules(tree: &crate::proving::DpProofTree) -> Option<&[RewriteRule]> {
    match tree {
        crate::proving::DpProofTree::RedPair { reduction, .. } => Some(&reduction.usable_rules),
        _ => None,
    }
}

fn write_muterm_typed_tree_cpf3(
    xml: &mut String,
    tree: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    csr: &CsrTrs,
    unhiding_rules: &[RewriteRule],
    indent: usize,
) -> Result<(), CpfError> {
    if let crate::proving::DpProofTree::ComponentContext { proof, .. } = tree {
        return write_muterm_typed_tree_cpf3(xml, proof, strategy, csr, unhiding_rules, indent);
    }
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<mutermTypedDpProof>\n"));
    match tree {
        crate::proving::DpProofTree::Empty => {
            xml.push_str(&format!("{pad}  <pIsEmpty/>\n"));
        }
        crate::proving::DpProofTree::ComponentContext { .. } => unreachable!(),
        crate::proving::DpProofTree::DepGraph { components } => {
            xml.push_str(&format!("{pad}  <depGraphProc>\n"));
            for component in components {
                xml.push_str(&format!("{pad}    <component>\n"));
                write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 6, "dps");
                if component.proved {
                    let child = component.proof_tree.as_deref().ok_or_else(|| {
                        CpfError::UnsupportedProofStep(
                            "proved typed MU-TERM graph component has no proof tree".to_string(),
                        )
                    })?;
                    write_muterm_typed_tree_cpf3(
                        xml,
                        child,
                        strategy,
                        csr,
                        unhiding_rules,
                        indent + 6,
                    )?;
                }
                xml.push_str(&format!("{pad}    </component>\n"));
            }
            xml.push_str(&format!("{pad}  </depGraphProc>\n"));
        }
        crate::proving::DpProofTree::Instantiation { step, proof } => {
            xml.push_str(&format!("{pad}  <typedInstantiationProc>\n"));
            write_unindexed_rule_cpf3(xml, &step.pair.as_rule(), indent + 4);
            xml.push_str(&format!("{pad}    <instantiations>\n"));
            write_dependency_pairs_rules_cpf3(xml, &step.instantiations, indent + 6);
            xml.push_str(&format!("{pad}    </instantiations>\n"));
            write_muterm_typed_tree_cpf3(xml, proof, strategy, csr, unhiding_rules, indent + 4)?;
            xml.push_str(&format!("{pad}  </typedInstantiationProc>\n"));
        }
        crate::proving::DpProofTree::TransformationExact {
            processor_tag,
            proof,
            ..
        } if processor_tag == "__mutermExpanded" => {
            if let crate::proving::DpProofTree::RedPair { reduction, proof } = proof.as_ref() {
                xml.push_str(&format!("{pad}  <expandedStrongUsableRulesProc>\n"));
                write_rules_trs_cpf3(xml, &reduction.usable_rules, indent + 4, "usableRules");
                write_reduction_pair_cpf3(xml, reduction, indent + 4);
                write_dependency_pairs_trs_cpf3(
                    xml,
                    &strict_pairs_for_reduction(reduction),
                    indent + 4,
                    "dps",
                );
                xml.push_str(&format!("{pad}    <csrDpProof>\n"));
                write_csr_dp_proof_tree_cpf3(xml, proof, strategy, csr.rules(), None, indent + 6);
                xml.push_str(&format!("{pad}    </csrDpProof>\n"));
                xml.push_str(&format!("{pad}  </expandedStrongUsableRulesProc>\n"));
            } else {
                // The MU-TERM extended-basic reduction-pair processor is the
                // certifiable boundary for expanded components below a graph.
                // Generic QCS closure may force every rule at an active
                // variable, while U3 is a different (and stronger) theorem.
                // Preserve the exact expanded state and let CeTA recursively
                // validate each extended-basic reduction and residual graph.
                xml.push_str(&format!("{pad}  <expandedExtendedBasicCsrProof>\n"));
                xml.push_str(&format!("{pad}    <csrDpProof>\n"));
                write_csr_dp_proof_tree_cpf3(xml, proof, strategy, csr.rules(), None, indent + 6);
                xml.push_str(&format!("{pad}    </csrDpProof>\n"));
                xml.push_str(&format!("{pad}  </expandedExtendedBasicCsrProof>\n"));
            }
        }
        crate::proving::DpProofTree::RedPair { reduction, proof } => {
            xml.push_str(&format!("{pad}  <generalUsableRulesProc>\n"));
            write_reduction_pair_cpf3(xml, reduction, indent + 4);
            write_dependency_pairs_trs_cpf3(
                xml,
                &strict_pairs_for_reduction(reduction),
                indent + 4,
                "dps",
            );
            let usable_rules = reduction
                .usable_rules
                .iter()
                .filter(|rule| csr.rules().contains(rule))
                .cloned()
                .collect::<Vec<_>>();
            write_rules_trs_cpf3(xml, &usable_rules, indent + 4, "usableRules");
            write_muterm_typed_tree_cpf3(xml, proof, strategy, csr, unhiding_rules, indent + 4)?;
            xml.push_str(&format!("{pad}  </generalUsableRulesProc>\n"));
        }
        _ => {
            xml.push_str(&format!("{pad}  <noncollapsingCsrProof>\n"));
            xml.push_str(&format!("{pad}    <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, tree, strategy, csr.rules(), None, indent + 6);
            xml.push_str(&format!("{pad}    </csrDpProof>\n"));
            xml.push_str(&format!("{pad}  </noncollapsingCsrProof>\n"));
        }
    }
    xml.push_str(&format!("{pad}</mutermTypedDpProof>\n"));
    Ok(())
}

fn write_csr_dp_graph_cpf3(
    xml: &mut String,
    proof: &crate::proving::DependencyPairProof,
    rules: &[RewriteRule],
    flatten_size_change: bool,
    qcs_csr: Option<&CsrTrs>,
    indent: usize,
) {
    if flatten_size_change && let Some(graphs) = flattened_csr_size_change_graphs(proof) {
        write_size_change_proc_cpf3(xml, &graphs, indent);
        return;
    }
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<depGraphProc>\n"));
    for component in &proof.component_proofs {
        xml.push_str(&format!("{pad}  <component>\n"));
        write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 4, "dps");
        if component.proved {
            write_csr_dp_component_proof_cpf3(
                xml,
                component,
                proof.strategy,
                rules,
                qcs_csr,
                indent + 4,
            );
        }
        xml.push_str(&format!("{pad}  </component>\n"));
    }
    xml.push_str(&format!("{pad}</depGraphProc>\n"));
}

fn flattened_csr_size_change_graphs(
    proof: &crate::proving::DependencyPairProof,
) -> Option<Vec<crate::proving::DpSizeChangeGraph>> {
    crate::proving::csr_dp_flattened_size_change_graphs(proof)
}

fn write_csr_dp_component_proof_cpf3(
    xml: &mut String,
    component: &crate::proving::DpComponentProof,
    strategy: RewriteStrategy,
    rules: &[RewriteRule],
    qcs_csr: Option<&CsrTrs>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<csrDpProof>\n"));
    write_csr_dp_component_body_cpf3(xml, component, strategy, rules, qcs_csr, indent + 2);
    xml.push_str(&format!("{pad}</csrDpProof>\n"));
}

fn write_csr_dp_component_body_cpf3(
    xml: &mut String,
    component: &crate::proving::DpComponentProof,
    strategy: RewriteStrategy,
    rules: &[RewriteRule],
    qcs_csr: Option<&CsrTrs>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    if let Some(proof_tree) = &component.proof_tree {
        let reconstructed_usable;
        let usable_rules = if let Some(usable_rules) = &component.usable_rules_processor {
            Some(usable_rules)
        } else if let Some(csr) = qcs_csr {
            reconstructed_usable = qcs_certificate_usable_rules(csr, &component.pairs)
                .into_iter()
                .filter(|rule| rules.contains(rule))
                .collect::<Vec<_>>();
            (reconstructed_usable.as_slice() != rules).then_some(&reconstructed_usable)
        } else {
            None
        };
        if let Some(usable_rules) = usable_rules {
            xml.push_str(&format!("{pad}<usableRulesProc>\n"));
            write_rules_trs_cpf3(xml, usable_rules, indent + 2, "usableRules");
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(
                xml,
                proof_tree,
                strategy,
                usable_rules,
                qcs_csr,
                indent + 4,
            );
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</usableRulesProc>\n"));
        } else {
            write_csr_dp_proof_tree_cpf3(xml, proof_tree, strategy, rules, qcs_csr, indent);
        }
    } else {
        xml.push_str(&format!("{pad}<pIsEmpty/>\n"));
    }
}

fn write_csr_dp_proof_tree_cpf3(
    xml: &mut String,
    proof_tree: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    rules: &[RewriteRule],
    qcs_csr: Option<&CsrTrs>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    match proof_tree {
        crate::proving::DpProofTree::ComponentContext { proof, .. } => {
            write_csr_dp_proof_tree_cpf3(xml, proof, strategy, rules, qcs_csr, indent);
        }
        crate::proving::DpProofTree::Empty => {
            xml.push_str(&format!("{pad}<pIsEmpty/>\n"));
        }
        crate::proving::DpProofTree::ExactXml(fragment) => {
            for line in fragment.lines() {
                xml.push_str(&format!("{pad}{line}\n"));
            }
        }
        crate::proving::DpProofTree::DepGraph { components } => {
            xml.push_str(&format!("{pad}<depGraphProc>\n"));
            for component in components {
                xml.push_str(&format!("{pad}  <component>\n"));
                write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 4, "dps");
                if component.proved {
                    write_csr_dp_component_proof_cpf3(
                        xml,
                        component,
                        strategy,
                        rules,
                        qcs_csr,
                        indent + 4,
                    );
                }
                xml.push_str(&format!("{pad}  </component>\n"));
            }
            xml.push_str(&format!("{pad}</depGraphProc>\n"));
        }
        crate::proving::DpProofTree::GeneralRedPairExact {
            payload_xml,
            proofs,
        } => {
            xml.push_str(&format!("{pad}<generalRedPairProc>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            for proof in proofs {
                xml.push_str(&format!("{pad}  <dpProof>\n"));
                write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
                xml.push_str(&format!("{pad}  </dpProof>\n"));
            }
            xml.push_str(&format!("{pad}</generalRedPairProc>\n"));
        }
        crate::proving::DpProofTree::ReductionPairExact {
            processor_tag,
            payload_xml,
            proof,
            ..
        } if processor_tag == "csrRedPairUrProc" => {
            // The verified recursive U3/QCS processor preserves the typed
            // CSR-DP obligation.  Its continuation must remain a csrDpProof;
            // routing it through the ordinary bridge loses the replacement
            // map and prevents state-local oracle replay of later processors.
            xml.push_str(&format!("{pad}<csrRedPairUrProc>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, proof, strategy, rules, qcs_csr, indent + 4);
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</csrRedPairUrProc>\n"));
        }
        crate::proving::DpProofTree::ReductionPairExact { .. } => {
            // A retained ordinary reduction pair proves the stronger
            // unrestricted component.  At a CSR-DP boundary CPF requires
            // the explicit bridge; emitting the ordinary processor directly
            // is neither parseable nor the proof that was replayed.
            xml.push_str(&format!("{pad}<ordinaryDpProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof_tree, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</ordinaryDpProof>\n"));
        }
        crate::proving::DpProofTree::SemanticLabeling { .. } => {
            // CPF represents semantic labeling in the ordinary DP language.
            // CeTA-CSR's exact bridge checks this wrapper while retaining the
            // context-sensitive replacement map for the labeled residual.
            xml.push_str(&format!("{pad}<ordinaryDpProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof_tree, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</ordinaryDpProof>\n"));
        }
        crate::proving::DpProofTree::TransformationExact { processor_tag, .. }
            if matches!(
                processor_tag.as_str(),
                "forwardInstantiationProc" | "narrowingProc" | "rewritingProc"
            ) =>
        {
            // These retained CPF processors belong to the ordinary DP proof
            // language.  They can occur below a certified CSR usable-rules
            // transition, whose child is precisely an ordinary non-minimal
            // DP problem.  Re-emitting them directly as a `csrDpProof` both
            // loses that boundary and produces a document CeTA must reject.
            xml.push_str(&format!("{pad}<ordinaryDpProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof_tree, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</ordinaryDpProof>\n"));
        }
        crate::proving::DpProofTree::TransformationExact {
            processor_tag,
            payload_xml,
            ..
        } if processor_tag == "gm04ResidualAssumption" => {
            xml.push_str(&format!("{pad}<finitenessAssumption>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            xml.push_str(&format!("{pad}</finitenessAssumption>\n"));
        }
        crate::proving::DpProofTree::TransformationExact {
            processor_tag,
            payload_xml,
            proof,
        } => {
            xml.push_str(&format!("{pad}<{processor_tag}>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            // This branch serializes a transformation retained inside a
            // context-sensitive DP tree.  Its continuation must therefore
            // stay in the typed CSR proof language; `<dpProof>` silently
            // drops the replacement-map obligation and is rejected by CeTA.
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, proof, strategy, rules, qcs_csr, indent + 4);
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</{processor_tag}>\n"));
        }
        crate::proving::DpProofTree::Instantiation { step, proof } if step.context_sensitive => {
            xml.push_str(&format!("{pad}<instantiationProc>\n"));
            write_unindexed_rule_cpf3(xml, &step.pair.as_rule(), indent + 2);
            xml.push_str(&format!("{pad}  <instantiations>\n"));
            write_dependency_pairs_rules_cpf3(xml, &step.instantiations, indent + 4);
            xml.push_str(&format!("{pad}  </instantiations>\n"));
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, proof, strategy, rules, qcs_csr, indent + 4);
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</instantiationProc>\n"));
        }
        crate::proving::DpProofTree::Subterm {
            projection,
            strict_pairs,
            proof,
            ..
        } => {
            write_subterm_projection_cpf3(xml, projection, strict_pairs, indent);
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, proof, strategy, rules, qcs_csr, indent + 4);
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</subtermProc>\n"));
        }
        crate::proving::DpProofTree::SizeChange { graphs } => {
            write_size_change_proc_cpf3(xml, graphs, indent);
        }
        crate::proving::DpProofTree::SizeChangeRedPair {
            graphs,
            reduction_pair,
            usable_rules,
        } if rules.iter().all(|rule| usable_rules.contains(rule)) => {
            write_size_change_red_pair_proc_cpf3(
                xml,
                graphs,
                reduction_pair,
                usable_rules,
                false,
                indent,
            );
        }
        crate::proving::DpProofTree::RedPair { reduction, proof }
            if ((reduction.force_non_mono_usable_rules
                && !reduction.strict_pair_indices.is_empty())
                || reduction.strict_rules.iter().any(is_rta_marking_obligation))
                && !matches!(proof.as_ref(), crate::proving::DpProofTree::Empty) =>
        {
            // A U3 reduction-pair processor preserves the minimal CSR-DP
            // obligation of its residual.  Keep its continuation in
            // `csrDpProof`: wrapping the same step in `ordinaryDpProof`
            // forgets minimality, so a sound residual subterm/SCT processor
            // is subsequently rejected by CeTA.  The custom recursive tag
            // independently checks U3 closure, the order, pair deletion, and
            // then the retained minimal CSR continuation.
            xml.push_str(&format!("{pad}<csrRedPairUrProc>\n"));
            write_reduction_pair_proof_cpf3(
                xml,
                arities_for_dp_reduction(reduction),
                &reduction.reduction_pair,
                indent + 2,
            );
            write_dependency_pairs_trs_cpf3(
                xml,
                &strict_pairs_for_reduction(reduction),
                indent + 2,
                "dps",
            );
            write_rules_trs_cpf3(xml, &reduction.usable_rules, indent + 2, "usableRules");
            xml.push_str(&format!("{pad}  <csrDpProof>\n"));
            write_csr_dp_proof_tree_cpf3(xml, proof, strategy, rules, qcs_csr, indent + 4);
            xml.push_str(&format!("{pad}  </csrDpProof>\n"));
            xml.push_str(&format!("{pad}</csrRedPairUrProc>\n"));
        }
        crate::proving::DpProofTree::RedPair { reduction, proof }
            if (reduction.uses_usable_rules && !reduction.strict_pair_indices.is_empty())
                || rules
                    .iter()
                    .all(|rule| reduction.usable_rules.contains(rule)) =>
        {
            let tag = if reduction.uses_usable_rules && !reduction.strict_pair_indices.is_empty() {
                "redPairUrProc"
            } else if reduction_pair_is_mono(&reduction.reduction_pair) {
                "monoRedPairProc"
            } else {
                "redPairProc"
            };
            xml.push_str(&format!("{pad}<ordinaryDpProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            xml.push_str(&format!("{pad}    <{tag}>\n"));
            write_reduction_pair_cpf3(xml, reduction, indent + 6);
            write_dependency_pairs_trs_cpf3(
                xml,
                &strict_pairs_for_reduction(reduction),
                indent + 6,
                "dps",
            );
            if tag == "monoRedPairProc" {
                write_rules_trs_cpf3(xml, &reduction.strict_rules, indent + 6, "trs");
            } else if tag == "redPairUrProc" {
                write_rules_trs_cpf3(xml, &reduction.usable_rules, indent + 6, "usableRules");
            }
            xml.push_str(&format!("{pad}      <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 8);
            xml.push_str(&format!("{pad}      </dpProof>\n"));
            xml.push_str(&format!("{pad}    </{tag}>\n"));
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</ordinaryDpProof>\n"));
        }
        _ => {
            xml.push_str(&format!("{pad}<ordinaryDpProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof_tree, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</ordinaryDpProof>\n"));
        }
    }
}

fn replacement_map_for_arities(
    replacement_map: &crate::core::ReplacementMap,
    arities: &BTreeMap<Symbol, usize>,
) -> crate::core::ReplacementMap {
    crate::core::ReplacementMap::new(
        arities
            .keys()
            .map(|symbol| {
                (
                    symbol.clone(),
                    replacement_map
                        .allowed_positions(symbol)
                        .cloned()
                        .unwrap_or_default(),
                )
            })
            .collect(),
    )
}

fn write_uncurry_cpf3(
    xml: &mut String,
    trs: &Trs,
    proof: &UncurryProof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    let transformed = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        variables_in_rules(&proof.transformed_rules),
        proof.transformed_rules.clone(),
        // Applicative uncurrying establishes termination of the transformed
        // unrestricted TRS, even when the source problem was innermost.
        // Retaining the source strategy here emitted an innermost finiteness
        // assumption (unsupported by CeTA and semantically the wrong target).
        RewriteStrategy::Full,
    );

    xml.push_str(&format!("{pad}<uncurry>\n"));
    write_uncurry_information_cpf3(
        xml,
        &proof.app_symbol,
        &proof.symbols,
        &proof.uncurry_rules,
        &proof.eta_rules,
        indent + 2,
    );
    write_trs_cpf3(xml, &transformed, indent + 2);
    match proof.proof.status() {
        Status::Terminating => {
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, &transformed, &proof.proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
        }
        Status::Nonterminating => {
            xml.push_str(&format!("{pad}  <trsNonterminationProof>\n"));
            write_trs_nontermination_proof_cpf3(xml, &proof.proof, indent + 4)?;
            xml.push_str(&format!("{pad}  </trsNonterminationProof>\n"));
        }
        Status::Unknown => {
            return Err(CpfError::UnsupportedProofStep(
                "uncurrying proof has an unknown continuation".to_string(),
            ));
        }
    }
    xml.push_str(&format!("{pad}</uncurry>\n"));
    Ok(())
}

fn write_uncurry_information_cpf3(
    xml: &mut String,
    app_symbol: &Symbol,
    symbols: &[crate::proving::UncurriedSymbolEntry],
    uncurry_rules: &[RewriteRule],
    eta_rules: &[RewriteRule],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<uncurryInformation>\n"));
    write_symbol_cpf3(xml, app_symbol.as_str(), indent + 2);
    xml.push_str(&format!("{pad}  <uncurriedSymbols>\n"));
    for entry in symbols {
        xml.push_str(&format!("{pad}    <uncurriedSymbolEntry>\n"));
        write_symbol_cpf3(xml, entry.original.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{}</arity>\n", entry.arity));
        for symbol in &entry.symbols {
            write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        }
        xml.push_str(&format!("{pad}    </uncurriedSymbolEntry>\n"));
    }
    xml.push_str(&format!("{pad}  </uncurriedSymbols>\n"));
    write_rules_trs_cpf3(xml, uncurry_rules, indent + 2, "uncurryRules");
    write_rules_trs_cpf3(xml, eta_rules, indent + 2, "etaRules");
    xml.push_str(&format!("{pad}</uncurryInformation>\n"));
}

fn variables_in_rules(rules: &[RewriteRule]) -> BTreeSet<Variable> {
    let mut variables = BTreeSet::new();
    for rule in rules {
        variables.extend(rule.lhs().variables());
        variables.extend(rule.rhs().variables());
    }
    variables
}

fn common_srs_tail_variable(trs: &Trs) -> Option<Variable> {
    let mut tail = None;
    for rule in trs.rules() {
        let (_, lhs_tail) = srs_word_with_tail(rule.lhs())?;
        let (_, rhs_tail) = srs_word_with_tail(rule.rhs())?;
        if lhs_tail != rhs_tail {
            return None;
        }
        match &tail {
            Some(existing) if existing != &lhs_tail => return None,
            Some(_) => {}
            None => tail = Some(lhs_tail),
        }
    }
    tail
}

fn srs_word_with_tail(term: &Term) -> Option<(Vec<Symbol>, Variable)> {
    let mut word = Vec::new();
    let mut cursor = term;
    loop {
        match cursor {
            Term::Var(variable) => return Some((word, variable.clone())),
            Term::App { symbol, args } if args.len() == 1 => {
                word.push(symbol.clone());
                cursor = &args[0];
            }
            Term::App { .. } => return None,
        }
    }
}

fn write_initial_terms_cpf3(
    xml: &mut String,
    initial_words: &[Vec<Symbol>],
    tail: &Variable,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<initialTerms>\n"));
    for word in initial_words {
        let term = srs_word_to_term(word, Term::var(tail.as_str()));
        write_term_cpf3(xml, &term, indent + 2);
    }
    xml.push_str(&format!("{pad}</initialTerms>\n"));
}

fn srs_word_to_term(word: &[Symbol], tail: Term) -> Term {
    word.iter()
        .rev()
        .fold(tail, |term, symbol| Term::app(symbol.as_str(), vec![term]))
}

fn trs_without_rules(trs: &Trs, removed: &[RewriteRule]) -> Trs {
    let mut remaining = Vec::new();
    let mut removed = removed.to_vec();
    'rule_loop: for rule in trs.rules().iter() {
        for i in 0..removed.len() {
            if removed[i] == *rule || crate::proving::rewrite_rules_are_variants(rule, &removed[i])
            {
                removed.remove(i);
                continue 'rule_loop;
            }
        }
        remaining.push(rule.clone());
    }
    Trs::new_with_strategy(
        trs.name().map(str::to_string),
        trs.variables().clone(),
        remaining,
        trs.strategy(),
    )
}

fn write_bounds_cpf3(xml: &mut String, proof: &BoundsProof, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<bounds>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    match proof.bounds_type {
        BoundsType::Match => xml.push_str(&format!("{pad}    <match/>\n")),
        BoundsType::Roof => xml.push_str(&format!("{pad}    <roof/>\n")),
    }
    xml.push_str(&format!("{pad}  </type>\n"));
    xml.push_str(&format!("{pad}  <bound>{}</bound>\n", proof.bound));
    write_state_list_cpf3(xml, "finalStates", &proof.final_states, indent + 2);
    write_tree_automaton_cpf3(xml, &proof.automaton, indent + 2);
    xml.push_str(&format!("{pad}  <criterion>\n"));
    if proof.state_compatibility.is_empty()
        || proof
            .state_compatibility
            .iter()
            .all(|(source, target)| source == target)
    {
        xml.push_str(&format!("{pad}    <compatibility/>\n"));
    } else {
        xml.push_str(&format!("{pad}    <stateCompatibility>\n"));
        xml.push_str(&format!("{pad}      <relation>\n"));
        for (source, target) in &proof.state_compatibility {
            xml.push_str(&format!("{pad}        <entry>\n"));
            write_state_cpf3(xml, source, indent + 10);
            write_state_cpf3(xml, target, indent + 10);
            xml.push_str(&format!("{pad}        </entry>\n"));
        }
        xml.push_str(&format!("{pad}      </relation>\n"));
        xml.push_str(&format!("{pad}    </stateCompatibility>\n"));
    }
    xml.push_str(&format!("{pad}  </criterion>\n"));
    xml.push_str(&format!("{pad}</bounds>\n"));
}

fn write_tree_automaton_cpf3(xml: &mut String, automaton: &TreeAutomaton, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<treeAutomaton>\n"));
    write_state_list_cpf3(xml, "finalStates", &automaton.final_states, indent + 2);
    xml.push_str(&format!("{pad}  <transitions>\n"));
    for transition in &automaton.transitions {
        xml.push_str(&format!("{pad}    <transition>\n"));
        xml.push_str(&format!("{pad}      <lhs>\n"));
        match &transition.lhs {
            TreeAutomatonTransitionLhs::State(state) => {
                write_state_cpf3(xml, state, indent + 8);
            }
            TreeAutomatonTransitionLhs::Symbol {
                symbol,
                height,
                args,
            } => {
                write_symbol_cpf3(xml, symbol, indent + 8);
                if let Some(height) = height {
                    xml.push_str(&format!("{pad}        <height>{height}</height>\n"));
                }
                for state in args {
                    write_state_cpf3(xml, state, indent + 8);
                }
            }
        }
        xml.push_str(&format!("{pad}      </lhs>\n"));
        xml.push_str(&format!("{pad}      <rhs>\n"));
        write_state_cpf3(xml, &transition.rhs, indent + 8);
        xml.push_str(&format!("{pad}      </rhs>\n"));
        xml.push_str(&format!("{pad}    </transition>\n"));
    }
    xml.push_str(&format!("{pad}  </transitions>\n"));
    xml.push_str(&format!("{pad}</treeAutomaton>\n"));
}

fn write_state_list_cpf3(xml: &mut String, tag: &str, states: &[String], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<{tag}>\n"));
    for state in states {
        write_state_cpf3(xml, state, indent + 2);
    }
    xml.push_str(&format!("{pad}</{tag}>\n"));
}

fn write_state_cpf3(xml: &mut String, state: &str, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<state>"));
    xml.push_str(&escape_xml(&cpf3_state_name(state)));
    xml.push_str("</state>\n");
}

fn cpf3_state_name(state: &str) -> String {
    format!("s{}_{}", state.len(), state)
}

fn write_polynomial_rule_removal_cpf3(
    xml: &mut String,
    trs: &Trs,
    interpretations: &[(String, i64, Vec<i64>)],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<ruleRemoval>\n"));
    write_polynomial_interpretation_cpf3(xml, trs, interpretations, indent + 2);
    write_trs_cpf3(xml, trs, indent + 2);
    xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}    <rIsEmpty/>\n"));
    xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}</ruleRemoval>\n"));
}

fn write_polynomial_rule_removal_with_proof_cpf3(
    xml: &mut String,
    interpretations: &[(String, i64, Vec<i64>)],
    removed: &[RewriteRule],
    remaining: &Trs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    let mut arities = remaining.arities();
    for rule in removed {
        collect_term_arities(rule.lhs(), &mut arities);
        collect_term_arities(rule.rhs(), &mut arities);
    }
    xml.push_str(&format!("{pad}<ruleRemoval>\n"));
    write_polynomial_interpretation_for_arities_cpf3(xml, arities, interpretations, indent + 2);
    write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
    xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
    write_trs_termination_proof_cpf3(xml, remaining, proof, indent + 4)?;
    xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}</ruleRemoval>\n"));
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn write_matrix_rule_removal_with_relative_proof_cpf3(
    xml: &mut String,
    arities: BTreeMap<Symbol, usize>,
    interpretations: &[(String, MatrixInterpretation)],
    dimension: usize,
    strict_dimension: usize,
    domain: MatrixDomain,
    removed: &[RewriteRule],
    remaining: &RelativeTrs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<ruleRemoval>\n"));
    let domain = match domain {
        MatrixDomain::Naturals => "naturals",
        MatrixDomain::Integers => "integers",
    };
    write_matrix_interpretation_for_arities_cpf3(
        xml,
        arities,
        interpretations,
        dimension,
        strict_dimension,
        domain,
        indent + 2,
    );
    write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
    xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
    write_relative_trs_termination_proof_cpf3(xml, remaining, proof, indent + 4)?;
    xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}</ruleRemoval>\n"));
    Ok(())
}

fn write_kbo_rule_removal_cpf3(
    xml: &mut String,
    trs: &Trs,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    weights: &BTreeMap<String, i64>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<ruleRemoval>\n"));
    write_kbo_order_cpf3(
        xml,
        trs.arities(),
        precedence,
        weights,
        None,
        Some(precedence_ranks),
        indent + 2,
    );
    write_trs_cpf3(xml, trs, indent + 2);
    xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}    <rIsEmpty/>\n"));
    xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}</ruleRemoval>\n"));
}

fn write_kbo_rule_removal_with_proof_cpf3(
    xml: &mut String,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    weights: &BTreeMap<String, i64>,
    removed: &[RewriteRule],
    remaining: &Trs,
    proof: &Proof,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    let mut arities = remaining.arities();
    for rule in removed {
        collect_term_arities(rule.lhs(), &mut arities);
        collect_term_arities(rule.rhs(), &mut arities);
    }
    xml.push_str(&format!("{pad}<ruleRemoval>\n"));
    write_kbo_order_cpf3(
        xml,
        arities,
        precedence,
        weights,
        None,
        Some(precedence_ranks),
        indent + 2,
    );
    write_rules_trs_cpf3(xml, removed, indent + 2, "trs");
    xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
    write_trs_termination_proof_cpf3(xml, remaining, proof, indent + 4)?;
    xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}</ruleRemoval>\n"));
    Ok(())
}

struct PathOrderRuleRemovalCpf<'a> {
    statuses: &'a BTreeMap<String, DpPathOrderKind>,
    precedence: &'a [String],
    precedence_ranks: &'a BTreeMap<String, usize>,
    argument_filter: &'a DpArgumentFilter,
    removed: &'a [RewriteRule],
    remaining: &'a Trs,
    proof: &'a Proof,
}

fn write_path_order_rule_removal_with_proof_cpf3(
    xml: &mut String,
    data: PathOrderRuleRemovalCpf<'_>,
    indent: usize,
) -> Result<(), CpfError> {
    let pad = " ".repeat(indent);
    let mut arities = data.remaining.arities();
    for rule in data.removed {
        collect_term_arities(rule.lhs(), &mut arities);
        collect_term_arities(rule.rhs(), &mut arities);
    }
    xml.push_str(&format!("{pad}<ruleRemoval>\n"));
    write_mixed_recursive_path_order_cpf3(
        xml,
        arities,
        data.statuses,
        data.precedence,
        Some(data.precedence_ranks),
        data.argument_filter,
        indent + 2,
    );
    write_rules_trs_cpf3(xml, data.removed, indent + 2, "trs");
    xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
    write_trs_termination_proof_cpf3(xml, data.remaining, data.proof, indent + 4)?;
    xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
    xml.push_str(&format!("{pad}</ruleRemoval>\n"));
    Ok(())
}

fn write_mixed_recursive_path_order_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    precedence_ranks: Option<&BTreeMap<String, usize>>,
    argument_filter: &DpArgumentFilter,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let computed_ranks = mixed_path_order_precedence_ranks(precedence);
    xml.push_str(&format!("{pad}<recursivePathOrder>\n"));
    xml.push_str(&format!("{pad}  <statusPrecedence>\n"));
    for (symbol, arity) in &arities {
        xml.push_str(&format!("{pad}    <statusPrecedenceEntry>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
        xml.push_str(&format!(
            "{pad}      <precedence>{}</precedence>\n",
            precedence_ranks
                .and_then(|ranks| ranks.get(symbol.as_str()).copied())
                .map(|rank| precedence.len().saturating_sub(rank))
                .or_else(|| computed_ranks.get(symbol.as_str()).copied())
                .unwrap_or(0)
        ));
        match statuses
            .get(symbol.as_str())
            .copied()
            .unwrap_or(DpPathOrderKind::Rpo)
        {
            DpPathOrderKind::Lpo => xml.push_str(&format!("{pad}      <lex/>\n")),
            DpPathOrderKind::Rpo => xml.push_str(&format!("{pad}      <mul/>\n")),
        }
        xml.push_str(&format!("{pad}    </statusPrecedenceEntry>\n"));
    }
    xml.push_str(&format!("{pad}  </statusPrecedence>\n"));
    write_argument_filter_cpf3(xml, &arities, argument_filter, indent + 2);
    xml.push_str(&format!("{pad}</recursivePathOrder>\n"));
}

fn mixed_path_order_precedence_ranks(precedence: &[String]) -> BTreeMap<&str, usize> {
    let mut ranks = BTreeMap::new();
    let mut family_ranks = BTreeMap::new();
    let mut next_rank = precedence.len();
    for symbol in precedence {
        let family = mixed_path_order_quasi_family(symbol);
        let rank = if let Some(family) = family {
            *family_ranks.entry(family).or_insert_with(|| {
                let rank = next_rank;
                next_rank = next_rank.saturating_sub(1);
                rank
            })
        } else {
            let rank = next_rank;
            next_rank = next_rank.saturating_sub(1);
            rank
        };
        ranks.insert(symbol.as_str(), rank);
    }
    ranks
}

fn mixed_path_order_quasi_family(symbol: &str) -> Option<&'static str> {
    match symbol {
        "a__and" | "and" => Some("and"),
        "a__plus" | "plus" => Some("plus"),
        "a__x" | "x" => Some("x"),
        _ => None,
    }
}

fn write_polynomial_interpretation_cpf3(
    xml: &mut String,
    trs: &Trs,
    interpretations: &[(String, i64, Vec<i64>)],
    indent: usize,
) {
    write_polynomial_interpretation_for_arities_cpf3(xml, trs.arities(), interpretations, indent);
}

fn write_polynomial_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &[(String, i64, Vec<i64>)],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, constant, coefficients)| (name.as_str(), (*constant, coefficients.as_slice())))
        .collect::<std::collections::BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <polynomial>\n"));
    xml.push_str(&format!("{pad}      <domain><naturals/></domain>\n"));
    xml.push_str(&format!("{pad}      <degree>1</degree>\n"));
    xml.push_str(&format!("{pad}    </polynomial>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, arity) in arities {
        let (constant, coefficients) = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or((0, &[]));
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_linear_polynomial_cpf3(xml, constant, coefficients, arity, indent + 4);
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_relative_adp_com_polynomial_interpretation_cpf3(
    xml: &mut String,
    interpretations: &[(String, i64, Vec<i64>)],
    indent: usize,
) {
    let mut interpretations = interpretations.to_vec();
    if !interpretations
        .iter()
        .any(|(symbol, _, _)| symbol == "__ferrum_adp_c0")
    {
        interpretations.push(("__ferrum_adp_c0".to_string(), 0, Vec::new()));
    }
    if !interpretations
        .iter()
        .any(|(symbol, _, _)| symbol == "__ferrum_adp_c2")
    {
        interpretations.push(("__ferrum_adp_c2".to_string(), 0, vec![1, 1]));
    }
    interpretations.sort_by(|left, right| left.0.cmp(&right.0));
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <polynomial>\n"));
    xml.push_str(&format!("{pad}      <domain><naturals/></domain>\n"));
    xml.push_str(&format!("{pad}      <degree>1</degree>\n"));
    xml.push_str(&format!("{pad}    </polynomial>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, constant, coefficients) in &interpretations {
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_relative_adp_com_symbol_cpf3(xml, symbol, indent + 4);
        xml.push_str(&format!("{pad}    <arity>{}</arity>\n", coefficients.len()));
        write_linear_polynomial_cpf3(xml, *constant, coefficients, coefficients.len(), indent + 4);
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_relative_adp_com_symbol_cpf3(xml: &mut String, symbol: &str, indent: usize) {
    let pad = " ".repeat(indent);
    match symbol {
        "__ferrum_adp_c0" => xml.push_str(&format!("{pad}<adpCom0/>\n")),
        "__ferrum_adp_c2" => xml.push_str(&format!("{pad}<adpCom2/>\n")),
        _ => write_symbol_cpf3(xml, symbol, indent),
    }
}

fn write_natural_polynomial_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &[(String, NaturalPolynomial)],
    degree: usize,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, polynomial)| (name.as_str(), polynomial))
        .collect::<BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <polynomial>\n"));
    xml.push_str(&format!("{pad}      <domain><naturals/></domain>\n"));
    xml.push_str(&format!("{pad}      <degree>{degree}</degree>\n"));
    xml.push_str(&format!("{pad}    </polynomial>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, arity) in arities {
        let default = NaturalPolynomial {
            constant: 0,
            linear: vec![1; arity],
            quadratic: vec![vec![0; arity]; arity],
        };
        let polynomial = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or(&default);
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_natural_polynomial_cpf3(xml, polynomial, arity, indent + 4);
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_max_polynomial_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &MaxPolynomialSummary,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, alternatives)| (name.as_str(), alternatives.as_slice()))
        .collect::<std::collections::BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<maxPoly>\n"));
    for (symbol, arity) in arities {
        let default_alternatives = [(0, Vec::new())];
        let alternatives = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or(&default_alternatives);
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_max_polynomial_expression_cpf3(xml, alternatives, arity, indent + 4);
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</maxPoly>\n"));
}

fn write_rational_polynomial_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &[(String, i64, Vec<i64>)],
    denominator: i64,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, constant, coefficients)| (name.as_str(), (*constant, coefficients.as_slice())))
        .collect::<std::collections::BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <polynomial>\n"));
    xml.push_str(&format!("{pad}      <domain>\n"));
    xml.push_str(&format!("{pad}        <rationals>\n"));
    xml.push_str(&format!("{pad}          <delta>\n"));
    write_rational_cpf3(xml, denominator, denominator, indent + 12);
    xml.push_str(&format!("{pad}          </delta>\n"));
    xml.push_str(&format!("{pad}        </rationals>\n"));
    xml.push_str(&format!("{pad}      </domain>\n"));
    xml.push_str(&format!("{pad}      <degree>1</degree>\n"));
    xml.push_str(&format!("{pad}    </polynomial>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, arity) in arities {
        let (constant, coefficients) = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or((0, &[]));
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_linear_rational_polynomial_cpf3(
            xml,
            constant,
            coefficients,
            arity,
            denominator,
            indent + 4,
        );
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_rational_natural_polynomial_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &[(String, NaturalPolynomial)],
    denominator: i64,
    delta: i64,
    degree: usize,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, polynomial)| (name.as_str(), polynomial))
        .collect::<BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <polynomial>\n"));
    xml.push_str(&format!("{pad}      <domain><rationals><delta>\n"));
    write_rational_cpf3(xml, delta, denominator, indent + 10);
    xml.push_str(&format!("{pad}      </delta></rationals></domain>\n"));
    xml.push_str(&format!("{pad}      <degree>{degree}</degree>\n"));
    xml.push_str(&format!("{pad}    </polynomial>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, arity) in arities {
        let default = NaturalPolynomial {
            constant: 0,
            linear: vec![denominator; arity],
            quadratic: vec![vec![0; arity]; arity],
        };
        let polynomial = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or(&default);
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_rational_natural_polynomial_cpf3(xml, polynomial, arity, denominator, indent + 4);
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_matrix_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &[(String, MatrixInterpretation)],
    dimension: usize,
    strict_dimension: usize,
    domain: &str,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, interpretation)| (name.as_str(), interpretation))
        .collect::<std::collections::BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <matrixInterpretation>\n"));
    xml.push_str(&format!("{pad}      <domain><{domain}/></domain>\n"));
    xml.push_str(&format!("{pad}      <dimension>{dimension}</dimension>\n"));
    xml.push_str(&format!(
        "{pad}      <strictDimension>{strict_dimension}</strictDimension>\n"
    ));
    xml.push_str(&format!("{pad}    </matrixInterpretation>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, arity) in arities {
        let fallback = MatrixInterpretation {
            constant: vec![0; dimension],
            coefficients: vec![identity_matrix_cpf3(dimension); arity],
        };
        let interpretation = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or(&fallback);
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_linear_matrix_polynomial_cpf3(xml, interpretation, arity, dimension, indent + 4);
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_arctic_matrix_interpretation_for_arities_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    interpretations: &[(String, MatrixInterpretation)],
    dimension: usize,
    strict_dimension: usize,
    domain: ArcticMatrixDomain,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let interpretation_map = interpretations
        .iter()
        .map(|(name, interpretation)| (name.as_str(), interpretation))
        .collect::<std::collections::BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<interpretation>\n"));
    xml.push_str(&format!("{pad}  <type>\n"));
    xml.push_str(&format!("{pad}    <matrixInterpretation>\n"));
    let scalar_domain = match domain {
        ArcticMatrixDomain::Naturals => "naturals",
        ArcticMatrixDomain::Integers => "integers",
    };
    xml.push_str(&format!(
        "{pad}      <domain><arctic><domain><{scalar_domain}/></domain></arctic></domain>\n"
    ));
    xml.push_str(&format!("{pad}      <dimension>{dimension}</dimension>\n"));
    xml.push_str(&format!(
        "{pad}      <strictDimension>{strict_dimension}</strictDimension>\n"
    ));
    xml.push_str(&format!("{pad}    </matrixInterpretation>\n"));
    xml.push_str(&format!("{pad}  </type>\n"));
    for (symbol, arity) in arities {
        let fallback = MatrixInterpretation {
            constant: vec![0; dimension],
            coefficients: vec![arctic_identity_matrix_cpf3(dimension); arity],
        };
        let interpretation = interpretation_map
            .get(symbol.as_str())
            .copied()
            .unwrap_or(&fallback);
        xml.push_str(&format!("{pad}  <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        write_linear_arctic_matrix_polynomial_cpf3(
            xml,
            interpretation,
            arity,
            dimension,
            indent + 4,
        );
        xml.push_str(&format!("{pad}  </interpret>\n"));
    }
    xml.push_str(&format!("{pad}</interpretation>\n"));
}

fn write_linear_arctic_matrix_polynomial_cpf3(
    xml: &mut String,
    interpretation: &MatrixInterpretation,
    arity: usize,
    dimension: usize,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<sum>\n"));
    write_arctic_vector_cpf3(xml, &interpretation.constant, indent + 2);
    for index in 0..arity {
        xml.push_str(&format!("{pad}  <product>\n"));
        write_arctic_matrix_cpf3(
            xml,
            interpretation
                .coefficients
                .get(index)
                .unwrap_or(&arctic_identity_matrix_cpf3(dimension)),
            indent + 4,
        );
        xml.push_str(&format!("{pad}    <variable>{}</variable>\n", index + 1));
        xml.push_str(&format!("{pad}  </product>\n"));
    }
    xml.push_str(&format!("{pad}</sum>\n"));
}

fn write_arctic_value_cpf3(xml: &mut String, value: i64, indent: usize) {
    let pad = " ".repeat(indent);
    if value == i64::MIN {
        xml.push_str(&format!("{pad}<minusInfinity/>\n"));
    } else {
        xml.push_str(&format!("{pad}<integer>{value}</integer>\n"));
    }
}

fn write_arctic_vector_cpf3(xml: &mut String, vector: &[i64], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<vector>\n"));
    for value in vector {
        write_arctic_value_cpf3(xml, *value, indent + 2);
    }
    xml.push_str(&format!("{pad}</vector>\n"));
}

fn write_arctic_matrix_cpf3(xml: &mut String, matrix: &[Vec<i64>], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<matrix>\n"));
    for row in matrix {
        write_arctic_vector_cpf3(xml, row, indent + 2);
    }
    xml.push_str(&format!("{pad}</matrix>\n"));
}

fn arctic_identity_matrix_cpf3(dimension: usize) -> Vec<Vec<i64>> {
    (0..dimension)
        .map(|row| {
            (0..dimension)
                .map(|column| if row == column { 0 } else { i64::MIN })
                .collect()
        })
        .collect()
}

fn write_linear_matrix_polynomial_cpf3(
    xml: &mut String,
    interpretation: &MatrixInterpretation,
    arity: usize,
    dimension: usize,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let mut terms = Vec::new();
    terms.push(MatrixPolynomialTerm::Vector(
        interpretation.constant.clone(),
    ));
    for index in 0..arity {
        terms.push(MatrixPolynomialTerm::Product(
            interpretation
                .coefficients
                .get(index)
                .cloned()
                .unwrap_or_else(|| identity_matrix_cpf3(dimension)),
            index + 1,
        ));
    }
    if terms.len() == 1 {
        write_matrix_polynomial_term_cpf3(xml, &terms[0], indent);
    } else {
        xml.push_str(&format!("{pad}<sum>\n"));
        for term in &terms {
            write_matrix_polynomial_term_cpf3(xml, term, indent + 2);
        }
        xml.push_str(&format!("{pad}</sum>\n"));
    }
}

enum MatrixPolynomialTerm {
    Vector(Vec<i64>),
    Product(Vec<Vec<i64>>, usize),
}

fn write_matrix_polynomial_term_cpf3(xml: &mut String, term: &MatrixPolynomialTerm, indent: usize) {
    let pad = " ".repeat(indent);
    match term {
        MatrixPolynomialTerm::Vector(vector) => write_vector_cpf3(xml, vector, indent),
        MatrixPolynomialTerm::Product(matrix, variable) => {
            xml.push_str(&format!("{pad}<product>\n"));
            write_matrix_cpf3(xml, matrix, indent + 2);
            xml.push_str(&format!("{pad}  <variable>{variable}</variable>\n"));
            xml.push_str(&format!("{pad}</product>\n"));
        }
    }
}

fn write_vector_cpf3(xml: &mut String, vector: &[i64], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<vector>\n"));
    for value in vector {
        xml.push_str(&format!("{pad}  <integer>{value}</integer>\n"));
    }
    xml.push_str(&format!("{pad}</vector>\n"));
}

fn write_matrix_cpf3(xml: &mut String, matrix: &[Vec<i64>], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<matrix>\n"));
    for row in matrix {
        write_vector_cpf3(xml, row, indent + 2);
    }
    xml.push_str(&format!("{pad}</matrix>\n"));
}

fn identity_matrix_cpf3(dimension: usize) -> Vec<Vec<i64>> {
    (0..dimension)
        .map(|row| {
            (0..dimension)
                .map(|column| i64::from(row == column))
                .collect()
        })
        .collect()
}

fn write_dp_trans_cpf3(
    xml: &mut String,
    proof: &crate::proving::DependencyPairProof,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<dpTrans>\n"));
    write_dependency_pairs_trs_cpf3(xml, &proof.pairs, indent + 2, "dps");
    write_dp_proof_cpf3(xml, proof, indent + 2);
    xml.push_str(&format!("{pad}</dpTrans>\n"));
}

fn write_dp_proof_cpf3(
    xml: &mut String,
    proof: &crate::proving::DependencyPairProof,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<dpProof>\n"));
    if proof.pairs.is_empty() {
        xml.push_str(&format!("{pad}  <pIsEmpty/>\n"));
    } else {
        xml.push_str(&format!("{pad}  <depGraphProc>\n"));
        for component in &proof.component_proofs {
            xml.push_str(&format!("{pad}    <component>\n"));
            write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 6, "dps");
            if component.proved {
                xml.push_str(&format!("{pad}      <dpProof>\n"));
                write_dp_reduction_trace_cpf3(xml, component, proof.strategy, indent + 8);
                xml.push_str(&format!("{pad}      </dpProof>\n"));
            }
            xml.push_str(&format!("{pad}    </component>\n"));
        }
        xml.push_str(&format!("{pad}  </depGraphProc>\n"));
    }
    xml.push_str(&format!("{pad}</dpProof>\n"));
}

fn write_dp_reduction_trace_cpf3(
    xml: &mut String,
    component: &crate::proving::DpComponentProof,
    strategy: RewriteStrategy,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    if let Some(usable_rules) = &component.usable_rules_processor {
        xml.push_str(&format!("{pad}<usableRulesProc>\n"));
        write_rules_trs_cpf3(xml, usable_rules, indent + 2, "usableRules");
        xml.push_str(&format!("{pad}  <dpProof>\n"));
        write_dp_reduction_trace_body_cpf3(xml, component, strategy, indent + 4);
        xml.push_str(&format!("{pad}  </dpProof>\n"));
        xml.push_str(&format!("{pad}</usableRulesProc>\n"));
        return;
    }
    write_dp_reduction_trace_body_cpf3(xml, component, strategy, indent);
}

fn write_dp_reduction_trace_body_cpf3(
    xml: &mut String,
    component: &crate::proving::DpComponentProof,
    strategy: RewriteStrategy,
    indent: usize,
) {
    if let Some(lhss) = &component.innermost_lhss_processor {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<innermostLhssRemovalProc>\n"));
        write_innermost_lhss_cpf3(xml, lhss, indent + 2);
        xml.push_str(&format!("{pad}  <dpProof>\n"));
        write_dp_reduction_trace_inner_cpf3(xml, component, strategy, indent + 4);
        xml.push_str(&format!("{pad}  </dpProof>\n"));
        xml.push_str(&format!("{pad}</innermostLhssRemovalProc>\n"));
        return;
    }
    write_dp_reduction_trace_inner_cpf3(xml, component, strategy, indent);
}

fn write_dp_reduction_trace_inner_cpf3(
    xml: &mut String,
    component: &crate::proving::DpComponentProof,
    strategy: RewriteStrategy,
    indent: usize,
) {
    if let Some(proof_tree) = &component.proof_tree {
        write_dp_proof_tree_cpf3(xml, proof_tree, strategy, indent);
        return;
    }
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<pIsEmpty/>\n"));
}

fn write_innermost_lhss_cpf3(xml: &mut String, lhss: &[Term], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<innermostLhss>\n"));
    for lhs in lhss {
        write_term_cpf3(xml, lhs, indent + 2);
    }
    xml.push_str(&format!("{pad}</innermostLhss>\n"));
}

fn write_dp_proof_tree_cpf3(
    xml: &mut String,
    proof_tree: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    match proof_tree {
        crate::proving::DpProofTree::ExactXml(fragment) => {
            for line in fragment.lines() {
                xml.push_str(&format!("{pad}{line}\n"));
            }
        }
        crate::proving::DpProofTree::ComponentContext {
            usable_rules_processor,
            innermost_lhss_processor,
            proof,
        } if strategy == RewriteStrategy::Innermost => write_nested_dp_component_context_cpf3(
            xml,
            usable_rules_processor.as_deref(),
            innermost_lhss_processor.as_deref(),
            proof,
            strategy,
            indent,
        ),
        crate::proving::DpProofTree::ComponentContext { proof, .. } => {
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent);
        }
        crate::proving::DpProofTree::Empty => {
            xml.push_str(&format!("{pad}<pIsEmpty/>\n"));
        }
        crate::proving::DpProofTree::DepGraph { components } => {
            xml.push_str(&format!("{pad}<depGraphProc>\n"));
            for component in components {
                xml.push_str(&format!("{pad}  <component>\n"));
                write_dependency_pairs_trs_cpf3(xml, &component.pairs, indent + 4, "dps");
                if component.proved {
                    xml.push_str(&format!("{pad}    <dpProof>\n"));
                    write_dp_reduction_trace_cpf3(xml, component, strategy, indent + 6);
                    xml.push_str(&format!("{pad}    </dpProof>\n"));
                }
                xml.push_str(&format!("{pad}  </component>\n"));
            }
            xml.push_str(&format!("{pad}</depGraphProc>\n"));
        }
        crate::proving::DpProofTree::GeneralRedPairExact {
            payload_xml,
            proofs,
        } => {
            xml.push_str(&format!("{pad}<generalRedPairProc>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            for proof in proofs {
                xml.push_str(&format!("{pad}  <dpProof>\n"));
                write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
                xml.push_str(&format!("{pad}  </dpProof>\n"));
            }
            xml.push_str(&format!("{pad}</generalRedPairProc>\n"));
        }
        crate::proving::DpProofTree::ReductionPairExact {
            processor_tag,
            payload_xml,
            proof,
            ..
        } => {
            xml.push_str(&format!("{pad}<{processor_tag}>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</{processor_tag}>\n"));
        }
        crate::proving::DpProofTree::TransformationExact {
            processor_tag,
            payload_xml,
            ..
        } if processor_tag == "gm04ResidualAssumption" => {
            xml.push_str(&format!("{pad}<finitenessAssumption>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            xml.push_str(&format!("{pad}</finitenessAssumption>\n"));
        }
        crate::proving::DpProofTree::TransformationExact {
            processor_tag,
            payload_xml,
            proof,
        } => {
            xml.push_str(&format!("{pad}<{processor_tag}>\n"));
            for line in payload_xml.lines() {
                xml.push_str(&format!("{pad}  {line}\n"));
            }
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</{processor_tag}>\n"));
        }
        crate::proving::DpProofTree::Split {
            selected_pairs,
            selected_rules,
            selected_proof,
            residual_proof,
        } => {
            xml.push_str(&format!("{pad}<splitProc>\n"));
            write_dependency_pairs_trs_cpf3(xml, selected_pairs, indent + 2, "dps");
            write_rules_trs_cpf3(xml, selected_rules, indent + 2, "trs");
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, selected_proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, residual_proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</splitProc>\n"));
        }
        crate::proving::DpProofTree::SwitchInnermost {
            wcr_depth, proof, ..
        } => {
            xml.push_str(&format!("{pad}<switchInnermostProc>\n"));
            xml.push_str(&format!("{pad}  <wcrProof>\n"));
            xml.push_str(&format!(
                "{pad}    <joinAutoBfs>{wcr_depth}</joinAutoBfs>\n"
            ));
            xml.push_str(&format!("{pad}  </wcrProof>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, RewriteStrategy::Innermost, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</switchInnermostProc>\n"));
        }
        crate::proving::DpProofTree::QdpToSrs {
            generated, proof, ..
        } => {
            xml.push_str(&format!("{pad}<qdpToSrs>\n"));
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_trs_termination_proof_cpf3(xml, generated, proof, indent + 4)
                .expect("a reconstructed QDP-to-SRS child proof must remain CPF3-serializable");
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</qdpToSrs>\n"));
        }
        crate::proving::DpProofTree::SwitchToTrs {
            generated, proof, ..
        } => {
            xml.push_str(&format!("{pad}<switchToTRS>\n"));
            xml.push_str(&format!("{pad}  <trsTerminationProof>\n"));
            write_relative_trs_termination_proof_cpf3(xml, generated, proof, indent + 4)
                .expect("a reconstructed switch-to-TRS child proof must remain CPF3-serializable");
            xml.push_str(&format!("{pad}  </trsTerminationProof>\n"));
            xml.push_str(&format!("{pad}</switchToTRS>\n"));
        }
        crate::proving::DpProofTree::Subterm {
            projection,
            strict_pairs,
            proof,
            ..
        } => {
            write_subterm_projection_cpf3(xml, projection, strict_pairs, indent);
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</subtermProc>\n"));
        }
        crate::proving::DpProofTree::SizeChange { graphs } => {
            write_size_change_proc_cpf3(xml, graphs, indent);
        }
        crate::proving::DpProofTree::SizeChangeRedPair {
            graphs,
            reduction_pair,
            usable_rules,
        } => {
            write_size_change_red_pair_proc_cpf3(
                xml,
                graphs,
                reduction_pair,
                usable_rules,
                true,
                indent,
            );
        }
        crate::proving::DpProofTree::Narrowing { step, proof } => {
            xml.push_str(&format!("{pad}<narrowingProc>\n"));
            write_unindexed_rule_cpf3(xml, &step.pair.as_rule(), indent + 2);
            write_position_in_term_cpf3(xml, &step.position, indent + 2);
            xml.push_str(&format!("{pad}  <narrowings>\n"));
            write_dependency_pairs_rules_cpf3(xml, &step.narrowings, indent + 4);
            xml.push_str(&format!("{pad}  </narrowings>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</narrowingProc>\n"));
        }
        crate::proving::DpProofTree::Instantiation { step, proof } => {
            xml.push_str(&format!("{pad}<instantiationProc>\n"));
            write_unindexed_rule_cpf3(xml, &step.pair.as_rule(), indent + 2);
            xml.push_str(&format!("{pad}  <instantiations>\n"));
            write_dependency_pairs_rules_cpf3(xml, &step.instantiations, indent + 4);
            xml.push_str(&format!("{pad}  </instantiations>\n"));
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</instantiationProc>\n"));
        }
        crate::proving::DpProofTree::ForwardInstantiation { step, proof } => {
            xml.push_str(&format!("{pad}<forwardInstantiationProc>\n"));
            write_unindexed_rule_cpf3(xml, &step.pair.as_rule(), indent + 2);
            xml.push_str(&format!("{pad}  <instantiations>\n"));
            write_dependency_pairs_rules_cpf3(xml, &step.instantiations, indent + 4);
            xml.push_str(&format!("{pad}  </instantiations>\n"));
            if step.uses_usable_rules || strategy == RewriteStrategy::Innermost {
                write_rules_trs_cpf3(xml, &step.usable_rules, indent + 2, "usableRules");
            }
            xml.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
            xml.push_str(&format!("{pad}  </dpProof>\n"));
            xml.push_str(&format!("{pad}</forwardInstantiationProc>\n"));
        }
        crate::proving::DpProofTree::Rewriting { step, proof } => {
            let mut output = String::new();
            output.push_str(&format!("{pad}<rewritingProc>\n"));
            write_unindexed_rule_cpf3(&mut output, &step.original_pair.as_rule(), indent + 2);
            output.push_str(&format!("{pad}  <rewriteStep>\n"));
            write_position_in_term_cpf3(&mut output, &step.rewrite_step.position, indent + 4);
            write_unindexed_rule_cpf3(&mut output, &step.rewrite_step.rule, indent + 4);
            write_term_cpf3(&mut output, &step.rewrite_step.result, indent + 4);
            output.push_str(&format!("{pad}  </rewriteStep>\n"));
            write_unindexed_rule_cpf3(&mut output, &step.rewritten_pair.as_rule(), indent + 2);
            write_rules_trs_cpf3(&mut output, &step.usable_rules, indent + 2, "usableRules");
            output.push_str(&format!("{pad}  <dpProof>\n"));
            write_dp_proof_tree_cpf3(&mut output, proof, strategy, indent + 4);
            output.push_str(&format!("{pad}  </dpProof>\n"));
            output.push_str(&format!("{pad}</rewritingProc>\n"));
            xml.push_str(&output);
        }
        crate::proving::DpProofTree::RedPair { reduction, proof } => {
            write_red_pair_proc_cpf3(xml, reduction, proof, strategy, indent);
        }
        crate::proving::DpProofTree::SemanticLabeling { step, proof } => {
            write_semantic_labeling_proc_cpf3(xml, step, proof, strategy, indent);
        }
        crate::proving::DpProofTree::Uncurry { step, proof } => {
            write_dp_uncurry_proc_cpf3(xml, step, proof, indent);
        }
    }
}

fn write_nested_dp_component_context_cpf3(
    xml: &mut String,
    usable_rules: Option<&[RewriteRule]>,
    innermost_lhss: Option<&[Term]>,
    proof: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    if let Some(usable_rules) = usable_rules {
        xml.push_str(&format!("{pad}<usableRulesProc>\n"));
        write_rules_trs_cpf3(xml, usable_rules, indent + 2, "usableRules");
        xml.push_str(&format!("{pad}  <dpProof>\n"));
        write_nested_dp_component_context_cpf3(
            xml,
            None,
            innermost_lhss,
            proof,
            strategy,
            indent + 4,
        );
        xml.push_str(&format!("{pad}  </dpProof>\n"));
        xml.push_str(&format!("{pad}</usableRulesProc>\n"));
    } else if let Some(lhss) = innermost_lhss {
        xml.push_str(&format!("{pad}<innermostLhssRemovalProc>\n"));
        write_innermost_lhss_cpf3(xml, lhss, indent + 2);
        xml.push_str(&format!("{pad}  <dpProof>\n"));
        write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
        xml.push_str(&format!("{pad}  </dpProof>\n"));
        xml.push_str(&format!("{pad}</innermostLhssRemovalProc>\n"));
    } else {
        write_dp_proof_tree_cpf3(xml, proof, strategy, indent);
    }
}

fn write_dp_uncurry_proc_cpf3(
    xml: &mut String,
    step: &crate::proving::DpUncurryingStep,
    proof: &crate::proving::DpProofTree,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<uncurryProc>\n"));
    if let Some(applicative_top) = step.applicative_top {
        xml.push_str(&format!(
            "{pad}  <applicativeTop>{applicative_top}</applicativeTop>\n"
        ));
    }
    write_uncurry_information_cpf3(
        xml,
        &step.app_symbol,
        &step.symbols,
        &step.uncurry_rules,
        &step.eta_rules,
        indent + 2,
    );
    write_dependency_pairs_trs_cpf3(xml, &step.transformed_pairs, indent + 2, "dps");
    write_rules_trs_cpf3(xml, &step.transformed_rules, indent + 2, "trs");
    xml.push_str(&format!("{pad}  <dpProof>\n"));
    write_dp_proof_tree_cpf3(xml, proof, RewriteStrategy::Full, indent + 4);
    xml.push_str(&format!("{pad}  </dpProof>\n"));
    xml.push_str(&format!("{pad}</uncurryProc>\n"));
}

fn write_subterm_projection_cpf3(
    xml: &mut String,
    projection: &[crate::proving::DpSubtermProjectionEntry],
    strict_pairs: &[crate::proving::DependencyPair],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<subtermProc>\n"));
    xml.push_str(&format!("{pad}  <argumentFilter>\n"));
    for entry in projection {
        xml.push_str(&format!("{pad}    <argumentFilterEntry>\n"));
        write_symbol_cpf3(xml, entry.symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{}</arity>\n", entry.arity));
        xml.push_str(&format!(
            "{pad}      <collapsing>{}</collapsing>\n",
            entry.position + 1
        ));
        xml.push_str(&format!("{pad}    </argumentFilterEntry>\n"));
    }
    xml.push_str(&format!("{pad}  </argumentFilter>\n"));
    write_dependency_pairs_trs_cpf3(xml, strict_pairs, indent + 2, "dps");
}

fn write_semantic_labeling_proc_cpf3(
    xml: &mut String,
    step: &crate::proving::DpSemanticLabelingStep,
    proof: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<semlabProc>\n"));
    if step.root_labeling {
        let model_pad = " ".repeat(indent + 2);
        xml.push_str(&format!("{model_pad}<model>\n"));
        xml.push_str(&format!("{model_pad}  <rootLabeling/>\n"));
        xml.push_str(&format!("{model_pad}</model>\n"));
    } else {
        write_semantic_labeling_model_cpf3(xml, &step.model, indent + 2);
    }
    write_dependency_pairs_trs_cpf3(xml, &step.labeled_pairs, indent + 2, "dps");
    write_rules_trs_cpf3(xml, &step.labeled_rules, indent + 2, "trs");
    if !step.labeled_innermost_lhss.is_empty() {
        write_innermost_lhss_cpf3(xml, &step.labeled_innermost_lhss, indent + 2);
    }
    xml.push_str(&format!("{pad}  <dpProof>\n"));
    write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
    xml.push_str(&format!("{pad}  </dpProof>\n"));
    xml.push_str(&format!("{pad}</semlabProc>\n"));
}

fn write_semantic_labeling_model_cpf3(
    xml: &mut String,
    model: &crate::proving::SemanticLabelingModel,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<model>\n"));
    xml.push_str(&format!("{pad}  <finiteModel>\n"));
    xml.push_str(&format!(
        "{pad}    <carrierSize>{}</carrierSize>\n",
        model.carrier_size
    ));
    for (symbol, function) in &model.interpretations {
        xml.push_str(&format!("{pad}    <interpret>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!(
            "{pad}      <arity>{}</arity>\n",
            model.arities.get(symbol).copied().unwrap_or(0)
        ));
        write_semantic_labeling_arith_function_cpf3(xml, function, indent + 6);
        xml.push_str(&format!("{pad}    </interpret>\n"));
    }
    xml.push_str(&format!("{pad}  </finiteModel>\n"));
    xml.push_str(&format!("{pad}</model>\n"));
}

fn write_semantic_labeling_arith_function_cpf3(
    xml: &mut String,
    function: &crate::proving::SlArithmeticFunction,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<arithFunction>\n"));
    match function {
        crate::proving::SlArithmeticFunction::IfEqual(parts) => {
            xml.push_str(&format!("{pad}  <ifEqual>\n"));
            for part in parts.iter() {
                write_semantic_labeling_arith_function_cpf3(xml, part, indent + 4);
            }
            xml.push_str(&format!("{pad}  </ifEqual>\n"));
        }
        crate::proving::SlArithmeticFunction::Constant(value) => {
            xml.push_str(&format!("{pad}  <natural>{value}</natural>\n"));
        }
        crate::proving::SlArithmeticFunction::Argument(index) => {
            xml.push_str(&format!("{pad}  <variable>{}</variable>\n", index + 1));
        }
        crate::proving::SlArithmeticFunction::Sum(items) => {
            xml.push_str(&format!("{pad}  <sum>\n"));
            for item in items {
                write_semantic_labeling_arith_function_cpf3(xml, item, indent + 4);
            }
            xml.push_str(&format!("{pad}  </sum>\n"));
        }
        crate::proving::SlArithmeticFunction::Product(items) => {
            xml.push_str(&format!("{pad}  <product>\n"));
            for item in items {
                write_semantic_labeling_arith_function_cpf3(xml, item, indent + 4);
            }
            xml.push_str(&format!("{pad}  </product>\n"));
        }
    }
    xml.push_str(&format!("{pad}</arithFunction>\n"));
}

fn write_red_pair_proc_cpf3(
    xml: &mut String,
    reduction: &crate::proving::DpRemovalProof,
    proof: &crate::proving::DpProofTree,
    strategy: RewriteStrategy,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let q_monotonic_rule_removal = strategy == RewriteStrategy::Innermost
        && !reduction.strict_rules.is_empty()
        && !reduction_pair_is_mono(&reduction.reduction_pair)
        && !reduction.force_non_mono_usable_rules;
    let (open_tag, close_tag) = if q_monotonic_rule_removal {
        ("innermostMonoRedPairProc", "innermostMonoRedPairProc")
    } else if reduction.uses_usable_rules
        && reduction_pair_is_mono(&reduction.reduction_pair)
        && !reduction.force_non_mono_usable_rules
    {
        ("monoRedPairUrProc", "monoRedPairUrProc")
    } else if reduction.uses_usable_rules {
        ("redPairUrProc", "redPairUrProc")
    } else if reduction_pair_is_mono(&reduction.reduction_pair)
        && !reduction.force_non_mono_usable_rules
    {
        ("monoRedPairProc", "monoRedPairProc")
    } else {
        ("redPairProc", "redPairProc")
    };
    xml.push_str(&format!("{pad}<{open_tag}>\n"));
    write_reduction_pair_cpf3(xml, reduction, indent + 2);
    let removed_pairs = strict_pairs_for_reduction(reduction);
    write_dependency_pairs_trs_cpf3(xml, &removed_pairs, indent + 2, "dps");
    if open_tag == "innermostMonoRedPairProc" {
        write_rules_trs_cpf3(xml, &reduction.strict_rules, indent + 2, "trs");
    } else if open_tag == "monoRedPairUrProc" {
        write_rules_trs_cpf3(xml, &reduction.strict_rules, indent + 2, "trs");
        write_rules_trs_cpf3(xml, &reduction.usable_rules, indent + 2, "usableRules");
    } else if open_tag == "redPairUrProc" {
        write_rules_trs_cpf3(xml, &reduction.usable_rules, indent + 2, "usableRules");
    } else if open_tag == "monoRedPairProc" {
        write_rules_trs_cpf3(xml, &reduction.strict_rules, indent + 2, "trs");
    }
    xml.push_str(&format!("{pad}  <dpProof>\n"));
    write_dp_proof_tree_cpf3(xml, proof, strategy, indent + 4);
    xml.push_str(&format!("{pad}  </dpProof>\n"));
    xml.push_str(&format!("{pad}</{close_tag}>\n"));
}

fn reduction_pair_is_mono(reduction_pair: &DpReductionPairProof) -> bool {
    match reduction_pair {
        DpReductionPairProof::Polynomial { interpretation, .. } => {
            interpretation.iter().all(|(_, constant, coefficients)| {
                *constant >= 0 && coefficients.iter().all(|coefficient| *coefficient >= 1)
            })
        }
        DpReductionPairProof::NaturalPolynomial { interpretation, .. } => {
            interpretation.iter().all(|(_, polynomial)| {
                polynomial.constant >= 0
                    && polynomial
                        .linear
                        .iter()
                        .all(|coefficient| *coefficient >= 1)
                    && polynomial
                        .quadratic
                        .iter()
                        .enumerate()
                        .all(|(row, coefficients)| {
                            coefficients
                                .iter()
                                .enumerate()
                                .all(|(column, coefficient)| column < row || *coefficient >= 0)
                        })
            })
        }
        DpReductionPairProof::MaxPolynomial { .. }
        | DpReductionPairProof::WeightedPathOrderMax { .. }
        | DpReductionPairProof::Matrix { .. }
        | DpReductionPairProof::IntegerMatrix { .. }
        | DpReductionPairProof::ArcticMatrix { .. }
        | DpReductionPairProof::RationalPolynomial { .. }
        | DpReductionPairProof::RationalNaturalPolynomial { .. }
        | DpReductionPairProof::PathOrder { .. }
        | DpReductionPairProof::Kbo { .. } => false,
    }
}

fn write_size_change_proc_cpf3(
    xml: &mut String,
    graphs: &[crate::proving::DpSizeChangeGraph],
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<sizeChangeProc>\n"));
    xml.push_str(&format!("{pad}  <subtermCriterion/>\n"));
    for graph in graphs {
        xml.push_str(&format!("{pad}  <sizeChangeGraph>\n"));
        write_unindexed_rule_cpf3(xml, &graph.pair.as_rule(), indent + 4);
        for edge in &graph.edges {
            xml.push_str(&format!("{pad}    <edge>\n"));
            xml.push_str(&format!(
                "{pad}      <position>{}</position>\n",
                edge.left_position
            ));
            xml.push_str(&format!("{pad}      <strict>{}</strict>\n", edge.strict));
            xml.push_str(&format!(
                "{pad}      <position>{}</position>\n",
                edge.right_position
            ));
            xml.push_str(&format!("{pad}    </edge>\n"));
        }
        xml.push_str(&format!("{pad}  </sizeChangeGraph>\n"));
    }
    xml.push_str(&format!("{pad}</sizeChangeProc>\n"));
}

fn write_size_change_red_pair_proc_cpf3(
    xml: &mut String,
    graphs: &[crate::proving::DpSizeChangeGraph],
    reduction_pair: &DpReductionPairProof,
    usable_rules: &[RewriteRule],
    emit_usable_rules: bool,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let arities = arities_for_size_change_graphs(graphs, usable_rules);
    xml.push_str(&format!("{pad}<sizeChangeProc>\n"));
    xml.push_str(&format!("{pad}  <reductionPair>\n"));
    write_reduction_pair_proof_cpf3(xml, arities, reduction_pair, indent + 4);
    if emit_usable_rules {
        write_rules_trs_cpf3(xml, usable_rules, indent + 4, "usableRules");
    }
    xml.push_str(&format!("{pad}  </reductionPair>\n"));
    for graph in graphs {
        xml.push_str(&format!("{pad}  <sizeChangeGraph>\n"));
        write_unindexed_rule_cpf3(xml, &graph.pair.as_rule(), indent + 4);
        for edge in &graph.edges {
            xml.push_str(&format!("{pad}    <edge>\n"));
            xml.push_str(&format!(
                "{pad}      <position>{}</position>\n",
                edge.left_position
            ));
            xml.push_str(&format!("{pad}      <strict>{}</strict>\n", edge.strict));
            xml.push_str(&format!(
                "{pad}      <position>{}</position>\n",
                edge.right_position
            ));
            xml.push_str(&format!("{pad}    </edge>\n"));
        }
        xml.push_str(&format!("{pad}  </sizeChangeGraph>\n"));
    }
    xml.push_str(&format!("{pad}</sizeChangeProc>\n"));
}

fn write_position_in_term_cpf3(xml: &mut String, position: &[usize], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<positionInTerm>\n"));
    for step in position {
        xml.push_str(&format!("{pad}  <position>{step}</position>\n"));
    }
    xml.push_str(&format!("{pad}</positionInTerm>\n"));
}

fn write_context_cpf3(xml: &mut String, term: &Term, position: &[usize], indent: usize) {
    let pad = " ".repeat(indent);
    if position.is_empty() {
        xml.push_str(&format!("{pad}<box/>\n"));
        return;
    }
    let Term::App { symbol, args } = term else {
        xml.push_str(&format!("{pad}<box/>\n"));
        return;
    };
    let Some(index) = position[0].checked_sub(1) else {
        xml.push_str(&format!("{pad}<box/>\n"));
        return;
    };
    if index >= args.len() {
        xml.push_str(&format!("{pad}<box/>\n"));
        return;
    }
    xml.push_str(&format!("{pad}<funContext>\n"));
    write_symbol_cpf3(xml, symbol.as_str(), indent + 2);
    xml.push_str(&format!("{pad}  <before>\n"));
    for arg in &args[..index] {
        write_term_cpf3(xml, arg, indent + 4);
    }
    xml.push_str(&format!("{pad}  </before>\n"));
    write_context_cpf3(xml, &args[index], &position[1..], indent + 2);
    xml.push_str(&format!("{pad}  <after>\n"));
    for arg in &args[index + 1..] {
        write_term_cpf3(xml, arg, indent + 4);
    }
    xml.push_str(&format!("{pad}  </after>\n"));
    xml.push_str(&format!("{pad}</funContext>\n"));
}

fn write_reduction_pair_cpf3(
    xml: &mut String,
    reduction: &crate::proving::DpRemovalProof,
    indent: usize,
) {
    let arities = arities_for_dp_reduction(reduction);
    if reduction.uses_usable_rules
        // A forced general usable-rule processor carries an independently
        // fixed rule set (CSR U3/RTA'08 and their exact test witnesses).  Its
        // closure was not computed from the polynomial's zero coefficients,
        // so adding a filteredRedPair here would change the order that the
        // runtime validated.  Ordinary DP usable-rule synthesis leaves this
        // flag false and still exports its required argument filter.
        && !reduction.force_non_mono_usable_rules
        && let Some(argument_filter) =
            polynomial_reduction_argument_filter(&arities, &reduction.reduction_pair)
    {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<filteredRedPair>\n"));
        write_argument_filter_cpf3(xml, &arities, &argument_filter, indent + 2);
        let (filtered_arities, filtered_reduction_pair) =
            filter_polynomial_reduction_pair(&arities, &argument_filter, &reduction.reduction_pair);
        write_reduction_pair_proof_cpf3(
            xml,
            filtered_arities,
            &filtered_reduction_pair,
            indent + 2,
        );
        xml.push_str(&format!("{pad}</filteredRedPair>\n"));
        return;
    }
    write_reduction_pair_proof_cpf3(xml, arities, &reduction.reduction_pair, indent);
}

/// CPF applies the argument filter before interpreting terms.  Consequently
/// the nested reduction pair lives over the filtered signature: its arities
/// and coefficient vectors must be compressed to the retained positions.
/// Keeping the original arity makes CeTA look up a default interpretation for
/// the filtered symbol and can turn an internally strict witness into a
/// checker-rejected one.
fn filter_polynomial_reduction_pair(
    arities: &BTreeMap<Symbol, usize>,
    argument_filter: &DpArgumentFilter,
    reduction_pair: &DpReductionPairProof,
) -> (BTreeMap<Symbol, usize>, DpReductionPairProof) {
    let retained = |name: &str, arity: usize| -> Vec<usize> {
        match argument_filter.get(name) {
            Some(DpArgumentFilterEntry::NonCollapsing(positions)) => positions.clone(),
            Some(DpArgumentFilterEntry::Collapsing(position)) => vec![*position],
            None => (0..arity).collect(),
        }
    };
    let filtered_arities = arities
        .iter()
        .map(|(symbol, arity)| (symbol.clone(), retained(symbol.as_str(), *arity).len()))
        .collect();
    let filter_linear = |interpretation: &[(String, i64, Vec<i64>)]| {
        interpretation
            .iter()
            .map(|(name, constant, coefficients)| {
                let positions = retained(name, coefficients.len());
                (
                    name.clone(),
                    *constant,
                    positions
                        .iter()
                        .map(|position| coefficients.get(*position).copied().unwrap_or(0))
                        .collect(),
                )
            })
            .collect()
    };
    let filter_natural = |interpretation: &[(String, NaturalPolynomial)]| {
        interpretation
            .iter()
            .map(|(name, polynomial)| {
                let positions = retained(name, polynomial.linear.len());
                let linear = positions
                    .iter()
                    .map(|position| polynomial.linear.get(*position).copied().unwrap_or(0))
                    .collect();
                let quadratic = positions
                    .iter()
                    .map(|row| {
                        positions
                            .iter()
                            .map(|column| {
                                polynomial
                                    .quadratic
                                    .get(*row)
                                    .and_then(|coefficients| coefficients.get(*column))
                                    .copied()
                                    .unwrap_or(0)
                            })
                            .collect()
                    })
                    .collect();
                (
                    name.clone(),
                    NaturalPolynomial {
                        constant: polynomial.constant,
                        linear,
                        quadratic,
                    },
                )
            })
            .collect()
    };
    let filtered = match reduction_pair {
        DpReductionPairProof::Polynomial {
            interpretation,
            backend,
        } => DpReductionPairProof::Polynomial {
            interpretation: filter_linear(interpretation),
            backend: backend.clone(),
        },
        DpReductionPairProof::RationalPolynomial {
            denominator,
            interpretation,
            backend,
        } => DpReductionPairProof::RationalPolynomial {
            denominator: *denominator,
            interpretation: filter_linear(interpretation),
            backend: backend.clone(),
        },
        DpReductionPairProof::NaturalPolynomial {
            interpretation,
            degree,
            backend,
        } => DpReductionPairProof::NaturalPolynomial {
            interpretation: filter_natural(interpretation),
            degree: *degree,
            backend: backend.clone(),
        },
        DpReductionPairProof::RationalNaturalPolynomial {
            denominator,
            delta,
            interpretation,
            degree,
            backend,
        } => DpReductionPairProof::RationalNaturalPolynomial {
            denominator: *denominator,
            delta: *delta,
            interpretation: filter_natural(interpretation),
            degree: *degree,
            backend: backend.clone(),
        },
        _ => reduction_pair.clone(),
    };
    (filtered_arities, filtered)
}

/// Recover the argument filter that Ferrum used when it computed a
/// polynomial usable-rule closure.  Zero coefficients make an argument
/// semantically invisible, but CPF does not infer that filter from the
/// interpretation.  Omitting the explicit `filteredRedPair` therefore made
/// the runtime processor and its certificate describe different closures.
fn polynomial_reduction_argument_filter(
    arities: &BTreeMap<Symbol, usize>,
    reduction_pair: &DpReductionPairProof,
) -> Option<DpArgumentFilter> {
    let active_positions = |symbol: &Symbol, arity: usize| -> Vec<usize> {
        match reduction_pair {
            DpReductionPairProof::Polynomial { interpretation, .. }
            | DpReductionPairProof::RationalPolynomial { interpretation, .. } => interpretation
                .iter()
                .find(|(name, _, _)| name == symbol.as_str())
                .map(|(_, _, coefficients)| {
                    (0..arity)
                        .filter(|position| coefficients.get(*position).copied().unwrap_or(1) != 0)
                        .collect()
                })
                .unwrap_or_else(|| (0..arity).collect()),
            DpReductionPairProof::NaturalPolynomial { interpretation, .. }
            | DpReductionPairProof::RationalNaturalPolynomial { interpretation, .. } => {
                interpretation
                    .iter()
                    .find(|(name, _)| name == symbol.as_str())
                    .map(|(_, polynomial)| {
                        (0..arity)
                            .filter(|position| {
                                polynomial.linear.get(*position).copied().unwrap_or(1) != 0
                                    || polynomial.quadratic.iter().enumerate().any(
                                        |(row, coefficients)| {
                                            coefficients.iter().enumerate().any(
                                                |(column, coefficient)| {
                                                    *coefficient != 0
                                                        && (row == *position || column == *position)
                                                },
                                            )
                                        },
                                    )
                            })
                            .collect()
                    })
                    .unwrap_or_else(|| (0..arity).collect())
            }
            _ => (0..arity).collect(),
        }
    };

    let filter = arities
        .iter()
        .map(|(symbol, arity)| {
            (
                symbol.as_str().to_string(),
                DpArgumentFilterEntry::NonCollapsing(active_positions(symbol, *arity)),
            )
        })
        .collect::<DpArgumentFilter>();
    let nontrivial = arities.iter().any(|(symbol, arity)| {
        matches!(
            filter.get(symbol.as_str()),
            Some(DpArgumentFilterEntry::NonCollapsing(positions)) if positions.len() < *arity
        )
    });
    nontrivial.then_some(filter)
}

fn write_reduction_pair_proof_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    reduction_pair: &DpReductionPairProof,
    indent: usize,
) {
    match reduction_pair {
        DpReductionPairProof::Polynomial { interpretation, .. } => {
            write_polynomial_interpretation_for_arities_cpf3(xml, arities, interpretation, indent);
        }
        DpReductionPairProof::NaturalPolynomial {
            interpretation,
            degree,
            ..
        } => write_natural_polynomial_interpretation_for_arities_cpf3(
            xml,
            arities,
            interpretation,
            *degree,
            indent,
        ),
        DpReductionPairProof::MaxPolynomial { interpretation, .. } => {
            write_max_polynomial_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretation,
                indent,
            );
        }
        DpReductionPairProof::WeightedPathOrderMax {
            precedence_ranks,
            statuses,
            argument_filter,
            interpretation,
            ..
        } => {
            let pad = " ".repeat(indent);
            if !argument_filter.is_empty() {
                xml.push_str(&format!("{pad}<filteredRedPair>\n"));
                write_argument_filter_cpf3(xml, &arities, argument_filter, indent + 2);
            }
            let wpo_indent = if argument_filter.is_empty() {
                indent
            } else {
                indent + 2
            };
            let pad = " ".repeat(wpo_indent);
            xml.push_str(&format!("{pad}<weightedPathOrder>\n"));
            xml.push_str(&format!("{pad}  <precedenceStatus>\n"));
            for (symbol, arity) in &arities {
                let name = symbol.as_str();
                let status = statuses.get(name);
                xml.push_str(&format!("{pad}    <precedenceStatusEntry>\n"));
                write_symbol_cpf3(xml, name, wpo_indent + 6);
                xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
                xml.push_str(&format!(
                    "{pad}      <precedence>{}</precedence>\n",
                    precedence_ranks.get(name).copied().unwrap_or(0)
                ));
                if status.is_some_and(|entry| entry.multiset) {
                    xml.push_str(&format!("{pad}      <mul/>\n"));
                }
                xml.push_str(&format!("{pad}      <status>\n"));
                if let Some(status) = status {
                    for position in &status.positions {
                        xml.push_str(&format!(
                            "{pad}        <position>{}</position>\n",
                            position + 1
                        ));
                    }
                }
                xml.push_str(&format!("{pad}      </status>\n"));
                xml.push_str(&format!("{pad}    </precedenceStatusEntry>\n"));
            }
            xml.push_str(&format!("{pad}  </precedenceStatus>\n"));
            write_max_polynomial_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretation,
                wpo_indent + 2,
            );
            xml.push_str(&format!("{pad}</weightedPathOrder>\n"));
            if !argument_filter.is_empty() {
                let pad = " ".repeat(indent);
                xml.push_str(&format!("{pad}</filteredRedPair>\n"));
            }
        }
        DpReductionPairProof::RationalPolynomial {
            denominator,
            interpretation,
            ..
        } => write_rational_polynomial_interpretation_for_arities_cpf3(
            xml,
            arities,
            interpretation,
            *denominator,
            indent,
        ),
        DpReductionPairProof::RationalNaturalPolynomial {
            denominator,
            delta,
            interpretation,
            degree,
            ..
        } => write_rational_natural_polynomial_interpretation_for_arities_cpf3(
            xml,
            arities,
            interpretation,
            *denominator,
            *delta,
            *degree,
            indent,
        ),
        DpReductionPairProof::Matrix {
            interpretation,
            dimension,
            strict_dimension,
            ..
        } => {
            write_matrix_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretation,
                *dimension,
                *strict_dimension,
                "naturals",
                indent,
            );
        }
        DpReductionPairProof::IntegerMatrix {
            interpretation,
            dimension,
            strict_dimension,
            ..
        } => {
            write_matrix_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretation,
                *dimension,
                *strict_dimension,
                "integers",
                indent,
            );
        }
        DpReductionPairProof::ArcticMatrix {
            interpretation,
            dimension,
            strict_dimension,
            domain,
            ..
        } => {
            write_arctic_matrix_interpretation_for_arities_cpf3(
                xml,
                arities,
                interpretation,
                *dimension,
                *strict_dimension,
                *domain,
                indent,
            );
        }
        DpReductionPairProof::PathOrder {
            order,
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
            ..
        } => {
            write_recursive_path_order_cpf3(
                xml,
                arities,
                *order,
                statuses,
                precedence,
                Some(precedence_ranks),
                argument_filter,
                indent,
            );
        }
        DpReductionPairProof::Kbo {
            precedence,
            precedence_ranks,
            weights,
            argument_filter,
            ..
        } => {
            write_kbo_order_cpf3(
                xml,
                arities,
                precedence,
                weights,
                Some(argument_filter),
                Some(precedence_ranks),
                indent,
            );
        }
    }
}

fn arities_for_size_change_graphs(
    graphs: &[crate::proving::DpSizeChangeGraph],
    usable_rules: &[RewriteRule],
) -> BTreeMap<crate::core::Symbol, usize> {
    let mut arities = BTreeMap::new();
    for graph in graphs {
        collect_term_arities(graph.pair.lhs(), &mut arities);
        collect_term_arities(graph.pair.rhs(), &mut arities);
    }
    for rule in usable_rules {
        collect_term_arities(rule.lhs(), &mut arities);
        collect_term_arities(rule.rhs(), &mut arities);
    }
    arities
}

fn strict_pairs_for_reduction(
    reduction: &crate::proving::DpRemovalProof,
) -> Vec<crate::proving::DependencyPair> {
    reduction
        .strict_pair_indices
        .iter()
        .filter_map(|index| reduction.pairs.get(*index).cloned())
        .collect()
}

fn write_recursive_path_order_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    order: DpPathOrderKind,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    explicit_precedence_ranks: Option<&BTreeMap<String, usize>>,
    argument_filter: &DpArgumentFilter,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let computed_ranks = precedence
        .iter()
        .enumerate()
        .map(|(index, symbol)| (symbol.as_str(), precedence.len() - index))
        .collect::<BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<recursivePathOrder>\n"));
    xml.push_str(&format!("{pad}  <statusPrecedence>\n"));
    for (symbol, arity) in &arities {
        xml.push_str(&format!("{pad}    <statusPrecedenceEntry>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
        xml.push_str(&format!(
            "{pad}      <precedence>{}</precedence>\n",
            explicit_precedence_ranks
                .and_then(|ranks| ranks.get(symbol.as_str()).copied())
                .map(|rank| precedence.len().saturating_sub(rank))
                .or_else(|| computed_ranks.get(symbol.as_str()).copied())
                .unwrap_or(0)
        ));
        match statuses.get(symbol.as_str()).copied().unwrap_or(order) {
            DpPathOrderKind::Lpo => xml.push_str(&format!("{pad}      <lex/>\n")),
            DpPathOrderKind::Rpo => xml.push_str(&format!("{pad}      <mul/>\n")),
        }
        xml.push_str(&format!("{pad}    </statusPrecedenceEntry>\n"));
    }
    xml.push_str(&format!("{pad}  </statusPrecedence>\n"));
    write_argument_filter_cpf3(xml, &arities, argument_filter, indent + 2);
    xml.push_str(&format!("{pad}</recursivePathOrder>\n"));
}

fn write_kbo_order_cpf3(
    xml: &mut String,
    arities: BTreeMap<crate::core::Symbol, usize>,
    precedence: &[String],
    weights: &BTreeMap<String, i64>,
    argument_filter: Option<&DpArgumentFilter>,
    explicit_precedence_ranks: Option<&BTreeMap<String, usize>>,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let computed_ranks = precedence
        .iter()
        .enumerate()
        .map(|(index, symbol)| (symbol.as_str(), precedence.len() - index))
        .collect::<BTreeMap<_, _>>();
    xml.push_str(&format!("{pad}<knuthBendixOrder>\n"));
    xml.push_str(&format!("{pad}  <w0>1</w0>\n"));
    xml.push_str(&format!("{pad}  <precedenceWeight>\n"));
    for (symbol, arity) in &arities {
        xml.push_str(&format!("{pad}    <precedenceWeightEntry>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
        xml.push_str(&format!(
            "{pad}      <precedence>{}</precedence>\n",
            explicit_precedence_ranks
                .and_then(|ranks| ranks.get(symbol.as_str()).copied())
                .map(|rank| precedence.len().saturating_sub(rank))
                .or_else(|| computed_ranks.get(symbol.as_str()).copied())
                .unwrap_or(0)
        ));
        xml.push_str(&format!(
            "{pad}      <weight>{}</weight>\n",
            weights.get(symbol.as_str()).copied().unwrap_or(1)
        ));
        xml.push_str(&format!("{pad}    </precedenceWeightEntry>\n"));
    }
    xml.push_str(&format!("{pad}  </precedenceWeight>\n"));
    if let Some(argument_filter) = argument_filter {
        write_argument_filter_cpf3(xml, &arities, argument_filter, indent + 2);
    }
    xml.push_str(&format!("{pad}</knuthBendixOrder>\n"));
}

fn write_argument_filter_cpf3(
    xml: &mut String,
    arities: &BTreeMap<crate::core::Symbol, usize>,
    argument_filter: &DpArgumentFilter,
    indent: usize,
) {
    if argument_filter.is_empty() {
        return;
    }
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<argumentFilter>\n"));
    for (symbol, positions) in argument_filter {
        let Some(arity) = arities.get(&crate::core::Symbol::new(symbol)) else {
            continue;
        };
        xml.push_str(&format!("{pad}  <argumentFilterEntry>\n"));
        write_symbol_cpf3(xml, symbol, indent + 4);
        xml.push_str(&format!("{pad}    <arity>{arity}</arity>\n"));
        if let DpArgumentFilterEntry::Collapsing(position) = positions {
            xml.push_str(&format!(
                "{pad}    <collapsing>{}</collapsing>\n",
                position + 1
            ));
        } else {
            xml.push_str(&format!("{pad}    <nonCollapsing>\n"));
            if let DpArgumentFilterEntry::NonCollapsing(positions) = positions {
                for position in positions {
                    xml.push_str(&format!(
                        "{pad}      <position>{}</position>\n",
                        position + 1
                    ));
                }
            }
            xml.push_str(&format!("{pad}    </nonCollapsing>\n"));
        }
        xml.push_str(&format!("{pad}  </argumentFilterEntry>\n"));
    }
    xml.push_str(&format!("{pad}</argumentFilter>\n"));
}

fn arities_for_dp_reduction(
    reduction: &crate::proving::DpRemovalProof,
) -> BTreeMap<crate::core::Symbol, usize> {
    let mut arities = BTreeMap::new();
    for pair in &reduction.pairs {
        collect_term_arities(pair.lhs(), &mut arities);
        collect_term_arities(pair.rhs(), &mut arities);
    }
    for rule in &reduction.usable_rules {
        collect_term_arities(rule.lhs(), &mut arities);
        collect_term_arities(rule.rhs(), &mut arities);
    }
    arities
}

fn collect_term_arities(term: &Term, arities: &mut BTreeMap<crate::core::Symbol, usize>) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            arities.insert(symbol.clone(), args.len());
            for arg in args {
                collect_term_arities(arg, arities);
            }
        }
    }
}

fn write_dependency_pairs_trs_cpf3(
    xml: &mut String,
    pairs: &[crate::proving::DependencyPair],
    indent: usize,
    tag: &str,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<{tag}>\n"));
    write_dependency_pairs_rules_cpf3(xml, pairs, indent + 2);
    xml.push_str(&format!("{pad}</{tag}>\n"));
}

fn write_dependency_pairs_rules_cpf3(
    xml: &mut String,
    pairs: &[crate::proving::DependencyPair],
    indent: usize,
) {
    let rules = pairs
        .iter()
        .map(crate::proving::DependencyPair::as_rule)
        .collect::<Vec<_>>();
    write_rules_cpf3(xml, &rules, indent);
}

fn write_rules_trs_cpf3(xml: &mut String, rules: &[RewriteRule], indent: usize, tag: &str) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<{tag}>\n"));
    write_rules_cpf3(xml, rules, indent + 2);
    xml.push_str(&format!("{pad}</{tag}>\n"));
}

fn write_rules_cpf3(xml: &mut String, rules: &[RewriteRule], indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<rules>\n"));
    for rule in rules {
        write_unindexed_rule_cpf3(xml, rule, indent + 2);
    }
    xml.push_str(&format!("{pad}</rules>\n"));
}

fn write_unindexed_rule_cpf3(xml: &mut String, rule: &RewriteRule, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<rule>\n"));
    write_term_cpf3(xml, rule.lhs(), indent + 2);
    write_term_cpf3(xml, rule.rhs(), indent + 2);
    xml.push_str(&format!("{pad}</rule>\n"));
}

fn write_linear_polynomial_cpf3(
    xml: &mut String,
    constant: i64,
    coefficients: &[i64],
    arity: usize,
    indent: usize,
) {
    let mut terms = Vec::new();
    if constant != 0 {
        terms.push(PolynomialTerm::Integer(constant));
    }
    for index in 0..arity {
        let coefficient = coefficients.get(index).copied().unwrap_or(1);
        if coefficient == 0 {
            continue;
        }
        terms.push(if coefficient == 1 {
            PolynomialTerm::Variable(index + 1)
        } else {
            PolynomialTerm::Product(coefficient, index + 1)
        });
    }
    if terms.is_empty() {
        terms.push(PolynomialTerm::Integer(0));
    }
    if terms.len() == 1 {
        write_polynomial_term_cpf3(xml, &terms[0], indent);
    } else {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<sum>\n"));
        for term in &terms {
            write_polynomial_term_cpf3(xml, term, indent + 2);
        }
        xml.push_str(&format!("{pad}</sum>\n"));
    }
}

fn write_natural_polynomial_cpf3(
    xml: &mut String,
    polynomial: &NaturalPolynomial,
    arity: usize,
    indent: usize,
) {
    let mut terms = Vec::new();
    if polynomial.constant != 0 {
        terms.push(PolynomialTerm::Integer(polynomial.constant));
    }
    for index in 0..arity {
        let coefficient = polynomial.linear.get(index).copied().unwrap_or(1);
        if coefficient == 0 {
            continue;
        }
        terms.push(if coefficient == 1 {
            PolynomialTerm::Variable(index + 1)
        } else {
            PolynomialTerm::Product(coefficient, index + 1)
        });
    }
    for left in 0..arity {
        for right in left..arity {
            let coefficient = polynomial
                .quadratic
                .get(left)
                .and_then(|row| row.get(right))
                .copied()
                .unwrap_or(0);
            if coefficient != 0 {
                terms.push(PolynomialTerm::QuadraticProduct(
                    coefficient,
                    left + 1,
                    right + 1,
                ));
            }
        }
    }
    if terms.is_empty() {
        terms.push(PolynomialTerm::Integer(0));
    }
    if terms.len() == 1 {
        write_polynomial_term_cpf3(xml, &terms[0], indent);
    } else {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<sum>\n"));
        for term in &terms {
            write_polynomial_term_cpf3(xml, term, indent + 2);
        }
        xml.push_str(&format!("{pad}</sum>\n"));
    }
}

fn write_max_polynomial_expression_cpf3(
    xml: &mut String,
    alternatives: &[(i64, Vec<i64>)],
    arity: usize,
    indent: usize,
) {
    if alternatives.len() == 1 {
        let (constant, coefficients) = &alternatives[0];
        write_linear_max_polynomial_cpf3(xml, *constant, coefficients, arity, indent);
        return;
    }
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<max>\n"));
    if alternatives.is_empty() {
        write_max_polynomial_term_cpf3(xml, &MaxPolynomialTerm::Constant(0), indent + 2);
    } else {
        for (constant, coefficients) in alternatives {
            write_linear_max_polynomial_cpf3(xml, *constant, coefficients, arity, indent + 2);
        }
    }
    xml.push_str(&format!("{pad}</max>\n"));
}

fn write_linear_max_polynomial_cpf3(
    xml: &mut String,
    constant: i64,
    coefficients: &[i64],
    arity: usize,
    indent: usize,
) {
    let mut terms = Vec::new();
    if constant != 0 {
        terms.push(MaxPolynomialTerm::Constant(constant));
    }
    for index in 0..arity {
        let coefficient = coefficients.get(index).copied().unwrap_or(1);
        if coefficient == 0 {
            continue;
        }
        terms.push(if coefficient == 1 {
            MaxPolynomialTerm::Variable(index + 1)
        } else {
            MaxPolynomialTerm::Product(coefficient, index + 1)
        });
    }
    if terms.is_empty() {
        terms.push(MaxPolynomialTerm::Constant(0));
    }
    if terms.len() == 1 {
        write_max_polynomial_term_cpf3(xml, &terms[0], indent);
    } else {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<sum>\n"));
        for term in &terms {
            write_max_polynomial_term_cpf3(xml, term, indent + 2);
        }
        xml.push_str(&format!("{pad}</sum>\n"));
    }
}

fn write_linear_rational_polynomial_cpf3(
    xml: &mut String,
    constant: i64,
    coefficients: &[i64],
    arity: usize,
    denominator: i64,
    indent: usize,
) {
    let mut terms = Vec::new();
    if constant != 0 {
        terms.push(RationalPolynomialTerm::Number(constant));
    }
    for index in 0..arity {
        let coefficient = coefficients.get(index).copied().unwrap_or(denominator);
        if coefficient == 0 {
            continue;
        }
        terms.push(if coefficient == denominator {
            RationalPolynomialTerm::Variable(index + 1)
        } else {
            RationalPolynomialTerm::Product(coefficient, index + 1)
        });
    }
    if terms.is_empty() {
        terms.push(RationalPolynomialTerm::Number(0));
    }
    if terms.len() == 1 {
        write_rational_polynomial_term_cpf3(xml, &terms[0], denominator, indent);
    } else {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<sum>\n"));
        for term in &terms {
            write_rational_polynomial_term_cpf3(xml, term, denominator, indent + 2);
        }
        xml.push_str(&format!("{pad}</sum>\n"));
    }
}

enum PolynomialTerm {
    Integer(i64),
    Variable(usize),
    Product(i64, usize),
    QuadraticProduct(i64, usize, usize),
}

enum MaxPolynomialTerm {
    Constant(i64),
    Variable(usize),
    Product(i64, usize),
}

enum RationalPolynomialTerm {
    Number(i64),
    Variable(usize),
    Product(i64, usize),
    QuadraticProduct(i64, usize, usize),
}

fn write_rational_natural_polynomial_cpf3(
    xml: &mut String,
    polynomial: &NaturalPolynomial,
    arity: usize,
    denominator: i64,
    indent: usize,
) {
    let mut terms = Vec::new();
    if polynomial.constant != 0 {
        terms.push(RationalPolynomialTerm::Number(polynomial.constant));
    }
    for index in 0..arity {
        let coefficient = polynomial.linear.get(index).copied().unwrap_or(denominator);
        if coefficient != 0 {
            terms.push(if coefficient == denominator {
                RationalPolynomialTerm::Variable(index + 1)
            } else {
                RationalPolynomialTerm::Product(coefficient, index + 1)
            });
        }
    }
    for left in 0..arity {
        for right in left..arity {
            let coefficient = polynomial
                .quadratic
                .get(left)
                .and_then(|row| row.get(right))
                .copied()
                .unwrap_or(0);
            if coefficient != 0 {
                terms.push(RationalPolynomialTerm::QuadraticProduct(
                    coefficient,
                    left + 1,
                    right + 1,
                ));
            }
        }
    }
    if terms.is_empty() {
        terms.push(RationalPolynomialTerm::Number(0));
    }
    if terms.len() == 1 {
        write_rational_polynomial_term_cpf3(xml, &terms[0], denominator, indent);
    } else {
        let pad = " ".repeat(indent);
        xml.push_str(&format!("{pad}<sum>\n"));
        for term in &terms {
            write_rational_polynomial_term_cpf3(xml, term, denominator, indent + 2);
        }
        xml.push_str(&format!("{pad}</sum>\n"));
    }
}

fn write_max_polynomial_term_cpf3(xml: &mut String, term: &MaxPolynomialTerm, indent: usize) {
    let pad = " ".repeat(indent);
    match term {
        MaxPolynomialTerm::Constant(value) => {
            xml.push_str(&format!("{pad}<constant>{value}</constant>\n"));
        }
        MaxPolynomialTerm::Variable(index) => {
            xml.push_str(&format!("{pad}<variable>{index}</variable>\n"));
        }
        MaxPolynomialTerm::Product(coefficient, variable) => {
            xml.push_str(&format!("{pad}<product>\n"));
            xml.push_str(&format!("{pad}  <constant>{coefficient}</constant>\n"));
            xml.push_str(&format!("{pad}  <variable>{variable}</variable>\n"));
            xml.push_str(&format!("{pad}</product>\n"));
        }
    }
}

fn write_polynomial_term_cpf3(xml: &mut String, term: &PolynomialTerm, indent: usize) {
    let pad = " ".repeat(indent);
    match term {
        PolynomialTerm::Integer(value) => {
            xml.push_str(&format!("{pad}<integer>{value}</integer>\n"));
        }
        PolynomialTerm::Variable(index) => {
            xml.push_str(&format!("{pad}<variable>{index}</variable>\n"));
        }
        PolynomialTerm::Product(coefficient, variable) => {
            xml.push_str(&format!("{pad}<product>\n"));
            xml.push_str(&format!("{pad}  <integer>{coefficient}</integer>\n"));
            xml.push_str(&format!("{pad}  <variable>{variable}</variable>\n"));
            xml.push_str(&format!("{pad}</product>\n"));
        }
        PolynomialTerm::QuadraticProduct(coefficient, left, right) => {
            xml.push_str(&format!("{pad}<product>\n"));
            xml.push_str(&format!("{pad}  <integer>{coefficient}</integer>\n"));
            xml.push_str(&format!("{pad}  <variable>{left}</variable>\n"));
            xml.push_str(&format!("{pad}  <variable>{right}</variable>\n"));
            xml.push_str(&format!("{pad}</product>\n"));
        }
    }
}

fn write_rational_polynomial_term_cpf3(
    xml: &mut String,
    term: &RationalPolynomialTerm,
    denominator: i64,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    match term {
        RationalPolynomialTerm::Number(value) => {
            write_rational_cpf3(xml, *value, denominator, indent)
        }
        RationalPolynomialTerm::Variable(index) => {
            xml.push_str(&format!("{pad}<variable>{index}</variable>\n"));
        }
        RationalPolynomialTerm::Product(coefficient, variable) => {
            xml.push_str(&format!("{pad}<product>\n"));
            write_rational_cpf3(xml, *coefficient, denominator, indent + 2);
            xml.push_str(&format!("{pad}  <variable>{variable}</variable>\n"));
            xml.push_str(&format!("{pad}</product>\n"));
        }
        RationalPolynomialTerm::QuadraticProduct(coefficient, left, right) => {
            xml.push_str(&format!("{pad}<product>\n"));
            write_rational_cpf3(xml, *coefficient, denominator, indent + 2);
            xml.push_str(&format!("{pad}  <variable>{left}</variable>\n"));
            xml.push_str(&format!("{pad}  <variable>{right}</variable>\n"));
            xml.push_str(&format!("{pad}</product>\n"));
        }
    }
}

fn write_rational_cpf3(xml: &mut String, numerator: i64, denominator: i64, indent: usize) {
    let pad = " ".repeat(indent);
    let divisor = gcd_i64(numerator, denominator);
    let numerator = numerator / divisor;
    let denominator = denominator / divisor;
    if denominator == 1 {
        xml.push_str(&format!("{pad}<integer>{numerator}</integer>\n"));
    } else {
        xml.push_str(&format!("{pad}<rational>\n"));
        xml.push_str(&format!("{pad}  <numerator>{numerator}</numerator>\n"));
        xml.push_str(&format!(
            "{pad}  <denominator>{denominator}</denominator>\n"
        ));
        xml.push_str(&format!("{pad}</rational>\n"));
    }
}

fn gcd_i64(left: i64, right: i64) -> i64 {
    let mut left = left.abs();
    let mut right = right.abs();
    while right != 0 {
        let next = left % right;
        left = right;
        right = next;
    }
    left.max(1)
}

fn write_trs_cpf3(xml: &mut String, trs: &Trs, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<trs>\n"));
    xml.push_str(&format!("{pad}  <rules>\n"));
    for rule in trs.rules() {
        xml.push_str(&format!("{pad}    <rule>\n"));
        write_term_cpf3(xml, rule.lhs(), indent + 6);
        write_term_cpf3(xml, rule.rhs(), indent + 6);
        xml.push_str(&format!("{pad}    </rule>\n"));
    }
    xml.push_str(&format!("{pad}  </rules>\n"));
    xml.push_str(&format!("{pad}</trs>\n"));
}

fn write_strategy_cpf3(xml: &mut String, strategy: RewriteStrategy, indent: usize) {
    write_dp_strategy_cpf3(xml, strategy, true, indent);
}

fn write_dp_strategy_cpf3(
    xml: &mut String,
    strategy: RewriteStrategy,
    normal_form_substitutions: bool,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    match strategy {
        RewriteStrategy::Full => return,
        RewriteStrategy::Innermost => {
            xml.push_str(&format!("{pad}<strategy>\n"));
            if normal_form_substitutions {
                xml.push_str(&format!("{pad}  <innermost><nfs>true</nfs></innermost>\n"));
            } else {
                xml.push_str(&format!("{pad}  <innermost><nfs>false</nfs></innermost>\n"));
            }
            xml.push_str(&format!("{pad}</strategy>\n"));
        }
        RewriteStrategy::Outermost => {
            xml.push_str(&format!("{pad}<strategy>\n"));
            xml.push_str(&format!("{pad}  <outermost/>\n"));
            xml.push_str(&format!("{pad}</strategy>\n"));
        }
    }
}

fn write_empty_q_innermost_lhss_strategy_cpf3(
    xml: &mut String,
    normal_form_substitutions: bool,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<strategy>\n"));
    xml.push_str(&format!("{pad}  <innermostLhss>\n"));
    xml.push_str(&format!(
        "{pad}    <nfs>{}</nfs>\n",
        if normal_form_substitutions {
            "true"
        } else {
            "false"
        }
    ));
    xml.push_str(&format!("{pad}  </innermostLhss>\n"));
    xml.push_str(&format!("{pad}</strategy>\n"));
}

fn write_context_sensitive_strategy_cpf3(xml: &mut String, csr: &CsrTrs, indent: usize) {
    write_context_sensitive_strategy_with_frozen_symbol_cpf3(xml, csr, None, false, indent);
}

fn write_context_sensitive_strategy_with_frozen_symbol_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    frozen_symbol: Option<(&Symbol, usize)>,
    include_marked_symbols: bool,
    indent: usize,
) {
    write_context_sensitive_strategy_with_extra_symbol_cpf3(
        xml,
        csr,
        frozen_symbol.map(|(symbol, arity)| (symbol, arity, false)),
        include_marked_symbols,
        indent,
    );
}

fn write_context_sensitive_strategy_with_extra_symbol_cpf3(
    xml: &mut String,
    csr: &CsrTrs,
    extra_symbol: Option<(&Symbol, usize, bool)>,
    include_marked_symbols: bool,
    indent: usize,
) {
    let pad = " ".repeat(indent);
    let arities = csr.trs().arities();
    let empty_positions = BTreeSet::new();
    xml.push_str(&format!("{pad}<strategy>\n"));
    xml.push_str(&format!("{pad}  <contextSensitive>\n"));
    for (symbol, arity) in arities {
        let positions = csr
            .replacement_map()
            .allowed_positions(&symbol)
            .unwrap_or(&empty_positions);
        xml.push_str(&format!("{pad}    <replacementMapEntry>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
        for position in positions {
            xml.push_str(&format!(
                "{pad}      <position>{}</position>\n",
                position + 1
            ));
        }
        xml.push_str(&format!("{pad}    </replacementMapEntry>\n"));
        if include_marked_symbols {
            xml.push_str(&format!("{pad}    <replacementMapEntry>\n"));
            write_symbol_cpf3(xml, &format!("{symbol}#"), indent + 6);
            xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
            for position in positions {
                xml.push_str(&format!(
                    "{pad}      <position>{}</position>\n",
                    position + 1
                ));
            }
            xml.push_str(&format!("{pad}    </replacementMapEntry>\n"));
        }
    }
    if let Some((symbol, arity, argument_active)) = extra_symbol {
        xml.push_str(&format!("{pad}    <replacementMapEntry>\n"));
        write_symbol_cpf3(xml, symbol.as_str(), indent + 6);
        xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
        if argument_active {
            xml.push_str(&format!("{pad}      <position>1</position>\n"));
        }
        xml.push_str(&format!("{pad}    </replacementMapEntry>\n"));
        if include_marked_symbols {
            xml.push_str(&format!("{pad}    <replacementMapEntry>\n"));
            write_symbol_cpf3(xml, &format!("{symbol}#"), indent + 6);
            xml.push_str(&format!("{pad}      <arity>{arity}</arity>\n"));
            if argument_active {
                xml.push_str(&format!("{pad}      <position>1</position>\n"));
            }
            xml.push_str(&format!("{pad}    </replacementMapEntry>\n"));
        }
    }
    xml.push_str(&format!("{pad}  </contextSensitive>\n"));
    xml.push_str(&format!("{pad}</strategy>\n"));
}

fn proof_uses_muterm_typed_replacement_map(proof: &Proof) -> bool {
    proof.steps().iter().any(|step| {
        matches!(
            step,
            ProofStep::ContextSensitiveDependencyPairProof {
                construction:
                    crate::proving::ContextSensitiveDependencyPairConstruction::MutermUnhiding,
                ..
            }
        )
    })
}

pub(crate) fn write_term_cpf3(xml: &mut String, term: &Term, indent: usize) {
    let pad = " ".repeat(indent);
    match term {
        Term::Var(variable) => {
            xml.push_str(&format!("{pad}<var>"));
            xml.push_str(&escape_xml(variable.as_str()));
            xml.push_str("</var>\n");
        }
        Term::App { symbol, args } => {
            xml.push_str(&format!("{pad}<funapp>\n"));
            write_symbol_cpf3(xml, symbol.as_str(), indent + 2);
            for arg in args {
                write_term_cpf3(xml, arg, indent + 2);
            }
            xml.push_str(&format!("{pad}</funapp>\n"));
        }
    }
}

pub(crate) fn write_symbol_cpf3(xml: &mut String, symbol: &str, indent: usize) {
    let pad = " ".repeat(indent);
    // Internally marked DP symbols use a trailing '#'.  The literal symbol
    // "#", however, occurs as an ordinary nullary symbol in TPDB inputs and
    // cannot denote a marked symbol because its putative base name is empty.
    // Keep it literal instead of emitting the malformed <sharp><name/></sharp>.
    if symbol == "#" {
        xml.push_str(&format!("{pad}<name>#</name>\n"));
    } else if let Some(unmarked) = symbol.strip_suffix('#') {
        xml.push_str(&format!("{pad}<sharp>\n"));
        write_symbol_cpf3(xml, unmarked, indent + 2);
        xml.push_str(&format!("{pad}</sharp>\n"));
    } else if let Some((base, labels)) = decode_root_label_symbol(symbol) {
        xml.push_str(&format!("{pad}<labeledSymbol>\n"));
        write_symbol_cpf3(xml, &base, indent + 2);
        xml.push_str(&format!("{pad}  <symbolLabel>\n"));
        for label in labels {
            write_symbol_cpf3(xml, &label, indent + 4);
        }
        xml.push_str(&format!("{pad}  </symbolLabel>\n"));
        xml.push_str(&format!("{pad}</labeledSymbol>\n"));
    } else if let Some((base, labels)) = decode_semantic_label_symbol(symbol) {
        xml.push_str(&format!("{pad}<labeledSymbol>\n"));
        write_symbol_cpf3(xml, &base, indent + 2);
        xml.push_str(&format!("{pad}  <numberLabel>\n"));
        for label in labels {
            xml.push_str(&format!("{pad}    <number>{label}</number>\n"));
        }
        xml.push_str(&format!("{pad}  </numberLabel>\n"));
        xml.push_str(&format!("{pad}</labeledSymbol>\n"));
    } else {
        xml.push_str(&format!("{pad}<name>"));
        xml.push_str(&escape_xml(symbol));
        xml.push_str("</name>\n");
    }
}

fn decode_semantic_label_symbol(symbol: &str) -> Option<(String, Vec<usize>)> {
    let rest = symbol.strip_prefix("__ferrum_sl__")?;
    let (hex, labels) = rest.split_once("__")?;
    let base = hex_decode(hex)?;
    let labels = if labels.is_empty() {
        Vec::new()
    } else {
        labels
            .split('_')
            .map(str::parse)
            .collect::<Result<Vec<_>, _>>()
            .ok()?
    };
    Some((base, labels))
}

fn decode_root_label_symbol(symbol: &str) -> Option<(String, Vec<String>)> {
    let rest = symbol.strip_prefix("__ferrum_rl__")?;
    let (base, labels) = rest.split_once("__")?;
    let base = hex_decode(base)?;
    let labels = if labels.is_empty() {
        Vec::new()
    } else {
        labels
            .split('_')
            .map(hex_decode)
            .collect::<Option<Vec<_>>>()?
    };
    Some((base, labels))
}

fn hex_decode(input: &str) -> Option<String> {
    if !input.len().is_multiple_of(2) {
        return None;
    }
    let mut bytes = Vec::with_capacity(input.len() / 2);
    let mut chars = input.as_bytes().chunks_exact(2);
    for pair in &mut chars {
        let high = hex_value(pair[0])?;
        let low = hex_value(pair[1])?;
        bytes.push((high << 4) | low);
    }
    String::from_utf8(bytes).ok()
}

fn hex_value(byte: u8) -> Option<u8> {
    match byte {
        b'0'..=b'9' => Some(byte - b'0'),
        b'a'..=b'f' => Some(byte - b'a' + 10),
        b'A'..=b'F' => Some(byte - b'A' + 10),
        _ => None,
    }
}

fn write_header(xml: &mut String) {
    xml.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n");
    xml.push_str("<?xml-stylesheet type=\"text/xsl\" href=\"cpfHTML.xsl\"?>\n");
    xml.push_str("<certificationProblem xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"cpf.xsd\">\n");
}

fn write_input(xml: &mut String, trs: &Trs) {
    xml.push_str("  <input>\n");
    xml.push_str("    <trsInput>\n");
    write_trs(xml, trs, 6);
    xml.push_str("    </trsInput>\n");
    xml.push_str("  </input>\n");
}

fn write_trs_termination_proof(
    xml: &mut String,
    _trs: &Trs,
    steps: &[ProofStep],
) -> Result<(), CpfError> {
    xml.push_str("    <trsTerminationProof>\n");
    match steps {
        [ProofStep::EmptySystem] => {
            xml.push_str("      <rIsEmpty/>\n");
        }
        [step] => return Err(CpfError::UnsupportedProofStep(format!("{step:?}"))),
        [] => return Err(CpfError::UnsupportedProofStep("empty proof".to_string())),
        steps => {
            return Err(CpfError::UnsupportedProofStep(format!(
                "multi-step proof with {} steps",
                steps.len()
            )));
        }
    }
    xml.push_str("    </trsTerminationProof>\n");
    Ok(())
}

fn write_trs(xml: &mut String, trs: &Trs, indent: usize) {
    let pad = " ".repeat(indent);
    xml.push_str(&format!("{pad}<trs>\n"));
    xml.push_str(&format!("{pad}  <rules>\n"));
    for rule in trs.rules() {
        xml.push_str(&format!("{pad}    <rule>\n"));
        xml.push_str(&format!("{pad}      <lhs>"));
        write_term(xml, rule.lhs());
        xml.push_str("</lhs>\n");
        xml.push_str(&format!("{pad}      <rhs>"));
        write_term(xml, rule.rhs());
        xml.push_str("</rhs>\n");
        xml.push_str(&format!("{pad}    </rule>\n"));
    }
    xml.push_str(&format!("{pad}  </rules>\n"));
    xml.push_str(&format!("{pad}</trs>\n"));
}

fn write_origin(xml: &mut String) {
    xml.push_str("  <origin>\n");
    xml.push_str("    <proofOrigin>\n");
    xml.push_str("      <tool>\n");
    xml.push_str("        <name>Ferrum</name>\n");
    xml.push_str(&format!(
        "        <version>{}</version>\n",
        env!("CARGO_PKG_VERSION")
    ));
    xml.push_str(
        "        <strategy>LLM-first proposal checking with trusted Rust validation</strategy>\n",
    );
    xml.push_str("      </tool>\n");
    xml.push_str("    </proofOrigin>\n");
    xml.push_str("    <inputOrigin/>\n");
    xml.push_str("  </origin>\n");
}

fn write_term(xml: &mut String, term: &Term) {
    match term {
        Term::Var(variable) => {
            xml.push_str("<var>");
            xml.push_str(&escape_xml(variable.as_str()));
            xml.push_str("</var>");
        }
        Term::App { symbol, args } => {
            xml.push_str("<funapp><name>");
            xml.push_str(&escape_xml(symbol.as_str()));
            xml.push_str("</name>");
            for arg in args {
                xml.push_str("<arg>");
                write_term(xml, arg);
                xml.push_str("</arg>");
            }
            xml.push_str("</funapp>");
        }
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn gm04_source_map_preserves_source_positions_and_freezes_fresh_u() {
        // Serialization regression, not a claim that these dummy child proofs
        // prove the nonempty source. Full checked regression artifacts are
        // recorded in docs/innermost-parameter-only-replay.md.
        let trs = Trs::new(None, BTreeSet::new(), vec![RewriteRule::new(
            Term::app("source", vec![Term::app("c", vec![])]),
            Term::app("c", vec![]))]);
        let csr = CsrTrs::full(trs.clone());
        let fresh = fresh_unhiding_symbol(csr.trs());
        let proof = Proof::terminating(vec![ProofStep::Gm04InverseContextSensitive {
            source_signature: trs.arities(),
            source_replacement_map: csr.replacement_map().clone(),
            source_csr: csr,
            active_symbol: Symbol::new("run"), mark_symbol: Symbol::new("done"),
            proper_symbol: Symbol::new("scan"), ok_symbol: Symbol::new("ready"),
            top_symbol: Symbol::new("wrap"), top_sharp_symbol: Symbol::new("wrap#"),
            transformed_proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
            source_proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let mut xml = String::new();
        write_trs_termination_proof_cpf3(&mut xml, &trs, &proof, 0).unwrap();
        let doc = roxmltree::Document::parse(&xml).unwrap();
        let map = doc.descendants().find(|n| n.has_tag_name("sourceReplacementMap")).unwrap();
        let entry = |name: &str| map.descendants().find(|n|
            n.has_tag_name("replacementMapEntry") && n.children().any(|c|
                c.has_tag_name("name") && c.text() == Some(name))).unwrap();
        assert!(!entry(fresh.as_str()).children().any(|n| n.has_tag_name("position")));
        assert!(entry("source").children().any(|n| n.has_tag_name("position") && n.text() == Some("1")));
    }

    #[test]
    fn local_ceta_standalone_csr_dp_checks_map_and_minimality() {
        let x = Term::var("x");
        let a = Term::app("a", vec![]);
        let b = Term::app("b", vec![]);
        let csr = CsrTrs::new(Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![
            RewriteRule::new(Term::app("f", vec![x.clone(), x.clone()]),
                Term::app("f", vec![a.clone(), b.clone()])),
            RewriteRule::new(b.clone(), a.clone()),
        ]), ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::from([0])),
            (Symbol::new("a"), BTreeSet::new()), (Symbol::new("b"), BTreeSet::new()),
        ]))).unwrap();
        let pair = DependencyPair::new(Term::app("f#", vec![x.clone(), x]),
            Term::app("f#", vec![a, b]), 0);
        let state = crate::proving::DpProblemState::csr_materialized_from_parts(
            &csr, vec![pair.clone()], vec![], None, true, "improved", "context-sensitive",
            false, DpOptions::default()).unwrap();
        let component = DpComponentProof {
            pairs: vec![pair], usable_rules: vec![], interpretation: None, backend: None,
            usable_rules_processor: None, innermost_lhss_processor: None,
            reductions: vec![], final_acyclic_components: vec![], proof_tree: None, proved: false,
        };
        let proof = DependencyPairProof {
            initial_pairs: 1, components: 1, removed_pairs: 1, usable_rules: 0,
            smt_attempted: false, smt_solved: false, strategy: RewriteStrategy::Full,
            pairs: state.pairs.clone(), component_proofs: vec![component],
        };
        let xml = write_cpf4_csr_dp_termination_state(&state, &proof).unwrap();
        assert_ceta_csr_certifies_cpf4(xml.clone(), "standalone-csr-graph-frozen");
        // Enabling the formerly frozen second argument creates a genuine cycle.
        let unfrozen = xml.replace("<position>1</position>", "<position>1</position><position>2</position>");
        assert_ne!(unfrozen, xml);
        assert_ceta_csr_rejects_cpf4(unfrozen, "standalone-csr-graph-unfrozen");
        let nonminimal = xml.replace("<minimal>true</minimal>", "<minimal>false</minimal>");
        assert_ne!(nonminimal, xml);
        // This graph proof does not use minimality; the nonminimal entry now
        // checks that stronger obligation rather than rejecting it by format.
        assert_ceta_csr_certifies_cpf4(nonminimal, "standalone-csr-graph-nonminimal");
        let defined_u = xml.replace("<name>__CSR_U0</name>", "<name>f</name>");
        assert_ne!(defined_u, xml);
        assert_ceta_csr_rejects_cpf4(defined_u, "standalone-csr-graph-defined-u");
        let sharp_u = replace_xml_section(&xml, "unhidingSymbol",
            "<unhidingSymbol><sharp><name>u</name></sharp></unhidingSymbol>");
        assert_ceta_csr_rejects_cpf4(sharp_u, "standalone-csr-graph-sharp-u");
        let legacy = xml.replace("csrImprovedDpInput", "dpInput");
        assert_ceta_csr_rejects_cpf4(legacy, "standalone-csr-no-ordinary-coercion");
    }

    #[test]
    fn standalone_csr_dp_export_is_typed_and_rejects_context_loss() {
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let csr = CsrTrs::full(Trs::new(None, BTreeSet::new(), vec![rule.clone()]))
            .with_frozen_auxiliary_symbol(Symbol::new("renamed_auxiliary"));
        let state = crate::proving::DpProblemState::csr_materialized_from_parts(
            &csr, vec![], vec![], Some(vec![]), true, "improved", "context-sensitive",
            false, DpOptions::default()).unwrap();
        let proof = crate::proving::complete_dependency_pair_probe(&state, DpProofTree::Empty);
        let xml = write_cpf4_csr_dp_termination_state(&state, &proof).unwrap();
        assert!(xml.contains("<csrImprovedDpInput>"));
        assert!(xml.contains("<csrImprovedDpProof>"));
        assert!(!xml.contains("<dpInput>"));
        assert!(!xml.contains("<dpProof>"));
        assert!(xml.contains("<unhidingSymbol>\n        <name>renamed_auxiliary</name>"));
        let doc = roxmltree::Document::parse(&xml).unwrap();
        let input = doc.descendants().find(|n| n.has_tag_name("csrImprovedDpInput")).unwrap();
        let rules = input.children().find(|n| n.has_tag_name("trs")).unwrap();
        assert!(!rules.descendants().any(|n| n.has_tag_name("rule")), "active R must stay empty");
        let marked_f = input.descendants().find(|n| n.has_tag_name("replacementMapEntry")
            && n.children().any(|c| c.has_tag_name("sharp")
                && c.descendants().any(|s| s.has_tag_name("name") && s.text() == Some("f"))))
            .expect("the sharp extension must survive rule deletion");
        assert_eq!(marked_f.children().find(|n| n.has_tag_name("position")).and_then(|n| n.text()), Some("1"));
        let mut changed = state.clone();
        changed.stats.minimal = false;
        let nonminimal = write_cpf4_csr_dp_termination_state(&changed, &proof).unwrap();
        assert!(nonminimal.contains("<minimal>false</minimal>"));
        changed = state.clone();
        changed.innermost_lhss = Some(vec![rule.lhs().clone()]);
        assert!(write_cpf4_csr_dp_termination_state(&changed, &proof).is_err());
        changed = state.clone();
        changed.stats.normal_form_substitutions = true;
        assert!(write_cpf4_csr_dp_termination_state(&changed, &proof).is_err());
        changed = state.clone();
        changed.stats.strict_rules = vec![rule];
        assert!(write_cpf4_csr_dp_termination_state(&changed, &proof).is_err());
        assert!(write_cpf3_dp_termination_state(&state, &proof).is_err());
    }

    #[test]
    fn standalone_semantic_csr_export_retains_chain_context() {
        let csr = CsrTrs::full(Trs::new(None, BTreeSet::new(), vec![
            RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x")),
        ]));
        let mut state = crate::proving::DpProblemState::csr_materialized_from_parts(
            &csr, vec![], vec![], Some(vec![]), false, "improved", "context-sensitive",
            false, DpOptions::default()).unwrap().restore_semantic_csr_continuation(true);
        let proof = crate::proving::complete_dependency_pair_probe(&state, DpProofTree::Empty);
        let xml = write_cpf4_csr_dp_termination_state(&state, &proof).unwrap();
        assert!(xml.contains("<csrImprovedDpInput>"));
        assert!(xml.contains("<minimal>false</minimal>"));
        assert!(xml.contains("<position>1</position>"));
        assert!(!xml.contains("<dpInput>"));
        assert_ceta_csr_certifies_cpf4(xml, "standalone-semantic-csr-empty");
        assert!(state.stats.semantic_csr_context.is_some());
        assert!(write_cpf3_dp_termination_state(&state, &proof).is_err());
        state.stats.minimal = true;
        assert!(write_cpf4_csr_dp_termination_state(&state, &proof).is_err());
        state.stats.minimal = false;
        state.innermost_lhss = Some(vec![Term::var("x")]);
        assert!(write_cpf4_csr_dp_termination_state(&state, &proof).is_err());
        state.innermost_lhss = None;
        state.stats.normal_form_substitutions = true;
        assert!(write_cpf4_csr_dp_termination_state(&state, &proof).is_err());
    }

    #[test]
    fn local_ceta_semantic_csr_standalone_polynomial_and_cycle_mutation() {
        use crate::proving::{DpProblemState, DpStrategy, solve_dp_state_with_strategy};
        let trs = Trs::new(None, BTreeSet::new(), vec![]);
        let lhs = Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]);
        let pair = DependencyPair::new_for_test(lhs.clone(), Term::app("f#", vec![Term::var("x")]));
        let state = DpProblemState::csr_materialized_from_parts(
            &CsrTrs::full(trs), vec![pair], vec![], Some(vec![]), false,
            "improved", "context-sensitive", false, DpOptions::default())
            .unwrap().restore_semantic_csr_continuation(true);
        let strategy = DpStrategy::parse("poly(max-constant=2,max-coefficient=2,max-symbols=4,max-arity=1)").unwrap();
        let proof = solve_dp_state_with_strategy(&state.trs, state.pairs.clone(),
            &state.options, &strategy,
            Some(std::time::Instant::now() + std::time::Duration::from_secs(10)))
            .expect("native polynomial descent");
        let xml = write_cpf4_csr_dp_termination_state(&state, &proof).unwrap();
        assert_ceta_csr_certifies_cpf4(xml, "semantic-csr-native-polynomial");
        let mut cyclic = state.clone();
        cyclic.pairs = vec![DependencyPair::new_for_test(lhs.clone(), lhs)];
        let invalid = write_cpf4_csr_dp_termination_state(&cyclic, &proof).unwrap();
        assert_ceta_csr_rejects_cpf4(invalid, "semantic-csr-cycle-mutation");
    }

    #[test]
    fn standalone_dp_export_preserves_active_rules_q_and_minimality() {
        use super::*;
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let trs = Trs::new(None, Default::default(), vec![rule.clone()]);
        let mut state = crate::proving::DpProblemState::ordinary(
            trs, vec![], crate::proving::DpOptions::default(),
        );
        state.stats.active_rules = Some(vec![]);
        state.stats.minimal = false;
        state.stats.normal_form_substitutions = true;
        state.innermost_lhss = Some(vec![rule.lhs().clone()]);
        let proof = crate::proving::complete_dependency_pair_probe(&state, crate::proving::DpProofTree::Empty);
        let xml = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        let crate::parsing::CpfInputProblem::Dp { trs, minimal, innermost_lhss,
            normal_form_substitutions, .. } = crate::parsing::parse_cpf_input(None, &xml).unwrap()
        else { panic!("expected ordinary DP input") };
        assert!(trs.rules().is_empty());
        assert!(!minimal);
        assert!(normal_form_substitutions);
        assert_eq!(innermost_lhss, state.innermost_lhss);
        state.stats.strict_rules.push(rule);
        let relative = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        assert!(relative.contains("<relativeDpInput>"));
        assert!(relative.contains("<strictRules>"));
        assert!(relative.contains("<relativeDpProof>"));
        let crate::parsing::CpfInputProblem::Dp { strict_rules, .. } =
            crate::parsing::parse_cpf_input(None, &relative).unwrap()
        else { panic!("expected a relative DP input") };
        assert_eq!(strict_rules, state.stats.strict_rules);
    }

    #[test]
    fn local_ceta_native_wpo_search() {
        use crate::proving::{DpProblemState, DpStrategy, solve_dp_state_with_strategy};
        let x = Term::var("x");
        let unary = |s: &str, t: Term| Term::app(s, vec![t]);
        let state = DpProblemState::ordinary(Trs::new(None, Default::default(), vec![
            RewriteRule::new(unary("mark", unary("dbl", x.clone())), unary("active", unary("mark", x.clone()))),
        ]), vec![DependencyPair::new_for_test(unary("top", unary("s", x.clone())),
            unary("top", unary("mark", x)))], DpOptions::default());
        let strategy = DpStrategy::parse("wpo-max(max-constant=1,max-coefficient=1,max-symbols=8,max-arity=2,alternatives=1)").unwrap();
        let proof = solve_dp_state_with_strategy(&state.trs, state.pairs.clone(), &state.options,
            &strategy, Some(std::time::Instant::now() + std::time::Duration::from_secs(10)))
            .expect("native WPO must synthesize a proof");
        let xml = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        assert!(xml.contains("<weightedPathOrder>"));
        assert_ceta_csr_certifies_cpf4(xml, "native-wpo");
    }

    #[test]
    fn local_ceta_native_rational_quadratic_search() {
        use crate::proving::{DpProblemState, DpStrategy, solve_dp_state_with_strategy};
        let state = DpProblemState::ordinary(Trs::new(None, Default::default(), vec![]),
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]))], DpOptions::default());
        let strategy = DpStrategy::parse(
            "rat-quadratic-poly(max-constant=4,max-coefficient=4,max-symbols=8,max-arity=2,denominator=4,delta-denominator=4,solver=z3,coefficients=0+2+4,quadratic-terms=1,quadratic-shape=multilinear)").unwrap();
        let proof = solve_dp_state_with_strategy(&state.trs, state.pairs.clone(),
            &state.options, &strategy,
            Some(std::time::Instant::now() + std::time::Duration::from_secs(10)))
            .expect("expected native quadratic descent");
        let xml = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        assert_ceta_csr_certifies_cpf4(xml, "native-rational-quadratic");
    }

    #[test]
    fn local_ceta_standalone_muterm_checks_minimality_and_unhiding_rules() {
        let x = Term::var("x");
        let csr = CsrTrs::new(
            Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![
                RewriteRule::new(Term::app("f", vec![x.clone()]), x),
            ]),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
            ])),
        ).unwrap();
        let state = crate::proving::DpProblemState::csr_materialized_from_parts(
            &csr, vec![], vec![], None, true, "muterm-unhiding", "ordinary",
            false, DpOptions::default(),
        ).unwrap();
        let proof = crate::proving::complete_dependency_pair_probe(
            &state, crate::proving::DpProofTree::Empty,
        );
        let xml = write_cpf4_muterm_typed_dp_problem(&csr, &[], &proof).unwrap();
        assert_ceta_csr_certifies_cpf4(xml.clone(), "standalone-muterm-empty");
        let nonminimal = xml.replace("<minimal>true</minimal>", "<minimal>false</minimal>");
        assert_ceta_csr_rejects_cpf4(nonminimal, "standalone-muterm-nonminimal");
        // An extraneous bridge is not the exact unhiding closure, even when P is empty.
        let extra = "<rule><lhs><var>x</var></lhs><rhs><var>x</var></rhs></rule>";
        let mut bad_bridge = xml.clone();
        let bridge_start = bad_bridge.find("<unhidingRules>").unwrap();
        let rules_start = bridge_start + bad_bridge[bridge_start..].find("<rules>").unwrap()
            + "<rules>".len();
        bad_bridge.insert_str(rules_start, extra);
        assert_ne!(bad_bridge, xml);
        assert_ceta_csr_rejects_cpf4(bad_bridge, "standalone-muterm-extra-bridge");
    }

    #[test]
    fn standalone_muterm_cannot_forget_collapsing_unhiding_obligation() {
        let x = Term::var("x");
        let csr = CsrTrs::new(
            Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![
                RewriteRule::new(Term::app("f", vec![x.clone()]), x.clone()),
            ]),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
            ])),
        ).unwrap();
        let pair = DependencyPair::new(Term::app("f#", vec![x.clone()]), x, 0);
        let state = crate::proving::DpProblemState::csr_materialized_from_parts(
            &csr, vec![pair], vec![], None, true, "muterm-unhiding", "ordinary",
            false, DpOptions::default(),
        ).unwrap();
        let proof = crate::proving::complete_dependency_pair_probe(
            &state, crate::proving::DpProofTree::Empty,
        );
        let xml = write_cpf4_csr_dp_termination_state(&state, &proof).unwrap();
        assert!(xml.contains("<csrMutermTypedDpInput>"));
        assert!(xml.contains("<unhidingRules>"));
        assert!(xml.contains("<csrMutermTypedDpProof>"));
        assert!(!xml.contains("<csrImprovedDpInput>"));
        let mut nonminimal = state.clone();
        nonminimal.stats.minimal = false;
        let error = write_cpf4_csr_dp_termination_state(&nonminimal, &proof).unwrap_err();
        assert!(error.to_string().contains("source-relative local obligation"));
        let mut with_q = state.clone();
        with_q.innermost_lhss = Some(vec![Term::app("f", vec![Term::var("x")])]);
        assert!(write_cpf4_csr_dp_termination_state(&with_q, &proof).is_err());
        let mut changed_rules = state.clone();
        changed_rules.stats.active_rules = Some(vec![]);
        assert!(write_cpf4_csr_dp_termination_state(&changed_rules, &proof).is_err());
        let mut component = proof.component_proofs[0].clone();
        component.proved = false;
        component.proof_tree = None;
        let graph = crate::proving::complete_dependency_pair_probe(
            &state, crate::proving::DpProofTree::DepGraph { components: vec![component] },
        );
        let graph_xml = write_cpf4_csr_dp_termination_state(&state, &graph).unwrap();
        assert_eq!(graph_xml.matches("<depGraphProc>").count(), 1);
    }

    #[test]
    fn local_ceta_relative_dp_empty_preserves_weak_pairs_and_strict_rules() {
        let weak = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let rule = RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![]));
        let mut state = crate::proving::DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![rule.clone()]),
            vec![weak.clone()], DpOptions::default(),
        );
        state.stats.weak_pairs = vec![weak];
        let proof = crate::proving::complete_dependency_pair_probe(
            &state, crate::proving::DpProofTree::Empty,
        );
        let xml = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        assert!(xml.contains("<weakDps>"));
        let crate::parsing::CpfInputProblem::Dp { pairs, weak_pairs, .. } =
            crate::parsing::parse_cpf_input(None, &xml).unwrap()
        else { panic!("expected a relative DP input") };
        assert_eq!(pairs.len(), 1);
        assert_eq!(weak_pairs.len(), 1);
        assert_eq!(pairs, weak_pairs);
        // Infinite weak rewriting is allowed when no strict step remains.
        assert_ceta_csr_certifies_cpf4(xml, "standalone-relative-weak-only");
        state.stats.strict_rules = vec![rule];
        let xml = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        let crate::parsing::CpfInputProblem::Dp { trs, strict_rules, .. } =
            crate::parsing::parse_cpf_input(None, &xml).unwrap()
        else { panic!("expected a relative DP input") };
        assert_eq!(trs.rules(), state.trs.rules());
        assert_eq!(strict_rules, state.stats.strict_rules);
        let document = roxmltree::Document::parse(&xml).unwrap();
        let input = document.descendants().find(|n| n.has_tag_name("relativeDpInput")).unwrap();
        let weak_trs = input.children().find(|n| n.has_tag_name("trs")).unwrap();
        assert_eq!(weak_trs.descendants().filter(|n| n.has_tag_name("rule")).count(), 0);
        let strict = input.children().find(|n| n.has_tag_name("strictRules")).unwrap();
        let duplicate = xml[strict.range()].replace("strictRules", "trs");
        let mut overlapping = xml.clone();
        overlapping.replace_range(weak_trs.range(), &duplicate);
        assert!(crate::parsing::parse_cpf_input(None, &overlapping).is_err(),
            "a combined runtime set cannot silently collapse distinct overlapping roles");
        // The very same loop as a strict rule makes the empty proof invalid.
        assert_ceta_csr_rejects_cpf4(xml, "standalone-relative-strict-loop");
    }

    use std::collections::{BTreeMap, BTreeSet};
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::process::Command;

    use crate::core::{
        CsrTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable,
    };
    use crate::proving::{
        ContextSensitiveDependencyPairConstruction, DependencyPair, DependencyPairProof,
        DpComponentProof, DpNarrowingStep, DpOptions, DpPathOrderKind, DpProofTree,
        DpReductionPairProof, DpRemovalProof, DpSearchBackend, DpSizeChangeEdge, DpSizeChangeGraph,
        DpStrategy, DpStrategyProcessor, LoopProof, LoopRewriteStep, NonterminationProof,
        ProblemState, Proof, ProofStep, ProveOptions, ProveStrategy, TreeAutomatonTransition,
        probe_dp_atom, prove_context_sensitive,
        solve_csr_dependency_pairs_with_kind_and_atomic_policy, solve_dependency_pairs,
        solve_dependency_pairs_with_strategy, solve_dp_state_with_strategy,
        solve_improved_csr_dependency_pairs_with_strategy,
    };

    use super::*;

    #[test]
    fn standalone_dp_nontermination_retains_minimality_q_and_nfs() {
        let mut state = crate::proving::DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![]), vec![], DpOptions::default());
        state.stats.minimal = false;
        let proof = DpNonterminationProof::ExactLoopXml("<loop></loop>".into());
        let xml = write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
        assert!(xml.contains("<minimal>false</minimal>"));
        assert!(!xml.contains("ferrumDpStateContext"));
        state.innermost_lhss = Some(vec![Term::app("q", vec![])]);
        state.stats.normal_form_substitutions = true;
        let xml = write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
        let crate::parsing::CpfInputProblem::Dp { minimal, normal_form_substitutions, innermost_lhss, .. } =
            crate::parsing::parse_cpf_input(None, &xml).unwrap() else { panic!() };
        assert!(!minimal);
        assert!(normal_form_substitutions);
        assert_eq!(innermost_lhss, state.innermost_lhss);
    }

    #[test]
    fn standalone_dp_nontermination_ceta_enforces_explicit_q() {
        let term = Term::app("f#", vec![Term::app("a", vec![])]);
        let pair = DependencyPair::new_for_test(term.clone(), term);
        let mut state = crate::proving::DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![]), vec![pair], DpOptions::default());
        state.stats.minimal = false;
        let term = "<funapp><sharp><name>f</name></sharp><funapp><name>a</name></funapp></funapp>";
        let proof = DpNonterminationProof::ExactLoopXml(format!(
            "<loop><rewriteSequence><startTerm>{term}</startTerm><rewriteStep><positionInTerm/><rule>{term}{term}</rule>{term}</rewriteStep></rewriteSequence><substitution/><box/></loop>"));
        assert_ceta_csr_certifies_cpf4(write_cpf3_dp_nontermination_state(&state, &proof).unwrap(), "standalone-no-empty-q");
        state.innermost_lhss = Some(vec![Term::app("a", vec![])]);
        assert_ceta_csr_rejects_cpf4(write_cpf3_dp_nontermination_state(&state, &proof).unwrap(), "standalone-no-blocking-q");
    }

    #[test]
    fn csr_exact_ordinary_transform_keeps_the_ordinary_dp_boundary() {
        let proof = DpProofTree::TransformationExact {
            processor_tag: "forwardInstantiationProc".to_string(),
            payload_xml: "<rule/>\n<instantiations><rules/></instantiations>".to_string(),
            proof: Box::new(DpProofTree::Empty),
        };
        let mut cpf = String::new();

        write_csr_dp_proof_tree_cpf3(&mut cpf, &proof, RewriteStrategy::Full, &[], None, 0);

        assert!(cpf.starts_with("<ordinaryDpProof>\n  <dpProof>\n"), "{cpf}");
        assert!(cpf.contains("<forwardInstantiationProc>"), "{cpf}");
        assert!(cpf.ends_with("  </dpProof>\n</ordinaryDpProof>\n"), "{cpf}");
    }

    #[test]
    fn relative_adp_dependency_graph_is_emitted_as_a_first_class_proof_node() {
        use crate::proving::{
            AnnotatedDependencyPair, RelativeAdpGraphChild, RelativeAdpOrigin, RelativeAdpProblem,
            RelativeAdpProofTree,
        };

        let pair = AnnotatedDependencyPair {
            lhs: Term::app("f", vec![Term::var("x")]),
            rhs: Term::app("f", vec![Term::var("x")]),
            annotations: BTreeSet::from([Vec::new()]),
            origin: RelativeAdpOrigin::Main,
            source_rule: 0,
        };
        let parent = RelativeAdpProblem {
            main: vec![pair.clone()],
            base: Vec::new(),
        };
        let child_problem = RelativeAdpProblem {
            main: Vec::new(),
            base: vec![pair.clone()],
        };
        let proof = RelativeAdpProofTree::DependencyGraph {
            children: vec![(
                RelativeAdpGraphChild {
                    selected: vec![0],
                    candidate: vec![pair],
                    problem: child_problem,
                },
                Box::new(RelativeAdpProofTree::Empty),
            )],
        };
        let relative = RelativeTrs::new(Trs::new(None, BTreeSet::new(), Vec::new()), Vec::new());
        let mut xml = String::new();

        write_relative_adp_tree_cpf3(&mut xml, &relative, &parent, &proof, 0).unwrap();

        assert_eq!(xml.matches("<relativeAdpDependencyGraph>").count(), 1);
        assert_eq!(xml.matches("<relativeAdpTerminationProof>").count(), 2);
        assert!(xml.contains("<relativeAdpEmpty/>"));
    }

    #[test]
    fn relative_adp_com_reduction_pair_emits_custom_carrier_symbols() {
        use crate::proving::{RelativeAdpPolynomialStep, RelativeAdpProblem, RelativeAdpProofTree};

        let problem = RelativeAdpProblem {
            main: Vec::new(),
            base: Vec::new(),
        };
        let proof = RelativeAdpProofTree::Polynomial {
            step: RelativeAdpPolynomialStep {
                interpretations: vec![
                    ("f#".to_string(), 0, vec![1]),
                    ("__ferrum_adp_c0".to_string(), 0, Vec::new()),
                ],
                strict_main: vec![0],
                strict_base: vec![1],
            },
            residual: problem.clone(),
            proof: Box::new(RelativeAdpProofTree::Empty),
        };
        let relative = RelativeTrs::new(Trs::new(None, BTreeSet::new(), Vec::new()), Vec::new());
        let mut xml = String::new();

        write_relative_adp_tree_cpf3(&mut xml, &relative, &problem, &proof, 0).unwrap();

        assert!(xml.contains("<relativeAdpComReductionPair>"));
        assert!(xml.contains("<adpCom0/>"));
        assert!(xml.contains("<adpCom2/>"));
        assert!(xml.contains("<sharp>"));
        assert!(xml.contains("<mainIndices>"));
        assert!(xml.contains("<baseIndices>"));
    }

    #[test]
    fn relative_adp_derelatification_embeds_the_ordinary_dp_proof() {
        use crate::proving::{RelativeAdpProblem, RelativeAdpProofTree};

        let problem = RelativeAdpProblem {
            main: Vec::new(),
            base: Vec::new(),
        };
        let dp_proof = DependencyPairProof {
            initial_pairs: 0,
            components: 0,
            removed_pairs: 0,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: Vec::new(),
            component_proofs: Vec::new(),
        };
        let proof = RelativeAdpProofTree::Derelatify {
            transformed: problem.clone(),
            ordinary_pairs: Vec::new(),
            ordinary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        };
        let relative = RelativeTrs::new(Trs::new(None, BTreeSet::new(), Vec::new()), Vec::new());
        let mut xml = String::new();

        write_relative_adp_tree_cpf3(&mut xml, &relative, &problem, &proof, 0).unwrap();

        assert!(xml.contains("<relativeAdpDerelatification>"));
        assert!(xml.contains("<dpProof>"));
        assert!(xml.contains("<pIsEmpty/>"));
    }

    fn dp_residual_cpf(state: &ProblemState) -> String {
        let ProblemState::DependencyPairs(state) = state else {
            panic!("expected dependency-pair residual state");
        };
        crate::proving::dp_state_input_cpf(state)
    }

    #[test]
    fn standalone_dp_state_preserves_parent_trs_and_exact_active_rules() {
        let parent_rule = RewriteRule::new(Term::app("f", vec![]), Term::app("g", vec![]));
        let active_rule = RewriteRule::new(Term::app("g", vec![]), Term::app("a", vec![]));
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![parent_rule, active_rule.clone()],
        );
        let pair = DependencyPair::new_for_test(Term::app("f#", vec![]), Term::app("g#", vec![]));
        let input = write_dp_state_input_cpf3(&trs, &[pair], Some(&[active_rule]), true, true);
        assert!(input.contains("<usableRules>"));
        let parent = input
            .split("<dps>")
            .next()
            .expect("DP input contains its parent TRS");
        let active = input
            .split("<usableRules>")
            .nth(1)
            .expect("DP input contains its active rules");
        assert!(parent.contains("<name>f</name>"));
        assert!(parent.contains("<name>g</name>"));
        assert!(active.contains("<name>g</name>"));
        assert!(active.contains("<name>a</name>"));
        assert!(!active.contains("<name>f</name>"));
    }

    #[test]
    fn writes_cpf21_empty_system_certificate() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let proof = Proof::terminating(vec![ProofStep::EmptySystem]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf21).unwrap();
        assert!(cpf.contains("<cpfVersion>2.1</cpfVersion>"));
        assert!(cpf.contains("<trsTerminationProof>"));
        assert!(cpf.contains("<rIsEmpty/>"));
    }

    #[test]
    fn auto_uses_cpf3_for_ordinary_proofs() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let proof = Proof::terminating(vec![ProofStep::EmptySystem]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Auto).unwrap();

        assert!(cpf.contains("xsi:noNamespaceSchemaLocation=\"cpf3.xsd\""));
        assert!(cpf.contains("<cpfVersion>3.0</cpfVersion>"));
    }

    #[test]
    fn writes_dedicated_muterm_typed_boundary() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let auxiliary_rules = muterm_innermost_unhiding_rules(&csr);
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::MutermUnhiding,
            auxiliary_rules: auxiliary_rules.clone(),
            proof: Box::new(DependencyPairProof {
                initial_pairs: 0,
                components: 1,
                removed_pairs: 0,
                usable_rules: 0,
                smt_attempted: false,
                smt_solved: false,
                strategy: RewriteStrategy::Innermost,
                pairs: Vec::new(),
                component_proofs: vec![DpComponentProof {
                    pairs: Vec::new(),
                    usable_rules: Vec::new(),
                    interpretation: None,
                    backend: None,
                    usable_rules_processor: None,
                    innermost_lhss_processor: None,
                    reductions: Vec::new(),
                    final_acyclic_components: Vec::new(),
                    proof_tree: Some(Box::new(DpProofTree::SizeChange { graphs: Vec::new() })),
                    proved: true,
                }],
            }),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        let multi_step = Proof::terminating(vec![ProofStep::EmptySystem, proof.steps()[0].clone()]);
        assert!(proof_uses_muterm_typed_replacement_map(&multi_step));
        assert!(cpf.contains("<csrMutermTypedDependencyPairs>"));
        assert!(cpf.contains("<unhidingRules>"));
        assert!(!cpf.contains("<expandedExtendedBasicCsrProof>"));
        assert!(cpf.contains("<pIsEmpty/>"));
        assert!(cpf.contains("<sharp>"));
        assert!(cpf.contains("<name>diff</name>"));
        assert!(cpf.contains("<name>p</name>"));
        let input_strategy = cpf
            .split("</strategy>")
            .next()
            .expect("CPF contains its input strategy");
        assert_eq!(input_strategy.matches("<name>__CSR_U0</name>").count(), 2);
        assert_eq!(cpf.matches("<unhidingRules>").count(), 1);
        assert_eq!(auxiliary_rules.len(), 2);
    }

    #[test]
    fn writes_self_contained_expanded_muterm_boundary_for_exact_pairs() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let auxiliary_rules = muterm_innermost_unhiding_rules(&csr);
        let pairs = muterm_expanded_dependency_pairs(&csr);
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::MutermExpandedInnermost,
            auxiliary_rules,
            proof: Box::new(DependencyPairProof {
                initial_pairs: pairs.len(),
                components: 1,
                removed_pairs: pairs.len(),
                usable_rules: 0,
                smt_attempted: false,
                smt_solved: false,
                strategy: RewriteStrategy::Innermost,
                pairs: pairs.clone(),
                component_proofs: vec![DpComponentProof {
                    pairs,
                    usable_rules: Vec::new(),
                    interpretation: None,
                    backend: None,
                    usable_rules_processor: None,
                    innermost_lhss_processor: None,
                    reductions: Vec::new(),
                    final_acyclic_components: Vec::new(),
                    proof_tree: Some(Box::new(DpProofTree::SizeChange { graphs: Vec::new() })),
                    proved: true,
                }],
            }),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrMutermExpandedInnermostDependencyPairs>"));
        assert!(!cpf.contains("<csrMutermTypedDependencyPairs>"));
        assert!(!cpf.contains("<expandedExtendedBasicCsrProof>"));
        assert!(cpf.contains("<unhidingRules>"));
        assert!(cpf.contains("<csrDpProof>"));
    }

    #[test]
    fn dp_processor_probe_returns_residual_without_partial_proof() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            Vec::new(),
            RewriteStrategy::Full,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let residual_pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let pairs = vec![pair, residual_pair];
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::Subterm);
        let (proof, residuals) =
            probe_dp_atom(&trs, pairs.clone(), &options, &strategy, None).unwrap();
        assert_eq!(residuals.len(), 1);
        assert!(proof.is_none());
        let residual = dp_residual_cpf(&residuals[0]);
        assert!(residual.contains("<dpInput>"));
        assert!(!residual.contains("Assumption"));
    }

    #[test]
    fn ceta_certifies_relative_dp_split_with_weak_pairs() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            Vec::new(),
            RewriteStrategy::Full,
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("t", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]),
            ),
        ];
        let options = DpOptions::default();
        let strategy =
            DpStrategy::parse("pipeline(split; poly(max-constant=1,max-coefficient=1))").unwrap();
        let proof = solve_dp_state_with_strategy(&trs, pairs.clone(), &options, &strategy, None)
            .expect("relative split and both polynomial branches should close");
        let cpf = write_cpf3_dp_problem(&trs, &pairs, &proof);
        assert!(cpf.contains("<splitProc>"), "{cpf}");
        assert_ceta_certifies_cpf3(cpf, "ferrum-relative-dp-split");
    }

    #[test]
    fn ceta_certifies_absolute_size_change_on_each_relative_split() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            Vec::new(),
            RewriteStrategy::Full,
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("t", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]),
            ),
        ];
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("pipeline(split; size-change)").unwrap();
        let proof = solve_dp_state_with_strategy(&trs, pairs.clone(), &options, &strategy, None)
            .expect("absolute SCT should close both relative split branches");
        let cpf = write_cpf3_dp_problem(&trs, &pairs, &proof);
        assert!(cpf.contains("<splitProc>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 2, "{cpf}");
        assert_ceta_certifies_cpf3(cpf, "ferrum-absolute-dp-sct");
    }

    #[test]
    fn full_dp_transform_returns_empty_q_nfs_residual_without_fragment() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let selected = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let predecessor = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("a", vec![])]),
            Term::app("f#", vec![Term::app("a", vec![])]),
        );
        let pairs = vec![selected, predecessor];
        let strategy = DpStrategy::Processor(DpStrategyProcessor::Instantiation {
            max_per_pair: Some(1),
        });
        let options = DpOptions {
            max_narrowing_steps: 1,
            ..DpOptions::default()
        };
        let (proof, residuals) =
            probe_dp_atom(&trs, pairs.clone(), &options, &strategy, None).unwrap();
        assert_eq!(residuals.len(), 1);
        assert!(proof.is_none());
        let residual = dp_residual_cpf(&residuals[0]);
        assert!(residual.contains("<innermostLhss>"));
        assert!(residual.contains("<nfs>true</nfs>"));
    }

    #[test]
    fn local_ceta_certifies_rewriting_residual_with_nfs_context_change() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("h", vec![Term::app("a", vec![])]),
                Term::app("s", vec![Term::app("a", vec![])]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::app("a", vec![])])]),
            Term::app("f#", vec![Term::app("h", vec![Term::app("a", vec![])])]),
        );
        let pairs = vec![pair];
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::Rewriting {
            max_per_pair: Some(1),
        });
        let (proof, residuals) =
            probe_dp_atom(&trs, pairs.clone(), &options, &strategy, None).unwrap();
        assert_eq!(residuals.len(), 1);
        assert!(proof.is_none());
        let crate::parsing::CpfInputProblem::Dp {
            normal_form_substitutions,
            ..
        } = crate::parsing::parse_cpf_input(None, &dp_residual_cpf(&residuals[0]))
            .expect("parse rewriting residual")
        else {
            panic!("expected DP residual");
        };
        assert!(normal_form_substitutions);
    }

    #[test]
    fn local_ceta_certifies_rewriting_with_trivial_usable_rule_overlap() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let zero = Term::app("0", vec![]);
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("min", vec![zero.clone(), Term::var("y")]),
                    zero.clone(),
                ),
                RewriteRule::new(
                    Term::app("min", vec![Term::var("x"), zero.clone()]),
                    zero.clone(),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("min", vec![zero, Term::var("x")])]),
        );
        let pairs = vec![pair];
        let strategy = DpStrategy::parse(
            "pipeline(rewrite(per-pair=1); poly(max-constant=1,max-coefficient=1))",
        )
        .unwrap();
        let proof = solve_dp_state_with_strategy(
            &trs,
            pairs.clone(),
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("trivial critical pairs must not block certified rewriting");
        let cpf = write_cpf3_dp_problem(&trs, &pairs, &proof);
        assert!(cpf.contains("<rewritingProc>"), "{cpf}");
        assert_ceta_certifies_cpf3(cpf, "ferrum-trivial-overlap-dp-rewriting");
    }

    #[test]
    fn local_ceta_certifies_arctic_bottom_constants() {
        if !Path::new("../CeTA-CSR/ceta").exists() { return; }
        let bottom = i64::MIN;
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![]);
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        )];
        let strategy = DpStrategy::Processor(DpStrategyProcessor::ExactArcticMatrixInterpretation {
            integer_domain: false,
            interpretation: vec![
                ("f".into(), vec![bottom, bottom], vec![vec![vec![0, bottom], vec![bottom, 0]]]),
                ("s".into(), vec![bottom, bottom], vec![vec![vec![1, bottom], vec![bottom, 1]]]),
            ],
        });
        let proof = solve_dp_state_with_strategy(&trs, pairs.clone(), &DpOptions::default(), &strategy, None)
            .expect("positive variable coefficients suffice without affine constants");
        assert_ceta_certifies_cpf3(write_cpf3_dp_problem(&trs, &pairs, &proof), "ferrum-arctic-bottom-constants");
    }

    #[test]
    fn local_ceta_certifies_arctic_interpretation_dependent_usable_rules() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let neg_inf = i64::MIN;
        let scalar = |constant, coefficients: Vec<i64>| {
            (
                vec![constant],
                coefficients
                    .into_iter()
                    .map(|coefficient| vec![vec![coefficient]])
                    .collect::<Vec<_>>(),
            )
        };
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("s", vec![Term::app("g", vec![Term::var("x")])]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app(
                "f#",
                vec![Term::app(
                    "h",
                    vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
                )],
            ),
        );
        let pairs = vec![pair];
        let strategy =
            DpStrategy::Processor(DpStrategyProcessor::ExactArcticMatrixInterpretation {
                integer_domain: false,
                interpretation: vec![
                    {
                        let (constant, coefficients) = scalar(0, vec![0]);
                        ("f#".to_string(), constant, coefficients)
                    },
                    {
                        let (constant, coefficients) = scalar(1, vec![1]);
                        ("s".to_string(), constant, coefficients)
                    },
                    {
                        let (constant, coefficients) = scalar(0, vec![neg_inf, 0]);
                        ("h".to_string(), constant, coefficients)
                    },
                    {
                        let (constant, coefficients) = scalar(0, vec![neg_inf]);
                        ("g".to_string(), constant, coefficients)
                    },
                ],
            });
        let proof = solve_dp_state_with_strategy(
            &trs,
            pairs.clone(),
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("interpretation-dependent usable rules should close the pair");
        let cpf = write_cpf3_dp_problem(&trs, &pairs, &proof);
        assert!(cpf.contains("<redPairUrProc>"), "{cpf}");
        assert_ceta_certifies_cpf3(cpf, "ferrum-arctic-filtered-usable-rules");
    }

    #[test]
    fn cpf4_rejects_context_sensitive_switch_without_a_transformation_proof() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("mark", vec![Term::app("nil", vec![])]),
                Term::app("nil", vec![]),
            )],
        );
        let csr_rules = trs.rules().to_vec();
        let proof = Proof::terminating(vec![ProofStep::SwitchContextSensitive {
            replacement_map: ReplacementMap::new(BTreeMap::from([(
                Symbol::new("mark"),
                BTreeSet::from([0]),
            )])),
            csr_rules: csr_rules.clone(),
            proof: Box::new(Proof::terminating(vec![
                ProofStep::ContextSensitivePolynomialRuleRemoval {
                    interpretations: vec![
                        ("mark".to_string(), 1, vec![1]),
                        ("nil".to_string(), 0, Vec::new()),
                    ],
                    removed: csr_rules,
                    proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
                },
            ])),
        }]);
        let error = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap_err();
        assert!(
            error
                .to_string()
                .contains("refusing to replace the original CPF input"),
            "{error}"
        );
    }

    #[test]
    fn cpf4_writes_full_map_standalone_csr_empty_system() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let csr = CsrTrs::new(trs, ReplacementMap::new(BTreeMap::new())).unwrap();
        let proof = Proof::terminating(vec![ProofStep::EmptySystem]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<contextSensitive>"));
        assert!(cpf.contains("<csrTerminationProof>"));
        assert!(cpf.contains("<rIsEmpty/>"));
        assert!(write_cpf_csr(&csr, &proof, CpfMode::Cpf30).is_err());
    }

    #[test]
    fn cpf4_writes_rta08_collapsing_dps_with_global_first_redpair() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_rta08_collapsing.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::SatPolynomial {
            max_constant: 2,
            max_coefficient: 2,
            max_symbols: None,
            max_arity: None,
        });
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Rta08,
            &options,
            &strategy,
            None,
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();

        assert!(cpf.contains("<csrRta08DependencyPairs>"));
        assert!(cpf.contains("<redPairUrProc>"));
        assert!(cpf.contains("<pIsEmpty/>"));
        assert!(!cpf.contains("<depGraphProc>"));
        assert!(cpf.contains("<sharp>"));
        assert!(cpf.contains("<name>f</name>"));
    }

    #[test]
    fn cpf4_writes_restricted_csr_by_trs_reflection() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![("f".to_string(), 1, vec![1])],
            removed: csr.rules().to_vec(),
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<contextSensitive>"));
        assert!(cpf.contains("<csrTerminationProof>"));
        assert!(cpf.contains("<csrRuleRemoval>"));
        assert!(cpf.contains("<replacementMapEntry>"));
        assert!(cpf.contains("<arity>1</arity>"));
        assert!(!cpf.contains("<position>1</position>"));
    }

    #[test]
    fn trs_without_rules_matches_alpha_variant_removed_rules() {
        let rules = vec![
            RewriteRule::new(Term::app("f", vec![Term::var("X")]), Term::var("X")),
            RewriteRule::new(Term::app("g", vec![Term::var("Y")]), Term::var("Y")),
        ];
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("X"), Variable::new("Y")]),
            rules,
        );
        let removed = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x0")]),
            Term::var("x0"),
        )];
        let remaining = trs_without_rules(&trs, &removed);
        assert_eq!(remaining.rules().len(), 1);
        assert_eq!(
            remaining.rules()[0],
            RewriteRule::new(Term::app("g", vec![Term::var("Y")]), Term::var("Y"))
        );
    }

    #[test]
    fn cpf4_writes_context_preserving_csr_rule_removal_fragment() {
        let removed = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let residual = RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![removed.clone(), residual],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let proof = Proof::unknown(
            "residual CSR problem remains",
            vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
                interpretations: vec![("f".to_string(), 1, vec![1]), ("g".to_string(), 0, vec![1])],
                removed: vec![removed],
                proof: Box::new(Proof::unknown("residual CSR problem remains", Vec::new())),
            }],
        );
        let cpf = write_cpf_csr_fragment(&csr, &proof).unwrap();
        assert!(cpf.contains("<cpfVersion>4.0</cpfVersion>"));
        assert!(cpf.contains("<csrRuleRemoval>"));
        assert!(cpf.contains("<csrTerminationAssumption>"));
        assert!(cpf.contains("<replacementMapEntry>"));
        assert!(cpf.contains("<position>1</position>"));
    }

    #[test]
    fn local_ceta_rejects_minimal_context_sensitive_termination_assumption() {
        assert_local_ceta_rejects_csr_cpf(
            "ferrum-csr-ceta-assumption-probe",
            r#"<trsTerminationProof>
      <terminationAssumption>
        <trsInput>
          <trs><rules/></trs>
          <strategy><contextSensitive/></strategy>
        </trsInput>
      </terminationAssumption>
    </trsTerminationProof>"#,
            &[
                "undefined",
                "termination assumption",
                "unknown proof",
                "innermost (relative) TRS expected",
            ],
        );
    }

    #[test]
    fn local_ceta_certifies_full_map_csr_empty_system() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let csr = CsrTrs::new(trs, ReplacementMap::new(BTreeMap::new())).unwrap();
        let proof = Proof::terminating(vec![ProofStep::EmptySystem]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-full-csr-empty");
    }

    #[test]
    fn local_ceta_certifies_full_map_csr_trs_reflection() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let csr = CsrTrs::full(trs);
        let proof = Proof::terminating(vec![ProofStep::EmptySystem]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-full-csr-reflection");
    }

    #[test]
    fn local_ceta_certifies_full_map_csr_rule_removal() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::full(trs);
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![("f".to_string(), 1, vec![1])],
            removed: csr.rules().to_vec(),
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-full-csr-rule-removal");
    }

    #[test]
    fn local_ceta_certifies_multi_step_csr_rule_removal() {
        let rule_f = RewriteRule::new(Term::app("f", vec![]), Term::app("a", vec![]));
        let rule_g = RewriteRule::new(Term::app("g", vec![]), Term::app("a", vec![]));
        let trs = Trs::new(None, BTreeSet::new(), vec![rule_f.clone(), rule_g.clone()]);
        let csr = CsrTrs::full(trs);
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![
                ("a".to_string(), 0, Vec::new()),
                ("f".to_string(), 1, Vec::new()),
                ("g".to_string(), 0, Vec::new()),
            ],
            removed: vec![rule_f],
            proof: Box::new(Proof::terminating(vec![
                ProofStep::ContextSensitivePolynomialRuleRemoval {
                    interpretations: vec![
                        ("a".to_string(), 0, Vec::new()),
                        ("g".to_string(), 1, Vec::new()),
                    ],
                    removed: vec![rule_g],
                    proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
                },
            ])),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert_eq!(cpf.matches("<csrRuleRemoval>").count(), 2);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-multi-step-csr-rule-removal");
    }

    #[test]
    fn local_ceta_certifies_mu_only_csr_polynomial_rule_removal() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("a", vec![])]),
                Term::app("b", vec![]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![
                ("a".to_string(), 0, Vec::new()),
                ("b".to_string(), 0, Vec::new()),
                ("f".to_string(), 1, vec![0]),
            ],
            removed: csr.rules().to_vec(),
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-mu-only-csr-polynomial");
    }

    #[test]
    fn local_ceta_certifies_true_mu_only_csr_polynomial_rule_removal() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("a", vec![])]),
                Term::app("g", vec![Term::app("f", vec![Term::app("b", vec![])])]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![
                ("a".to_string(), 0, Vec::new()),
                ("b".to_string(), 1, Vec::new()),
                ("f".to_string(), 1, vec![0]),
                ("g".to_string(), 0, vec![0]),
            ],
            removed: csr.rules().to_vec(),
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-true-mu-only-csr-polynomial");
    }

    #[test]
    fn cpf4_rejects_switch_to_mu_only_csr_polynomial_rule_removal() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("mark", vec![Term::app("a", vec![])]),
                Term::app("b", vec![]),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::SwitchContextSensitive {
            replacement_map: ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("mark"), BTreeSet::new()),
            ])),
            csr_rules: trs.rules().to_vec(),
            proof: Box::new(Proof::terminating(vec![
                ProofStep::ContextSensitivePolynomialRuleRemoval {
                    interpretations: vec![
                        ("a".to_string(), 0, Vec::new()),
                        ("b".to_string(), 0, Vec::new()),
                        ("mark".to_string(), 1, vec![0]),
                    ],
                    removed: trs.rules().to_vec(),
                    proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
                },
            ])),
        }]);
        let error = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap_err();
        assert!(error.to_string().contains("native IsaFoR/CeTA export"));
    }

    #[test]
    fn local_ceta_certifies_csr_innermost_dependency_pairs() {
        let csr = restricted_unary_csr();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("csr-innermost").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrInnermostDependencyPairs>"), "{cpf}");
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-csr-innermost-dependency-pairs");
    }

    #[test]
    fn cpf4_exports_context_sensitive_loop_as_trs_nontermination_proof() {
        let rule = RewriteRule::new(
            Term::app("a", vec![]),
            Term::app("f", vec![Term::app("a", vec![])]),
        );
        let csr = CsrTrs::new(
            Trs::new(None, BTreeSet::new(), vec![rule.clone()]),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let proof = Proof::nonterminating(NonterminationProof::Loop(LoopProof {
            start: Term::app("a", vec![]),
            steps: vec![LoopRewriteStep {
                position: vec![],
                rule,
                result: Term::app("f", vec![Term::app("a", vec![])]),
            }],
            substitution: BTreeMap::new(),
            context_position: vec![1],
        }));

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();

        assert!(cpf.contains("<contextSensitive>"));
        assert!(cpf.contains("<answer><no/></answer>"));
        assert!(cpf.contains("<trsNonterminationProof>"));
        assert!(cpf.contains("<loop>"));
        assert_ceta_csr_certifies_cpf4(cpf, "ferrum-context-sensitive-loop");
    }

    #[test]
    fn local_ceta_certifies_restricted_csr_rule_removal_by_trs_reflection() {
        let csr = restricted_unary_csr();
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![
                ("a".to_string(), 0, Vec::new()),
                ("f".to_string(), 1, vec![1]),
            ],
            removed: csr.rules().to_vec(),
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-restricted-csr-rule-removal");
    }

    #[test]
    fn local_ceta_certifies_restricted_csr_dp_by_trs_reflection() {
        let csr = restricted_unary_csr();
        let dp_proof = DependencyPairProof {
            initial_pairs: 0,
            components: 0,
            removed_pairs: 0,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: Vec::new(),
            component_proofs: Vec::new(),
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrDpProof>"));
        assert!(cpf.contains("<pIsEmpty/>"));
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-restricted-csr-dp-trs-reflection");
    }

    #[test]
    fn safe_csr_dependency_pairs_may_use_minimal_processors() {
        let rules = vec![RewriteRule::new(
            Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        )];
        let variables = rules
            .iter()
            .flat_map(|rule| rule.lhs().variables().into_iter())
            .collect();
        let trs = Trs::new(None, variables, rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let strategy = DpStrategy::parse("graph; size-change").unwrap();
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Safe,
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("safe CS-DPs should close under state-local graph/SCT guidance");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Safe,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(
            cpf.contains("<csrSafeDependencyPairs>")
                || cpf.contains("<csrImprovedDependencyPairs>")
                || cpf.contains("<csrRta08DependencyPairs>"),
            "{cpf}"
        );
        assert_ceta_csr_certifies_cpf4(cpf, "ferrum-safe-csr-dp-minimal-processor");
    }

    #[test]
    fn improved_csr_reduction_pair_materializes_and_closes_residuals() {
        let rules = vec![
            RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x")),
            RewriteRule::new(
                Term::app("h", vec![Term::var("x")]),
                Term::app("c", vec![Term::app("g", vec![Term::var("x")])]),
            ),
            RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
        ];
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("h"), BTreeSet::from([0])),
                (Symbol::new("c"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("a"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy =
            DpStrategy::parse("poly(max-constant=2,max-coefficient=2); graph; size-change")
                .unwrap();
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .expect("the residual chain should be solved independently");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Improved,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-improved-csr-closed-residuals");
    }

    #[test]
    fn local_ceta_certifies_direct_csr_dp_instantiation() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("X")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![]), Term::var("X"), Term::var("X")],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::var("X"),
                            Term::app("b", vec![]),
                            Term::app("b", vec![]),
                        ],
                    ),
                ),
                RewriteRule::new(Term::app("b", vec![]), Term::app("a", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::from([1])),
            ])),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Pipeline(vec![
            DpStrategy::Processor(DpStrategyProcessor::Instantiation { max_per_pair: None }),
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
            DpStrategy::Processor(DpStrategyProcessor::SatPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: None,
                max_arity: None,
            }),
        ]);
        // This is one complete processor chain, so preserve the explicit
        // pipeline continuation across its residual states.  The atomic
        // policy helper deliberately reapplies the first state-local atom at
        // every child and is intended for oracle-fragment tests instead.
        let dp_proof = crate::proving::solve_csr_dependency_pairs_with_kind_and_strategy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &options,
            &strategy,
            None,
        )
        .expect("direct improved CSR instantiation proof");
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(!cpf.contains("<ordinaryDpProof>"), "{cpf}");
        assert!(cpf.contains("<instantiationProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-direct-csr-dp-instantiation");

        let missing_instance = replace_nth_xml_section(
            &cpf,
            "instantiations",
            1,
            "<instantiations><rules/></instantiations>",
        );
        assert_ceta_csr_rejects_cpf4(
            missing_instance,
            "ferrum-direct-csr-dp-instantiation-missing-instance",
        );
    }

    #[test]
    fn local_ceta_certifies_ex9_luc06_default_csr_ladder_instantiation() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex9_luc06.ari"),
        )
        .unwrap();
        let strategy = DpStrategy::parse("instantiate(per-pair=2); graph; size-change").unwrap();
        let options = DpOptions::default();
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &options,
            &strategy,
            None,
        )
        .expect("state-local CSR guidance must retain the certifiable instantiation branch");
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(
            cpf.contains("<csrImprovedDependencyPairs>")
                || cpf.contains("<csrMutermExpandedInnermostDependencyPairs>"),
            "{cpf}"
        );
        assert!(cpf.contains("<instantiationProc>"), "{cpf}");
        assert!(!cpf.contains("<monoRedPairUrProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex9-luc06");

        let missing_instance = replace_nth_xml_section(
            &cpf,
            "instantiations",
            1,
            "<instantiations><rules/></instantiations>",
        );
        assert_ceta_csr_rejects_cpf4(missing_instance, "ferrum-csr-ex9-luc06-missing-instance");
    }

    #[test]
    fn local_ceta_certifies_ex14_luc06_default_proof() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex14_luc06.ari"),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("timeout(60s, default)").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(
            cpf.contains("<csrRuleRemovalThenImproved>")
                || cpf.contains("<csrRuleRemovalsThenImproved>")
                || cpf.contains("<csrSafeDependencyPairs>")
                || cpf.contains("<csrMutermTypedDependencyPairs>")
                || cpf.contains("<csrMutermInnermostDependencyPairs>")
                || cpf.contains("<csrMutermExpandedInnermostDependencyPairs>"),
            "{cpf}"
        );
        assert_ceta_csr_certifies_cpf4(cpf, "ferrum-csr-ex14-luc06-default");
    }

    #[test]
    fn local_ceta_certifies_ex1_gm03_structural_typed_muterm_proof() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse(
                    "timeout(60s, csr-muterm-unhiding(pipeline(graph; parallel(\
                     size-change | pipeline(\
                     rational-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2); \
                     rational-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2); \
                     graph)))))",
                )
                .unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrMutermTypedDependencyPairs>"), "{cpf}");
        assert!(
            cpf.contains("<localUsableRulesProc>") || cpf.contains("<generalUsableRulesProc>"),
            "{cpf}"
        );
        assert!(!cpf.contains("<expandedCsrProof>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf, "ferrum-csr-ex1-gm03-structural-typed-muterm");
    }

    #[test]
    fn cpf4_nests_improved_csr_dps_after_multiple_rule_removals() {
        let removed_h = RewriteRule::new(Term::app("h", vec![Term::var("x")]), Term::var("x"));
        let removed_k = RewriteRule::new(Term::app("k", vec![Term::var("x")]), Term::var("x"));
        let residual_rules = vec![
            RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("c", vec![Term::app("g", vec![Term::var("x")])]),
            ),
            RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
        ];
        let replacement_map = ReplacementMap::new(BTreeMap::from([
            (Symbol::new("a"), BTreeSet::new()),
            (Symbol::new("c"), BTreeSet::new()),
            (Symbol::new("f"), BTreeSet::from([0])),
            (Symbol::new("g"), BTreeSet::from([0])),
            (Symbol::new("h"), BTreeSet::from([0])),
            (Symbol::new("k"), BTreeSet::from([0])),
        ]));
        let mut original_rules = vec![removed_h.clone(), removed_k.clone()];
        original_rules.extend(residual_rules.clone());
        let csr = CsrTrs::new(
            Trs::new(None, BTreeSet::from([Variable::new("x")]), original_rules),
            replacement_map,
        )
        .unwrap();
        let residual = CsrTrs::new(
            Trs::new(None, BTreeSet::from([Variable::new("x")]), residual_rules),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("c"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let dp_options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; size-change").unwrap();
        let dp_proof = solve_improved_csr_dependency_pairs_with_strategy(
            &residual,
            &dp_options,
            &strategy,
            None,
        )
        .expect("residual improved CSR-DP proof");
        let continuation =
            Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
                construction: ContextSensitiveDependencyPairConstruction::Improved,
                auxiliary_rules: Vec::new(),
                proof: Box::new(dp_proof),
            }]);
        let proof = Proof::terminating(vec![ProofStep::ContextSensitivePolynomialRuleRemoval {
            interpretations: vec![
                ("a".to_string(), 0, vec![]),
                ("c".to_string(), 0, vec![0]),
                ("f".to_string(), 0, vec![1]),
                ("g".to_string(), 0, vec![1]),
                ("h".to_string(), 1, vec![1]),
                ("k".to_string(), 0, vec![1]),
            ],
            removed: vec![removed_h],
            proof: Box::new(Proof::terminating(vec![
                ProofStep::ContextSensitivePolynomialRuleRemoval {
                    interpretations: vec![
                        ("a".to_string(), 0, vec![]),
                        ("c".to_string(), 0, vec![0]),
                        ("f".to_string(), 0, vec![1]),
                        ("g".to_string(), 0, vec![1]),
                        ("k".to_string(), 1, vec![1]),
                    ],
                    removed: vec![removed_k],
                    proof: Box::new(continuation),
                },
            ])),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrRuleRemovalsThenImproved>"), "{cpf}");
        assert_eq!(cpf.matches("<ruleRemoval>").count(), 2, "{cpf}");
        assert!(cpf.contains("<sizeChangeProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-rule-removals-then-improved");
        let missing_final_pairs = replace_xml_section(&cpf, "dps", "<dps><rules/></dps>");
        assert_ceta_csr_rejects_cpf4(
            missing_final_pairs,
            "ferrum-csr-rule-removals-missing-final-pairs",
        );
    }

    #[test]
    fn cpf4_preserves_marked_improved_csr_subterm_closures() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let graph = crate::proving::DpSizeChangeGraph {
            pair: pair.clone(),
            edges: vec![crate::proving::DpSizeChangeEdge {
                left_position: 1,
                strict: true,
                right_position: 1,
            }],
        };
        let mut tree = crate::proving::DpProofTree::Subterm {
            projection: vec![crate::proving::DpSubtermProjectionEntry {
                symbol: Symbol::new("f#"),
                arity: 1,
                position: 1,
            }],
            strict_pairs: vec![pair],
            graphs: vec![graph.clone()],
            proof: Box::new(crate::proving::DpProofTree::Empty),
        };

        convert_complete_subterm_tree_to_csr_size_change(&mut tree);
        assert!(matches!(tree, crate::proving::DpProofTree::Subterm { .. }));
    }

    #[test]
    fn local_ceta_rejects_improved_csr_coverage_mutations() {
        let rules = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::var("x"),
        )];
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; size-change")
            .expect("focused improved-CSR strategy should parse");
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &options,
            &strategy,
            None,
        )
        .expect("the CSR-aware improved-DP processor should close the fixture");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Improved,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"));
        assert!(!cpf.contains("<auxiliaryRules>"));
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-exact-improved-csr");

        let missing_pairs = replace_xml_section(&cpf, "dps", "<dps><rules/></dps>");
        let stale_unhiding = cpf.replace("__CSR_U0", "f");
        for (name, mutation) in [
            ("missing-pairs", missing_pairs),
            ("nonfresh-unhiding-symbol", stale_unhiding),
        ] {
            assert_ceta_csr_rejects_cpf4(mutation, &format!("ferrum-improved-csr-{name}"));
        }
    }

    #[test]
    fn gm04_source_map_preserves_source_positions_and_freezes_fresh_wrapper() {
        let csr = crate::parsing::parse_ari_cstrs(
            None, include_str!("../../tests/fixtures/csr_improved_gm99.ari"),
        ).unwrap();
        let signature = csr.trs().arities();
        let fresh = fresh_unhiding_symbol(csr.trs());
        let mut xml = String::new();
        write_gm04_source_map_cpf3(&mut xml, &csr, &signature, csr.replacement_map(), 2);
        let document = roxmltree::Document::parse(&xml).unwrap();
        let entries = document.descendants().filter(|n| n.has_tag_name("replacementMapEntry"))
            .collect::<Vec<_>>();
        assert_eq!(entries.len(), signature.len() + 1);
        for entry in entries {
            let name = entry.children().find(|n| n.has_tag_name("name")).unwrap().text().unwrap();
            let positions = entry.children().filter(|n| n.has_tag_name("position"))
                .map(|n| n.text().unwrap().parse::<usize>().unwrap() - 1).collect::<BTreeSet<_>>();
            if name == fresh.as_str() {
                assert!(positions.is_empty());
                assert_eq!(entry.children().find(|n| n.has_tag_name("arity")).unwrap().text(), Some("1"));
            } else {
                assert_eq!(positions, csr.replacement_map().allowed_positions(&Symbol::new(name))
                    .cloned().unwrap_or_default());
            }
        }
        assert!(csr.replacement_map().allowed_positions(&fresh).is_none());
    }

    #[test]
    fn improved_csr_dp_state_keeps_fresh_unhiding_argument_frozen() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_improved_gm99.ari"),
        )
        .unwrap();
        let pairs = certificate_improved_csr_dependency_pairs(&csr);
        let unhiding = fresh_unhiding_symbol(csr.trs());
        assert!(pairs.iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&unhiding)
                || pair.rhs().root_symbol() == Some(&unhiding)
        }));
        let input = write_csr_dp_input_cpf4(
            &csr,
            &pairs,
            None,
            true,
            "improved",
            "context-sensitive",
            true,
        );
        let symbol = format!("<name>{unhiding}</name>");
        let strategy = input.find("<strategy>").expect("CSR strategy");
        let start = input[strategy..]
            .find(&symbol)
            .map(|offset| strategy + offset)
            .expect("fresh U replacement-map entry");
        let end = input[start..]
            .find("</replacementMapEntry>")
            .map(|offset| start + offset)
            .expect("complete fresh U replacement-map entry");
        assert!(!input[start..end].contains("<position>"));
    }

    #[test]
    fn local_ceta_certifies_refined_csr_search_with_conservative_parent() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_improved_gm99.ari"),
        )
        .unwrap();
        let refined_pairs = improved_csr_dependency_pairs(&csr);
        let certificate_pairs = certificate_improved_csr_dependency_pairs(&csr);
        let unhiding_symbol = fresh_unhiding_symbol(csr.trs());
        let from_projection = |pair: &DependencyPair| {
            pair.lhs().root_symbol() == Some(&unhiding_symbol)
                && pair.rhs().root_symbol() == Some(&unhiding_symbol)
                && pair.as_rule().to_string().starts_with("__CSR_U0(from(")
        };
        assert!(!refined_pairs.iter().any(from_projection));
        assert!(certificate_pairs.iter().any(from_projection));

        let strategy = DpStrategy::parse("graph; size-change").unwrap();
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("refined CS-DPs should close under state-local graph/SCT guidance");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Improved,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        let parent_dps_start = cpf.find("<dps>").unwrap();
        let parent_dps_end = cpf[parent_dps_start..]
            .find("</dps>")
            .map(|offset| parent_dps_start + offset + "</dps>".len())
            .unwrap();
        let parent_dps = &cpf[parent_dps_start..parent_dps_end];
        assert!(parent_dps.contains("<name>from</name>"), "{parent_dps}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-gm99-conservative-parent");

        let mut missing_projection = cpf.clone();
        let mut search_start = parent_dps_start;
        loop {
            let rule_start = missing_projection[search_start..]
                .find("<rule>")
                .map(|offset| search_start + offset)
                .expect("certificate-only from projection");
            let rule_end = missing_projection[rule_start..]
                .find("</rule>")
                .map(|offset| rule_start + offset + "</rule>".len())
                .unwrap();
            let rule = &missing_projection[rule_start..rule_end];
            if rule.contains("<name>__CSR_U0</name>") && rule.contains("<name>from</name>") {
                missing_projection.replace_range(rule_start..rule_end, "");
                break;
            }
            search_start = rule_end;
            assert!(search_start < parent_dps_end);
        }
        assert_ceta_csr_rejects_cpf4(
            missing_projection,
            "ferrum-csr-gm99-missing-conservative-projection",
        );
    }

    #[test]
    fn local_ceta_certifies_csr_graph_shared_frozen_active_refinement() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("X")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("a", vec![]),
                            Term::app("b", vec![]),
                            Term::var("X"),
                        ],
                    ),
                    Term::app("f", vec![Term::var("X"), Term::var("X"), Term::var("X")]),
                ),
                RewriteRule::new(Term::app("c", vec![]), Term::app("a", vec![])),
                RewriteRule::new(Term::app("c", vec![]), Term::app("b", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("c"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::from([0, 2])),
            ])),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                // This is a checker regression for the frozen-argument graph
                // refinement, not a benchmark of the broad default race.
                // Exercise the relevant certified construction directly so
                // unrelated delayed fallback lanes cannot consume the test
                // deadline.
                strategy: ProveStrategy::parse("timeout(5s, csr-improved-dp)").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(
            cpf.contains("<csrImprovedDependencyPairs>")
                || cpf.contains("<csrMutermTypedDependencyPairs>")
                || cpf.contains("<csrMutermInnermostDependencyPairs>")
                || cpf.contains("<csrMutermExpandedInnermostDependencyPairs>")
                || cpf.contains("<csrSafeDependencyPairs>"),
            "{cpf}"
        );
        assert!(cpf.contains("<depGraphProc>"), "{cpf}");
        assert!(!cpf.contains("<forwardInstantiationProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-shared-frozen-active-graph");

        let active_middle = cpf.replacen(
            "            <position>1</position>\n            <position>3</position>",
            "            <position>1</position>\n            <position>2</position>\n            <position>3</position>",
            1,
        );
        assert_ne!(active_middle, cpf);
        assert_ceta_csr_rejects_cpf4(
            active_middle,
            "ferrum-csr-shared-frozen-active-graph-active-middle",
        );
    }

    #[test]
    fn local_ceta_certifies_ex4_zan97_improved_graph_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex4_zan97.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Pipeline(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::UsableRules),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 7);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            3
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 3);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex4-zan97");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(no_strict_descent, "ferrum-csr-ex4-zan97-no-strict-descent");
    }

    #[test]
    fn local_ceta_certifies_ex8_blr02_improved_graph_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex8_blr02.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 11);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            3
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 3);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex8-blr02");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(no_strict_descent, "ferrum-csr-ex8-blr02-no-strict-descent");
    }

    #[test]
    fn local_ceta_certifies_ex7_blr02_improved_graph_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex7_blr02.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 10);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            2
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 2);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex7-blr02");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(no_strict_descent, "ferrum-csr-ex7-blr02-no-strict-descent");
    }

    #[test]
    fn local_ceta_certifies_exsec4_2_dlmmu04_improved_graph_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_exsec4_2_dlmmu04.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 14);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            2
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 2);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-exsec4-2-dlmmu04");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(
            no_strict_descent,
            "ferrum-csr-exsec4-2-dlmmu04-no-strict-descent",
        );
    }

    #[test]
    fn local_ceta_certifies_ex1_2_ael03_improved_graph_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex1_2_ael03.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 15);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            4
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 4);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex1-2-ael03");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(
            no_strict_descent,
            "ferrum-csr-ex1-2-ael03-no-strict-descent",
        );
    }

    #[test]
    fn local_ceta_certifies_ex9_luc04_improved_acyclic_graph() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex9_luc04.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::DependencyGraph);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 1);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            0
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert!(cpf.contains("<depGraphProc>"), "{cpf}");
        assert!(!cpf.contains("<sizeChangeProc>"), "{cpf}");
        assert!(!cpf.contains("<ordinaryDpProof>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex9-luc04");

        let active_middle = cpf.replacen(
            "            <position>1</position>\n            <position>3</position>",
            "            <position>1</position>\n            <position>2</position>\n            <position>3</position>",
            1,
        );
        assert_ne!(active_middle, cpf);
        assert_ceta_csr_rejects_cpf4(active_middle, "ferrum-csr-ex9-luc04-active-middle");
    }

    #[test]
    fn local_ceta_certifies_ex1_luc02b_refined_search_and_full_projection_certificate() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex1_luc02b.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 8);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            2
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 2);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex1-luc02b");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(no_strict_descent, "ferrum-csr-ex1-luc02b-no-strict-descent");
    }

    #[test]
    fn local_ceta_certifies_ex4_7_56_full_improved_csr_certificate() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex4_7_56_bor03.ari"),
        )
        .unwrap();
        let strategy = DpStrategy::parse("graph; size-change").unwrap();
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("state-local graph/SCT policy should close every improved-CS-DP residual");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Improved,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert!(cpf.contains("<sizeChangeProc>"), "{cpf}");
        assert!(!cpf.contains("<innermostLhssRemovalProc>"), "{cpf}");
        assert!(!cpf.contains("<ordinaryDpProof>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex4-7-56-bor03");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(
            no_strict_descent,
            "ferrum-csr-ex4-7-56-bor03-no-strict-descent",
        );
    }

    #[test]
    fn local_ceta_certifies_improved_certificate_pair_wrapper() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex3_12_luc96a.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; size-change").unwrap();
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert!(same_dependency_pair_rules(
            &dp_proof.pairs,
            &certificate_improved_csr_dependency_pairs(&csr)
        ));
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-improved-certificate-wrapper");

        let wrong_wrapper = cpf.replace("csrImprovedDependencyPairs", "csrSafeDependencyPairs");
        assert_ceta_csr_rejects_cpf4(
            wrong_wrapper,
            "ferrum-csr-improved-certificate-safe-wrapper",
        );
    }

    #[test]
    fn local_ceta_certifies_mixed_frozen_csr_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_mixed_frozen_projection.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; size-change").unwrap();
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<sizeChangeProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-mixed-frozen-size-change");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(
            no_strict_descent,
            "ferrum-csr-mixed-frozen-size-change-no-strict",
        );
    }

    #[test]
    fn local_ceta_certifies_ex3_12_refined_scc_and_projection_certificate_scc() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex3_12_luc96a.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        assert_eq!(dp_proof.initial_pairs, 5);
        assert_eq!(
            dp_proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            2
        );

        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert_eq!(cpf.matches("<sizeChangeProc>").count(), 2);
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex3-12-luc96a");

        let no_strict_descent = cpf.replace("<strict>true</strict>", "<strict>false</strict>");
        assert_ne!(no_strict_descent, cpf);
        assert_ceta_csr_rejects_cpf4(
            no_strict_descent,
            "ferrum-csr-ex3-12-luc96a-no-strict-descent",
        );
    }

    #[test]
    fn local_ceta_checks_exact_hidden_term_pairs() {
        let rules = vec![
            RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x")),
            RewriteRule::new(
                Term::app("h", vec![Term::var("x")]),
                Term::app("c", vec![Term::app("g", vec![Term::var("x")])]),
            ),
            RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
        ];
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("h"), BTreeSet::from([0])),
                (Symbol::new("c"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("a"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = improved_csr_dependency_pairs(&csr);
        let unhiding_symbol = fresh_unhiding_symbol(csr.trs());
        assert!(
            pairs.iter().any(|pair| {
                pair.lhs().root_symbol() == Some(&unhiding_symbol)
                    && pair.rhs().root_symbol() == Some(&Symbol::new("g#"))
            }),
            "{pairs:#?}"
        );
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_improved_csr_dependency_pairs_with_strategy(&csr, &options, &strategy, None)
                .unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-improved-hidden-pair");

        let mut graph_search_start = 0;
        let graph_start = loop {
            let start = cpf[graph_search_start..]
                .find("<sizeChangeGraph>")
                .map(|offset| graph_search_start + offset)
                .unwrap();
            let end = cpf[start..]
                .find("</sizeChangeGraph>")
                .map(|offset| start + offset)
                .unwrap();
            if cpf[start..end].contains("<name>__CSR_U0</name>") {
                break start;
            }
            graph_search_start = end + "</sizeChangeGraph>".len();
        };
        let component_dps_start = cpf[..graph_start].rfind("<dps>").unwrap();
        let component_dps_end = cpf[component_dps_start..graph_start]
            .rfind("</dps>")
            .map(|offset| component_dps_start + offset)
            .unwrap();
        let rule_end = cpf[..component_dps_end].rfind("</rule>").unwrap();
        let rhs_var_start = cpf[component_dps_start..rule_end]
            .rfind("<var>")
            .map(|offset| component_dps_start + offset)
            .unwrap();
        let rhs_var_end = cpf[rhs_var_start..]
            .find("</var>")
            .map(|offset| rhs_var_start + offset + "</var>".len())
            .unwrap();
        let mut non_subterm_unhiding = cpf.clone();
        non_subterm_unhiding.replace_range(
            rhs_var_start..rhs_var_end,
            &format!(
                "<funapp><name>s</name>{}</funapp>",
                &cpf[rhs_var_start..rhs_var_end]
            ),
        );
        assert_ceta_csr_rejects_cpf4(non_subterm_unhiding, "ferrum-improved-non-subterm-unhiding");

        let missing_pair_cases = [
            (
                "collapsing",
                pairs.iter().position(|pair| {
                    pair.lhs().root_symbol() != Some(&unhiding_symbol)
                        && pair.rhs().root_symbol() == Some(&unhiding_symbol)
                }),
            ),
            (
                "hidden",
                pairs.iter().position(|pair| {
                    pair.lhs().root_symbol() == Some(&unhiding_symbol)
                        && pair.rhs().root_symbol() == Some(&Symbol::new("g#"))
                }),
            ),
        ];
        for (kind, index) in missing_pair_cases {
            let index = index.unwrap_or_else(|| panic!("missing {kind} fixture pair: {pairs:#?}"));
            let remaining = pairs
                .iter()
                .enumerate()
                .filter_map(|(candidate, pair)| (candidate != index).then_some(pair.clone()))
                .collect::<Vec<_>>();
            let mut replacement = String::new();
            write_dependency_pairs_trs_cpf3(&mut replacement, &remaining, 0, "dps");
            assert_ceta_csr_rejects_cpf4(
                replace_xml_section(&cpf, "dps", &replacement),
                &format!("ferrum-improved-missing-{kind}-pair"),
            );
        }
    }

    #[test]
    fn csr_dp_export_rejects_replacement_map_specific_pairs() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::app("f", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = crate::proving::csr_dependency_pairs(&csr);
        assert_ne!(pairs, crate::proving::dependency_pairs(csr.trs()));
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(DependencyPairProof {
                initial_pairs: pairs.len(),
                components: 0,
                removed_pairs: 0,
                usable_rules: 0,
                smt_attempted: false,
                smt_solved: false,
                strategy: RewriteStrategy::Full,
                pairs,
                component_proofs: Vec::new(),
            }),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrDependencyPairs>"));
    }

    #[test]
    fn local_ceta_certifies_full_map_csr_dp() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
        );
        let csr = CsrTrs::full(trs);
        let dp_proof = DependencyPairProof {
            initial_pairs: 0,
            components: 0,
            removed_pairs: 0,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: Vec::new(),
            component_proofs: Vec::new(),
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-full-map-csr-dp");
    }

    #[test]
    fn csr_dp_export_emits_native_qcs_usable_rules_restriction() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .unwrap();
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(DependencyPairProof {
                initial_pairs: 2,
                components: 1,
                removed_pairs: 1,
                usable_rules: 0,
                smt_attempted: false,
                smt_solved: false,
                strategy: RewriteStrategy::Full,
                pairs: vec![pair.clone(), pair.clone()],
                component_proofs: vec![DpComponentProof {
                    pairs: vec![pair.clone()],
                    usable_rules: Vec::new(),
                    interpretation: None,
                    backend: None,
                    usable_rules_processor: Some(Vec::new()),
                    innermost_lhss_processor: None,
                    reductions: Vec::new(),
                    final_acyclic_components: Vec::new(),
                    proof_tree: Some(Box::new(DpProofTree::SizeChange {
                        graphs: vec![DpSizeChangeGraph {
                            pair,
                            edges: vec![DpSizeChangeEdge {
                                left_position: 1,
                                strict: true,
                                right_position: 1,
                            }],
                        }],
                    })),
                    proved: true,
                }],
            }),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<usableRulesProc>"));
        assert!(cpf.contains("<sizeChangeProc>"));
        assert_ceta_certifies_csr(&csr, &proof, "ferrum-qcs-usable-rules");
    }

    #[test]
    fn local_ceta_certifies_csr_u3_red_pair_and_rejects_mutations() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_u3_redpair.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: None,
                max_arity: None,
            }),
        ]);
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &options,
            &strategy,
            None,
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        let u3 = cpf
            .split("<redPairUrProc>")
            .nth(1)
            .and_then(|suffix| suffix.split("</redPairUrProc>").next())
            .expect("native CSR reduction pair must use the U3 processor");
        assert!(u3.contains("<usableRules>"));
        assert!(u3.contains("<name>s</name>"));
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-u3-red-pair");

        let non_closed_u3 = replace_xml_section_after(
            &cpf,
            "<redPairUrProc>",
            "usableRules",
            "<usableRules><rules/></usableRules>",
        );
        let missing_pairs =
            replace_xml_section_after(&cpf, "<redPairUrProc>", "dps", "<dps><rules/></dps>");
        assert_ceta_csr_rejects_cpf4(non_closed_u3, "ferrum-csr-u3-non-closed-closure");
        assert_ceta_csr_rejects_cpf4(missing_pairs, "ferrum-csr-u3-missing-pairs");
    }

    #[test]
    fn local_ceta_certifies_mixed_unhiding_u3_and_rejects_second_unmarked_root() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        );
        let csr = CsrTrs::new(
            Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![rule]),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let unhiding = crate::proving::fresh_unhiding_symbol(csr.trs());
        let pair = DependencyPair::new_for_test(
            Term::app(
                unhiding.as_str(),
                vec![Term::app("s", vec![Term::var("x")])],
            ),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: csr.rules().to_vec(),
            uses_usable_rules: true,
            // Exercise the non-monotone U3 certificate shape even though
            // this deliberately simple witness is also monotone.
            force_non_mono_usable_rules: true,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![
                    // Keep the argument in the interpretation.  Under CPF's
                    // positive carrier convention, constant-only symbols are
                    // normalized at the carrier floor and can unexpectedly
                    // tie.  This witness proves
                    // U(s(x)) = 2 + x > x = f#(x) directly.
                    (unhiding.to_string(), 1, vec![1]),
                    ("s".to_string(), 1, vec![1]),
                    ("f#".to_string(), 0, vec![1]),
                ],
                backend: DpSearchBackend::Smt,
            },
        };
        let proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: true,
            smt_solved: true,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: Some(DpSearchBackend::Smt),
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        let cpf = write_cpf4_csr_dp_problem(&csr, &proof.pairs, None, true, &proof);
        assert!(cpf.contains("<redPairUrProc>"), "{cpf}");
        assert!(cpf.contains(&format!("<name>{unhiding}</name>")), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-mixed-u3");

        let compact = cpf
            .chars()
            .filter(|ch| !ch.is_whitespace())
            .collect::<String>();
        let second_unmarked =
            compact.replace("<sharp><name>f</name></sharp>", "<name>other</name>");
        assert_ne!(
            second_unmarked, compact,
            "mutation must replace the marked root"
        );
        assert_ceta_csr_rejects_cpf4(second_unmarked, "ferrum-csr-mixed-u3-two-unmarked");
    }

    #[test]
    fn local_ceta_certifies_ex4_7_37_with_state_local_u3_reductions() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex4_7_37_bor03.ari"),
        )
        .unwrap();
        let strategy =
            DpStrategy::parse("graph; size-change; poly(max-constant=2, max-coefficient=2)")
                .unwrap();
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("state-local graph/SCT/polynomial policy should close every residual");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Improved,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrImprovedDependencyPairs>"), "{cpf}");
        assert!(cpf.contains("<redPairUrProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ex4-7-37-improved-u3");

        let missing_closure = replace_xml_section_after(
            &cpf,
            "<redPairUrProc>",
            "usableRules",
            "<usableRules><rules/></usableRules>",
        );
        assert_ceta_csr_rejects_cpf4(
            missing_closure,
            "ferrum-csr-ex4-7-37-improved-u3-missing-closure",
        );
    }

    #[test]
    fn local_ceta_certifies_ex6_15_u3_arctic_then_subterm() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex6_15_ael02.ari"),
        )
        .unwrap();
        let strategy = DpStrategy::parse(
            "graph; (size-change | pipeline(usable-rules; \
             poly(max-constant=2,max-coefficient=2)) | \
             pipeline(arctic-matrix(dimension=3,max-constant=3,max-coefficient=3); subterm))",
        )
        .unwrap();
        let dp_proof = solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Improved,
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("the U3 Arctic deletion must expose the terminal subterm component");
        let proof = Proof::terminating(vec![ProofStep::ContextSensitiveDependencyPairProof {
            construction: ContextSensitiveDependencyPairConstruction::Improved,
            auxiliary_rules: Vec::new(),
            proof: Box::new(dp_proof),
        }]);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrRedPairUrProc>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf, "ferrum-csr-ex6-15-u3-arctic-subterm");
    }

    #[test]
    fn local_ceta_certifies_generic_guarded_list_ovconsos_default_proof() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ovconsos_nokinds.ari"),
        )
        .expect("parse OvConsOS fixture");
        let proof = crate::proving::prove_context_sensitive(
            &csr,
            &crate::proving::ProveOptions {
                strategy: crate::proving::ProveStrategy::default_from_file(),
                llm_first: false,
                ..crate::proving::ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);

        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<csrGuardedImprovedDependencyPairs>"), "{cpf}");
        assert!(cpf.contains("<csrGuardedListTerminal>"), "{cpf}");
        assert_ceta_csr_certifies_cpf4(cpf.clone(), "ferrum-csr-ovconsos-guarded");

        let wrong_truth = replace_xml_section_after(
            &cpf,
            "<csrGuardedListTerminal>",
            "truthSymbol",
            "<truthSymbol><name>nil</name></truthSymbol>",
        );
        assert_ceta_csr_rejects_cpf4(wrong_truth, "ferrum-csr-ovconsos-wrong-truth");

        let wrong_tail = replace_xml_section_after(
            &cpf,
            "<csrGuardedListTerminal>",
            "listVariable",
            "<listVariable>not_the_live_tail</listVariable>",
        );
        assert_ceta_csr_rejects_cpf4(wrong_tail, "ferrum-csr-guarded-list-wrong-tail");

        let extended_input = include_str!("../../tests/fixtures/csr_ovconsos_nokinds.ari").replace(
            "(rule zeros (cons |0| zeros))",
            "(fun alpha 1 :replacement-map (1))\n\
                 (fun beta 1 :replacement-map (1))\n\
                 (rule zeros (cons |0| zeros))",
        ) + "(rule (alpha X) (beta X))\n";
        let extended_csr = crate::parsing::parse_ari_cstrs(None, &extended_input)
            .expect("parse OvConsOS fixture with unrelated safe rule");
        let extended_proof = crate::proving::prove_context_sensitive(
            &extended_csr,
            &crate::proving::ProveOptions {
                strategy: crate::proving::ProveStrategy::default_from_file(),
                llm_first: false,
                ..crate::proving::ProveOptions::default()
            },
        );
        assert_eq!(extended_proof.status(), &Status::Terminating);
        let extended_cpf = write_cpf_csr(&extended_csr, &extended_proof, CpfMode::Cpf40).unwrap();
        assert!(extended_cpf.contains("<csrGuardedListTerminal>"));
        assert_ceta_csr_certifies_cpf4(extended_cpf, "ferrum-csr-guarded-list-unrelated-safe-rule");

        // Rename every input symbol and variable (including the pair tail),
        // and reverse rule order. Recognition must use roles, not spelling or
        // encounter order. Retain the unrelated safe rule as a non-isomorphism
        // guard: the recognizer must not demand a complete benchmark template.
        let renaming = extended_csr.trs().arities().keys().enumerate()
            .map(|(i, symbol)| (symbol.as_str().to_owned(), format!("role_{i}")))
            .chain(extended_csr.trs().variables().iter().enumerate()
                .map(|(i, variable)| (variable.as_str().to_owned(), format!("arg_{i}"))))
            .collect::<BTreeMap<_, _>>();
        let renamed = extended_input.split_inclusive(|c: char| c.is_whitespace() || c == '(' || c == ')')
            .map(|part| {
                let token = part.trim_end_matches(|c: char| c.is_whitespace() || c == '(' || c == ')');
                format!("{}{}", renaming.get(token).map(String::as_str).unwrap_or(token), &part[token.len()..])
            }).collect::<String>();
        let (mut rules, mut declarations): (Vec<_>, Vec<_>) = renamed.lines()
            .partition(|line| line.starts_with("(rule "));
        rules.reverse();
        declarations.extend(rules);
        let renamed_csr = crate::parsing::parse_ari_cstrs(None, &declarations.join("\n")).unwrap();
        let renamed_proof = crate::proving::prove_context_sensitive(
            &renamed_csr,
            &crate::proving::ProveOptions {
                strategy: crate::proving::ProveStrategy::default_from_file(),
                llm_first: false,
                ..crate::proving::ProveOptions::default()
            },
        );
        assert_eq!(renamed_proof.status(), &Status::Terminating);
        let renamed_cpf = write_cpf_csr(&renamed_csr, &renamed_proof, CpfMode::Cpf40).unwrap();
        assert!(renamed_cpf.contains("<csrGuardedListTerminal>"));
        assert_ceta_csr_certifies_cpf4(renamed_cpf, "ferrum-csr-guarded-list-renamed");
    }

    #[test]
    fn local_ceta_certifies_gutierrez_secret2_and_secret4_defaults() {
        let cases = [
            (
                "secret2",
                include_str!("../../../TPDB-ARI/TRS_Contextsensitive/Gutierrez_26/secret2.ari"),
                Status::Terminating,
            ),
            (
                "secret4",
                include_str!("../../../TPDB-ARI/TRS_Contextsensitive/Gutierrez_26/secret4.ari"),
                Status::Nonterminating,
            ),
        ];
        for (name, input, expected) in cases {
            let csr = crate::parsing::parse_ari_cstrs(None, input).unwrap();
            let proof = crate::proving::prove_context_sensitive(
                &csr,
                &crate::proving::ProveOptions {
                    strategy: crate::proving::ProveStrategy::default_from_file(),
                    llm_first: false,
                    ..crate::proving::ProveOptions::default()
                },
            );
            assert_eq!(proof.status(), &expected, "{name}");
            let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
            assert_ceta_csr_certifies_cpf4(cpf, &format!("ferrum-csr-{name}"));
        }
    }

    #[test]
    fn cpf4_keeps_subterm_continuation_inside_recursive_u3_processor() {
        let csr = CsrTrs::new(
            Trs::new(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![
                    RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x")),
                    RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
                    RewriteRule::new(Term::app("s", vec![Term::var("x")]), Term::var("x")),
                ],
            ),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let deleted = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let residual = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![deleted.clone(), residual.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: true,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![
                    ("f#".to_string(), 0, vec![0]),
                    ("g#".to_string(), 0, vec![1]),
                    ("s".to_string(), 1, vec![1]),
                ],
                backend: DpSearchBackend::Sat,
            },
        };
        let tail = DpProofTree::Subterm {
            projection: vec![crate::proving::DpSubtermProjectionEntry {
                symbol: Symbol::new("f#"),
                arity: 1,
                position: 0,
            }],
            strict_pairs: vec![residual.clone()],
            graphs: vec![DpSizeChangeGraph {
                pair: residual.clone(),
                edges: vec![DpSizeChangeEdge {
                    left_position: 1,
                    strict: true,
                    right_position: 1,
                }],
            }],
            proof: Box::new(DpProofTree::Empty),
        };
        let tree = DpProofTree::RedPair {
            reduction,
            proof: Box::new(tail),
        };
        let mut xml = String::new();
        write_csr_dp_proof_tree_cpf3(
            &mut xml,
            &tree,
            RewriteStrategy::Full,
            csr.trs().rules(),
            None,
            0,
        );
        let body = xml
            .split("<csrRedPairUrProc>")
            .nth(1)
            .and_then(|suffix| suffix.split("</csrRedPairUrProc>").next())
            .expect("the U3 step must use the recursive CSR processor");
        assert!(body.contains("<subtermProc>"), "{body}");
        assert!(!body.contains("<ordinaryDpProof>"), "{body}");
    }

    fn restricted_unary_csr() -> CsrTrs {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("a", vec![])]),
                Term::app("a", vec![]),
            )],
        );
        CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::new()),
            ])),
        )
        .unwrap()
    }

    fn assert_local_ceta_rejects_csr_cpf(name: &str, proof_body: &str, expected: &[&str]) {
        let ceta = Path::new("../CeTA-CSR/ceta");
        if !ceta.exists() {
            return;
        }
        let cpf = format!(
            r#"<?xml version="1.0" encoding="UTF-8"?>
<certificationProblem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="cpf3.xsd">
  <cpfVersion>3.0</cpfVersion>
  <lookupTables/>
  <input>
    <trsInput>
      <trs><rules/></trs>
      <strategy><contextSensitive/></strategy>
    </trsInput>
  </input>
  <property><termination/></property>
  <answer><yes/></answer>
  <proof>
    {proof_body}
  </proof>
  <metaInformation><toolInfos><toolInfo>Ferrum CSR capability probe</toolInfo></toolInfos></metaInformation>
</certificationProblem>
"#
        );
        assert_local_ceta_rejects_cpf3(name, &cpf, expected);
    }

    fn assert_local_ceta_rejects_cpf3(name: &str, cpf: &str, expected: &[&str]) {
        let ceta = Path::new("../CeTA-CSR/ceta");
        if !ceta.exists() {
            return;
        }
        let path = std::env::temp_dir().join(format!("{name}-{}.cpf3.xml", std::process::id()));
        fs::write(&path, cpf).unwrap();
        let output = Command::new(ceta).arg(&path).output().unwrap();
        let _ = fs::remove_file(path);
        assert!(
            !output.status.success(),
            "local CeTA unexpectedly accepted {name}"
        );
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        let combined = format!("{stdout}\n{stderr}");
        assert!(
            expected.iter().any(|needle| combined.contains(needle)),
            "unexpected CeTA rejection for {name}:\nstdout:\n{stdout}\nstderr:\n{stderr}"
        );
    }

    #[test]
    fn writes_cpf3_match_bounds_certificate_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::Bounds {
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "a".to_string(),
                            height: Some(0),
                            args: vec!["q".to_string()],
                        },
                        rhs: "q".to_string(),
                    }],
                },
                state_compatibility: Vec::new(),
            },
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<bounds>"));
        assert!(cpf.contains("<match/>"));
        assert!(cpf.contains("<treeAutomaton>"));
        assert!(cpf.contains("<compatibility/>"));
    }

    #[test]
    fn writes_cpf3_match_bounds_state_compatibility_relation() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::Bounds {
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q0".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q0".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "a".to_string(),
                            height: Some(0),
                            args: vec!["q0".to_string()],
                        },
                        rhs: "q0".to_string(),
                    }],
                },
                state_compatibility: vec![("q1".to_string(), "q0".to_string())],
            },
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();

        assert!(cpf.contains("<stateCompatibility>"));
        assert!(cpf.contains("<relation>"));
        assert!(cpf.contains("<entry>"));
        assert!(cpf.contains("<state>s2_q1</state>"));
        assert!(cpf.contains("<state>s2_q0</state>"));
        assert!(!cpf.contains("<compatibility/>"));
    }

    #[test]
    fn ceta_certifies_cpf3_match_bounds_with_canonical_identity_compatibility_when_available() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::Bounds {
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "a".to_string(),
                            height: Some(0),
                            args: vec!["q".to_string()],
                        },
                        rhs: "q".to_string(),
                    }],
                },
                state_compatibility: vec![("q".to_string(), "q".to_string())],
            },
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();

        assert!(cpf.contains("<compatibility/>"));
        assert!(!cpf.contains("<stateCompatibility>"));
        assert_ceta_certifies_cpf3(cpf, "ferrum-match-bounds-identity-compatibility");
    }

    #[test]
    fn writes_semantic_label_symbols_as_cpf_labeled_symbols() {
        let mut xml = String::new();
        write_symbol_cpf3(&mut xml, "__ferrum_sl__66__0_1", 0);

        assert!(xml.contains("<labeledSymbol>"));
        assert!(xml.contains("<name>f</name>"));
        assert!(xml.contains("<number>0</number>"));
        assert!(xml.contains("<number>1</number>"));
    }

    #[test]
    fn writes_marked_semantic_label_symbols_as_nested_cpf_symbols() {
        let mut xml = String::new();
        write_symbol_cpf3(&mut xml, "__ferrum_sl__66__0_1#", 0);

        assert!(xml.starts_with("<sharp>\n"), "{xml}");
        assert!(xml.contains("<labeledSymbol>"), "{xml}");
        assert!(xml.contains("<name>f</name>"), "{xml}");
        assert!(xml.contains("<number>0</number>"), "{xml}");
        assert!(xml.contains("<number>1</number>"), "{xml}");
        assert!(xml.ends_with("</sharp>\n"), "{xml}");
    }

    #[test]
    fn writes_root_label_symbols_as_cpf_symbol_labels() {
        let mut xml = String::new();
        write_symbol_cpf3(&mut xml, "__ferrum_rl__6623__61_66", 0);

        assert!(xml.contains("<labeledSymbol>"), "{xml}");
        assert!(xml.contains("<sharp>"), "{xml}");
        assert!(xml.contains("<symbolLabel>"), "{xml}");
        assert!(xml.contains("<name>a</name>"), "{xml}");
        assert!(xml.contains("<name>f</name>"), "{xml}");
        assert!(!xml.contains("<numberLabel>"), "{xml}");
    }

    #[test]
    fn writes_literal_hash_as_an_ordinary_cpf_symbol() {
        let mut xml = String::new();
        write_symbol_cpf3(&mut xml, "#", 0);

        assert_eq!(xml, "<name>#</name>\n");
    }

    #[test]
    fn completed_cpf_uses_numeric_symbol_spelling_without_changing_state_spelling() {
        let mut state_symbol = String::new();
        write_symbol_cpf3(&mut state_symbol, "|01|", 0);
        assert_eq!(state_symbol, "<name>|01|</name>\n");

        let cpf = canonicalize_cpf_numeric_symbol_names(
            "<funapp><name>|01|</name></funapp><name>|not-numeric|</name>".into(),
        );
        assert_eq!(
            cpf,
            "<funapp><name>01</name></funapp><name>|not-numeric|</name>"
        );
    }

    #[test]
    fn completed_cpf_canonicalizes_every_numeric_symbol_occurrence() {
        let cpf = canonicalize_cpf_numeric_symbol_names(
            "<name>|sort|1</name><name>|0|</name><name>|0|</name><interpret><name>|17|</name></interpret>".into(),
        );
        assert_eq!(
            cpf,
            "<name>|sort|1</name><name>0</name><name>0</name><interpret><name>17</name></interpret>"
        );
        assert!(!cpf.contains("<name>|0|</name>"));
    }

    #[test]
    fn ceta_certifies_cpf3_semantic_labeling_processor_when_available() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("semlab").unwrap();
        let dp_proof = solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None)
            .expect("semantic labeling should expose a certifiable labeled DP problem");
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();

        assert!(cpf.contains("<semlabProc>"));
        assert_ceta_certifies_cpf3(cpf, "ferrum-semlab-dp");
    }

    #[test]
    fn writes_cpf3_relative_match_bounds_certificate_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::RelativeBounds {
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "a".to_string(),
                            height: Some(0),
                            args: vec!["q".to_string()],
                        },
                        rhs: "q".to_string(),
                    }],
                },
                state_compatibility: Vec::new(),
            },
            removed: trs.rules().to_vec(),
            proof_after_removal: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<relativeBounds>"));
        assert!(cpf.contains("<bounds>"));
        assert!(cpf.contains("<trsTerminationProof>"));
        assert!(cpf.contains("<rIsEmpty/>"));
    }

    #[test]
    fn writes_cpf4_rfc_relative_match_bounds_certificate_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::RfcRelativeBounds {
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "b".to_string(),
                            height: Some(0),
                            args: vec!["q".to_string()],
                        },
                        rhs: "q".to_string(),
                    }],
                },
                state_compatibility: Vec::new(),
            },
            initial_words: vec![vec![Symbol::new("b")]],
            removed: trs.rules().to_vec(),
            proof_after_removal: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Auto).unwrap();
        assert!(cpf.contains("<cpfVersion>4.0</cpfVersion>"));
        assert!(cpf.contains("<rfcRelativeBounds>"));
        assert!(cpf.contains("<initialTerms>"));
        assert!(cpf.contains("<bounds>"));
        assert!(cpf.contains("<trsTerminationProof>"));
        assert!(cpf.contains("<rIsEmpty/>"));
        assert!(write_cpf(&trs, &proof, CpfMode::Cpf30).is_err());
    }

    #[test]
    fn writes_cpf4_rfc_matchbox_relative_bounds_certificate_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::RfcMatchboxRelativeBounds {
            absolute_residual: false,
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "b".to_string(),
                            height: Some(0),
                            args: vec!["q".to_string()],
                        },
                        rhs: "q".to_string(),
                    }],
                },
                state_compatibility: Vec::new(),
            },
            initial_words: vec![vec![Symbol::new("b")]],
            removed: trs.rules().to_vec(),
            proof_after_removal: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<cpfVersion>4.0</cpfVersion>"));
        assert!(cpf.contains("<rfcMatchboxRelativeBounds>"));
        assert!(cpf.contains("<initialTerms>"));
        assert!(cpf.contains("<bounds>"));
        assert!(cpf.contains("<trsTerminationProof>"));
        assert!(cpf.contains("<rIsEmpty/>"));
    }

    #[test]
    fn writes_cpf4_rfc_native_matchbox_relative_bounds_certificate_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::RfcNativeMatchboxRelativeBounds {
            proof: BoundsProof {
                bounds_type: BoundsType::Match,
                bound: 0,
                final_states: vec!["q".to_string()],
                automaton: TreeAutomaton {
                    final_states: vec!["q".to_string()],
                    transitions: vec![TreeAutomatonTransition {
                        lhs: TreeAutomatonTransitionLhs::Symbol {
                            symbol: "b".to_string(),
                            height: Some(0),
                            args: vec!["q".to_string()],
                        },
                        rhs: "q".to_string(),
                    }],
                },
                state_compatibility: Vec::new(),
            },
            initial_words: vec![vec![Symbol::new("b")]],
            removed: trs.rules().to_vec(),
            proof_after_removal: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<cpfVersion>4.0</cpfVersion>"));
        assert!(cpf.contains("<rfcNativeMatchboxRelativeBounds>"));
        assert!(!cpf.contains("<rfcMatchboxRelativeBounds>"));
        assert!(cpf.contains("<initialTerms>"));
        assert!(cpf.contains("<bounds>"));
        assert!(cpf.contains("<trsTerminationProof>"));
    }

    #[test]
    fn writes_cpf3_string_reversal_certificate_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::app("b", vec![Term::var("x")])]),
                Term::app("c", vec![Term::var("x")]),
            )],
        );
        let reversed_rules = vec![RewriteRule::new(
            Term::app("b", vec![Term::app("a", vec![Term::var("x")])]),
            Term::app("c", vec![Term::var("x")]),
        )];
        let proof = Proof::terminating(vec![ProofStep::StringReversal {
            reversed_rules,
            reversed_weak_rules: Vec::new(),
            proof: Box::new(Proof::terminating(vec![ProofStep::Bounds {
                proof: BoundsProof {
                    bounds_type: BoundsType::Match,
                    bound: 0,
                    final_states: vec!["q".to_string()],
                    automaton: TreeAutomaton {
                        final_states: vec!["q".to_string()],
                        transitions: vec![
                            TreeAutomatonTransition {
                                lhs: TreeAutomatonTransitionLhs::Symbol {
                                    symbol: "a".to_string(),
                                    height: Some(0),
                                    args: vec!["q".to_string()],
                                },
                                rhs: "q".to_string(),
                            },
                            TreeAutomatonTransition {
                                lhs: TreeAutomatonTransitionLhs::Symbol {
                                    symbol: "b".to_string(),
                                    height: Some(0),
                                    args: vec!["q".to_string()],
                                },
                                rhs: "q".to_string(),
                            },
                            TreeAutomatonTransition {
                                lhs: TreeAutomatonTransitionLhs::Symbol {
                                    symbol: "c".to_string(),
                                    height: Some(0),
                                    args: vec!["q".to_string()],
                                },
                                rhs: "q".to_string(),
                            },
                        ],
                    },
                    state_compatibility: Vec::new(),
                },
            }])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<stringReversal>"));
        assert!(cpf.contains("<trsTerminationProof>"));
        assert!(cpf.contains("<bounds>"));
    }

    #[test]
    fn writes_cpf3_top_level_kbo_rule_removal_without_argument_filter() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let proof = Proof::terminating(vec![ProofStep::SynthesizedKbo {
            precedence: vec!["f".to_string(), "g".to_string()],
            precedence_ranks: BTreeMap::from([("f".to_string(), 0), ("g".to_string(), 1)]),
            weights: vec![("f".to_string(), 1), ("g".to_string(), 1)],
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<ruleRemoval>"));
        assert!(cpf.contains("<knuthBendixOrder>"));
        assert!(!cpf.contains("<argumentFilter>"));
    }

    #[test]
    fn writes_cpf3_recursive_kbo_rule_removal() {
        let removed = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![removed.clone()],
        );
        let proof = Proof::terminating(vec![ProofStep::KboRuleRemoval {
            precedence: vec!["f".to_string(), "g".to_string()],
            precedence_ranks: BTreeMap::from([("f".to_string(), 0), ("g".to_string(), 1)]),
            weights: vec![("f".to_string(), 1), ("g".to_string(), 1)],
            removed: vec![removed],
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<ruleRemoval>"));
        assert!(cpf.contains("<knuthBendixOrder>"));
        assert!(cpf.contains("<rIsEmpty/>"));
        assert!(!cpf.contains("<argumentFilter>"));
    }

    #[test]
    fn writes_cpf3_recursive_polynomial_rule_removal() {
        let removed = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![removed.clone()],
        );
        let proof = Proof::terminating(vec![ProofStep::PolynomialRuleRemoval {
            interpretations: vec![("f".to_string(), 1, vec![1]), ("g".to_string(), 0, vec![1])],
            removed: vec![removed],
            proof: Box::new(Proof::terminating(vec![ProofStep::EmptySystem])),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<ruleRemoval>"));
        assert!(cpf.contains("<polynomial>"));
        assert!(cpf.contains("<rIsEmpty/>"));
    }

    #[test]
    fn writes_and_certifies_cpf3_polynomial_rule_removal_fragment() {
        let removed = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let residual = RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("h", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![removed.clone(), residual],
        );
        let proof = Proof::unknown(
            "residual problem remains",
            vec![ProofStep::PolynomialRuleRemoval {
                interpretations: vec![
                    ("f".to_string(), 1, vec![1]),
                    ("g".to_string(), 0, vec![1]),
                    ("h".to_string(), 0, vec![1]),
                ],
                removed: vec![removed],
                proof: Box::new(Proof::unknown("residual problem remains", Vec::new())),
            }],
        );
        let cpf = write_cpf3_fragment(&trs, &proof).unwrap();
        assert!(cpf.contains("<ruleRemoval>"));
        assert!(cpf.contains("<terminationAssumption>"));
        assert_ceta_certifies_fragment_cpf3(cpf, "ferrum-polynomial-fragment");
    }

    #[test]
    fn cpf3_fragment_rejects_assumption_only_proofs() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let proof = Proof::unknown("nothing transformed", Vec::new());
        assert!(write_cpf3_fragment(&trs, &proof).is_err());
    }

    #[test]
    fn partial_rfc_proofs_use_cpf4() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        let proof = Proof::unknown(
            "residual problem remains",
            vec![ProofStep::RfcBounds {
                proof: BoundsProof {
                    bounds_type: BoundsType::Match,
                    bound: 0,
                    final_states: vec!["q".to_string()],
                    automaton: TreeAutomaton {
                        final_states: vec!["q".to_string()],
                        transitions: vec![TreeAutomatonTransition {
                            lhs: TreeAutomatonTransitionLhs::Symbol {
                                symbol: "b".to_string(),
                                height: Some(0),
                                args: vec!["q".to_string()],
                            },
                            rhs: "q".to_string(),
                        }],
                    },
                    state_compatibility: Vec::new(),
                },
                initial_words: vec![vec![Symbol::new("b")]],
            }],
        );

        let cpf = write_cpf_fragment(&trs, &proof).unwrap();
        assert!(cpf.contains("xsi:noNamespaceSchemaLocation=\"cpf4.xsd\""));
        assert!(cpf.contains("<cpfVersion>4.0</cpfVersion>"));
        assert!(cpf.contains("<rfcBounds>"));
        assert!(write_cpf3_fragment(&trs, &proof).is_err());
    }

    #[test]
    fn writes_and_certifies_standalone_empty_dp_problem() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let proof = DependencyPairProof {
            initial_pairs: 0,
            components: 0,
            removed_pairs: 0,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: Vec::new(),
            component_proofs: Vec::new(),
        };
        let cpf = write_cpf3_dp_problem(&trs, &[], &proof);
        assert!(cpf.contains("<dpInput>"));
        assert!(cpf.contains("<dpProof>"));
        assert!(cpf.contains("<pIsEmpty/>"));
        assert_ceta_certifies_cpf3(cpf, "ferrum-standalone-empty-dp");
    }

    #[test]
    fn writes_cpf3_linear_polynomial_certificate() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let proof = Proof::terminating(vec![ProofStep::LlmLinearPolynomial {
            interpretations: vec![("f".to_string(), 1, vec![1])],
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<cpfVersion>3.0</cpfVersion>"));
        assert!(cpf.contains("<polynomial>"));
        assert!(cpf.contains("<degree>1</degree>"));
    }

    #[test]
    fn local_ceta_native_constant_to_unary_certifies() {
        let trs = Trs::new_with_strategy(None, BTreeSet::new(),
            vec![RewriteRule::new(Term::app("f", vec![Term::app("a", vec![])]),
                                 Term::app("a", vec![]))], RewriteStrategy::Innermost);
        let proof = crate::proving::prove(&trs, &ProveOptions {
            strategy: ProveStrategy::parse("timeout(5s, constant-to-unary; dp)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        });
        assert_eq!(proof.status(), &crate::proving::Status::Terminating);
        let xml = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(xml.contains("<constantToUnary"));
        assert_ceta_certifies_cpf3(xml, "native-constant-to-unary");
    }

    #[test]
    fn local_ceta_native_full_rule_path_order_with_q_certifies() {
        check_native_full_rule_order_with_q_certifies("path-order");
    }

    #[test]
    fn local_ceta_native_conditional_polynomials_and_mutations() {
        for (name, source) in [
            ("cade03", include_str!("../../tests/fixtures/conditional_cade03.ari")),
            ("cade05", include_str!("../../tests/fixtures/conditional_cade05.ari")),
            ("cade13", include_str!("../../tests/fixtures/conditional_cade13.ari")),
        ] {
            let parsed = crate::parsing::parse_ari_trs(None, source).unwrap();
            let trs = Trs::new_with_strategy(None, parsed.variables().clone(), parsed.rules().to_vec(), RewriteStrategy::Innermost);
            for trs in [trs.clone(), crate::standardize::standardize_trs(&trs).unwrap()] {
                let proof = crate::proving::prove(&trs, &ProveOptions {
                    strategy: ProveStrategy::parse("timeout(30s, dp(graph; (conditional-poly(max-coefficient=2,reinduct=1) | size-change | poly(max-constant=2,max-coefficient=2))))").unwrap(),
                    llm_first: false, ..ProveOptions::default()
                });
                assert_eq!(proof.status(), &crate::proving::Status::Terminating);
                let xml = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
                assert!(xml.contains("<generalRedPairProc>"));
                assert_ceta_certifies_cpf3(xml.clone(), &format!("native-conditional-{name}"));
                let missing = replace_xml_section(&xml, "conditions", "<conditions/>");
                assert_ne!(missing, xml);
                assert_ceta_csr_rejects_cpf4(missing, &format!("native-conditional-missing-{name}"));
                let zero_order = replace_xml_section(&xml, "interpretation",
                    "<interpretation><type><polynomial><domain><naturals/></domain><degree>1</degree></polynomial></type></interpretation>");
                assert_ceta_csr_rejects_cpf4(zero_order, &format!("native-conditional-no-order-{name}"));
            }
        }
    }

    #[test]
    fn local_ceta_native_conditional_split_bounds() {
        use crate::proving::{DpProblemState, ProblemState, ProblemCertificate,
            solve_top_level_worklist, complete_dependency_pair_probe};
        let crate::parsing::CpfInputProblem::Dp {
            trs, pairs, active_rules, minimal, normal_form_substitutions,
            innermost_lhss, clear_innermost_lhss, graph_rules, transformation_rules,
            active_rules_are_residual, ordinary_reduction_started, ordinary_bridge_loses_minimality, ..
        } = crate::parsing::parse_cpf_input(None,
            include_str!("../../tests/fixtures/conditional_split_bound.dp.xml")).unwrap()
            else { panic!("DP input") };
        let pairs = pairs.into_iter().enumerate()
            .map(|(i, r)| DependencyPair::from_rule(r, i)).collect();
        let mut state = DpProblemState::materialized_from_parts(
            trs, pairs, vec![], active_rules, minimal, DpOptions::default())
            .with_active_rules_are_residual(active_rules_are_residual)
            .restore_runtime_context(innermost_lhss, clear_innermost_lhss,
                graph_rules, transformation_rules, ordinary_reduction_started,
                ordinary_bridge_loses_minimality)
            .with_normal_form_substitutions(normal_form_substitutions);
        state.options.strategy = Some(DpStrategy::parse(
            "graph | size-change | conditional-poly(max-coefficient=1,before=0,after=1)").unwrap());
        let deadline = Some(std::time::Instant::now() + std::time::Duration::from_secs(60));
        let ProblemCertificate::DependencyPairTree(tree) = solve_top_level_worklist(
            ProblemState::DependencyPairs(state.clone()), &ProveOptions::default(), deadline)
            .expect("native split conditional synthesis") else { panic!("DP proof") };
        let proof = complete_dependency_pair_probe(&state, tree);
        let xml = write_cpf3_dp_termination_state(&state, &proof).unwrap();
        let document = roxmltree::Document::parse(&xml).unwrap();
        let processor = document.descendants().find(|n| n.has_tag_name("generalRedPairProc")).unwrap();
        assert_eq!(processor.children().filter(|n| n.has_tag_name("dpProof")).count(), 2);
        assert_ceta_certifies_cpf3(xml.clone(), "native-conditional-split-bounds");
        let missing = replace_xml_section(&xml, "conditions", "<conditions/>");
        assert_ne!(missing, xml);
        assert_ceta_csr_rejects_cpf4(missing, "native-conditional-split-missing-conditions");
    }

    #[test]
    fn local_ceta_native_quadratic_conditional_two_predecessors() {
        let trs = crate::parsing::parse_ari_trs(None, include_str!("../../tests/fixtures/conditional_beerendonk24.ari")).unwrap();
        let proof = crate::proving::prove(&trs, &ProveOptions {
            strategy: ProveStrategy::parse("timeout(40s, switch-innermost; dp(graph | usable-rules | innermost-lhss | size-change | timeout(5s, rat-poly(max-constant=16,max-coefficient=16,max-symbols=256,max-arity=16,denominator=4,delta-denominator=1)) | conditional-poly(max-coefficient=2,degree=2,before=2,squares=1)))").unwrap(),
            llm_first: false, ..ProveOptions::default()
        });
        assert_eq!(proof.status(), &crate::proving::Status::Terminating);
        let xml = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(xml.contains("<degree>2</degree>"));
        assert!(xml.contains("<before>2</before>"));
        assert_ceta_certifies_cpf3(xml.clone(), "native-quadratic-two-predecessors");
        let missing = replace_xml_section(&xml, "conditions", "<conditions/>");
        assert_ne!(missing, xml);
        assert_ceta_csr_rejects_cpf4(missing, "native-quadratic-missing-conditions");
    }

    #[test]
    fn local_ceta_native_full_rule_kbo_with_q_certifies() {
        check_native_full_rule_order_with_q_certifies("kbo(max-weight=4,max-symbols=16)");
    }

    #[test]
    fn local_ceta_q_filtered_kbo_chain_and_context_mutation() {
        use crate::proving::{DpProblemState, ProblemState, ProblemCertificate, solve_top_level_worklist, complete_dependency_pair_probe};
        let crate::parsing::CpfInputProblem::Dp {
            trs, pairs, active_rules, minimal, normal_form_substitutions,
            innermost_lhss, clear_innermost_lhss, graph_rules, transformation_rules,
            active_rules_are_residual, ordinary_reduction_started, ordinary_bridge_loses_minimality, ..
        } = crate::parsing::parse_cpf_input(None, include_str!("../../tests/fixtures/q_filtered_kbo.dp.xml")).unwrap() else {panic!("DP input")};
        let pairs = pairs.into_iter().enumerate().map(|(i,r)| DependencyPair::from_rule(r,i)).collect();
        let mut state = DpProblemState::materialized_from_parts(trs,pairs,vec![],active_rules,minimal,DpOptions::default())
            .with_active_rules_are_residual(active_rules_are_residual)
            .restore_runtime_context(innermost_lhss,clear_innermost_lhss,graph_rules,transformation_rules,ordinary_reduction_started,ordinary_bridge_loses_minimality)
            .with_normal_form_substitutions(normal_form_substitutions);
        state.options.strategy = Some(DpStrategy::parse("kbo(max-weight=1,max-symbols=256); graph; (weak-poly(min-constant=-2,max-constant=1,max-coefficient=2,max-symbols=256,max-arity=16) | arctic-matrix(dimension=1,max-constant=5,max-coefficient=5,max-symbols=256,max-arity=16))").unwrap());
        let deadline=Some(std::time::Instant::now()+std::time::Duration::from_secs(60));
        let ProblemCertificate::DependencyPairTree(tree)=solve_top_level_worklist(
            ProblemState::DependencyPairs(state.clone()), &ProveOptions::default(),deadline).unwrap() else {panic!("DP proof")};
        let proof=complete_dependency_pair_probe(&state,tree);
        let xml=write_cpf3_dp_termination_state(&state,&proof).unwrap();
        assert!(xml.contains("<redPairUrProc>"));
        assert_ceta_certifies_cpf3(xml.clone(),"native-q-filtered-kbo");
        // Q = empty also admits a separate ordinary usable-rule proof for
        // this example, so it is not a negative mutation. Add an unchecked
        // active root rewrite instead: closure must reject the empty U.
        let t=state.pairs[0].rhs().clone();
        let mut rule=String::new();
        write_rules_cpf3(&mut rule,&[RewriteRule::new(t.clone(),t)],0);
        let rule=rule.trim().strip_prefix("<rules>").unwrap().strip_suffix("</rules>").unwrap();
        let wrong_r=xml.replacen("</rules>",&format!("{rule}</rules>"),1);
        assert_ne!(xml,wrong_r);
        assert_ceta_csr_rejects_cpf4(wrong_r,"native-q-filtered-kbo-extra-rule");
    }

    fn check_native_full_rule_order_with_q_certifies(atom: &str) {
        let trs = crate::parsing::parse_ari_trs(
            Some("innermost-full-rule-path-order".to_owned()),
            include_str!("../../tests/fixtures/innermost_full_rule_path_order.ari"),
        ).unwrap();
        let proof = crate::proving::prove(&trs, &ProveOptions {
            strategy: ProveStrategy::parse(&format!("timeout(10s, dp({atom}))")).unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        });
        assert_eq!(proof.status(), &crate::proving::Status::Terminating);
        let xml = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(xml.contains("<redPairProc>"));
        assert!(xml.contains("<innermost>"));
        assert!(!xml.contains("<innermostLhssProc>"));
        assert_ceta_certifies_cpf3(xml, "native-full-rule-path-order-with-q");
    }

    #[test]
    fn writes_cpf3_variable_condition_no_certificate() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("y"),
            )],
        );
        let proof = crate::proving::prove(
            &trs,
            &crate::proving::ProveOptions {
                strategy: crate::proving::ProveStrategy::parse(
                    "nontermination(variable-condition)",
                )
                .unwrap(),
                llm_first: false,
                ..crate::proving::ProveOptions::default()
            },
        );
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<answer><no/></answer>"));
        assert!(cpf.contains("<trsNonterminationProof>"));
        assert!(cpf.contains("<variableConditionViolated/>"));
    }

    #[test]
    fn writes_cpf3_loop_no_certificate() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            )],
        );
        let proof = crate::proving::prove(&trs, &crate::proving::ProveOptions::default());
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<answer><no/></answer>"));
        assert!(cpf.contains("<loop>"));
        assert!(cpf.contains("<substitution>"));
        assert!(cpf.contains("<box/>"));
    }

    #[test]
    fn loop_term_indentation_is_bounded_without_changing_xml_elements() {
        let mut term = Term::app("f#", vec![Term::var("x<&"), Term::app("constant", vec![])]);
        for _ in 0..512 {
            term = Term::app("a", vec![term]);
        }
        let mut old = String::new();
        let mut bounded = String::new();
        write_term_cpf3(&mut old, &term, 6);
        write_loop_term_cpf3(&mut bounded, &term, 6);
        let tokens = |xml: &str| {
            let doc = roxmltree::Document::parse(xml).unwrap();
            doc.descendants()
                .filter_map(|n| {
                    if n.is_element() {
                        Some(format!("element:{}", n.tag_name().name()))
                    } else {
                        n.text()
                            .filter(|s| !s.trim().is_empty())
                            .map(|s| format!("text:{s}"))
                    }
                })
                .collect::<Vec<_>>()
        };
        assert_eq!(tokens(&old), tokens(&bounded));
        assert!(bounded.len() * 4 < old.len());
    }

    #[test]
    fn ceta_certifies_innermost_switch_to_full_loop() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("a", vec![])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let proof = crate::proving::prove(&trs, &crate::proving::ProveOptions::default());
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<answer><no/></answer>"));
        assert_ceta_certifies(&trs, &proof, "ferrum-innermost-switch-full-loop");
    }

    #[test]
    fn writes_and_certifies_unmarked_cpf3_dp_loop() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app(
                    "h",
                    vec![Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    )],
                ),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("i", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app(
                "i",
                vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
            ),
        );
        let loop_proof = LoopProof {
            start: pair.lhs().clone(),
            steps: vec![LoopRewriteStep {
                position: Vec::new(),
                rule: pair.as_rule(),
                result: pair.rhs().clone(),
            }],
            substitution: BTreeMap::from([(
                Variable::new("x"),
                Term::app("s", vec![Term::var("x")]),
            )]),
            context_position: Vec::new(),
        };
        let proof = DpNonterminationProof::Loop(loop_proof);
        let cpf = write_cpf3_dp_nontermination_problem(&trs, std::slice::from_ref(&pair), &proof)
            .unwrap();
        assert!(cpf.contains("<answer><no/></answer>"));
        assert!(cpf.contains("<dpInput>"));
        assert!(cpf.contains("<dpNonterminationProof>"));
        assert!(cpf.contains("<loop>"));
        assert!(!cpf.contains("<relative/>"));
        assert_ceta_certifies_cpf3(cpf, "ferrum-unmarked-dp-loop");
    }

    #[test]
    fn writes_cpf3_dp_rule_removal_no_certificate() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let kept = dp_pair_for_loop();
        let removed = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![kept.clone(), removed.clone()],
            proof: Box::new(DpNonterminationProof::DpRuleRemoval {
                removed_pairs: vec![removed],
                removed_rules: Vec::new(),
                proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&kept))),
            }),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<dpRuleRemoval>"));
        assert!(cpf.contains("<loop>"));
    }

    #[test]
    fn writes_cpf3_dp_rewriting_no_certificate() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let original = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );
        let rewritten = dp_pair_for_loop();
        let rewrite_rule = RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
        );
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![original.clone()],
            proof: Box::new(DpNonterminationProof::Rewriting {
                step: Box::new(DpRewriteProof {
                    original_pair: original,
                    rewrite_step: LoopRewriteStep {
                        position: vec![1],
                        rule: rewrite_rule.clone(),
                        result: rewritten.rhs().clone(),
                    },
                    rewritten_pair: rewritten.clone(),
                    usable_rules: vec![rewrite_rule],
                    proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&rewritten))),
                }),
            }),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<rewritingProc>"));
        assert!(cpf.contains("<rewriteStep>"));
        assert!(cpf.contains("<usableRules>"));
    }

    #[test]
    fn writes_cpf3_dp_instantiation_no_certificate() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let instantiated = dp_pair_for_loop();
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![instantiated.clone()],
            proof: Box::new(DpNonterminationProof::Instantiation {
                instantiated_pairs: vec![instantiated.clone()],
                proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&instantiated))),
            }),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<instantiationProc>"));
        assert!(cpf.contains("<dpNonterminationProof>"));
    }

    #[test]
    fn writes_cpf3_nonloop_no_certificate_shape() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let pair = dp_pair_for_loop();
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![pair],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule: PatternRule {
                    lhs: Term::app("f#", vec![Term::var("x")]),
                    rhs: Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                    pumping_substitution: BTreeMap::new(),
                    closing_substitution: BTreeMap::new(),
                    rhs_pumping_substitution: None,
                    rhs_closing_substitution: None,
                    proof: PatternRuleProof::OriginalRule {
                        rule: RewriteRule::new(
                            Term::app("f#", vec![Term::var("x")]),
                            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                        ),
                        is_pair: true,
                    },
                },
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 0,
                subterm_index: 0,
                position: Vec::new(),
            })),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<nonLoop>"));
        assert!(cpf.contains("<patternRule>"));
        assert!(cpf.contains("<patternTerm>"));
    }

    #[test]
    fn writes_cpf3_pattern_rule_narrowing_and_equivalence_shape() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let pair = dp_pair_for_loop();
        let original = PatternRule {
            lhs: Term::app("f#", vec![Term::var("x")]),
            rhs: Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: RewriteRule::new(
                    Term::app("f#", vec![Term::var("x")]),
                    Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
                ),
                is_pair: true,
            },
        };
        let narrowed = PatternRule {
            lhs: original.lhs.clone(),
            rhs: Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Narrowing {
                pattern_rule: Box::new(original),
                narrowing_rule: Box::new(PatternRule {
                    lhs: Term::app("h", vec![Term::var("x")]),
                    rhs: Term::app("s", vec![Term::var("x")]),
                    pumping_substitution: BTreeMap::new(),
                    closing_substitution: BTreeMap::new(),
                    rhs_pumping_substitution: None,
                    rhs_closing_substitution: None,
                    proof: PatternRuleProof::OriginalRule {
                        rule: RewriteRule::new(
                            Term::app("h", vec![Term::var("x")]),
                            Term::app("s", vec![Term::var("x")]),
                        ),
                        is_pair: false,
                    },
                }),
                position: vec![0],
            },
        };
        let pattern_rule = PatternRule {
            lhs: narrowed.lhs.clone(),
            rhs: narrowed.rhs.clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Equivalence {
                pattern_rule: Box::new(narrowed),
                side: PatternEquivalenceSide::Right,
                equivalence: PatternEquivalence::DomainRenaming {
                    substitution: BTreeMap::from([(Variable::new("x"), Term::var("y"))]),
                },
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![pair],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 0,
                subterm_index: 0,
                position: Vec::new(),
            })),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<narrowing>"));
        assert!(cpf.contains("<equivalence>"));
        assert!(cpf.contains("<right/>"));
        assert!(cpf.contains("<patternEquivalence>"));
        assert!(cpf.contains("<domainRenaming>"));
    }

    #[test]
    fn writes_cpf3_pattern_rule_rewriting_and_simplification_shape() {
        let original_rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let original = PatternRule {
            lhs: original_rule.lhs().clone(),
            rhs: original_rule.rhs().clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: original_rule.clone(),
                is_pair: false,
            },
        };
        let rewritten_rhs = Term::app("h", vec![Term::var("x")]);
        let rewritten = PatternRule {
            lhs: original.lhs.clone(),
            rhs: rewritten_rhs.clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Rewriting {
                pattern_rule: Box::new(original),
                start: Term::app("g", vec![Term::var("x")]),
                steps: vec![LoopRewriteStep {
                    position: Vec::new(),
                    rule: RewriteRule::new(
                        Term::app("g", vec![Term::var("x")]),
                        rewritten_rhs.clone(),
                    ),
                    result: rewritten_rhs,
                }],
                target: PatternInstantiationTarget::Base,
                variable: None,
            },
        };
        let pattern_rule = PatternRule {
            lhs: rewritten.lhs.clone(),
            rhs: rewritten.rhs.clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Equivalence {
                pattern_rule: Box::new(rewritten),
                side: PatternEquivalenceSide::Right,
                equivalence: PatternEquivalence::Simplification {
                    first_substitution: BTreeMap::new(),
                    second_substitution: BTreeMap::new(),
                },
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("f#", vec![Term::var("x")]),
            )],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 0,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![original_rule],
        );
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<rewriting>"));
        assert!(cpf.contains("<rewriteSequence>"));
        assert!(cpf.contains("<simplification>"));
    }

    #[test]
    fn writes_cpf3_pattern_rule_rewriting_substitution_variable() {
        let original_rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::var("z")]),
        );
        let original = PatternRule {
            lhs: original_rule.lhs().clone(),
            rhs: original_rule.rhs().clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: Some(BTreeMap::from([(
                Variable::new("z"),
                Term::app("g", vec![Term::var("z")]),
            )])),
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: original_rule.clone(),
                is_pair: true,
            },
        };
        let rewritten = PatternRule {
            lhs: original.lhs.clone(),
            rhs: original.rhs.clone(),
            pumping_substitution: original.pumping_substitution.clone(),
            closing_substitution: original.closing_substitution.clone(),
            rhs_pumping_substitution: Some(BTreeMap::from([(
                Variable::new("z"),
                Term::app("h", vec![Term::var("z")]),
            )])),
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Rewriting {
                pattern_rule: Box::new(original),
                start: Term::app("g", vec![Term::var("z")]),
                steps: vec![LoopRewriteStep {
                    position: Vec::new(),
                    rule: RewriteRule::new(
                        Term::app("g", vec![Term::var("z")]),
                        Term::app("h", vec![Term::var("z")]),
                    ),
                    result: Term::app("h", vec![Term::var("z")]),
                }],
                target: PatternInstantiationTarget::Pumping,
                variable: Some(Variable::new("z")),
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("f#", vec![Term::var("z")]),
            )],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule: rewritten,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 1,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        let trs = Trs::new(None, BTreeSet::new(), vec![original_rule]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<pumping>"));
        assert!(cpf.contains("<var>z</var>"));
        assert!(!cpf.contains("__ferrum_pumping"));
    }

    #[test]
    fn writes_cpf3_asymmetric_pattern_rule_substitutions() {
        let rule = PatternRule {
            lhs: Term::app("f#", vec![Term::var("xl")]),
            rhs: Term::app("f#", vec![Term::var("xr")]),
            pumping_substitution: BTreeMap::from([(
                Variable::new("xl"),
                Term::app("s", vec![Term::var("xl")]),
            )]),
            closing_substitution: BTreeMap::from([(Variable::new("xl"), Term::app("0", vec![]))]),
            rhs_pumping_substitution: Some(BTreeMap::from([(
                Variable::new("xr"),
                Term::app("s", vec![Term::var("xr")]),
            )])),
            rhs_closing_substitution: Some(BTreeMap::from([(
                Variable::new("xr"),
                Term::app("0", vec![]),
            )])),
            proof: PatternRuleProof::OriginalRule {
                rule: RewriteRule::new(
                    Term::app("f#", vec![Term::var("xl")]),
                    Term::app("f#", vec![Term::var("xr")]),
                ),
                is_pair: true,
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("xl")]),
                Term::app("f#", vec![Term::var("xr")]),
            )],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule: rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 1,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<var>xl</var>"));
        assert!(cpf.contains("<var>xr</var>"));
        assert!(cpf.contains("<name>s</name>"));
    }

    #[test]
    fn writes_cpf3_pattern_rule_initial_pumping_shapes() {
        let original_rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let original = PatternRule {
            lhs: original_rule.lhs().clone(),
            rhs: original_rule.rhs().clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: original_rule.clone(),
                is_pair: false,
            },
        };
        let mut sigma = BTreeMap::new();
        sigma.insert(Variable::new("x"), Term::app("s", vec![Term::var("x")]));
        let initialized = PatternRule {
            lhs: original.lhs.clone(),
            rhs: original.rhs.clone(),
            pumping_substitution: sigma.clone(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::InitialPumping {
                pattern_rule: Box::new(original),
                pumping_substitution: sigma.clone(),
                closing_substitution: BTreeMap::new(),
            },
        };
        let context = PatternRule {
            lhs: initialized.lhs.clone(),
            rhs: initialized.rhs.clone(),
            pumping_substitution: sigma.clone(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::InitialPumpingContext {
                pattern_rule: Box::new(initialized),
                pumping_substitution: sigma,
                position: vec![1],
                variable: Variable::new("z"),
            },
        };
        let pattern_rule = PatternRule {
            lhs: context.lhs.clone(),
            rhs: context.rhs.clone(),
            pumping_substitution: context.pumping_substitution.clone(),
            closing_substitution: context.closing_substitution.clone(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::InstantiationPumping {
                pattern_rule: Box::new(context),
                power: 2,
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("f#", vec![Term::var("x")]),
            )],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 0,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![original_rule],
        );
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<initialPumping>"));
        assert!(cpf.contains("<initialPumpingContext>"));
        assert!(cpf.contains("<instantiationPumping>"));
    }

    #[test]
    fn writes_cpf3_innermost_strategy() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            Vec::new(),
            RewriteStrategy::Innermost,
        );
        let proof = Proof::terminating(vec![ProofStep::EmptySystem]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<strategy>"));
        assert!(cpf.contains("<innermost><nfs>true</nfs></innermost>"));
    }

    fn dp_pair_for_loop() -> DependencyPair {
        DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
            ),
        )
    }

    fn loop_for_pair(pair: &DependencyPair) -> LoopProof {
        LoopProof {
            start: pair.lhs().clone(),
            steps: vec![LoopRewriteStep {
                position: Vec::new(),
                rule: pair.as_rule(),
                result: pair.rhs().clone(),
            }],
            substitution: BTreeMap::from([(
                Variable::new("x"),
                Term::app("s", vec![Term::var("x")]),
            )]),
            context_position: Vec::new(),
        }
    }

    #[test]
    fn writes_cpf3_path_order_dp_certificate() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::PathOrder {
                order: DpPathOrderKind::Rpo,
                statuses: BTreeMap::from([
                    ("f#".to_string(), DpPathOrderKind::Lpo),
                    ("f".to_string(), DpPathOrderKind::Rpo),
                    ("g".to_string(), DpPathOrderKind::Rpo),
                ]),
                precedence: vec!["f#".to_string(), "g".to_string(), "f".to_string()],
                precedence_ranks: BTreeMap::from([
                    ("f#".to_string(), 0),
                    ("g".to_string(), 1),
                    ("f".to_string(), 2),
                ]),
                argument_filter: BTreeMap::from([
                    (
                        "f#".to_string(),
                        DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    ),
                    (
                        "f".to_string(),
                        DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    ),
                    (
                        "g".to_string(),
                        DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    ),
                ]),
                backend: DpSearchBackend::PathOrder,
            },
        };
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: Some(DpSearchBackend::PathOrder),
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<recursivePathOrder>"));
        assert!(cpf.contains("<statusPrecedenceEntry>"));
        assert!(cpf.contains("<lex/>"));
        assert!(cpf.contains("<mul/>"));
        assert!(cpf.contains("<argumentFilter>"));
    }

    #[test]
    fn ceta_certifies_cpf3_zero_weight_dp_kbo_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Kbo {
                precedence: vec!["s".to_string(), "f#".to_string()],
                precedence_ranks: BTreeMap::from([("s".to_string(), 0), ("f#".to_string(), 1)]),
                weights: BTreeMap::from([("s".to_string(), 0), ("f#".to_string(), 1)]),
                argument_filter: BTreeMap::from([
                    (
                        "f#".to_string(),
                        DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    ),
                    (
                        "s".to_string(),
                        DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    ),
                ]),
                backend: DpSearchBackend::Kbo,
            },
        };
        let proof = dp_proof_from_reduction(vec![pair], reduction);
        assert_ceta_certifies(&trs, &proof, "ferrum-dp-kbo-zero-weight");
    }

    #[test]
    fn writes_cpf3_size_change_subterm_certificate() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair.clone()],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: Vec::new(),
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::SizeChange {
                    graphs: vec![DpSizeChangeGraph {
                        pair,
                        edges: vec![DpSizeChangeEdge {
                            left_position: 1,
                            strict: true,
                            right_position: 1,
                        }],
                    }],
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<sizeChangeProc>"));
        assert!(cpf.contains("<subtermCriterion/>"));
        assert!(cpf.contains("<sizeChangeGraph>"));
        let ceta = Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path = std::env::temp_dir().join("ferrum-size-change-subterm.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(&path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected CPF:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn ceta_certifies_cpf3_general_size_change_certificate_when_available() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("y")]),
                ),
            ],
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
                Term::app("f#", vec![Term::var("x"), Term::var("y")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
                Term::app("f#", vec![Term::var("x"), Term::var("y")]),
            ),
        ];
        let graphs = vec![
            DpSizeChangeGraph {
                pair: pairs[0].clone(),
                edges: vec![
                    DpSizeChangeEdge {
                        left_position: 1,
                        strict: true,
                        right_position: 1,
                    },
                    DpSizeChangeEdge {
                        left_position: 2,
                        strict: false,
                        right_position: 2,
                    },
                ],
            },
            DpSizeChangeGraph {
                pair: pairs[1].clone(),
                edges: vec![
                    DpSizeChangeEdge {
                        left_position: 1,
                        strict: false,
                        right_position: 1,
                    },
                    DpSizeChangeEdge {
                        left_position: 2,
                        strict: true,
                        right_position: 2,
                    },
                ],
            },
        ];
        let dp_proof = DependencyPairProof {
            initial_pairs: 2,
            components: 1,
            removed_pairs: 2,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: pairs.clone(),
            component_proofs: vec![DpComponentProof {
                pairs,
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: Vec::new(),
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::SizeChange { graphs })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<sizeChangeProc>"));
        assert!(cpf.contains("<strict>false</strict>"));

        let ceta = Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path = std::env::temp_dir().join("ferrum-general-size-change.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(&path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected CPF:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn ceta_certifies_cpf3_innermost_size_change_with_q_wrapper() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let options = DpOptions::default();
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None).unwrap();
        assert!(dp_proof.component_proofs.iter().any(|component| matches!(
            component.proof_tree.as_deref(),
            Some(DpProofTree::SizeChange { .. })
        )));
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<sizeChangeProc>"));

        let ceta = Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path = std::env::temp_dir().join("ferrum-innermost-size-change-q.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(&path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected CPF:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn cpf3_serializes_nonmonotone_innermost_rule_deletion_as_q_monotonic() {
        let rule = RewriteRule::new(
            Term::app("h", vec![Term::app("0", Vec::new())]),
            Term::app("a", Vec::new()),
        );
        let reduction = DpRemovalProof {
            pairs: Vec::new(),
            usable_rules: vec![rule.clone()],
            uses_usable_rules: false,
            force_non_mono_usable_rules: false,
            strict_pair_indices: Vec::new(),
            strict_rules: vec![rule],
            reduction_pair: DpReductionPairProof::Matrix {
                interpretation: vec![(
                    "h".to_string(),
                    MatrixInterpretation {
                        constant: vec![0],
                        coefficients: vec![vec![vec![0]]],
                    },
                )],
                dimension: 1,
                strict_dimension: 1,
                backend: DpSearchBackend::Sat,
            },
        };
        let mut cpf = String::new();
        write_red_pair_proc_cpf3(
            &mut cpf,
            &reduction,
            &DpProofTree::Empty,
            RewriteStrategy::Innermost,
            0,
        );
        assert!(cpf.contains("<innermostMonoRedPairProc>"));
        assert!(cpf.contains("<trs>"));
    }

    #[test]
    fn ceta_certifies_cpf3_innermost_pure_size_change_with_nonempty_q_wrapper() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
            ],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Innermost,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair.clone()],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: Some(Vec::new()),
                innermost_lhss_processor: Some(vec![Term::app("a", vec![])]),
                reductions: Vec::new(),
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::SizeChange {
                    graphs: vec![DpSizeChangeGraph {
                        pair,
                        edges: vec![DpSizeChangeEdge {
                            left_position: 1,
                            strict: true,
                            right_position: 1,
                        }],
                    }],
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<innermostLhssRemovalProc>"));
        assert!(cpf.contains("<sizeChangeProc>"));

        let ceta = Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path = std::env::temp_dir().join("ferrum-innermost-size-change-q.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(&path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected pure size-change below non-empty Q:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn ceta_certifies_cpf3_innermost_size_change_red_pair_with_nonempty_q_wrapper() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
            ],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction_pair = DpReductionPairProof::Polynomial {
            interpretation: vec![
                ("f#".to_string(), 0, vec![1]),
                ("s".to_string(), 1, vec![1]),
            ],
            backend: DpSearchBackend::Enumerative,
        };
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Innermost,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair.clone()],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: Some(Vec::new()),
                innermost_lhss_processor: Some(vec![Term::app("a", vec![])]),
                reductions: Vec::new(),
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::SizeChangeRedPair {
                    graphs: vec![DpSizeChangeGraph {
                        pair,
                        edges: vec![DpSizeChangeEdge {
                            left_position: 1,
                            strict: true,
                            right_position: 1,
                        }],
                    }],
                    reduction_pair,
                    usable_rules: Vec::new(),
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<innermostLhssRemovalProc>"));
        assert!(cpf.contains("<sizeChangeProc>"));
        assert!(cpf.contains("<reductionPair>"));

        let ceta = Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path =
                std::env::temp_dir().join("ferrum-innermost-size-change-red-pair-q.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(&path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected CPF:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn writes_cpf3_matrix_interpretation_dp_certificate() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Matrix {
                interpretation: vec![
                    (
                        "f#".to_string(),
                        MatrixInterpretation {
                            constant: vec![0, 0],
                            coefficients: vec![vec![vec![1, 0], vec![0, 1]]],
                        },
                    ),
                    (
                        "s".to_string(),
                        MatrixInterpretation {
                            constant: vec![1, 0],
                            coefficients: vec![vec![vec![1, 0], vec![0, 1]]],
                        },
                    ),
                ],
                dimension: 2,
                strict_dimension: 1,
                backend: DpSearchBackend::Enumerative,
            },
        };
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: Some(DpSearchBackend::Enumerative),
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<matrixInterpretation>"));
        assert!(cpf.contains("<dimension>2</dimension>"));
        assert!(cpf.contains("<strictDimension>1</strictDimension>"));
        assert!(cpf.contains("<matrix>"));
        assert!(cpf.contains("<vector>"));
    }

    #[test]
    fn ceta_certifies_cpf3_integer_matrix_dp_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::IntegerMatrix {
                interpretation: vec![
                    (
                        "f#".to_string(),
                        MatrixInterpretation {
                            constant: vec![0, 0],
                            coefficients: vec![vec![vec![1, 0], vec![0, 0]]],
                        },
                    ),
                    (
                        "s".to_string(),
                        MatrixInterpretation {
                            constant: vec![1, 0],
                            coefficients: vec![vec![vec![1, 0], vec![0, 1]]],
                        },
                    ),
                ],
                dimension: 2,
                strict_dimension: 1,
                backend: DpSearchBackend::Sat,
            },
        };
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: true,
            smt_solved: true,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: Some(DpSearchBackend::Sat),
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<domain><integers/></domain>"));
        assert_ceta_certifies(&trs, &proof, "integer-matrix-dp");
    }

    #[test]
    fn writes_cpf3_max_polynomial_dp_certificate() {
        let (trs, proof) = max_polynomial_dp_proof();
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<maxPoly>"));
        assert!(cpf.contains("<max>"));
        assert!(cpf.contains("<constant>1</constant>"));
        assert!(cpf.contains("<variable>1</variable>"));
    }

    #[test]
    fn writes_cpf3_integer_arctic_domain_and_negative_entries() {
        let mut cpf = String::new();
        let arities = BTreeMap::from([(Symbol::new("f#"), 1)]);
        let interpretations = vec![(
            "f#".to_string(),
            MatrixInterpretation {
                constant: vec![-1],
                coefficients: vec![vec![vec![0]]],
            },
        )];

        write_arctic_matrix_interpretation_for_arities_cpf3(
            &mut cpf,
            arities,
            &interpretations,
            1,
            1,
            ArcticMatrixDomain::Integers,
            0,
        );

        assert!(cpf.contains("<arctic><domain><integers/></domain></arctic>"));
        assert!(cpf.contains("<integer>-1</integer>"));
    }

    #[test]
    fn ceta_certifies_cpf3_max_polynomial_dp_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let (trs, proof) = max_polynomial_dp_proof();
        assert_ceta_certifies(&trs, &proof, "max-polynomial-dp");
    }

    #[test]
    fn writes_cpf3_narrowing_processor() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("y")])]),
                    Term::var("y"),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let narrowed = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("y__n0")])]),
            Term::app("f#", vec![Term::var("y__n0")]),
        );
        let dp_proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 0,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Innermost,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair.clone()],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: Vec::new(),
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::Narrowing {
                    step: DpNarrowingStep {
                        pair,
                        position: vec![1],
                        narrowings: vec![narrowed],
                    },
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<narrowingProc>"));
        assert!(cpf.contains("<positionInTerm>"));
        assert!(cpf.contains("<position>1</position>"));
        assert!(cpf.contains("<narrowings>"));
    }

    #[test]
    fn ceta_certifies_cpf3_narrowing_processor_when_available() {
        let ceta = Path::new("../CeTA-CSR/ceta");
        if !ceta.exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app(
                        "f",
                        vec![Term::app("g", vec![Term::app("s", vec![Term::var("x")])])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("y")])]),
                    Term::var("y"),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let dp_proof = solve_dependency_pairs(&trs, &DpOptions::default()).unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        if !cpf.contains("<narrowingProc>") {
            return;
        }
        let path = std::env::temp_dir().join("ferrum-narrowing.cpf3.xml");
        fs::write(&path, cpf).unwrap();
        let output = Command::new(ceta).arg(&path).output().unwrap();
        assert!(
            output.status.success(),
            "CeTA rejected CPF:\nstdout:\n{}\nstderr:\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn writes_only_strict_dp_pairs_in_each_red_pair_step() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("g", vec![Term::var("y")])],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("y")]),
                ),
            ],
        );
        let pair_one = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
            Term::app("f#", vec![Term::var("x"), Term::var("y")]),
        );
        let pair_two = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::var("x"), Term::app("g", vec![Term::var("y")])],
            ),
            Term::app("f#", vec![Term::var("x"), Term::var("y")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair_one.clone(), pair_two.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![
                    ("f#".to_string(), 0, vec![1, 1]),
                    ("s".to_string(), 1, vec![1]),
                    ("g".to_string(), 0, vec![1]),
                ],
                backend: DpSearchBackend::Enumerative,
            },
        };
        let mut forced_non_mono = reduction.clone();
        forced_non_mono.force_non_mono_usable_rules = true;
        let dp_proof = DependencyPairProof {
            initial_pairs: 2,
            components: 1,
            removed_pairs: 1,
            usable_rules: 0,
            smt_attempted: false,
            smt_solved: false,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair_one.clone(), pair_two.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair_one, pair_two],
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let first_removed_dps = cpf
            .split("<monoRedPairUrProc>")
            .nth(1)
            .and_then(|section| section.split("<dpProof>").next())
            .expect("expected first monoRedPairUrProc dps section");
        assert_eq!(first_removed_dps.matches("<rule>").count(), 1);
        assert!(first_removed_dps.contains("<usableRules>"));

        let mut forced_xml = String::new();
        write_red_pair_proc_cpf3(
            &mut forced_xml,
            &forced_non_mono,
            &DpProofTree::Empty,
            RewriteStrategy::Full,
            0,
        );
        assert!(forced_xml.contains("<redPairUrProc>"), "{forced_xml}");
        assert!(!forced_xml.contains("<monoRedPairUrProc>"), "{forced_xml}");
    }

    #[test]
    fn writes_weak_polynomial_dp_removal_as_non_mono_red_pair() {
        let (trs, proof) = weak_polynomial_zero_coefficient_dp_proof();
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();

        assert!(cpf.contains("<redPairUrProc>"));
        assert!(!cpf.contains("<monoRedPairUrProc>"));
    }

    #[test]
    fn writes_negative_constant_polynomial_dp_removal() {
        let (trs, proof) = negative_constant_polynomial_dp_proof();
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();

        assert!(cpf.contains("<redPairUrProc>"));
        assert!(!cpf.contains("<monoRedPairUrProc>"));
        assert!(cpf.contains("<integer>-1</integer>"));
    }

    #[test]
    fn writes_cpf3_innermost_usable_rules_processor() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        // Exercise the processor explicitly.  The default solver may close
        // this still-minimal innermost component directly with SCT, in which
        // case omitting a redundant usable-rules node is intentional.
        let strategy = DpStrategy::Pipeline(vec![
            DpStrategy::Processor(DpStrategyProcessor::UsableRules),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let dp_proof =
            solve_dependency_pairs_with_strategy(&trs, &DpOptions::default(), &strategy, None)
                .unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<innermost><nfs>true</nfs></innermost>"));
        assert!(cpf.contains("<usableRulesProc>"));
    }

    #[test]
    fn writes_cpf3_remove_non_applicable_rules() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("h", vec![Term::app("g", vec![Term::var("x")])])],
                    ),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("h", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let removed = vec![trs.rules()[0].clone()];
        let remaining = Trs::new_with_strategy(
            None,
            trs.variables().clone(),
            vec![trs.rules()[1].clone()],
            RewriteStrategy::Innermost,
        );
        let remaining_proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(
                solve_dependency_pairs(&remaining, &crate::proving::DpOptions::default()).unwrap(),
            ),
        }]);
        let proof = Proof::terminating(vec![ProofStep::RemoveNonApplicableRules {
            removed,
            proof: Box::new(remaining_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<removeNonApplicableRules>"));
    }

    #[test]
    fn ceta_certifies_cpf3_innermost_usable_rules_processor_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let dp_proof = solve_dependency_pairs(&trs, &DpOptions::default()).unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-innermost-usable-rules-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_cpf3_forward_instantiation_processor_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x"), Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![Term::app("0", Vec::new()), Term::app("0", Vec::new())],
                    ),
                    Term::app("f", vec![Term::app("s", vec![Term::app("0", Vec::new())])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let options = DpOptions {
            max_narrowing_steps: 1,
            ..DpOptions::default()
        };
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::ForwardInstantiation { max_per_pair: None }),
        ]);
        let dp_proof =
            solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None).unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<forwardInstantiationProc>"));
        assert!(cpf.contains("<usableRules>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-forward-instantiation-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_cpf3_path_order_dp_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let dp_proof = solve_dependency_pairs(
            &trs,
            &DpOptions {
                max_symbol_weight: 0,
                max_polynomial_constant: 0,
                max_polynomial_coefficient: 0,
                ..DpOptions::default()
            },
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-path-order-dp-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_cpf3_weak_polynomial_dp_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let (trs, proof) = weak_polynomial_zero_coefficient_dp_proof();
        assert_ceta_certifies(&trs, &proof, "ferrum-weak-polynomial-dp");
    }

    #[test]
    fn ceta_certifies_cpf3_negative_constant_polynomial_dp_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let (trs, proof) = negative_constant_polynomial_dp_proof();
        assert_ceta_certifies(&trs, &proof, "ferrum-negative-polynomial-dp");
    }

    #[test]
    fn ceta_certifies_cpf3_dp_loop_no_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app(
                    "h",
                    vec![Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    )],
                ),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
            ),
        );
        let loop_proof = LoopProof {
            start: pair.lhs().clone(),
            steps: vec![LoopRewriteStep {
                position: Vec::new(),
                rule: pair.as_rule(),
                result: pair.rhs().clone(),
            }],
            substitution: BTreeMap::from([(
                Variable::new("x"),
                Term::app("s", vec![Term::var("x")]),
            )]),
            context_position: Vec::new(),
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![pair],
            proof: Box::new(DpNonterminationProof::Loop(loop_proof)),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path =
            std::env::temp_dir().join(format!("ferrum-dp-loop-no-{}.cpf3.xml", std::process::id()));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_standalone_dp_nontermination_problem_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
        );
        let proof = DpNonterminationProof::Loop(LoopProof {
            start: pair.lhs().clone(),
            steps: vec![LoopRewriteStep {
                position: Vec::new(),
                rule: pair.as_rule(),
                result: pair.rhs().clone(),
            }],
            substitution: BTreeMap::from([(
                Variable::new("x"),
                Term::app("s", vec![Term::var("x")]),
            )]),
            context_position: Vec::new(),
        });
        let cpf = write_cpf3_dp_nontermination_problem(&trs, std::slice::from_ref(&pair), &proof)
            .unwrap();
        assert!(cpf.contains("<dpInput>"));
        assert!(cpf.contains("<answer><no/></answer>"));
        assert!(cpf.contains("<dpNonterminationProof>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-standalone-dp-loop-no-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_relative_steps_in_full_dp_loop_and_rejects_missing_marker() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![Term::app("c", vec![])]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("h#", vec![Term::var("x")]),
            Term::app("h#", vec![Term::app("a", vec![])]),
        );
        let proof = DpNonterminationProof::Loop(LoopProof {
            start: pair.lhs().clone(),
            steps: vec![
                LoopRewriteStep {
                    position: Vec::new(),
                    rule: pair.as_rule(),
                    result: pair.rhs().clone(),
                },
                LoopRewriteStep {
                    position: vec![1],
                    rule: trs.rules()[0].clone(),
                    result: Term::app("h#", vec![Term::app("b", vec![Term::app("c", vec![])])]),
                },
            ],
            substitution: BTreeMap::from([(
                Variable::new("x"),
                Term::app("b", vec![Term::app("c", vec![])]),
            )]),
            context_position: Vec::new(),
        });
        let cpf = write_cpf3_dp_nontermination_problem(&trs, std::slice::from_ref(&pair), &proof)
            .unwrap();
        assert!(cpf.contains("<relative/>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-relative-dp-loop-no-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, &cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        fs::write(&path, cpf.replace("<relative/>", "")).unwrap();
        let mutated = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(!mutated.status.success());
    }

    #[test]
    fn ceta_certifies_cpf3_dp_rule_removal_no_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app(
                        "h",
                        vec![Term::app(
                            "f",
                            vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                        )],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
        );
        let kept = dp_pair_for_loop();
        let removed = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![kept.clone(), removed.clone()],
            proof: Box::new(DpNonterminationProof::DpRuleRemoval {
                removed_pairs: vec![removed],
                removed_rules: Vec::new(),
                proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&kept))),
            }),
        });
        assert_ceta_certifies(&trs, &proof, "ferrum-dp-rule-removal-no");
    }

    #[test]
    fn ceta_certifies_cpf3_dp_instantiation_no_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app(
                    "h",
                    vec![Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    )],
                ),
            )],
        );
        let instantiated = dp_pair_for_loop();
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![instantiated.clone()],
            proof: Box::new(DpNonterminationProof::Instantiation {
                instantiated_pairs: vec![instantiated.clone()],
                proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&instantiated))),
            }),
        });
        assert_ceta_certifies(&trs, &proof, "ferrum-dp-instantiation-no");
    }

    #[test]
    fn ceta_certifies_cpf3_dp_narrowing_no_certificate_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("a", Vec::new())]),
                    Term::app("a", Vec::new()),
                ),
            ],
        );
        let original = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let narrowed = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("a", Vec::new())]),
            Term::app("f#", vec![Term::app("a", Vec::new())]),
        );
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![original.clone()],
            proof: Box::new(DpNonterminationProof::Narrowing {
                step: DpNarrowingStep {
                    pair: original,
                    position: vec![1],
                    narrowings: vec![narrowed.clone()],
                },
                proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&narrowed))),
            }),
        });
        assert_ceta_certifies(&trs, &proof, "ferrum-dp-narrowing-no");
    }

    #[test]
    fn ceta_rejects_innermost_dp_rewriting_no_with_non_normal_pair() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let variables = BTreeSet::from([Variable::new("x")]);
        let rewrite_rule = RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
        );
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::app("h", vec![Term::var("x")])]),
                ),
                rewrite_rule.clone(),
            ],
            RewriteStrategy::Innermost,
        );
        let original = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );
        let extra = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("h#", vec![Term::var("x")]),
        );
        let rewritten = dp_pair_for_loop();
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![original.clone(), extra.clone()],
            proof: Box::new(DpNonterminationProof::Rewriting {
                step: Box::new(DpRewriteProof {
                    original_pair: original,
                    rewrite_step: LoopRewriteStep {
                        position: vec![1],
                        rule: rewrite_rule.clone(),
                        result: rewritten.rhs().clone(),
                    },
                    rewritten_pair: rewritten.clone(),
                    usable_rules: vec![rewrite_rule],
                    proof: Box::new(DpNonterminationProof::DpRuleRemoval {
                        removed_pairs: vec![extra],
                        removed_rules: Vec::new(),
                        proof: Box::new(DpNonterminationProof::Loop(loop_for_pair(&rewritten))),
                    }),
                }),
            }),
        });
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-invalid-innermost-dp-rewriting-no-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(!output.status.success());
        let rejection = format!(
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(rejection.contains("error in DP transformation"));
    }

    #[test]
    fn ceta_certifies_cpf3_simple_nonloop_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("0", vec![]), Term::app("0", vec![])),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                ),
            ],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
        );
        let pump = BTreeMap::from([(Variable::new("x"), Term::app("s", vec![Term::var("x")]))]);
        let close = BTreeMap::from([(Variable::new("x"), Term::app("0", vec![]))]);
        let original = PatternRule {
            lhs: pair.lhs().clone(),
            rhs: pair.rhs().clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: pair.as_rule(),
                is_pair: true,
            },
        };
        let pumped = PatternRule {
            lhs: original.lhs.clone(),
            rhs: original.rhs.clone(),
            pumping_substitution: pump.clone(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Instantiation {
                pattern_rule: Box::new(original),
                substitution: pump.clone(),
                target: PatternInstantiationTarget::Pumping,
            },
        };
        let pattern_rule = PatternRule {
            lhs: pumped.lhs.clone(),
            rhs: pumped.rhs.clone(),
            pumping_substitution: pump,
            closing_substitution: close.clone(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Instantiation {
                pattern_rule: Box::new(pumped),
                substitution: close,
                target: PatternInstantiationTarget::Closing,
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![pair],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 1,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        assert_ceta_certifies(&trs, &proof, "ferrum-simple-nonloop-no");
    }

    #[test]
    fn ceta_certifies_cpf3_initial_pumping_nonloop_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
        );
        let original = PatternRule {
            lhs: pair.lhs().clone(),
            rhs: pair.rhs().clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: pair.as_rule(),
                is_pair: true,
            },
        };
        let sigma = BTreeMap::from([(Variable::new("x"), Term::app("s", vec![Term::var("x")]))]);
        let theta = BTreeMap::from([(
            Variable::new("x"),
            Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
        )]);
        let pattern_rule = PatternRule {
            lhs: original.lhs.clone(),
            rhs: original.rhs.clone(),
            pumping_substitution: sigma.clone(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: Some(theta.clone()),
            rhs_closing_substitution: None,
            proof: PatternRuleProof::InitialPumping {
                pattern_rule: Box::new(original),
                pumping_substitution: sigma,
                closing_substitution: theta,
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![pair],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 2,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        assert_ceta_certifies(&trs, &proof, "ferrum-initial-pumping-nonloop-no");
    }

    #[test]
    fn ceta_certifies_cpf3_pattern_narrowing_nonloop_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("0", vec![]), Term::app("0", vec![])),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::var("x")]),
                ),
            ],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let original = PatternRule {
            lhs: pair.lhs().clone(),
            rhs: pair.rhs().clone(),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: pair.as_rule(),
                is_pair: true,
            },
        };
        let narrowing_rule = PatternRule {
            lhs: Term::app("g", vec![Term::var("x")]),
            rhs: Term::app("s", vec![Term::var("x")]),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::OriginalRule {
                rule: RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::var("x")]),
                ),
                is_pair: false,
            },
        };
        let narrowed = PatternRule {
            lhs: original.lhs.clone(),
            rhs: Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Narrowing {
                pattern_rule: Box::new(original),
                narrowing_rule: Box::new(narrowing_rule),
                position: vec![1],
            },
        };
        let pump = BTreeMap::from([(Variable::new("x"), Term::app("s", vec![Term::var("x")]))]);
        let close = BTreeMap::from([(Variable::new("x"), Term::app("0", vec![]))]);
        let pumped = PatternRule {
            lhs: narrowed.lhs.clone(),
            rhs: narrowed.rhs.clone(),
            pumping_substitution: pump.clone(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Instantiation {
                pattern_rule: Box::new(narrowed),
                substitution: pump.clone(),
                target: PatternInstantiationTarget::Pumping,
            },
        };
        let pattern_rule = PatternRule {
            lhs: pumped.lhs.clone(),
            rhs: pumped.rhs.clone(),
            pumping_substitution: pump,
            closing_substitution: close.clone(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Instantiation {
                pattern_rule: Box::new(pumped),
                substitution: close,
                target: PatternInstantiationTarget::Closing,
            },
        };
        let proof = Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs: vec![pair],
            proof: Box::new(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule,
                pumping_substitution: BTreeMap::new(),
                closing_substitution: BTreeMap::new(),
                pumping_decomposition: 1,
                subterm_index: 1,
                position: Vec::new(),
            })),
        });
        assert_ceta_certifies(&trs, &proof, "ferrum-pattern-narrowing-nonloop-no");
    }

    fn weak_polynomial_zero_coefficient_dp_proof() -> (Trs, Proof) {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![
                        Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                        Term::var("y"),
                    ],
                ),
                Term::app(
                    "f",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![
                    ("f#".to_string(), 0, vec![1, 0]),
                    ("s".to_string(), 1, vec![1]),
                ],
                backend: DpSearchBackend::Smt,
            },
        };
        (trs, dp_proof_from_reduction(vec![pair], reduction))
    }

    fn negative_constant_polynomial_dp_proof() -> (Trs, Proof) {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![
                        Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                        Term::var("y"),
                    ],
                ),
                Term::app(
                    "f",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![
                    ("f#".to_string(), -1, vec![1, 1]),
                    ("s".to_string(), 1, vec![1]),
                ],
                backend: DpSearchBackend::Smt,
            },
        };
        (trs, dp_proof_from_reduction(vec![pair], reduction))
    }

    fn max_polynomial_dp_proof() -> (Trs, Proof) {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::MaxPolynomial {
                interpretation: vec![
                    ("f#".to_string(), vec![(0, vec![1]), (0, vec![0])]),
                    ("s".to_string(), vec![(1, vec![1]), (0, vec![0])]),
                ],
                backend: DpSearchBackend::Smt,
            },
        };
        (trs, dp_proof_from_reduction(vec![pair], reduction))
    }

    fn dp_proof_from_reduction(pairs: Vec<DependencyPair>, reduction: DpRemovalProof) -> Proof {
        let dp_proof = DependencyPairProof {
            initial_pairs: pairs.len(),
            components: 1,
            removed_pairs: reduction.strict_pair_indices.len(),
            usable_rules: reduction.usable_rules.len(),
            smt_attempted: true,
            smt_solved: true,
            strategy: RewriteStrategy::Full,
            pairs: pairs.clone(),
            component_proofs: vec![DpComponentProof {
                pairs,
                usable_rules: Vec::new(),
                interpretation: None,
                backend: None,
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };
        Proof::terminating(vec![ProofStep::DependencyPairProof {
            proof: Box::new(dp_proof),
        }])
    }

    fn assert_ceta_certifies(trs: &Trs, proof: &Proof, name: &str) {
        let cpf = write_cpf(trs, proof, CpfMode::Cpf30).unwrap();
        assert_ceta_certifies_cpf3(cpf, name);
    }

    fn assert_ceta_certifies_cpf3(cpf: String, name: &str) {
        // Different tests can use the same descriptive name concurrently.
        // A PID alone lets one proof overwrite another while CeTA reads it.
        static NEXT_CERTIFICATE: std::sync::atomic::AtomicU64 =
            std::sync::atomic::AtomicU64::new(0);
        let unique = NEXT_CERTIFICATE.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let path = std::env::temp_dir().join(format!("{name}-{}-{unique}.cpf3.xml", std::process::id()));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    fn assert_ceta_certifies_fragment_cpf3(cpf: String, name: &str) {
        let path = std::env::temp_dir().join(format!("{name}-{}.cpf3.xml", std::process::id()));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg("--allow-assumptions")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    fn assert_ceta_certifies_csr(csr: &CsrTrs, proof: &Proof, name: &str) {
        let cpf = write_cpf_csr(csr, proof, CpfMode::Cpf40).unwrap();
        assert_ceta_csr_certifies_cpf4(cpf, name);
    }

    #[test]
    fn writes_degree_two_natural_polynomial_products() {
        let mut xml = String::new();
        write_natural_polynomial_interpretation_for_arities_cpf3(
            &mut xml,
            BTreeMap::from([(Symbol::new("*"), 2)]),
            &[(
                "*".to_string(),
                NaturalPolynomial {
                    constant: 0,
                    linear: vec![1, 1],
                    quadratic: vec![vec![0, 1], vec![0, 0]],
                },
            )],
            2,
            0,
        );

        assert!(xml.contains("<degree>2</degree>"));
        let compact = xml
            .chars()
            .filter(|ch| !ch.is_whitespace())
            .collect::<String>();
        assert!(compact.contains(
            "<product><integer>1</integer><variable>1</variable><variable>2</variable></product>"
        ));
    }

    #[test]
    fn filtered_polynomial_cpf_uses_the_filtered_signature() {
        let arities = BTreeMap::from([(Symbol::new("f"), 3)]);
        let argument_filter = BTreeMap::from([(
            "f".to_string(),
            DpArgumentFilterEntry::NonCollapsing(vec![0, 2]),
        )]);
        let reduction_pair = DpReductionPairProof::NaturalPolynomial {
            interpretation: vec![(
                "f".to_string(),
                NaturalPolynomial {
                    constant: 5,
                    linear: vec![1, 0, 3],
                    quadratic: vec![vec![2, 0, 4], vec![0, 0, 0], vec![6, 0, 8]],
                },
            )],
            degree: 2,
            backend: DpSearchBackend::Sat,
        };

        let (filtered_arities, filtered) =
            filter_polynomial_reduction_pair(&arities, &argument_filter, &reduction_pair);
        assert_eq!(filtered_arities[&Symbol::new("f")], 2);
        let DpReductionPairProof::NaturalPolynomial { interpretation, .. } = filtered else {
            panic!("expected a filtered natural-polynomial interpretation");
        };
        assert_eq!(interpretation[0].1.linear, vec![1, 3]);
        assert_eq!(interpretation[0].1.quadratic, vec![vec![2, 4], vec![6, 8]]);
    }

    #[test]
    fn local_ceta_rule_strengthening_and_mutations() {
        for (prefix, middle, suffix) in [("a", "b", "c"), ("outer", "inner", "tail")] {
            let rhs = Term::app(prefix, vec![Term::app(suffix, vec![Term::var("x")])]);
            let lhs = Term::app(prefix, vec![Term::app(middle, vec![Term::app(suffix, vec![Term::var("x")])])]);
            let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![RewriteRule::new(lhs, rhs)]);
            let proof = crate::proving::prove(&trs, &ProveOptions {
                strategy: ProveStrategy::parse("srs-strip-contexts; srs-length").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            });
            assert_eq!(proof.status(), &Status::Terminating);
            let xml = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
            assert!(xml.contains("<ruleStrengthening>"));
            assert_ceta_csr_certifies_cpf4(xml.clone(), "rule-strengthening-positive");
            let missing = replace_xml_section_after(&xml, "<ruleStrengthening>", "trs", "<trs><rules/></trs>");
            assert_ceta_csr_rejects_cpf4(missing, "rule-strengthening-missing-rules");
            let false_child = replace_xml_section_after(&xml, "<ruleStrengthening>", "trsTerminationProof", "<trsTerminationProof><rIsEmpty/></trsTerminationProof>");
            assert_ceta_csr_rejects_cpf4(false_child, "rule-strengthening-false-child");
        }
    }

    fn assert_ceta_csr_certifies_cpf4(cpf: String, name: &str) {
        let Some(ceta) = local_ceta_csr_binary() else {
            eprintln!("skipping native CSR CeTA smoke test: CeTA-CSR binary is not available");
            return;
        };
        let path = std::env::temp_dir().join(format!("{name}-{}.cpf4.xml", std::process::id()));
        fs::write(&path, cpf).unwrap();
        let mut output = Command::new(&ceta)
            .arg("--allow-assumptions")
            .arg(&path)
            .output()
            .unwrap();
        if !output.status.success()
            && (String::from_utf8_lossy(&output.stdout).contains("usage: ceta")
                || String::from_utf8_lossy(&output.stderr).contains("usage: ceta"))
        {
            output = Command::new(ceta).arg(&path).output().unwrap();
        }
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    fn local_ceta_csr_binary() -> Option<PathBuf> {
        if let Ok(path) = std::env::var("CETA_CSR_BIN") {
            let path = PathBuf::from(path);
            if path.exists() {
                return Some(path);
            }
        }
        let path = PathBuf::from("/work/dfm/festschrift/CeTA-CSR/ceta");
        let current = PathBuf::from("/work/dfm/festschrift/CeTA/ceta");
        if current.exists() {
            return Some(current);
        }
        path.exists().then_some(path)
    }

    fn replace_xml_section(cpf: &str, tag: &str, replacement: &str) -> String {
        let start_tag = format!("<{tag}>");
        let end_tag = format!("</{tag}>");
        let start = cpf.find(&start_tag).expect("fixture section must exist");
        let end = cpf[start..]
            .find(&end_tag)
            .map(|offset| start + offset + end_tag.len())
            .expect("fixture section must close");
        format!("{}{}{}", &cpf[..start], replacement, &cpf[end..])
    }

    fn replace_xml_section_after(cpf: &str, anchor: &str, tag: &str, replacement: &str) -> String {
        let anchor_offset = cpf.find(anchor).expect("fixture anchor must exist");
        let suffix = &cpf[anchor_offset..];
        let replaced = replace_xml_section(suffix, tag, replacement);
        format!("{}{}", &cpf[..anchor_offset], replaced)
    }

    fn replace_nth_xml_section(cpf: &str, tag: &str, index: usize, replacement: &str) -> String {
        let start_tag = format!("<{tag}>");
        let start = cpf
            .match_indices(&start_tag)
            .nth(index)
            .map(|(offset, _)| offset)
            .expect("fixture section must exist");
        let suffix = &cpf[start..];
        let replaced = replace_xml_section(suffix, tag, replacement);
        format!("{}{}", &cpf[..start], replaced)
    }

    fn assert_ceta_csr_rejects_cpf4(cpf: String, name: &str) {
        let Some(ceta) = local_ceta_csr_binary() else {
            eprintln!("skipping CSR CeTA mutation test: CeTA-CSR binary is not available");
            return;
        };
        let path = std::env::temp_dir().join(format!("{name}-{}.cpf4.xml", std::process::id()));
        fs::write(&path, cpf).unwrap();
        let output = Command::new(ceta).arg(&path).output().unwrap();
        let _ = fs::remove_file(path);
        assert!(
            !output.status.success(),
            "mutated certificate {name} was accepted:\n{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }
}

fn escape_xml(input: &str) -> String {
    input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}
