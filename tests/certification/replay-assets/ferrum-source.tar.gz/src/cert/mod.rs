mod cpf;
pub(crate) use cpf::{write_term_cpf3, write_symbol_cpf3};
pub(crate) use cpf::gm04_source_dp_context_xml;

#[cfg(test)]
pub(crate) use cpf::write_csr_dp_input_cpf4;
pub(crate) use cpf::write_csr_state_input_cpf4;
pub use cpf::{
    CpfError, CpfMode, write_cpf, write_cpf_csr, write_cpf_csr_fragment, write_cpf_fragment,
    write_cpf_relative, write_cpf3_dp_nontermination_problem, write_cpf3_dp_problem,
    write_cpf3_fragment, write_csr_input_cpf4, write_dp_input_cpf3, write_relative_trs_input_cpf3,
    write_trs_input_cpf3,
};
pub(crate) use cpf::{
    append_ferrum_dp_state_context, write_cpf3_dp_nontermination_state,
    write_cpf3_dp_termination_state, write_cpf4_csr_dp_termination_state, write_csr_dp_state_input_cpf4,
    write_dp_state_input_cpf3, write_relative_dp_state_input_cpf3,
};
