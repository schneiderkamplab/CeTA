use std::path::{Path, PathBuf};

use walkdir::WalkDir;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TpdbFormat {
    Ari,
    TextTrs,
    Xml,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Benchmark {
    path: PathBuf,
    format: TpdbFormat,
}

impl Benchmark {
    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn format(&self) -> &TpdbFormat {
        &self.format
    }
}

pub fn discover_benchmarks(root: &Path) -> Vec<Benchmark> {
    let mut benchmarks = Vec::new();
    for entry in WalkDir::new(root)
        .into_iter()
        .filter_map(Result::ok)
        .filter(|entry| entry.file_type().is_file())
    {
        let Some(extension) = entry.path().extension().and_then(|ext| ext.to_str()) else {
            continue;
        };
        let format = match extension {
            "ari" => TpdbFormat::Ari,
            "trs" => TpdbFormat::TextTrs,
            "xml" => TpdbFormat::Xml,
            _ => continue,
        };
        benchmarks.push(Benchmark {
            path: entry.path().to_path_buf(),
            format,
        });
    }
    benchmarks.sort_by(|left, right| left.path.cmp(&right.path));
    benchmarks
}
