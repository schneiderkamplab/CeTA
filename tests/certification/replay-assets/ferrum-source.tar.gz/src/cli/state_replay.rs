//! Audit entry point, using the production typed worklist and CPF exporters.
use super::*;
use std::io::Write;
use std::sync::Mutex;
use sha2::{Digest, Sha256};

fn import(problem: CpfInputProblem, options: DpOptions) -> Result<ProblemState> {
    Ok(match problem {
        CpfInputProblem::Trs(trs) => ProblemState::from_trs(trs),
        CpfInputProblem::Relative(relative) => ProblemState::from_relative(relative),
        CpfInputProblem::Csr { csr, boundary } => ProblemState::Csr(crate::proving::CsrProblemState { csr, boundary }),
        CpfInputProblem::Dp { trs, pairs, pair_source_rules, weak_pairs, weak_pair_source_rules,
            strict_rules, active_rules, minimal, normal_form_substitutions, innermost_lhss,
            clear_innermost_lhss, graph_rules, transformation_rules, active_rules_are_residual,
            ordinary_reduction_started, ordinary_bridge_loses_minimality } => {
            let state = DpProblemState::materialized_from_parts(trs,
                dependency_pairs_with_sources(pairs, pair_source_rules),
                dependency_pairs_with_sources(weak_pairs, weak_pair_source_rules),
                active_rules, minimal, options)
                .with_active_rules_are_residual(active_rules_are_residual)
                .with_strict_rules(strict_rules)
                .restore_runtime_context(innermost_lhss, clear_innermost_lhss, graph_rules,
                    transformation_rules, ordinary_reduction_started, ordinary_bridge_loses_minimality)
                .with_normal_form_substitutions(normal_form_substitutions);
            ProblemState::DependencyPairs(state)
        }
        CpfInputProblem::CsrDp { csr, pairs, pair_source_rules, weak_pairs, weak_pair_source_rules,
            strict_rules, active_rules, minimal, construction, graph_estimator, use_qcs_usable_rules,
            innermost_lhss, clear_innermost_lhss, graph_rules, transformation_rules,
            active_rules_are_residual, ordinary_reduction_started, ordinary_bridge_loses_minimality,
            semantic_csr_continuation } => {
            let state = DpProblemState::csr_materialized_from_parts(&csr,
                dependency_pairs_with_sources(pairs, pair_source_rules),
                dependency_pairs_with_sources(weak_pairs, weak_pair_source_rules),
                active_rules, minimal, &construction, &graph_estimator, use_qcs_usable_rules, options)
                .context("invalid typed CSR residual")?
                .with_active_rules_are_residual(active_rules_are_residual)
                .with_strict_rules(strict_rules)
                .restore_runtime_context(innermost_lhss, clear_innermost_lhss, graph_rules,
                    transformation_rules, ordinary_reduction_started, ordinary_bridge_loses_minimality)
                .restore_semantic_csr_continuation(semantic_csr_continuation);
            ProblemState::DependencyPairs(state)
        }
    })
}

fn export(state: &ProblemState, certificate: ProblemCertificate, csr_dp: bool) -> Result<(String, String)> {
    let result = match (state, certificate) {
        (ProblemState::Trs(trs) | ProblemState::Srs(trs), ProblemCertificate::Trs(proof)) =>
            (format!("{:?}", proof.status()), write_cpf_fragment(trs, &proof)?),
        (ProblemState::Csr(csr), ProblemCertificate::Trs(proof)) =>
            (format!("{:?}", proof.status()), write_cpf_csr_fragment(&csr.csr, &proof)?),
        (ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative), ProblemCertificate::Trs(proof)) =>
            (format!("{:?}", proof.status()), write_cpf_relative(relative, &proof, CpfMode::Auto)?),
        (ProblemState::DependencyPairs(dp), ProblemCertificate::DependencyPairTree(tree)) => {
            let proof = complete_dependency_pair_probe(dp, tree);
            ("Terminating".to_owned(), if csr_dp {
                write_cpf4_csr_dp_termination_state(dp, &proof)?
            } else {
                crate::cert::write_cpf3_dp_termination_state(dp, &proof)?
            })
        }
        (ProblemState::DependencyPairs(dp), ProblemCertificate::DependencyPairNontermination(proof)) => {
            // The typed exporter retains active R/minimality and rejects
            // unsupported Q, relative, and normal-form obligations.
            if csr_dp {
                bail!("typed CSR-DP nontermination export is unsupported");
            }
            ("Nonterminating".to_owned(), crate::cert::write_cpf3_dp_nontermination_state(dp, &proof)?)
        }
        _ => bail!("worklist certificate does not match the imported state kind"),
    };
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Trs};

    #[test]
    fn replay_import_preserves_dp_runtime_context() {
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let trs = Trs::new(None, Default::default(), vec![rule.clone()]);
        let state = DpProblemState::materialized_from_parts(trs, vec![], vec![],
            Some(vec![]), false, DpOptions::default())
            .with_active_rules_are_residual(true)
            .with_strict_rules(vec![rule.clone()])
            .restore_runtime_context(Some(vec![rule.lhs().clone()]), false,
                Some(vec![rule.clone()]), Some(vec![rule]), true, true)
            .with_normal_form_substitutions(true);
        let original = serialize_probe_problem_state(&ProblemState::DependencyPairs(state));
        let restored = import(parse_cpf_input(None, &original).unwrap(), DpOptions::default()).unwrap();
        assert_eq!(serialize_probe_problem_state(&restored), original);
    }

    #[test]
    fn replay_import_preserves_nested_csr_boundary() {
        let xml = "<trsInput><trs><rules/></trs><strategy><contextSensitive/></strategy><ferrumCsrBoundary>nested</ferrumCsrBoundary></trsInput>";
        let state = import(parse_cpf_input(None, xml).unwrap(), DpOptions::default()).unwrap();
        let serialized = serialize_probe_problem_state(&state);
        assert!(serialized.contains("<ferrumCsrBoundary>nested</ferrumCsrBoundary>"));
        assert!(matches!(state, ProblemState::Csr(_)));
    }
}

pub(super) fn run(inputs: &Path, manifest: &Path, output: &Path, jobs: usize, timeout_ms: u64) -> Result<()> {
    if std::env::var_os("FERRUM_DP_LLM_NO_FALLBACK").is_none() {
        bail!("this audit requires FERRUM_DP_LLM_NO_FALLBACK=1");
    }
    let paths: Vec<_> = fs::read_to_string(inputs)?.lines().filter(|line| !line.trim().is_empty())
        .map(PathBuf::from).collect();
    fs::create_dir(output)?;
    fs::create_dir(output.join("proofs"))?;
    fs::create_dir(output.join("blocked"))?;
    configure_processor_events(Some(output.join("processor-events.jsonl")))?;
    let log = Mutex::new(fs::OpenOptions::new().create_new(true).write(true).open(output.join("results.jsonl"))?);
    let lookup = crate::llm::UtilityGuidanceLookup::from_path(manifest)?;
    let options = ProveOptions { strategy: ProveStrategy::Processor(ProveStrategyProcessor::Fail),
        llm_first: false, utility_guidance: Some(lookup.clone()),
        dp_options: DpOptions { utility_guidance: Some(lookup.clone()), ..DpOptions::default() },
        ..ProveOptions::default() };
    let pool = rayon::ThreadPoolBuilder::new().num_threads(jobs.max(1)).build()?;
    pool.install(|| paths.par_iter().enumerate().try_for_each(|(index, path)| -> Result<()> {
        let started = Instant::now();
        eprintln!("state-replay input={} phase=start", path.display());
        let mut report = serde_json::json!({"input": path, "index": index, "certified": false});
        let attempt = (|| -> Result<()> {
            let xml = fs::read_to_string(path)?;
            let digest = format!("{:x}", Sha256::digest(xml.as_bytes()));
            report["sha256"] = digest.clone().into();
            let problem = parse_cpf_input(Some(path.display().to_string()), &xml)?;
            let csr_dp = matches!(&problem, CpfInputProblem::CsrDp { .. });
            let state = import(problem, options.dp_options.clone())?;
            let live = serialize_probe_problem_state(&state);
            report["live_sha256"] = format!("{:x}", Sha256::digest(live.as_bytes())).into();
            report["raw_lookup_positive"] = lookup.predict(&live)
                .is_some_and(|prediction| !prediction.ordered_positive.is_empty()).into();
            eprintln!("state-replay input={} phase=worklist elapsed_ms={}", path.display(), started.elapsed().as_millis());
            let deadline = Instant::now() + Duration::from_millis(timeout_ms);
            let context = ProcessorEventContext {
                run_id: processor_event_run_id(), problem_id: path.display().to_string(), category: None,
            };
            let certificate = match with_processor_event_context(context, ||
                solve_top_level_worklist(state.clone(), &options, Some(deadline))) {
                Ok(certificate) => certificate,
                Err(failure) => {
                    report["worklist_failure"] = format!("{:?}", failure.kind).into();
                    if let Some(blocked) = failure.state {
                        fs::write(output.join("blocked").join(format!("{index}-{digest}.cpf")), serialize_probe_problem_state(&blocked))?;
                    }
                    return Ok(());
                }
            };
            let (status, cpf) = export(&state, certificate, csr_dp)?;
            // Distinct invocations must not overwrite each other's evidence,
            // even when two input paths contain identical CPF bytes.
            let proof_path = output.join("proofs").join(format!("{index}-{digest}.cpf.xml"));
            fs::write(&proof_path, cpf)?;
            report["status"] = status.into();
            report["proof"] = proof_path.into_os_string().to_string_lossy().as_ref().into();
            // Preserve identity for subsequent modular extraction. This is
            // producer metadata, explicitly not an independent certificate.
            fs::write(output.join("proofs").join(format!("{index}-{digest}.result.json")),
                serde_json::to_vec(&serde_json::json!({"path": path,
                    "status": report["status"], "certified": false}))?)?;
            Ok(())
        })();
        if let Err(error) = attempt {
            report["error"] = format!("{error:#}").into();
        }
        report["elapsed_ms"] = (started.elapsed().as_millis() as u64).into();
        eprintln!("state-replay input={} phase=finished elapsed_ms={}", path.display(), started.elapsed().as_millis());
        let mut log = log.lock().expect("audit log lock");
        writeln!(log, "{report}")?;
        log.flush()?;
        Ok(())
    }))
}
