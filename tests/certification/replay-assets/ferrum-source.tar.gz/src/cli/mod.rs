use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{Duration, Instant};

use anyhow::{Context, Result, bail};
use clap::{Parser, Subcommand, ValueEnum};
use rayon::prelude::*;

use crate::cert::{
    CpfError, CpfMode, write_cpf, write_cpf_csr, write_cpf_csr_fragment, write_cpf_fragment,
    write_cpf_relative, write_cpf4_csr_dp_termination_state,
    write_csr_state_input_cpf4, write_relative_trs_input_cpf3, write_trs_input_cpf3,
};
use crate::core::{CsrTrs, Trs, TrsIssue};
use crate::llm::{
    LlmBackend, LlmClient, LocalLlmConfig, UtilityGuidanceLookup, parse_proposal_batch,
    proof_state_json, top_level_prompt,
};
use crate::parsing::{
    CpfInputProblem, is_relative_ari, parse_ari_cstrs, parse_ari_relative_trs, parse_cpf_input,
    parse_trs,
};
use crate::proving::{
    ConfiguredTopLevelProcessor, DependencyPair, DpNonterminationProcessor, DpOptions,
    DpProblemState, DpStrategy, ProblemCertificate, ProblemState, ProcessorApplication,
    ProcessorEventContext, ProcessorResult, ProveOptions, ProveStrategy, ProveStrategyProcessor,
    Status, WorklistProcessor, complete_dependency_pair_probe, dependency_pairs,
    next_scheduled_result_with_strategy, prove, prove_context_sensitive, prove_relative,
    serialize_relative_adp_state, set_processor_event_log_path, solve_top_level_worklist,
    standardized_csr_input_cpf4, standardized_relative_trs_input_cpf3, standardized_trs_input_cpf3,
    with_processor_event_context,
};
use crate::tpdb::{Benchmark, TpdbFormat, discover_benchmarks};

mod state_replay;

static CERTIFY_TEMP_COUNTER: AtomicUsize = AtomicUsize::new(0);

fn solve_recursive_dp_probe(
    state: &DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<crate::proving::DependencyPairProof> {
    let ProblemCertificate::DependencyPairTree(tree) =
        solve_recursive_dp_certificate(state, strategy, deadline)? else { return None; };
    Some(complete_dependency_pair_probe(state, tree))
}

fn solve_recursive_dp_certificate(
    state: &DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<ProblemCertificate> {
    let mut root = state.clone();
    // Seed the recipe once. Transformation processors attach a pipeline's
    // remaining tail to each materialized child. Passing the whole original
    // strategy explicitly on every worklist call instead replayed stage one
    // forever and made `probe-cpf --recursive` disagree with normal proving.
    root.options.strategy = Some(strategy.clone());
    let mut options = ProveOptions::default();
    options.dp_options = root.options.clone();
    solve_top_level_worklist(ProblemState::DependencyPairs(root), &options, deadline).ok()
}

fn first_applied_dp_processor(
    state: &DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<ProcessorApplication> {
    let state = ProblemState::DependencyPairs(state.clone());
    let mut cursor = 1;
    loop {
        if deadline.is_some_and(|deadline| Instant::now() >= deadline) {
            return None;
        }
        let attempt =
            next_scheduled_result_with_strategy(&state, cursor, deadline, Some(strategy))?;
        cursor = attempt.next_cursor;
        if let ProcessorResult::Applied(application) = attempt.result {
            return Some(application);
        }
    }
}

fn empty_dp_probe(state: &DpProblemState) -> Option<ProcessorApplication> {
    match crate::proving::EmptySystemProcessor.apply(&ProblemState::DependencyPairs(state.clone()))
    {
        ProcessorResult::Applied(application) => Some(application),
        _ => None,
    }
}

fn dp_probe_strategy(strategy: &str) -> Result<DpStrategy> {
    if strategy == "empty" {
        Ok(DpStrategy::Choice(Vec::new()))
    } else {
        DpStrategy::parse(strategy).map_err(Into::into)
    }
}

#[derive(Debug, Parser)]
#[command(
    author,
    version,
    about = "Ferrum: an LLM-first termination prover for TRSs"
)]
pub struct Args {
    #[command(subcommand)]
    command: CommandKind,
}

#[derive(Debug, Subcommand)]
enum CommandKind {
    Parse {
        input: PathBuf,
    },
    Prove {
        input: PathBuf,
        #[arg(long)]
        cpf: Option<PathBuf>,
        #[arg(long, value_enum, default_value_t = CliCpfMode::Auto)]
        cpf_mode: CliCpfMode,
        #[arg(long)]
        llm_proposals: Option<PathBuf>,
        #[arg(long)]
        llm_model_dir: Option<PathBuf>,
        #[arg(long)]
        utility_guidance_manifest: Option<PathBuf>,
        #[arg(long, value_enum, default_value_t = CliLlmBackend::Vllm)]
        llm_backend: CliLlmBackend,
        #[arg(long)]
        no_top_level_llm: bool,
        #[arg(long, default_value_t = 2)]
        llm_iterations: usize,
        #[arg(long)]
        strategy: Option<String>,
        #[arg(long)]
        strategy_file: Option<PathBuf>,
        #[arg(long, default_value_t = 1.0)]
        timeout_multiplier: f64,
        #[arg(long)]
        processor_events: Option<PathBuf>,
    },
    Dp {
        input: PathBuf,
    },
    CanonicalizeCpf {
        input: PathBuf,
    },
    /// Independently replay typed residual inputs through the oracle-only
    /// worklist, loading the oracle once. Decisions still require CeTA checks.
    ReplayCpfStates {
        #[arg(long)]
        inputs: PathBuf,
        #[arg(long)]
        utility_guidance_manifest: PathBuf,
        #[arg(long)]
        output: PathBuf,
        #[arg(long, default_value_t = 4)]
        jobs: usize,
        #[arg(long, default_value_t = 180_000)]
        timeout_ms: u64,
    },
    ProbeCpf {
        input: PathBuf,
        /// Print outcome/count diagnostics only, after the normal residual
        /// validation and CPF export. Full child contexts remain the default.
        #[arg(long)]
        summary: bool,
        #[arg(long)]
        strategy: Option<String>,
        /// Read the strategy atom from a file. This also avoids the operating
        /// system's per-argument limit for large exact witnesses.
        #[arg(long)]
        strategy_file: Option<PathBuf>,
        #[arg(long, default_value_t = 2_000)]
        timeout_ms: u64,
        #[arg(long)]
        processor_events: Option<PathBuf>,
        #[arg(long)]
        cpf: Option<PathBuf>,
        /// Solve every materialized DP residual with the supplied state-local
        /// strategy/continuation through the universal worklist and reconstruct
        /// one complete proof.
        #[arg(long)]
        recursive: bool,
    },
    Llm {
        #[command(subcommand)]
        command: LlmCommand,
    },
    Tpdb {
        #[command(subcommand)]
        command: TpdbCommand,
    },
    Cert {
        #[command(subcommand)]
        command: CertCommand,
    },
}

#[derive(Debug, Subcommand)]
enum TpdbCommand {
    Discover {
        root: PathBuf,
    },
    CheckParse {
        root: PathBuf,
        #[arg(long)]
        limit: Option<usize>,
        #[arg(long)]
        verbose: bool,
    },
    Prove {
        root: PathBuf,
        #[arg(long)]
        limit: Option<usize>,
        #[arg(long)]
        verbose: bool,
        #[arg(long, default_value_t = 50)]
        progress_every: usize,
        #[arg(long, default_value_t = 8)]
        jobs: usize,
        #[arg(long, value_enum, default_value_t = TpdbSampleMode::First)]
        sample: TpdbSampleMode,
        #[arg(long, default_value_t = 0)]
        seed: u64,
        #[arg(long)]
        llm_model_dir: Option<PathBuf>,
        #[arg(long)]
        utility_guidance_manifest: Option<PathBuf>,
        #[arg(long, value_enum, default_value_t = CliLlmBackend::Vllm)]
        llm_backend: CliLlmBackend,
        #[arg(long)]
        no_top_level_llm: bool,
        #[arg(long, default_value_t = 2)]
        llm_iterations: usize,
        #[arg(long)]
        strategy: Option<String>,
        #[arg(long)]
        strategy_file: Option<PathBuf>,
        #[arg(long, default_value_t = 1.0)]
        timeout_multiplier: f64,
        #[arg(long)]
        processor_events: Option<PathBuf>,
    },
    Certify {
        root: PathBuf,
        #[arg(long)]
        limit: Option<usize>,
        #[arg(long)]
        verbose: bool,
        #[arg(long, default_value_t = 50)]
        progress_every: usize,
        #[arg(long, default_value_t = 8)]
        jobs: usize,
        #[arg(long, value_enum, default_value_t = TpdbSampleMode::First)]
        sample: TpdbSampleMode,
        #[arg(long, default_value_t = 0)]
        seed: u64,
        #[arg(long)]
        llm_model_dir: Option<PathBuf>,
        #[arg(long)]
        utility_guidance_manifest: Option<PathBuf>,
        #[arg(long, value_enum, default_value_t = CliLlmBackend::Vllm)]
        llm_backend: CliLlmBackend,
        #[arg(long)]
        no_top_level_llm: bool,
        #[arg(long, default_value_t = 2)]
        llm_iterations: usize,
        #[arg(long)]
        strategy: Option<String>,
        #[arg(long)]
        strategy_file: Option<PathBuf>,
        #[arg(long, default_value_t = 1.0)]
        timeout_multiplier: f64,
        #[arg(long)]
        processor_events: Option<PathBuf>,
        #[arg(long)]
        ceta: Option<PathBuf>,
        #[arg(long)]
        converter: Option<PathBuf>,
    },
    CloneAri {
        destination: PathBuf,
    },
}

#[derive(Debug, Subcommand)]
enum LlmCommand {
    State { input: PathBuf },
    Prompt { input: PathBuf },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, ValueEnum)]
enum TpdbSampleMode {
    First,
    Random,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
enum CliLlmBackend {
    Vllm,
    Mlx,
    TransformersCpu,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
enum CliCpfMode {
    Auto,
    Cpf21,
    Cpf30,
    Cpf40,
}

impl From<CliCpfMode> for CpfMode {
    fn from(value: CliCpfMode) -> Self {
        match value {
            CliCpfMode::Auto => Self::Auto,
            CliCpfMode::Cpf21 => Self::Cpf21,
            CliCpfMode::Cpf30 => Self::Cpf30,
            CliCpfMode::Cpf40 => Self::Cpf40,
        }
    }
}

impl From<CliLlmBackend> for LlmBackend {
    fn from(value: CliLlmBackend) -> Self {
        match value {
            CliLlmBackend::Vllm => Self::Vllm,
            CliLlmBackend::Mlx => Self::Mlx,
            CliLlmBackend::TransformersCpu => Self::TransformersCpu,
        }
    }
}

#[derive(Debug, Subcommand)]
enum CertCommand {
    Check {
        cpf: PathBuf,
        #[arg(long)]
        ceta: Option<PathBuf>,
        #[arg(long)]
        converter: Option<PathBuf>,
        #[arg(long)]
        cpf3_out: Option<PathBuf>,
    },
}

pub fn run() -> Result<()> {
    let args = Args::parse();
    match args.command {
        CommandKind::Parse { input } => {
            let raw_input = fs::read_to_string(&input)
                .with_context(|| format!("failed to read {}", input.display()))?;
            if raw_input.contains("(format CSTRS)") {
                let csr = parse_ari_cstrs(Some(input.display().to_string()), &raw_input)
                    .with_context(|| format!("failed to parse {}", input.display()))?;
                let trs = csr.trs();
                println!("name: {}", trs.name().unwrap_or("<anonymous>"));
                println!("variables: {}", trs.variables().len());
                println!("rules: {}", trs.rules().len());
                println!("symbols: {}", trs.arities().len());
                println!("strategy: {:?}", trs.strategy());
                println!("context-sensitive: true");
                println!(
                    "replacement-map-symbols: {}",
                    csr.replacement_map().entries().len()
                );
                let issues = trs.validate();
                println!("validation-issues: {}", issues.len());
                for issue in issues {
                    println!("issue: {issue}");
                }
                return Ok(());
            }
            if is_relative_ari(&raw_input)? {
                let relative =
                    parse_ari_relative_trs(Some(input.display().to_string()), &raw_input)
                        .with_context(|| format!("failed to parse {}", input.display()))?;
                println!(
                    "name: {}",
                    relative.strict().name().unwrap_or("<anonymous>")
                );
                println!("strict-rules: {}", relative.strict().rules().len());
                println!("weak-rules: {}", relative.weak_rules().len());
                println!("symbols: {}", relative.union().arities().len());
                println!("strategy: {:?}", relative.strict().strategy());
                println!("relative: true");
                println!("srs-encoded: {}", relative.is_srs_encoded());
                return Ok(());
            }
            let trs = parse_trs(Some(input.display().to_string()), &raw_input)
                .with_context(|| format!("failed to parse {}", input.display()))?;
            println!("name: {}", trs.name().unwrap_or("<anonymous>"));
            println!("variables: {}", trs.variables().len());
            println!("rules: {}", trs.rules().len());
            println!("symbols: {}", trs.arities().len());
            println!("strategy: {:?}", trs.strategy());
            if let Some(srs_rules) = trs.srs_rules() {
                println!("srs-encoded: true");
                println!("srs-rules: {}", srs_rules.len());
            } else {
                println!("srs-encoded: false");
            }
            if let Some(unary_srs_rules) = trs.unary_srs_rules() {
                println!("unary-srs-transform: true");
                println!("unary-srs-rules: {}", unary_srs_rules.len());
            } else {
                println!("unary-srs-transform: false");
            }
            let issues = trs.validate();
            println!("validation-issues: {}", issues.len());
            for issue in issues {
                println!("issue: {issue}");
            }
        }
        CommandKind::Prove {
            input,
            cpf,
            cpf_mode,
            llm_proposals,
            llm_model_dir,
            utility_guidance_manifest,
            llm_backend,
            no_top_level_llm,
            llm_iterations,
            strategy,
            strategy_file,
            timeout_multiplier,
            processor_events,
        } => {
            configure_processor_events(processor_events)?;
            let raw_input = fs::read_to_string(&input)
                .with_context(|| format!("failed to read {}", input.display()))?;
            let proposals = match llm_proposals {
                Some(path) => {
                    let input = fs::read_to_string(&path)
                        .with_context(|| format!("failed to read {}", path.display()))?;
                    parse_proposal_batch(&input)
                        .with_context(|| format!("failed to parse {}", path.display()))?
                        .candidates
                }
                None => Vec::new(),
            };
            let llm_client = llm_client(llm_model_dir, llm_backend)?;
            let utility_guidance = utility_guidance(utility_guidance_manifest)?;
            let mut options = ProveOptions {
                strategy: prove_strategy_options(
                    strategy.as_deref(),
                    strategy_file.as_deref(),
                    timeout_multiplier,
                )?,
                llm_first: !no_top_level_llm,
                llm_proposals: proposals,
                llm_client: llm_client.clone(),
                utility_guidance: utility_guidance.clone(),
                llm_iterations,
                dp_options: dp_options(llm_client, utility_guidance, llm_iterations),
                ..ProveOptions::default()
            };
            options.dp_options.llm_iterations = llm_iterations;
            let is_cstrs = raw_input.contains("(format CSTRS)");
            let is_relative = !is_cstrs && is_relative_ari(&raw_input)?;
            let proof = if is_cstrs {
                let csr = parse_ari_cstrs(Some(input.display().to_string()), &raw_input)
                    .with_context(|| format!("failed to parse {}", input.display()))?;
                prove_context_sensitive(&csr, &options)
            } else if is_relative {
                let relative =
                    parse_ari_relative_trs(Some(input.display().to_string()), &raw_input)
                        .with_context(|| format!("failed to parse {}", input.display()))?;
                prove_relative(&relative, &options)
            } else {
                let trs = parse_trs(Some(input.display().to_string()), &raw_input)
                    .with_context(|| format!("failed to parse {}", input.display()))?;
                prove(&trs, &options)
            };
            println!("status: {:?}", proof.status());
            for step in proof.steps() {
                // Large reconstructed DP/CSR trees can contain hundreds of
                // rules and components. Formatting the complete Debug value
                // used to cost tens of seconds after proof search had already
                // finished. Keep the normal CLI result compact; retain the
                // old diagnostic output behind an explicit opt-in.
                if std::env::var_os("FERRUM_PRINT_PROOF_DEBUG").is_some() {
                    println!("step: {step:?}");
                } else {
                    println!("step: {}", proof_step_name(step));
                }
            }
            if let Some(path) = cpf {
                if is_cstrs {
                    let csr = parse_ari_cstrs(Some(input.display().to_string()), &raw_input)
                        .with_context(|| format!("failed to parse {}", input.display()))?;
                    fs::write(&path, write_cpf_csr(&csr, &proof, cpf_mode.into())?)
                        .with_context(|| format!("failed to write {}", path.display()))?;
                    println!("cpf: {}", path.display());
                    if proof.status() == &Status::Unknown {
                        bail!(
                            "Ferrum could not prove or disprove termination with implemented processors"
                        );
                    }
                    return Ok(());
                }
                if is_relative {
                    let relative =
                        parse_ari_relative_trs(Some(input.display().to_string()), &raw_input)
                            .with_context(|| format!("failed to parse {}", input.display()))?;
                    if proof.status() == &Status::Unknown {
                        bail!(
                            "Ferrum could not prove or disprove relative termination with implemented processors"
                        );
                    }
                    fs::write(
                        &path,
                        write_cpf_relative(&relative, &proof, cpf_mode.into())?,
                    )
                    .with_context(|| format!("failed to write {}", path.display()))?;
                    println!("cpf: {}", path.display());
                    return Ok(());
                }
                let trs = parse_trs(Some(input.display().to_string()), &raw_input)
                    .with_context(|| format!("failed to parse {}", input.display()))?;
                fs::write(&path, write_cpf(&trs, &proof, cpf_mode.into())?)
                    .with_context(|| format!("failed to write {}", path.display()))?;
                println!("cpf: {}", path.display());
            }
            if proof.status() == &Status::Unknown {
                bail!("Ferrum could not prove or disprove termination with implemented processors");
            }
        }
        CommandKind::Dp { input } => {
            let trs = read_trs(&input)?;
            let pairs = dependency_pairs(&trs);
            println!("dependency-pairs: {}", pairs.len());
            for pair in pairs {
                println!("{} -> {}", pair.lhs(), pair.rhs());
            }
        }
        CommandKind::CanonicalizeCpf { input } => {
            let raw_input = fs::read_to_string(&input)
                .with_context(|| format!("failed to read {}", input.display()))?;
            let problem = parse_cpf_input(Some(input.display().to_string()), &raw_input)
                .with_context(|| format!("failed to parse CPF input {}", input.display()))?;
            let (canonical, error) = match problem {
                CpfInputProblem::Trs(trs) => standardized_trs_input_cpf3(&trs),
                CpfInputProblem::Relative(relative) => {
                    standardized_relative_trs_input_cpf3(&relative)
                }
                CpfInputProblem::Dp {
                    trs,
                    pairs,
                    pair_source_rules,
                    weak_pairs,
                    weak_pair_source_rules,
                    strict_rules,
                    active_rules,
                    minimal,
                    normal_form_substitutions,
                    innermost_lhss,
                    clear_innermost_lhss,
                    graph_rules,
                    transformation_rules,
                    active_rules_are_residual,
                    ordinary_reduction_started,
                    ordinary_bridge_loses_minimality,
                } => {
                    let has_runtime_context = pair_source_rules.is_some()
                        || weak_pair_source_rules.is_some()
                        || !strict_rules.is_empty()
                        || innermost_lhss.is_some()
                        || clear_innermost_lhss
                        || graph_rules.is_some()
                        || transformation_rules.is_some()
                        || active_rules_are_residual
                        || ordinary_reduction_started
                        || ordinary_bridge_loses_minimality;
                    let pairs = dependency_pairs_with_sources(pairs, pair_source_rules);
                    let weak_pairs =
                        dependency_pairs_with_sources(weak_pairs, weak_pair_source_rules);
                    if !has_runtime_context {
                        crate::proving::standardized_relative_dp_state_input_cpf3(
                            &trs,
                            &pairs,
                            &weak_pairs,
                            active_rules.as_deref(),
                            minimal,
                            normal_form_substitutions,
                        )
                    } else {
                        let state = DpProblemState::materialized_from_parts(
                            trs,
                            pairs,
                            weak_pairs,
                            active_rules,
                            minimal,
                            DpOptions::default(),
                        )
                        .with_active_rules_are_residual(active_rules_are_residual)
                        .with_strict_rules(strict_rules)
                        .restore_runtime_context(
                            innermost_lhss,
                            clear_innermost_lhss,
                            graph_rules,
                            transformation_rules,
                            ordinary_reduction_started,
                            ordinary_bridge_loses_minimality,
                        )
                        .with_normal_form_substitutions(normal_form_substitutions);
                        crate::proving::standardized_dp_problem_state_input_cpf(&state)
                    }
                }
                CpfInputProblem::Csr { csr, .. } => standardized_csr_input_cpf4(&csr),
                CpfInputProblem::CsrDp {
                    csr,
                    pairs,
                    pair_source_rules,
                    weak_pairs,
                    weak_pair_source_rules,
                    strict_rules,
                    active_rules,
                    minimal,
                    construction,
                    graph_estimator,
                    use_qcs_usable_rules,
                    innermost_lhss,
                    clear_innermost_lhss,
                    graph_rules,
                    transformation_rules,
                    active_rules_are_residual,
                    ordinary_reduction_started,
                    ordinary_bridge_loses_minimality,
                    semantic_csr_continuation,
                } => {
                    let pairs = dependency_pairs_with_sources(pairs, pair_source_rules);
                    let weak_pairs =
                        dependency_pairs_with_sources(weak_pairs, weak_pair_source_rules);
                    let state = DpProblemState::csr_materialized_from_parts(
                        &csr,
                        pairs,
                        weak_pairs,
                        active_rules,
                        minimal,
                        &construction,
                        &graph_estimator,
                        use_qcs_usable_rules,
                        DpOptions::default(),
                    )
                    .expect("parsed CSR-DP state must remain valid")
                    .with_active_rules_are_residual(active_rules_are_residual)
                    .with_strict_rules(strict_rules)
                    .restore_runtime_context(
                        innermost_lhss,
                        clear_innermost_lhss,
                        graph_rules,
                        transformation_rules,
                        ordinary_reduction_started,
                        ordinary_bridge_loses_minimality,
                    )
                    .restore_semantic_csr_continuation(semantic_csr_continuation);
                    crate::proving::standardized_dp_problem_state_input_cpf(&state)
                }
            };
            if let Some(error) = error {
                bail!("failed to standardize CPF input: {error}");
            }
            print!("{canonical}");
        }
        CommandKind::ReplayCpfStates { inputs, utility_guidance_manifest, output, jobs, timeout_ms } => {
            state_replay::run(&inputs, &utility_guidance_manifest, &output, jobs, timeout_ms)?;
        }
        CommandKind::ProbeCpf {
            input,
            summary,
            strategy,
            strategy_file,
            timeout_ms,
            processor_events,
            cpf,
            recursive,
        } => {
            configure_processor_events(processor_events)?;
            let strategy = match (strategy, strategy_file) {
                (Some(strategy), None) => strategy,
                (None, Some(path)) => fs::read_to_string(&path)
                    .with_context(|| format!("failed to read strategy file {}", path.display()))?,
                (Some(_), Some(_)) => {
                    bail!("use exactly one of --strategy and --strategy-file")
                }
                (None, None) => bail!("missing --strategy or --strategy-file"),
            };
            let strategy = strategy.trim().to_string();
            let raw_input = fs::read_to_string(&input)
                .with_context(|| format!("failed to read {}", input.display()))?;
            let problem = parse_cpf_input(Some(input.display().to_string()), &raw_input)
                .with_context(|| format!("failed to parse CPF input {}", input.display()))?;
            let started = Instant::now();
            let deadline = Instant::now() + Duration::from_millis(timeout_ms);
            let context = ProcessorEventContext {
                run_id: processor_event_run_id(),
                problem_id: std::env::var("FERRUM_PROCESSOR_EVENT_PROBLEM_ID")
                    .unwrap_or_else(|_| input.display().to_string()),
                category: std::env::var("FERRUM_PROCESSOR_EVENT_CATEGORY").ok(),
            };
            let (level, outcome, details) = with_processor_event_context(
                context,
                || -> Result<_> {
                    match problem {
                        CpfInputProblem::Trs(trs) => {
                            let state = if trs.srs_rules().is_some() {
                                ProblemState::Srs(trs.clone())
                            } else {
                                ProblemState::Trs(trs.clone())
                            };
                            materialize_top_level_atom_probe(
                                state,
                                TopLevelProbeRoot::Trs(&trs),
                                &strategy,
                                deadline,
                                recursive,
                                cpf.as_deref(),
                            )
                        }
                        CpfInputProblem::Relative(relative) => {
                            let state = if relative.strict().srs_rules().is_some() {
                                ProblemState::RelativeSrs(relative.clone())
                            } else {
                                ProblemState::RelativeTrs(relative.clone())
                            };
                            materialize_top_level_atom_probe(
                                state,
                                TopLevelProbeRoot::Relative(&relative),
                                &strategy,
                                deadline,
                                recursive,
                                cpf.as_deref(),
                            )
                        }
                        CpfInputProblem::Csr { csr, boundary } => materialize_top_level_atom_probe(
                            ProblemState::Csr(crate::proving::CsrProblemState {
                                csr: csr.clone(),
                                boundary,
                            }),
                            TopLevelProbeRoot::Csr(&csr),
                            &strategy,
                            deadline,
                            recursive,
                            cpf.as_deref(),
                        ),
                        CpfInputProblem::CsrDp {
                            csr,
                            pairs,
                            pair_source_rules,
                            weak_pairs,
                            weak_pair_source_rules,
                            strict_rules,
                            active_rules,
                            minimal,
                            construction,
                            graph_estimator,
                            use_qcs_usable_rules,
                            innermost_lhss,
                            clear_innermost_lhss,
                            graph_rules,
                            transformation_rules,
                            active_rules_are_residual,
                            ordinary_reduction_started,
                            ordinary_bridge_loses_minimality,
                            semantic_csr_continuation,
                        } => {
                            if strategy.eq_ignore_ascii_case("nontermination") {
                                bail!(
                                    "context-sensitive DP nontermination probing is not supported"
                                );
                            }
                            let empty_probe = strategy == "empty";
                            let strategy = dp_probe_strategy(&strategy).with_context(|| {
                                format!("failed to parse atomic DP strategy {strategy:?}")
                            })?;
                            let pairs = dependency_pairs_with_sources(pairs, pair_source_rules);
                            let weak_pairs =
                                dependency_pairs_with_sources(weak_pairs, weak_pair_source_rules);
                            let state = DpProblemState::csr_materialized_from_parts(
                                &csr,
                                pairs.clone(),
                                weak_pairs,
                                active_rules.clone(),
                                minimal,
                                &construction,
                                &graph_estimator,
                                use_qcs_usable_rules,
                                DpOptions::default(),
                            )
                            .context("invalid context-sensitive DP probe state")?
                            .with_active_rules_are_residual(active_rules_are_residual)
                            .with_strict_rules(strict_rules)
                            .restore_runtime_context(
                                innermost_lhss,
                                clear_innermost_lhss,
                                graph_rules,
                                transformation_rules,
                                ordinary_reduction_started,
                                ordinary_bridge_loses_minimality,
                            )
                            .restore_semantic_csr_continuation(semantic_csr_continuation);
                            let (residuals, selected_atom, proof) = if recursive {
                                (
                                    Vec::new(),
                                    Some(strategy.to_strategy_atom()),
                                    solve_recursive_dp_probe(&state, &strategy, Some(deadline)),
                                )
                            } else if let Some(application) = if empty_probe {
                                empty_dp_probe(&state)
                            } else {
                                first_applied_dp_processor(&state, &strategy, Some(deadline))
                            } {
                                let (mut residuals, selected_atom, reconstruction) =
                                    application.into_parts_with_selected_atom();
                                let children = if recursive && !residuals.is_empty() {
                                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                                        for residual in &residuals {
                                            if let ProblemState::DependencyPairs(problem) = residual
                                            {
                                                eprintln!(
                                                    "recursive probe starting pairs={} strategy={:?} remaining_ms={}",
                                                    problem.pairs.len(),
                                                    problem.options.strategy,
                                                    deadline
                                                        .saturating_duration_since(Instant::now())
                                                        .as_millis(),
                                                );
                                            }
                                        }
                                    }
                                    match crate::proving::solve_worklist_lazy_until(
                                        residuals.clone(),
                                        || Instant::now() >= deadline,
                                        |state, cursor, _| {
                                            crate::proving::next_scheduled_result(
                                                state,
                                                cursor,
                                                Some(deadline),
                                            )
                                        },
                                    ) {
                                        Ok(children) => Some(children),
                                        Err(error) => {
                                            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                                                eprintln!(
                                                    "recursive probe residual failed: {error:?}"
                                                );
                                            }
                                            None
                                        }
                                    }
                                } else {
                                    residuals
                                        .iter()
                                        .map(|residual| match residual {
                                            ProblemState::DependencyPairs(residual)
                                                if residual.pairs.is_empty() =>
                                            {
                                                Some(ProblemCertificate::DependencyPairTree(
                                                    crate::proving::DpProofTree::Empty,
                                                ))
                                            }
                                            _ => None,
                                        })
                                        .collect::<Option<Vec<_>>>()
                                };
                                let proof = if residuals.is_empty() || children.is_some() {
                                    match reconstruction.reconstruct(children.unwrap_or_default()) {
                                        Some(ProblemCertificate::DependencyPairTree(tree)) => {
                                            Some(complete_dependency_pair_probe(&state, tree))
                                        }
                                        // Ordinary nontermination CPF cannot discard CSR context.
                                        Some(ProblemCertificate::DependencyPairNontermination(
                                            _,
                                        )) => None,
                                        _ => None,
                                    }
                                } else {
                                    None
                                };
                                if proof.is_some() {
                                    residuals.clear();
                                }
                                (residuals, selected_atom, proof)
                            } else {
                                (Vec::new(), None, None)
                            };
                            let outcome = if !residuals.is_empty() {
                                "transformed"
                            } else if proof.is_some() {
                                "solved"
                            } else if Instant::now() >= deadline {
                                "timeout"
                            } else {
                                "failed"
                            };
                            let children = serialize_probe_children(&residuals);
                            let cpf_export = if !children.is_empty() {
                                serde_json::json!({
                                    "status": "residual-manifest",
                                    "children": children.clone(),
                                })
                            } else if let Some(proof) = proof.as_ref() {
                                write_probe_cpf(
                                    cpf.as_deref(),
                                    write_cpf4_csr_dp_termination_state(&state, proof),
                                )
                            } else {
                                serde_json::json!({
                                    "status": "not-positive",
                                    "reason": "processor was inapplicable"
                                })
                            };
                            if outcome == "transformed" {
                                verify_probe_child_bijection(&cpf_export, &children)?;
                            }
                            Ok((
                                "context-sensitive-dependency-pair",
                                outcome,
                                serde_json::json!({
                                    "status": if outcome == "solved" { "Terminating" } else { "Unknown" },
                                    "proof": proof.as_ref().map(|proof| format!("{proof:?}")),
                                    "selected_atom": selected_atom,
                                    "cpf_export": cpf_export,
                                    "children": children,
                                }),
                            ))
                        }
                        CpfInputProblem::Dp {
                            trs,
                            pairs,
                            pair_source_rules,
                            weak_pairs,
                            weak_pair_source_rules,
                            strict_rules,
                            active_rules,
                            minimal,
                            normal_form_substitutions,
                            innermost_lhss,
                            clear_innermost_lhss,
                            graph_rules,
                            transformation_rules,
                            active_rules_are_residual,
                            ordinary_reduction_started,
                            ordinary_bridge_loses_minimality,
                        } => {
                            let nontermination = strategy.eq_ignore_ascii_case("nontermination");
                            let empty_probe = strategy == "empty";
                            if strategy.eq_ignore_ascii_case("termination") {
                                bail!(
                                    "probe-cpf requires one atomic DP processor, not the termination scheduler alias"
                                );
                            }
                            let strategy = (!nontermination)
                                .then(|| dp_probe_strategy(&strategy))
                                .transpose()
                                .with_context(|| {
                                    format!("failed to parse atomic DP strategy {strategy:?}")
                                })?;
                            let pairs = dependency_pairs_with_sources(pairs, pair_source_rules);
                            let weak_pairs =
                                dependency_pairs_with_sources(weak_pairs, weak_pair_source_rules);
                            if nontermination {
                                if !weak_pairs.is_empty() || !strict_rules.is_empty() {
                                    bail!(
                                        "DP nontermination probing does not support relative weak pairs"
                                    );
                                }
                                let state = DpProblemState::from_parts(
                                    trs.clone(),
                                    pairs.clone(),
                                    Vec::new(),
                                    active_rules,
                                    minimal,
                                    DpOptions::default(),
                                )
                                .with_active_rules_are_residual(active_rules_are_residual)
                                .restore_runtime_context(
                                    innermost_lhss,
                                    clear_innermost_lhss,
                                    graph_rules,
                                    transformation_rules,
                                    ordinary_reduction_started,
                                    ordinary_bridge_loses_minimality,
                                )
                                .with_normal_form_substitutions(normal_form_substitutions);
                                let proof = match (DpNonterminationProcessor {
                                    deadline: Some(deadline),
                                })
                                .apply(&ProblemState::DependencyPairs(state.clone()))
                                {
                                    ProcessorResult::Applied(application)
                                        if application.residuals.is_empty() =>
                                    {
                                        match application.reconstruct(Vec::new()) {
                                            Some(
                                                ProblemCertificate::DependencyPairNontermination(
                                                    proof,
                                                ),
                                            ) => Some(proof),
                                            _ => None,
                                        }
                                    }
                                    _ => None,
                                };
                                let outcome = if proof.is_some() {
                                    "solved"
                                } else if Instant::now() >= deadline {
                                    "timeout"
                                } else {
                                    "failed"
                                };
                                return Ok((
                                    "dependency-pair",
                                    outcome,
                                    serde_json::json!({
                                        "status": if proof.is_some() { "Nonterminating" } else { "Unknown" },
                                        "proof": proof.as_ref().map(|proof| format!("{proof:?}")),
                                        "cpf_export": proof
                                            .as_ref()
                                            .map(|proof| write_probe_cpf(
                                                cpf.as_deref(),
                                                crate::cert::write_cpf3_dp_nontermination_state(
                                                    &state,
                                                    proof,
                                                ),
                                            ))
                                            .unwrap_or_else(|| serde_json::json!({
                                                "status": "not-positive",
                                                "reason": "processor was inapplicable"
                                            })),
                                    }),
                                ));
                            }
                            let state = DpProblemState::materialized_from_parts(
                                trs.clone(),
                                pairs.clone(),
                                weak_pairs,
                                active_rules,
                                minimal,
                                DpOptions::default(),
                            )
                            .with_active_rules_are_residual(active_rules_are_residual)
                            .with_strict_rules(strict_rules)
                            .restore_runtime_context(
                                innermost_lhss,
                                clear_innermost_lhss,
                                graph_rules,
                                transformation_rules,
                                ordinary_reduction_started,
                                ordinary_bridge_loses_minimality,
                            )
                            .with_normal_form_substitutions(normal_form_substitutions);
                            let strategy =
                                strategy.as_ref().expect("nontermination returned above");
                            let (residuals, selected_atom, proof) = if recursive {
                                let proof = match solve_recursive_dp_certificate(&state, strategy, Some(deadline)) {
                                    Some(ProblemCertificate::DependencyPairTree(tree)) => Some(complete_dependency_pair_probe(&state, tree)),
                                    Some(ProblemCertificate::DependencyPairNontermination(proof)) => {
                                        return Ok((
                                            "dependency-pair", "solved", serde_json::json!({
                                                "status": "Nonterminating",
                                                "selected_atom": strategy.to_strategy_atom(),
                                                "children": [],
                                                "cpf_export": write_probe_cpf(cpf.as_deref(),
                                                    crate::cert::write_cpf3_dp_nontermination_state(&state, &proof)),
                                            }),
                                        ));
                                    }
                                    _ => None,
                                };
                                (
                                    Vec::new(),
                                    Some(strategy.to_strategy_atom()),
                                    proof,
                                )
                            } else if let Some(application) = if empty_probe {
                                empty_dp_probe(&state)
                            } else {
                                first_applied_dp_processor(&state, strategy, Some(deadline))
                            } {
                                let (mut residuals, selected_atom, reconstruction) =
                                    application.into_parts_with_selected_atom();
                                let children = if recursive && !residuals.is_empty() {
                                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                                        for residual in &residuals {
                                            if let ProblemState::DependencyPairs(problem) = residual
                                            {
                                                eprintln!(
                                                    "recursive probe starting pairs={} strategy={:?} remaining_ms={}",
                                                    problem.pairs.len(),
                                                    problem.options.strategy,
                                                    deadline
                                                        .saturating_duration_since(Instant::now())
                                                        .as_millis(),
                                                );
                                            }
                                        }
                                    }
                                    match crate::proving::solve_worklist_lazy_until(
                                        residuals.clone(),
                                        || Instant::now() >= deadline,
                                        |state, cursor, _| {
                                            crate::proving::next_scheduled_result(
                                                state,
                                                cursor,
                                                Some(deadline),
                                            )
                                        },
                                    ) {
                                        Ok(children) => Some(children),
                                        Err(error) => {
                                            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                                                eprintln!(
                                                    "recursive probe residual failed: {error:?}"
                                                );
                                            }
                                            None
                                        }
                                    }
                                } else {
                                    residuals
                                        .iter()
                                        .map(|residual| match residual {
                                            ProblemState::DependencyPairs(residual)
                                                if residual.pairs.is_empty() =>
                                            {
                                                Some(ProblemCertificate::DependencyPairTree(
                                                    crate::proving::DpProofTree::Empty,
                                                ))
                                            }
                                            _ => None,
                                        })
                                        .collect::<Option<Vec<_>>>()
                                };
                                let proof = if residuals.is_empty() || children.is_some() {
                                    match reconstruction.reconstruct(children.unwrap_or_default()) {
                                        Some(ProblemCertificate::DependencyPairTree(tree)) => {
                                            Some(complete_dependency_pair_probe(&state, tree))
                                        }
                                        Some(ProblemCertificate::DependencyPairNontermination(
                                            proof,
                                        )) => {
                                            // Preserve the polarity of an atomic loop/non-loop
                                            // certificate instead of treating it as inapplicable.
                                            return Ok((
                                                "dependency-pair",
                                                "solved",
                                                serde_json::json!({
                                                    "status": "Nonterminating",
                                                    "selected_atom": selected_atom,
                                                    "children": [],
                                                    "cpf_export": write_probe_cpf(cpf.as_deref(),
                                                        crate::cert::write_cpf3_dp_nontermination_state(&state, &proof)),
                                                }),
                                            ));
                                        }
                                        _ => None,
                                    }
                                } else {
                                    None
                                };
                                if proof.is_some() {
                                    residuals.clear();
                                }
                                (residuals, selected_atom, proof)
                            } else {
                                (Vec::new(), None, None)
                            };
                            let outcome = if !residuals.is_empty() {
                                "transformed"
                            } else if proof.is_some() {
                                "solved"
                            } else if Instant::now() >= deadline {
                                "timeout"
                            } else {
                                "failed"
                            };
                            let children = serialize_probe_children(&residuals);
                            let cpf_export = if !children.is_empty() {
                                serde_json::json!({
                                    "status": "residual-manifest",
                                    "children": children.clone(),
                                })
                            } else if let Some(proof) = proof.as_ref() {
                                write_probe_cpf(
                                    cpf.as_deref(),
                                    crate::cert::write_cpf3_dp_termination_state(&state, proof),
                                )
                            } else {
                                serde_json::json!({
                                    "status": "not-positive",
                                    "reason": "processor was inapplicable"
                                })
                            };
                            if outcome == "transformed" {
                                verify_probe_child_bijection(&cpf_export, &children)?;
                            }
                            Ok((
                                "dependency-pair",
                                outcome,
                                serde_json::json!({
                                    "status": if outcome == "solved" { "Terminating" } else { "Unknown" },
                                    "proof": proof.as_ref().map(|proof| format!("{proof:?}")),
                                    "selected_atom": selected_atom,
                                    "cpf_export": cpf_export,
                                    "children": children,
                                }),
                            ))
                        }
                    }
                },
            )?;
            if summary {
                println!(
                    "{}",
                    probe_summary(level, outcome, &details, started.elapsed().as_millis())
                );
            } else {
                println!(
                    "{}",
                    serde_json::json!({
                        "schema": "ferrum.canonical-probe.v1",
                        "level": level,
                        "problem_kind": probe_problem_kind(&raw_input),
                        "strategy_atom": details
                            .get("selected_atom")
                            .and_then(serde_json::Value::as_str)
                            .unwrap_or(&strategy),
                        "outcome": outcome,
                        "typed_outcome": typed_probe_outcome(outcome, &details),
                        "context": probe_context_json(&raw_input),
                        "children": probe_children_from_details(&details),
                        "transition": {
                            "processor_atom": details
                                .get("selected_atom")
                                .and_then(serde_json::Value::as_str)
                                .unwrap_or(&strategy),
                            "fragment": details.get("cpf_export"),
                            "soundness": "requires-independent-check",
                            "completeness": "processor-specific",
                        },
                        "elapsed_ms": started.elapsed().as_millis(),
                        "details": details,
                    })
                );
            }
        }
        CommandKind::Llm { command } => match command {
            LlmCommand::State { input } => {
                let trs = read_trs(&input)?;
                println!("{}", proof_state_json(&trs)?);
            }
            LlmCommand::Prompt { input } => {
                let trs = read_trs(&input)?;
                println!("{}", top_level_prompt(&trs, &[])?);
            }
        },
        CommandKind::Tpdb { command } => match command {
            TpdbCommand::Discover { root } => {
                let benchmarks = discover_benchmarks(&root);
                let ari = benchmarks
                    .iter()
                    .filter(|benchmark| benchmark.format() == &TpdbFormat::Ari)
                    .count();
                let trs = benchmarks
                    .iter()
                    .filter(|benchmark| benchmark.format() == &TpdbFormat::TextTrs)
                    .count();
                let xml = benchmarks
                    .iter()
                    .filter(|benchmark| benchmark.format() == &TpdbFormat::Xml)
                    .count();
                println!("benchmarks: {}", benchmarks.len());
                println!("ari: {ari}");
                println!("trs: {trs}");
                println!("xml: {xml}");
            }
            TpdbCommand::CheckParse {
                root,
                limit,
                verbose,
            } => {
                let benchmarks = discover_benchmarks(&root);
                let selected = benchmarks
                    .iter()
                    .filter(|benchmark| benchmark.format() != &TpdbFormat::Xml);
                let parse_limit = limit.unwrap_or(usize::MAX);
                let mut parsed = 0usize;
                let mut failed = 0usize;
                let mut invalid = 0usize;
                let mut skipped = 0usize;
                for benchmark in selected {
                    if parsed + invalid + failed >= parse_limit {
                        break;
                    }
                    let input = fs::read_to_string(benchmark.path()).with_context(|| {
                        format!("failed to read {}", benchmark.path().display())
                    })?;
                    if benchmark.format() == &TpdbFormat::Ari
                        && !input.contains("(format TRS)")
                        && !input.contains("(format CSTRS)")
                    {
                        skipped += 1;
                        continue;
                    }
                    let parse_result = if input.contains("(format CSTRS)") {
                        parse_ari_cstrs(Some(benchmark.path().display().to_string()), &input)
                            .map(|csr| csr.trs().clone())
                    } else {
                        parse_trs(Some(benchmark.path().display().to_string()), &input)
                    };
                    match parse_result {
                        Ok(problem) => {
                            let issues = problem.validate();
                            if issues.is_empty() {
                                parsed += 1;
                            } else {
                                invalid += 1;
                                if verbose {
                                    println!("INVALID {}", benchmark.path().display());
                                    for issue in issues {
                                        println!("  {issue}");
                                    }
                                }
                            }
                        }
                        Err(error) => {
                            failed += 1;
                            if verbose {
                                println!("FAIL {}: {error}", benchmark.path().display());
                            }
                        }
                    }
                }
                println!("parsed: {parsed}");
                println!("invalid: {invalid}");
                println!("failed: {failed}");
                println!("skipped-non-trs: {skipped}");
            }
            TpdbCommand::Prove {
                root,
                limit,
                verbose,
                progress_every,
                jobs,
                sample,
                seed,
                llm_model_dir,
                utility_guidance_manifest,
                llm_backend,
                no_top_level_llm,
                llm_iterations,
                strategy,
                strategy_file,
                timeout_multiplier,
                processor_events,
            } => {
                configure_processor_events(processor_events)?;
                let llm_client = llm_client(llm_model_dir, llm_backend)?;
                let utility_guidance = utility_guidance(utility_guidance_manifest)?;
                let run_id = processor_event_run_id();
                let category = tpdb_category_name(&root);
                prove_tpdb(
                    ProveTpdbConfig {
                        root,
                        limit,
                        verbose,
                        progress_every,
                        jobs,
                        sample,
                        seed,
                        run_id,
                        category,
                    },
                    ProveOptions {
                        strategy: prove_strategy_options(
                            strategy.as_deref(),
                            strategy_file.as_deref(),
                            timeout_multiplier,
                        )?,
                        llm_first: !no_top_level_llm,
                        llm_proposals: Vec::new(),
                        llm_client: llm_client.clone(),
                        utility_guidance: utility_guidance.clone(),
                        llm_iterations,
                        dp_options: dp_options(llm_client, utility_guidance, llm_iterations),
                        ..ProveOptions::default()
                    },
                )?
            }
            TpdbCommand::Certify {
                root,
                limit,
                verbose,
                progress_every,
                jobs,
                sample,
                seed,
                llm_model_dir,
                utility_guidance_manifest,
                llm_backend,
                no_top_level_llm,
                llm_iterations,
                strategy,
                strategy_file,
                timeout_multiplier,
                processor_events,
                ceta,
                converter,
            } => {
                configure_processor_events(processor_events)?;
                let llm_client = llm_client(llm_model_dir, llm_backend)?;
                let utility_guidance = utility_guidance(utility_guidance_manifest)?;
                let run_id = processor_event_run_id();
                let category = tpdb_category_name(&root);
                certify_tpdb(
                    CertifyTpdbConfig {
                        root,
                        limit,
                        verbose,
                        progress_every,
                        jobs,
                        sample,
                        seed,
                        ceta,
                        converter,
                        run_id,
                        category,
                    },
                    ProveOptions {
                        strategy: prove_strategy_options(
                            strategy.as_deref(),
                            strategy_file.as_deref(),
                            timeout_multiplier,
                        )?,
                        llm_first: !no_top_level_llm,
                        llm_proposals: Vec::new(),
                        llm_client: llm_client.clone(),
                        utility_guidance: utility_guidance.clone(),
                        llm_iterations,
                        dp_options: dp_options(llm_client, utility_guidance, llm_iterations),
                        ..ProveOptions::default()
                    },
                )?
            }
            TpdbCommand::CloneAri { destination } => clone_tpdb_ari(&destination)?,
        },
        CommandKind::Cert { command } => match command {
            CertCommand::Check {
                cpf,
                ceta,
                converter,
                cpf3_out,
            } => check_certificate(&cpf, ceta, converter, cpf3_out)?,
        },
    }
    Ok(())
}

fn llm_client(model_dir: Option<PathBuf>, backend: CliLlmBackend) -> Result<Option<LlmClient>> {
    model_dir
        .map(|model_dir| {
            LlmClient::from_local_config(LocalLlmConfig {
                model_dir,
                backend: backend.into(),
            })
        })
        .transpose()
        .context("failed to initialize LLM client")
}

fn utility_guidance(path: Option<PathBuf>) -> Result<Option<UtilityGuidanceLookup>> {
    path.map(|path| {
        UtilityGuidanceLookup::from_path(&path)
            .with_context(|| format!("failed to load {}", path.display()))
    })
    .transpose()
}

fn dp_options(
    llm_client: Option<LlmClient>,
    utility_guidance: Option<UtilityGuidanceLookup>,
    llm_iterations: usize,
) -> crate::proving::DpOptions {
    crate::proving::DpOptions {
        llm_client,
        utility_guidance,
        llm_iterations,
        ..crate::proving::DpOptions::default()
    }
}

fn dependency_pairs_with_sources(
    rules: Vec<crate::core::RewriteRule>,
    source_rules: Option<Vec<usize>>,
) -> Vec<DependencyPair> {
    rules
        .into_iter()
        .enumerate()
        .map(|(index, rule)| {
            DependencyPair::from_rule(
                rule,
                source_rules
                    .as_ref()
                    .and_then(|sources| sources.get(index))
                    .copied()
                    .unwrap_or(index),
            )
        })
        .collect()
}

fn configure_processor_events(path: Option<PathBuf>) -> Result<()> {
    if let Some(path) = path {
        set_processor_event_log_path(path).map_err(|path| {
            anyhow::anyhow!("processor event log already set: {}", path.display())
        })?;
    }
    Ok(())
}

enum TopLevelProbeRoot<'a> {
    Trs(&'a Trs),
    Csr(&'a CsrTrs),
    Relative(&'a crate::core::RelativeTrs),
}

fn atomic_top_level_strategy(input: &str) -> Result<ProveStrategyProcessor> {
    match ProveStrategy::parse(input)
        .with_context(|| format!("failed to parse atomic strategy {input:?}"))?
    {
        ProveStrategy::Processor(processor) => Ok(processor),
        _ => bail!(
            "probe-cpf requires exactly one processor atom; composition belongs to the universal worklist"
        ),
    }
}

fn serialize_probe_problem_state(state: &ProblemState) -> String {
    match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => write_trs_input_cpf3(trs),
        ProblemState::Csr(state) => write_csr_state_input_cpf4(&state.csr, state.boundary),
        ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => {
            write_relative_trs_input_cpf3(relative)
        }
        ProblemState::DependencyPairs(state) => crate::proving::dp_state_input_cpf(state),
        ProblemState::RelativeAnnotatedDependencyPairs(state) => {
            serialize_relative_adp_state(state)
        }
    }
}

fn probe_assumption_kind(state: &ProblemState) -> &'static str {
    match state {
        ProblemState::DependencyPairs(_) => "finitenessAssumption",
        ProblemState::Csr(_) => "csrTerminationAssumption",
        ProblemState::RelativeAnnotatedDependencyPairs(_) => "relativeAdpAssumption",
        ProblemState::Trs(_)
        | ProblemState::Srs(_)
        | ProblemState::RelativeTrs(_)
        | ProblemState::RelativeSrs(_) => "terminationAssumption",
    }
}

fn serialize_probe_children(residuals: &[ProblemState]) -> Vec<serde_json::Value> {
    residuals
        .iter()
        .enumerate()
        .map(|(index, residual)| {
            let cpf = serialize_probe_problem_state(residual);
            serde_json::json!({
                "index": index, "cpf": cpf,
                "problem_kind": probe_problem_kind(&cpf),
                "context": probe_context_json(&cpf),
                "assumption_kind": probe_assumption_kind(residual),
            })
        })
        .collect()
}

fn materialize_top_level_atom_probe(
    state: ProblemState,
    root: TopLevelProbeRoot<'_>,
    strategy: &str,
    deadline: Instant,
    recursive: bool,
    cpf_path: Option<&Path>,
) -> Result<(&'static str, &'static str, serde_json::Value)> {
    if recursive && strategy != "empty" {
        let options = ProveOptions {
            strategy: ProveStrategy::parse(strategy)?,
            llm_first: false,
            ..ProveOptions::default()
        };
        let certificate = match solve_top_level_worklist(state, &options, Some(deadline)) {
            Ok(certificate) => certificate,
            Err(failure) => return Ok(("top-level", "failed",
                serde_json::json!({"status":"Unknown", "reason":format!("{failure:?}")}))),
        };
        let ProblemCertificate::Trs(proof) = certificate else {
            bail!("recursive top-level probe reconstructed the wrong certificate kind");
        };
        let cpf = match root {
            TopLevelProbeRoot::Trs(trs) => write_cpf_fragment(trs, &proof),
            TopLevelProbeRoot::Csr(csr) => write_cpf_csr_fragment(csr, &proof),
            TopLevelProbeRoot::Relative(relative) => write_cpf_relative(relative, &proof, CpfMode::Auto),
        };
        return Ok(("top-level", "solved", serde_json::json!({
            "status":format!("{:?}", proof.status()),
            "proof_steps":proof.steps().len(),
            "cpf_export":write_probe_cpf(cpf_path, cpf),
            "children":[],
        })));
    }
    let options = ProveOptions {
        llm_first: false,
        ..ProveOptions::default()
    };
    let result = if strategy == "empty" {
        crate::proving::EmptySystemProcessor.apply(&state)
    } else {
        let processor = atomic_top_level_strategy(strategy)?;
        ConfiguredTopLevelProcessor {
            processor: &processor,
            options: &options,
            deadline: Some(deadline),
        }
        .apply(&state)
    };
    let application = match result {
        ProcessorResult::Applied(application) => application,
        ProcessorResult::Inapplicable => {
            return Ok((
                "top-level",
                "failed",
                serde_json::json!({"status":"Unknown","reason":"processor was inapplicable"}),
            ));
        }
        ProcessorResult::Failed { reason } => {
            return Ok((
                "top-level",
                "failed",
                serde_json::json!({"status":"Unknown","reason":reason}),
            ));
        }
        ProcessorResult::TimedOut => {
            return Ok((
                "top-level",
                "timeout",
                serde_json::json!({"status":"Unknown","reason":"processor timed out"}),
            ));
        }
    };
    let (residuals, selected_atom, reconstruction) = application.into_parts_with_selected_atom();
    let children = residuals
        .iter()
        .enumerate()
        .map(|(index, residual)| {
            let cpf = serialize_probe_problem_state(residual);
            serde_json::json!({
                "index": index,
                "cpf": cpf,
                "problem_kind": probe_problem_kind(&cpf),
                "context": probe_context_json(&cpf),
                "assumption_kind": probe_assumption_kind(residual),
            })
        })
        .collect::<Vec<_>>();
    if !residuals.is_empty() {
        // A transformation is represented by its exact residual vector, not
        // by an open or assumption-bearing proof fragment. Reconstruction is
        // invoked only after the universal worklist has solved every child.
        let cpf_export = serde_json::json!({
            "status": "residual-manifest",
            "children": children.clone(),
        });
        verify_probe_child_bijection(&cpf_export, &children)?;
        return Ok((
            "top-level",
            "transformed",
            serde_json::json!({
                "status": "Unknown",
                "selected_atom": selected_atom,
                "cpf_export": cpf_export,
                "children": children,
            }),
        ));
    }
    let certificate = reconstruction
        .reconstruct(Vec::new())
        .ok_or_else(|| anyhow::anyhow!("terminal atomic processor failed reconstruction"))?;
    let ProblemCertificate::Trs(proof) = certificate else {
        bail!("top-level atom reconstructed the wrong certificate kind");
    };
    let fragment = match root {
        TopLevelProbeRoot::Trs(trs) => write_cpf_fragment(trs, &proof),
        TopLevelProbeRoot::Csr(csr) => write_cpf_csr_fragment(csr, &proof),
        TopLevelProbeRoot::Relative(relative) => {
            write_cpf_relative(relative, &proof, CpfMode::Auto)
        }
    };
    let cpf_export = write_probe_cpf(cpf_path, fragment);
    Ok((
        "top-level",
        "solved",
        serde_json::json!({
            "status": format!("{:?}", proof.status()),
            "proof_steps": proof.steps().len(),
            "selected_atom": selected_atom,
            "cpf_export": cpf_export,
            "children": children,
        }),
    ))
}

fn write_probe_cpf(path: Option<&Path>, cpf: Result<String, CpfError>) -> serde_json::Value {
    let Some(path) = path else {
        return serde_json::json!({"status": "not-requested"});
    };
    match cpf {
        Ok(xml) => match fs::write(path, xml) {
            Ok(()) => serde_json::json!({
                "status": "written",
                "path": path,
                "children": [],
            }),
            Err(error) => serde_json::json!({
                "status": "error",
                "reason": error.to_string(),
            }),
        },
        Err(error) => serde_json::json!({
            "status": "unsupported",
            "reason": error.to_string(),
        }),
    }
}

fn typed_probe_outcome(outcome: &str, details: &serde_json::Value) -> &'static str {
    match outcome {
        "solved" => "Solved",
        "transformed" => "Transformed",
        "timeout" => "TimedOut",
        "failed"
            if details
                .get("cpf_export")
                .and_then(|export| export.get("status"))
                .and_then(serde_json::Value::as_str)
                == Some("error") =>
        {
            "Failed"
        }
        "failed" => "Inapplicable",
        _ => "Failed",
    }
}

/// An explicit diagnostic-only view. Do not duplicate residual XML or imply
/// that the summary itself can reconstruct a proof. The normal probe has
/// already validated its child bijection and exported any terminal proof.
fn probe_summary(
    level: &str,
    outcome: &str,
    details: &serde_json::Value,
    elapsed_ms: u128,
) -> serde_json::Value {
    let children = details
        .get("children")
        .and_then(serde_json::Value::as_array)
        .filter(|items| !items.is_empty())
        .or_else(|| details.get("cpf_export")?.get("children")?.as_array());
    let export = details.get("cpf_export");
    serde_json::json!({
        "schema": "ferrum.canonical-probe-summary.v1",
        "level": level,
        "outcome": outcome,
        "typed_outcome": typed_probe_outcome(outcome, details),
        "child_count": children.map_or(0, Vec::len),
        "elapsed_ms": elapsed_ms,
        "cpf_export": {
            "status": export.and_then(|e| e.get("status")),
            "path": export.and_then(|e| e.get("path")),
            "reason": export.and_then(|e| e.get("reason")),
        },
        "soundness": "requires-independent-check",
    })
}

fn probe_problem_kind(raw: &str) -> &'static str {
    let lowered = raw.to_ascii_lowercase();
    let dp = lowered.contains("<dpinput");
    let csr = lowered.contains("<contextsensitive");
    let minimal = lowered.contains("<minimal>true");
    if dp && csr && minimal {
        "qcs-dp"
    } else if dp && csr {
        "csdp"
    } else if dp && minimal {
        "qdp"
    } else if dp {
        "dp"
    } else if csr {
        "cs-trs"
    } else if lowered.contains("<string") || lowered.contains("<word") {
        "srs"
    } else if lowered.contains("<innermost") {
        "innermost-trs"
    } else {
        "trs"
    }
}

fn probe_context_json(raw: &str) -> serde_json::Value {
    let lowered = raw.to_ascii_lowercase();
    serde_json::json!({
        "strategy": if lowered.contains("<contextsensitive") {
            "context-sensitive"
        } else if lowered.contains("<innermost") {
            "innermost"
        } else {
            "full"
        },
        "minimal": if lowered.contains("<minimal>true") {
            Some(true)
        } else if lowered.contains("<minimal>false") {
            Some(false)
        } else {
            None
        },
        "replacement_map_present": lowered.contains("<contextsensitive"),
        "usable_rules_present": lowered.contains("<usablerules"),
        "weak_dps_present": lowered.contains("<ferrumweakdps"),
        "q_present": lowered.contains("<q>")
            || lowered.contains("<q ")
            || lowered.contains("<q/"),
        "source_cpf": raw,
    })
}

fn verify_probe_child_bijection(
    cpf_export: &serde_json::Value,
    expected: &[serde_json::Value],
) -> Result<()> {
    let exported = cpf_export
        .get("children")
        .and_then(serde_json::Value::as_array)
        .ok_or_else(|| anyhow::anyhow!("transformed probe CPF did not expose child obligations"))?;
    if exported.len() != expected.len() {
        bail!(
            "runtime/CPF child mismatch: runtime produced {} child obligation(s), CPF exposed {}",
            expected.len(),
            exported.len()
        );
    }
    for (index, (runtime, cpf)) in expected.iter().zip(exported).enumerate() {
        let runtime_kind = runtime
            .get("assumption_kind")
            .and_then(serde_json::Value::as_str);
        let cpf_kind = cpf
            .get("assumption_kind")
            .and_then(serde_json::Value::as_str);
        if runtime_kind != cpf_kind {
            bail!(
                "runtime/CPF child {index} assumption mismatch: runtime={runtime_kind:?}, CPF={cpf_kind:?}"
            );
        }
        let runtime_input = runtime
            .get("cpf")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| anyhow::anyhow!("runtime child {index} has no CPF input"))?;
        let cpf_input = cpf
            .get("cpf")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| anyhow::anyhow!("CPF child {index} has no input"))?;
        let runtime_signature = probe_xml_signature(runtime_input)?;
        let cpf_signature = probe_xml_signature(cpf_input)?;
        if runtime_signature != cpf_signature {
            let first_difference = runtime_signature
                .chars()
                .zip(cpf_signature.chars())
                .position(|(runtime, cpf)| runtime != cpf)
                .unwrap_or_else(|| {
                    runtime_signature
                        .chars()
                        .count()
                        .min(cpf_signature.chars().count())
                });
            let runtime_context = runtime_signature
                .chars()
                .skip(first_difference.saturating_sub(80))
                .take(160)
                .collect::<String>();
            let cpf_context = cpf_signature
                .chars()
                .skip(first_difference.saturating_sub(80))
                .take(160)
                .collect::<String>();
            bail!(
                "runtime/CPF child {index} proof obligations differ at structural character \
                 {first_difference}: runtime={runtime_context:?}, CPF={cpf_context:?}"
            );
        }
    }
    Ok(())
}

fn probe_xml_signature(raw: &str) -> Result<String> {
    fn append_node(node: roxmltree::Node<'_, '_>, output: &mut String) {
        if node.is_element() {
            let name = node.tag_name().name();
            // Ferrum's construction and graph-estimator annotations guide
            // recursive search but are not part of the CPF proof obligation
            // understood by CeTA.  Compare every semantic CPF field while
            // allowing that private annotation to remain event-local.
            if matches!(name, "ferrumCsrDpContext" | "ferrumDpStateContext") {
                return;
            }
            output.push('<');
            output.push_str(&format!("{}:{name}", name.len()));
            let mut attributes = node
                .attributes()
                .map(|attribute| (attribute.name(), attribute.value()))
                .collect::<Vec<_>>();
            attributes.sort_unstable();
            for (name, value) in attributes {
                output.push_str(&format!("@{}:{name}={}:{}", name.len(), value.len(), value));
            }
            output.push('>');
            for child in node.children() {
                append_node(child, output);
            }
            output.push_str("</>");
        } else if node.is_text()
            && let Some(text) = node.text().map(str::trim).filter(|text| !text.is_empty())
        {
            output.push_str(&format!("#{}:{text}", text.len()));
        }
    }

    let document = roxmltree::Document::parse(raw)
        .with_context(|| "failed to parse probe child CPF input for bijection check")?;
    let mut signature = String::new();
    append_node(document.root_element(), &mut signature);
    Ok(signature)
}

fn probe_children_from_details(details: &serde_json::Value) -> serde_json::Value {
    details
        .get("children")
        .filter(|children| children.as_array().is_some_and(|items| !items.is_empty()))
        .cloned()
        .or_else(|| {
            details
                .get("cpf_export")
                .and_then(|export| export.get("children"))
                .cloned()
        })
        .unwrap_or_else(|| serde_json::json!([]))
}

fn processor_event_run_id() -> String {
    std::env::var("FERRUM_PROCESSOR_EVENT_RUN_ID")
        .unwrap_or_else(|_| std::process::id().to_string())
}

fn tpdb_category_name(root: &Path) -> Option<String> {
    root.file_name()
        .and_then(|name| name.to_str())
        .map(str::to_string)
}

fn prove_strategy_options(
    strategy: Option<&str>,
    strategy_file: Option<&Path>,
    timeout_multiplier: f64,
) -> Result<ProveStrategy> {
    if !timeout_multiplier.is_finite() || timeout_multiplier <= 0.0 {
        bail!("--timeout-multiplier must be finite and greater than zero");
    }
    if strategy.is_some() && strategy_file.is_some() {
        bail!("--strategy and --strategy-file cannot be used together");
    }
    let parsed = if let Some(strategy) = strategy {
        ProveStrategy::parse(strategy).context("failed to parse --strategy")?
    } else if let Some(path) = strategy_file {
        let strategy = fs::read_to_string(path)
            .with_context(|| format!("failed to read {}", path.display()))?;
        ProveStrategy::parse(&strategy)
            .with_context(|| format!("failed to parse --strategy-file {}", path.display()))?
    } else {
        ProveStrategy::default_from_file()
    };
    Ok(parsed.with_timeout_multiplier(timeout_multiplier))
}

struct CertifyTpdbConfig {
    root: PathBuf,
    limit: Option<usize>,
    verbose: bool,
    progress_every: usize,
    jobs: usize,
    sample: TpdbSampleMode,
    seed: u64,
    ceta: Option<PathBuf>,
    converter: Option<PathBuf>,
    run_id: String,
    category: Option<String>,
}

struct ProveTpdbConfig {
    root: PathBuf,
    limit: Option<usize>,
    verbose: bool,
    progress_every: usize,
    jobs: usize,
    sample: TpdbSampleMode,
    seed: u64,
    run_id: String,
    category: Option<String>,
}

fn default_ceta_path() -> PathBuf {
    let integrated = PathBuf::from("../CeTA-CSR-relative-adp/ceta");
    if integrated.exists() {
        integrated
    } else {
        PathBuf::from("../CeTA-CSR/ceta")
    }
}

fn certify_tpdb(config: CertifyTpdbConfig, options: ProveOptions) -> Result<()> {
    let started = Instant::now();
    let ceta = config.ceta.unwrap_or_else(default_ceta_path);
    let converter = config
        .converter
        .unwrap_or_else(|| PathBuf::from(".tools/cpf3/cpf3/xml/cpf2_to_3.sh"));
    if !ceta.exists() {
        bail!("CeTA not found at {}", ceta.display());
    }
    if !converter.exists() {
        bail!("CPF converter not found at {}", converter.display());
    }

    let (benchmarks, skipped) =
        select_tpdb_benchmarks(&config.root, config.limit, config.sample, config.seed)?;
    eprintln!(
        "tpdb-certify-start selected={} skipped-non-trs={} jobs={} progress-every={} sample={:?} seed={}",
        benchmarks.len(),
        skipped,
        config.jobs.max(1),
        config.progress_every,
        config.sample,
        config.seed
    );
    let completed = AtomicUsize::new(0);
    let proved_progress = AtomicUsize::new(0);
    let certified_progress = AtomicUsize::new(0);
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(config.jobs.max(1))
        .build()
        .context("failed to initialize Rayon thread pool")?;
    let results = pool.install(|| {
        benchmarks
            .par_iter()
            .map(|benchmark| {
                let context = tpdb_processor_event_context(
                    &config.root,
                    benchmark,
                    &config.run_id,
                    config.category.as_deref(),
                );
                let result = with_processor_event_context(context, || {
                    certify_tpdb_benchmark(benchmark, &options, &ceta, config.verbose)
                });
                proved_progress.fetch_add(result.proved, Ordering::Relaxed);
                certified_progress.fetch_add(result.certified, Ordering::Relaxed);
                let done = completed.fetch_add(1, Ordering::Relaxed) + 1;
                report_certify_progress(
                    done,
                    benchmarks.len(),
                    config.progress_every,
                    started,
                    proved_progress.load(Ordering::Relaxed),
                    certified_progress.load(Ordering::Relaxed),
                );
                result
            })
            .collect::<Vec<_>>()
    });
    let stats = results
        .into_iter()
        .fold(CertifyStats::default(), |mut stats, result| {
            stats.add(result);
            stats
        });

    println!("attempted-valid-trs: {}", stats.attempted);
    println!("proved: {}", stats.proved);
    println!("cpf-supported: {}", stats.cpf_supported);
    println!("cpf-unsupported: {}", stats.cpf_unsupported);
    println!("certified: {}", stats.certified);
    println!("certification-failed: {}", stats.certification_failed);
    println!("invalid: {}", stats.invalid);
    println!("failed: {}", stats.failed);
    println!("skipped-non-trs: {skipped}");
    println!("jobs: {}", config.jobs.max(1));
    println!("sample: {:?}", config.sample);
    println!("seed: {}", config.seed);
    println!("elapsed-ms: {}", started.elapsed().as_millis());
    Ok(())
}

fn certify_cpf_string(cpf: &str, ceta: &Path) -> Result<()> {
    let counter = CERTIFY_TEMP_COUNTER.fetch_add(1, Ordering::Relaxed);
    let cpf_path = std::env::temp_dir().join(format!(
        "ferrum-certify-{}-{}.cpf.xml",
        std::process::id(),
        counter
    ));
    fs::write(&cpf_path, cpf).with_context(|| format!("failed to write {}", cpf_path.display()))?;
    let output = Command::new(ceta)
        .arg(&cpf_path)
        .output()
        .with_context(|| format!("failed to execute {}", ceta.display()))?;
    let _ = fs::remove_file(cpf_path);
    if !output.status.success() {
        bail!(
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }
    Ok(())
}

#[derive(Default)]
struct CertifyStats {
    attempted: usize,
    proved: usize,
    cpf_supported: usize,
    cpf_unsupported: usize,
    certified: usize,
    certification_failed: usize,
    invalid: usize,
    failed: usize,
}

impl CertifyStats {
    fn add(&mut self, other: Self) {
        self.attempted += other.attempted;
        self.proved += other.proved;
        self.cpf_supported += other.cpf_supported;
        self.cpf_unsupported += other.cpf_unsupported;
        self.certified += other.certified;
        self.certification_failed += other.certification_failed;
        self.invalid += other.invalid;
        self.failed += other.failed;
    }
}

#[derive(Default)]
struct ProveStats {
    attempted: usize,
    proved: usize,
    unknown: usize,
    invalid: usize,
    failed: usize,
    steps: std::collections::BTreeMap<String, usize>,
}

impl ProveStats {
    fn add(&mut self, other: Self) {
        self.attempted += other.attempted;
        self.proved += other.proved;
        self.unknown += other.unknown;
        self.invalid += other.invalid;
        self.failed += other.failed;
        for (step, count) in other.steps {
            *self.steps.entry(step).or_default() += count;
        }
    }
}

fn select_tpdb_benchmarks(
    root: &Path,
    limit: Option<usize>,
    sample: TpdbSampleMode,
    seed: u64,
) -> Result<(Vec<Benchmark>, usize)> {
    let mut selected = Vec::new();
    let mut skipped = 0usize;
    let limit = limit.unwrap_or(usize::MAX);
    for benchmark in discover_benchmarks(root)
        .into_iter()
        .filter(|benchmark| benchmark.format() != &TpdbFormat::Xml)
    {
        if sample == TpdbSampleMode::First && selected.len() >= limit {
            break;
        }
        if benchmark.format() == &TpdbFormat::Ari {
            let input = fs::read_to_string(benchmark.path())
                .with_context(|| format!("failed to read {}", benchmark.path().display()))?;
            if !input.contains("(format TRS)") && !input.contains("(format CSTRS)") {
                skipped += 1;
                continue;
            }
        }
        selected.push(benchmark);
    }
    if sample == TpdbSampleMode::Random {
        selected.sort_by_key(|benchmark| seeded_benchmark_score(benchmark, seed));
    }
    selected.truncate(limit);
    Ok((selected, skipped))
}

fn seeded_benchmark_score(benchmark: &Benchmark, seed: u64) -> (u64, String) {
    let path = benchmark.path().to_string_lossy();
    (
        splitmix64(stable_path_hash(&path) ^ seed),
        path.into_owned(),
    )
}

fn tpdb_processor_event_context(
    root: &Path,
    benchmark: &Benchmark,
    run_id: &str,
    category: Option<&str>,
) -> ProcessorEventContext {
    let problem_id = benchmark
        .path()
        .strip_prefix(root)
        .unwrap_or_else(|_| benchmark.path())
        .to_string_lossy()
        .trim_start_matches(std::path::MAIN_SEPARATOR)
        .to_string();
    ProcessorEventContext {
        run_id: run_id.to_string(),
        problem_id,
        category: category.map(str::to_string),
    }
}

fn stable_path_hash(path: &str) -> u64 {
    path.bytes().fold(0xcbf2_9ce4_8422_2325, |hash, byte| {
        (hash ^ u64::from(byte)).wrapping_mul(0x0000_0100_0000_01b3)
    })
}

fn splitmix64(mut value: u64) -> u64 {
    value = value.wrapping_add(0x9e37_79b9_7f4a_7c15);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}

fn certify_tpdb_benchmark(
    benchmark: &Benchmark,
    options: &ProveOptions,
    ceta: &Path,
    verbose: bool,
) -> CertifyStats {
    let mut stats = CertifyStats::default();
    let input = match fs::read_to_string(benchmark.path()) {
        Ok(input) => input,
        Err(error) => {
            stats.failed = 1;
            if verbose {
                println!("FAIL {}: {error}", benchmark.path().display());
            }
            return stats;
        }
    };
    if input.contains("(format CSTRS)") {
        let csr = match parse_ari_cstrs(Some(benchmark.path().display().to_string()), &input) {
            Ok(csr) => csr,
            Err(error) => {
                stats.failed = 1;
                if verbose {
                    println!("FAIL {}: {error}", benchmark.path().display());
                }
                return stats;
            }
        };
        let issues = csr.trs().validate();
        if !issues.is_empty() {
            stats.invalid = 1;
            return stats;
        }
        stats.attempted = 1;
        let proof = prove_context_sensitive(&csr, options);
        if proof.status() == &Status::Unknown {
            return stats;
        }
        stats.proved = 1;
        let cpf = match write_cpf_csr(&csr, &proof, CpfMode::Auto) {
            Ok(cpf) => {
                stats.cpf_supported = 1;
                cpf
            }
            Err(error) => {
                stats.cpf_unsupported = 1;
                if verbose {
                    println!(
                        "UNSUPPORTED {} {:?}: {error}",
                        benchmark.path().display(),
                        proof.steps()
                    );
                }
                return stats;
            }
        };
        match certify_cpf_string(&cpf, ceta) {
            Ok(()) => {
                stats.certified = 1;
                if verbose {
                    println!("CERTIFIED {}", benchmark.path().display());
                }
            }
            Err(error) => {
                stats.certification_failed = 1;
                if verbose {
                    println!("CERT-FAIL {}: {error}", benchmark.path().display());
                }
            }
        }
        return stats;
    }
    let is_relative = match is_relative_ari(&input) {
        Ok(is_relative) => is_relative,
        Err(error) => {
            stats.failed = 1;
            if verbose {
                println!("FAIL {}: {error}", benchmark.path().display());
            }
            return stats;
        }
    };
    if is_relative {
        let relative =
            match parse_ari_relative_trs(Some(benchmark.path().display().to_string()), &input) {
                Ok(relative) => relative,
                Err(error) => {
                    stats.failed = 1;
                    if verbose {
                        println!("FAIL {}: {error}", benchmark.path().display());
                    }
                    return stats;
                }
            };
        stats.attempted = 1;
        let proof = prove_relative(&relative, options);
        if proof.status() == &Status::Unknown {
            return stats;
        }
        stats.proved = 1;
        let cpf = match write_cpf_relative(&relative, &proof, CpfMode::Auto) {
            Ok(cpf) => {
                stats.cpf_supported = 1;
                cpf
            }
            Err(error) => {
                stats.cpf_unsupported = 1;
                if verbose {
                    println!(
                        "UNSUPPORTED {} {:?}: {error}",
                        benchmark.path().display(),
                        proof.steps()
                    );
                }
                return stats;
            }
        };
        match certify_cpf_string(&cpf, ceta) {
            Ok(()) => {
                stats.certified = 1;
                if verbose {
                    println!("CERTIFIED {}", benchmark.path().display());
                }
            }
            Err(error) => {
                stats.certification_failed = 1;
                if verbose {
                    println!("CERT-FAIL {}: {error}", benchmark.path().display());
                }
            }
        }
        return stats;
    }
    let trs = match parse_trs(Some(benchmark.path().display().to_string()), &input) {
        Ok(trs) => trs,
        Err(error) => {
            stats.failed = 1;
            if verbose {
                println!("FAIL {}: {error}", benchmark.path().display());
            }
            return stats;
        }
    };
    let issues = trs.validate();
    if !issues.is_empty() && !can_attempt_nontermination_from_issues(&issues) {
        stats.invalid = 1;
        return stats;
    }
    stats.attempted = 1;
    let proof = prove(&trs, options);
    if proof.status() == &Status::Unknown {
        return stats;
    }
    stats.proved = 1;
    let cpf = match write_cpf(&trs, &proof, CpfMode::Auto) {
        Ok(cpf) => {
            stats.cpf_supported = 1;
            cpf
        }
        Err(error) => {
            stats.cpf_unsupported = 1;
            if verbose {
                println!(
                    "UNSUPPORTED {} {:?}: {error}",
                    benchmark.path().display(),
                    proof.steps()
                );
            }
            return stats;
        }
    };
    match certify_cpf_string(&cpf, ceta) {
        Ok(()) => {
            stats.certified = 1;
            if verbose {
                println!("CERTIFIED {}", benchmark.path().display());
            }
        }
        Err(error) => {
            stats.certification_failed = 1;
            if verbose {
                println!("CERT-FAIL {}: {error}", benchmark.path().display());
            }
        }
    }
    stats
}

fn prove_tpdb_benchmark(
    benchmark: &Benchmark,
    options: &ProveOptions,
    verbose: bool,
) -> ProveStats {
    let mut stats = ProveStats::default();
    let input = match fs::read_to_string(benchmark.path()) {
        Ok(input) => input,
        Err(error) => {
            stats.failed = 1;
            if verbose {
                println!("FAIL {}: {error}", benchmark.path().display());
            }
            return stats;
        }
    };
    let proof = if input.contains("(format CSTRS)") {
        let csr = match parse_ari_cstrs(Some(benchmark.path().display().to_string()), &input) {
            Ok(csr) => csr,
            Err(error) => {
                stats.failed = 1;
                if verbose {
                    println!("FAIL {}: {error}", benchmark.path().display());
                }
                return stats;
            }
        };
        let issues = csr.trs().validate();
        if !issues.is_empty() {
            stats.invalid = 1;
            if verbose {
                println!("INVALID {}", benchmark.path().display());
                for issue in issues {
                    println!("  {issue}");
                }
            }
            return stats;
        }
        stats.attempted = 1;
        prove_context_sensitive(&csr, options)
    } else if matches!(is_relative_ari(&input), Ok(true)) {
        let relative =
            match parse_ari_relative_trs(Some(benchmark.path().display().to_string()), &input) {
                Ok(relative) => relative,
                Err(error) => {
                    stats.failed = 1;
                    if verbose {
                        println!("FAIL {}: {error}", benchmark.path().display());
                    }
                    return stats;
                }
            };
        stats.attempted = 1;
        prove_relative(&relative, options)
    } else {
        let trs = match parse_trs(Some(benchmark.path().display().to_string()), &input) {
            Ok(trs) => trs,
            Err(error) => {
                stats.failed = 1;
                if verbose {
                    println!("FAIL {}: {error}", benchmark.path().display());
                }
                return stats;
            }
        };
        let issues = trs.validate();
        if !issues.is_empty() && !can_attempt_nontermination_from_issues(&issues) {
            stats.invalid = 1;
            if verbose {
                println!("INVALID {}", benchmark.path().display());
                for issue in issues {
                    println!("  {issue}");
                }
            }
            return stats;
        }
        stats.attempted = 1;
        prove(&trs, options)
    };
    match proof.status() {
        Status::Terminating => {
            stats.proved = 1;
            if let Some(step) = proof.steps().first() {
                *stats
                    .steps
                    .entry(proof_step_name(step).to_string())
                    .or_default() += 1;
            }
            if verbose {
                println!("PROVED {} {:?}", benchmark.path().display(), proof.steps());
            }
        }
        Status::Nonterminating => {
            stats.proved = 1;
            if let Some(step) = proof.steps().first() {
                *stats
                    .steps
                    .entry(proof_step_name(step).to_string())
                    .or_default() += 1;
            }
            if verbose {
                println!(
                    "DISPROVED {} {:?}",
                    benchmark.path().display(),
                    proof.steps()
                );
            }
        }
        Status::Unknown => {
            stats.unknown = 1;
            if verbose {
                println!("UNKNOWN {} {:?}", benchmark.path().display(), proof.steps());
            }
        }
    }
    stats
}

fn report_prove_progress(
    completed: usize,
    total: usize,
    progress_every: usize,
    started: Instant,
    proved: usize,
) {
    if !should_report_progress(completed, total, progress_every) {
        return;
    }
    eprintln!(
        "tpdb-prove-progress completed={completed}/{total} proved={proved} elapsed={} eta={}",
        format_duration(started.elapsed()),
        format_eta(started, completed, total)
    );
}

fn report_certify_progress(
    completed: usize,
    total: usize,
    progress_every: usize,
    started: Instant,
    proved: usize,
    certified: usize,
) {
    if !should_report_progress(completed, total, progress_every) {
        return;
    }
    eprintln!(
        "tpdb-certify-progress completed={completed}/{total} proved={proved} certified={certified} elapsed={} eta={}",
        format_duration(started.elapsed()),
        format_eta(started, completed, total)
    );
}

fn should_report_progress(completed: usize, total: usize, progress_every: usize) -> bool {
    completed == total || (progress_every > 0 && completed.is_multiple_of(progress_every))
}

fn format_eta(started: Instant, completed: usize, total: usize) -> String {
    if completed == 0 || total <= completed {
        return "0s".to_string();
    }
    let elapsed = started.elapsed();
    let total_secs = elapsed.as_secs_f64() * total as f64 / completed as f64;
    let remaining =
        std::time::Duration::from_secs_f64((total_secs - elapsed.as_secs_f64()).max(0.0));
    format_duration(remaining)
}

fn format_duration(duration: std::time::Duration) -> String {
    let seconds = duration.as_secs();
    let minutes = seconds / 60;
    let seconds = seconds % 60;
    if minutes == 0 {
        format!("{seconds}s")
    } else {
        format!("{minutes}m{seconds:02}s")
    }
}

fn prove_tpdb(config: ProveTpdbConfig, options: ProveOptions) -> Result<()> {
    let started = Instant::now();
    let (benchmarks, skipped) =
        select_tpdb_benchmarks(&config.root, config.limit, config.sample, config.seed)?;
    eprintln!(
        "tpdb-prove-start selected={} skipped-non-trs={} jobs={} progress-every={} sample={:?} seed={}",
        benchmarks.len(),
        skipped,
        config.jobs.max(1),
        config.progress_every,
        config.sample,
        config.seed
    );
    let completed = AtomicUsize::new(0);
    let proved_progress = AtomicUsize::new(0);
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(config.jobs.max(1))
        .build()
        .context("failed to initialize Rayon thread pool")?;
    let results = pool.install(|| {
        benchmarks
            .par_iter()
            .map(|benchmark| {
                let context = tpdb_processor_event_context(
                    &config.root,
                    benchmark,
                    &config.run_id,
                    config.category.as_deref(),
                );
                let result = with_processor_event_context(context, || {
                    prove_tpdb_benchmark(benchmark, &options, config.verbose)
                });
                proved_progress.fetch_add(result.proved, Ordering::Relaxed);
                let done = completed.fetch_add(1, Ordering::Relaxed) + 1;
                report_prove_progress(
                    done,
                    benchmarks.len(),
                    config.progress_every,
                    started,
                    proved_progress.load(Ordering::Relaxed),
                );
                result
            })
            .collect::<Vec<_>>()
    });
    let stats = results
        .into_iter()
        .fold(ProveStats::default(), |mut stats, result| {
            stats.add(result);
            stats
        });

    println!("attempted-valid-trs: {}", stats.attempted);
    println!("proved: {}", stats.proved);
    println!("unknown: {}", stats.unknown);
    println!("invalid: {}", stats.invalid);
    println!("failed: {}", stats.failed);
    println!("skipped-non-trs: {skipped}");
    println!("jobs: {}", config.jobs.max(1));
    println!("sample: {:?}", config.sample);
    println!("seed: {}", config.seed);
    println!("elapsed-ms: {}", started.elapsed().as_millis());
    for (step, count) in stats.steps {
        println!("step.{step}: {count}");
    }
    Ok(())
}

fn proof_step_name(step: &crate::proving::ProofStep) -> &'static str {
    match step {
        crate::proving::ProofStep::EmptySystem => "empty-system",
        crate::proving::ProofStep::ExactTerminationXml(_) => "exact-termination-proof",
        crate::proving::ProofStep::LlmLinearPolynomial { .. } => "llm-linear-polynomial",
        crate::proving::ProofStep::SynthesizedLinearPolynomial { .. } => {
            "synthesized-linear-polynomial"
        }
        crate::proving::ProofStep::PolynomialRuleRemoval { .. } => "polynomial-rule-removal",
        crate::proving::ProofStep::MatrixRuleRemoval { .. } => "matrix-rule-removal",
        crate::proving::ProofStep::SynthesizedKbo { .. } => "synthesized-kbo",
        crate::proving::ProofStep::KboRuleRemoval { .. } => "kbo-rule-removal",
        crate::proving::ProofStep::PathOrderRuleRemoval { .. } => "path-order-rule-removal",
        crate::proving::ProofStep::SemanticLabeling { .. } => "semantic-labeling",
        crate::proving::ProofStep::FlatContextClosure { .. } => "flat-context-closure",
        crate::proving::ProofStep::OutermostRaffelsieperZantemaTransformation { .. } => {
            "outermost-raffelsieper-zantema"
        }
        crate::proving::ProofStep::DependencyPairs { .. } => "dependency-pairs",
        crate::proving::ProofStep::DependencyPairProof { .. } => "dependency-pair-proof",
        crate::proving::ProofStep::ContextSensitiveDependencyPairProof { .. } => {
            "csr-dependency-pair-proof"
        }
        crate::proving::ProofStep::RelativeAnnotatedDependencyPairProof { .. } => {
            "relative-annotated-dependency-pair-proof"
        }
        crate::proving::ProofStep::ContextSensitiveInnermostDependencyPairProof { .. } => {
            "csr-innermost-dependency-pair-proof"
        }
        crate::proving::ProofStep::RemoveNonApplicableRules { .. } => "remove-non-applicable-rules",
        crate::proving::ProofStep::SwitchInnermost { .. } => "switch-innermost",
        crate::proving::ProofStep::AaeccInnermost { .. } => "aaecc-innermost",
        crate::proving::ProofStep::SwitchContextSensitive { .. } => "switch-context-sensitive",
        crate::proving::ProofStep::Gm04InverseContextSensitive { .. } => {
            "gm04-inverse-context-sensitive"
        }
        crate::proving::ProofStep::Gm04InverseContextSensitiveFull { .. } => {
            "gm04-inverse-context-sensitive-full"
        }
        crate::proving::ProofStep::Gm04InverseContextSensitiveNontermination { .. } => {
            "gm04-inverse-context-sensitive-nontermination"
        }
        crate::proving::ProofStep::ContextSensitivePolynomialRuleRemoval { .. } => {
            "csr-polynomial-rule-removal"
        }
        crate::proving::ProofStep::ContextSensitiveMatrixRuleRemoval { .. } => {
            "csr-matrix-rule-removal"
        }
        crate::proving::ProofStep::ContextSensitiveInnermostEquivalence { .. } => {
            "csr-innermost-equivalence"
        }
        crate::proving::ProofStep::ContextSensitiveGmTransformation { .. } => {
            "csr-gm-transformation"
        }
        crate::proving::ProofStep::StringReversal { .. } => "string-reversal",
        crate::proving::ProofStep::RuleStrengthening { .. } => "rule-strengthening",
        crate::proving::ProofStep::ConstantToUnary { .. } => "constant-to-unary",
        crate::proving::ProofStep::Uncurry { .. } => "uncurry",
        crate::proving::ProofStep::Bounds { .. } => "bounds",
        crate::proving::ProofStep::RelativeBounds { .. } => "relative-bounds",
        crate::proving::ProofStep::RfcBounds { .. } => "rfc-bounds",
        crate::proving::ProofStep::RfcAutomatonClosedBounds { .. } => "rfc-automaton-closed-bounds",
        crate::proving::ProofStep::RfcRelativeBounds { .. } => "rfc-relative-bounds",
        crate::proving::ProofStep::RfcAutomatonClosedRelativeBounds { .. } => {
            "rfc-automaton-closed-relative-bounds"
        }
        crate::proving::ProofStep::RfcMatchboxRelativeBounds { .. } => {
            "rfc-matchbox-relative-bounds"
        }
        crate::proving::ProofStep::RfcNativeMatchboxRelativeBounds { .. } => {
            "rfc-native-matchbox-relative-bounds"
        }
        crate::proving::ProofStep::Nontermination { proof } => match proof {
            crate::proving::NonterminationProof::RuleRemoval { .. } => "no-rule-removal",
            crate::proving::NonterminationProof::ExactXml(_) => "exact-nontermination-proof",
            crate::proving::NonterminationProof::VariableConditionViolated => {
                "no-variable-condition"
            }
            crate::proving::NonterminationProof::Loop(_) => "no-loop",
            crate::proving::NonterminationProof::NotWnTreeAutomaton { .. } => "no-tree-automaton",
            crate::proving::NonterminationProof::SrsDerivationPatterns(_) => {
                "no-srs-derivation-patterns"
            }
            crate::proving::NonterminationProof::SwitchFullStrategy { .. } => "no-switch-full-loop",
            crate::proving::NonterminationProof::DependencyPairs { .. } => "no-dp-loop",
            crate::proving::NonterminationProof::InnermostLhssDependencyPairs { .. } => {
                "no-innermost-lhss-dp"
            }
        },
        crate::proving::ProofStep::Unsupported { .. } => "unsupported",
    }
}

fn can_attempt_nontermination_from_issues(issues: &[TrsIssue]) -> bool {
    issues.iter().all(|issue| {
        matches!(
            issue,
            TrsIssue::ExtraVariablesOnRhs { .. } | TrsIssue::LhsIsVariable { .. }
        )
    })
}

fn read_trs(path: &PathBuf) -> Result<crate::core::Trs> {
    let input =
        fs::read_to_string(path).with_context(|| format!("failed to read {}", path.display()))?;
    parse_trs(Some(path.display().to_string()), &input)
        .with_context(|| format!("failed to parse {}", path.display()))
}

fn clone_tpdb_ari(destination: &PathBuf) -> Result<()> {
    if destination.exists() {
        bail!("destination already exists: {}", destination.display());
    }
    let status = Command::new("git")
        .args([
            "clone",
            "--depth",
            "1",
            "https://github.com/TermCOMP/TPDB-ARI.git",
        ])
        .arg(destination)
        .status()
        .context("failed to execute git")?;
    if !status.success() {
        bail!("git clone failed with status {status}");
    }
    Ok(())
}

fn check_certificate(
    cpf: &PathBuf,
    ceta: Option<PathBuf>,
    converter: Option<PathBuf>,
    cpf3_out: Option<PathBuf>,
) -> Result<()> {
    let ceta = ceta.unwrap_or_else(default_ceta_path);
    let converter = converter.unwrap_or_else(|| PathBuf::from(".tools/cpf3/cpf3/xml/cpf2_to_3.sh"));
    if !ceta.exists() {
        bail!(
            "CeTA not found at {}. Set --ceta or build the integrated sibling checker",
            ceta.display()
        );
    }
    if !converter.exists() {
        bail!(
            "CPF 2-to-3 converter not found at {}. Set --converter or install cpf3.tgz into .tools/cpf3",
            converter.display()
        );
    }
    let cpf3 = cpf3_out.unwrap_or_else(|| {
        let counter = CERTIFY_TEMP_COUNTER.fetch_add(1, Ordering::Relaxed);
        std::env::temp_dir().join(format!(
            "ferrum-{}-{}-cpf3.xml",
            std::process::id(),
            counter
        ))
    });
    let conversion = Command::new(&converter)
        .arg(cpf)
        .output()
        .with_context(|| format!("failed to execute {}", converter.display()))?;
    if !conversion.status.success() {
        bail!(
            "CPF conversion failed:\n{}",
            String::from_utf8_lossy(&conversion.stderr)
        );
    }
    fs::write(&cpf3, conversion.stdout)
        .with_context(|| format!("failed to write {}", cpf3.display()))?;
    println!("cpf3: {}", cpf3.display());

    let schema = PathBuf::from(".tools/cpf3/cpf3/xml/cpf3.xsd");
    if schema.exists() && command_exists("xmllint") {
        let status = Command::new("xmllint")
            .args(["--huge", "--noout", "--schema"])
            .arg(&schema)
            .arg(&cpf3)
            .status()
            .context("failed to execute xmllint")?;
        if !status.success() {
            bail!("CPF 3 XML schema validation failed");
        }
    }

    let output = Command::new(&ceta)
        .arg(&cpf3)
        .output()
        .with_context(|| format!("failed to execute {}", ceta.display()))?;
    print!("{}", String::from_utf8_lossy(&output.stdout));
    eprint!("{}", String::from_utf8_lossy(&output.stderr));
    if !output.status.success() {
        bail!("CeTA failed with status {}", output.status);
    }
    Ok(())
}

fn command_exists(command: &str) -> bool {
    Command::new("sh")
        .arg("-c")
        .arg(format!("command -v {command} >/dev/null 2>&1"))
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

#[cfg(test)]
mod probe_contract_tests {
    use super::{probe_context_json, probe_problem_kind, probe_xml_signature, typed_probe_outcome};

    #[test]
    fn summary_reports_counts_without_copying_or_mutating_contexts() {
        let xml = format!(
            "<trsInput>{}<trs><rules/></trs></trsInput>",
            " ".repeat(100_000)
        );
        let child = serde_json::json!({"cpf": xml, "context": {"minimal": false}});
        let details = serde_json::json!({"children": [child.clone()],
            "cpf_export": {"status": "residual-manifest", "children": [child]}});
        let summary = super::probe_summary("dependency-pair", "transformed", &details, 17);
        assert_eq!(summary["child_count"], 1);
        assert_eq!(summary["typed_outcome"], "Transformed");
        assert_eq!(summary["elapsed_ms"], 17);
        assert!(summary.to_string().len() < 500);
        assert_eq!(details["children"][0]["cpf"], xml);
        super::verify_probe_child_bijection(
            &details["cpf_export"],
            details["children"].as_array().unwrap(),
        )
        .unwrap();
        let fallback = serde_json::json!({"cpf_export": {"children": [{}, {}]}});
        assert_eq!(
            super::probe_summary("dp", "transformed", &fallback, 1)["child_count"],
            2
        );
    }

    #[test]
    fn summary_does_not_hide_export_rejection_or_claim_certification() {
        let details =
            serde_json::json!({"cpf_export": {"status": "unsupported", "reason": "context"}});
        let summary = super::probe_summary("dp", "solved", &details, 1);
        assert_eq!(summary["cpf_export"]["status"], "unsupported");
        assert_eq!(summary["cpf_export"]["reason"], "context");
        assert_eq!(summary["child_count"], 0);
        assert_eq!(summary["soundness"], "requires-independent-check");
        assert!(summary.get("certified").is_none());
    }

    #[test]
    fn empty_probe_is_independent_and_rejects_nonempty_obligations() {
        assert!(super::dp_probe_strategy("empty").is_ok());
        use crate::core::{RewriteRule, Term, Trs};
        use crate::proving::{DpOptions, DpProblemState};
        let empty = DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            vec![],
            DpOptions::default(),
        );
        assert!(super::empty_dp_probe(&empty).is_some());
        let trs = Trs::new(
            None,
            Default::default(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let result = super::materialize_top_level_atom_probe(
            crate::proving::ProblemState::Trs(trs.clone()),
            super::TopLevelProbeRoot::Trs(&trs),
            "empty",
            std::time::Instant::now() + std::time::Duration::from_secs(1),
            false,
            None,
        )
        .unwrap();
        assert_eq!(result.1, "failed");
    }

    #[test]
    fn recursive_dp_probe_preserves_nontermination_polarity_and_context() {
        use crate::core::{RewriteRule, Term, Trs};
        use crate::proving::{DpOptions, DpProblemState, DpStrategy, ProblemCertificate};
        let constant = Term::app("cycle", vec![]);
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(constant.clone(), constant)]);
        let pairs = crate::proving::dependency_pairs(&trs);
        let state = DpProblemState::ordinary(trs, pairs, DpOptions::default());
        let strategy = DpStrategy::parse("nontermination(dp-symbolic-loop)").unwrap();
        let Some(ProblemCertificate::DependencyPairNontermination(proof)) =
            super::solve_recursive_dp_certificate(&state, &strategy, None)
        else { panic!("recursive probe must retain a solved NO certificate") };
        let cpf = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
        assert!(cpf.contains("<dpNonterminationProof>"));
        assert!(!cpf.contains("<dpProof>"));
        let restricted = state.with_normal_form_substitutions(true);
        assert!(super::solve_recursive_dp_certificate(&restricted, &strategy, None).is_none());
    }

    #[test]
    fn recursive_top_level_probe_follows_dp_continuation() {
        use crate::core::{RewriteRule, Term, Trs};
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]), Term::var("x"))]);
        let result = super::materialize_top_level_atom_probe(
            crate::proving::ProblemState::Trs(trs.clone()),
            super::TopLevelProbeRoot::Trs(&trs), "dp(size-change)",
            std::time::Instant::now() + std::time::Duration::from_secs(5),
            true, None).unwrap();
        assert_eq!(result.1, "solved", "{:?}", result.2);
        assert_eq!(result.2["status"], "Terminating");
        assert_eq!(result.2["children"], serde_json::json!([]));
    }

    #[test]
    fn dp_probe_manifest_retains_trs_children() {
        let trs = crate::core::Trs::new(None, Default::default(), Vec::new());
        let children = super::serialize_probe_children(&[
            crate::proving::ProblemState::Trs(trs.clone()),
            crate::proving::ProblemState::Srs(trs),
        ]);
        assert_eq!(children.len(), 2);
        for (index, child) in children.iter().enumerate() {
            assert_eq!(child["index"], index);
            assert_eq!(child["assumption_kind"], "terminationAssumption");
            assert!(child["cpf"].as_str().unwrap().contains("<trsInput>"));
        }
    }

    #[test]
    fn classifies_every_typed_probe_problem_kind() {
        let cases = [
            ("<trsInput><trs/></trsInput>", "trs"),
            ("<trsInput><trs/><innermost/></trsInput>", "innermost-trs"),
            ("<trsInput><trs/><word/></trsInput>", "srs"),
            ("<trsInput><trs/><contextSensitive/></trsInput>", "cs-trs"),
            (
                "<dpInput><trs/><dps/><minimal>false</minimal></dpInput>",
                "dp",
            ),
            (
                "<dpInput><trs/><dps/><minimal>true</minimal></dpInput>",
                "qdp",
            ),
            (
                "<dpInput><trs/><dps/><contextSensitive/><minimal>false</minimal></dpInput>",
                "csdp",
            ),
            (
                "<dpInput><trs/><dps/><contextSensitive/><minimal>true</minimal></dpInput>",
                "qcs-dp",
            ),
        ];
        for (cpf, expected) in cases {
            assert_eq!(probe_problem_kind(cpf), expected);
        }
    }

    #[test]
    fn probe_child_signature_ignores_only_xml_formatting() {
        let compact = "<trsInput><trs><rules/></trs></trsInput>";
        let formatted = "<trsInput>\n  <trs>\n    <rules />\n  </trs>\n</trsInput>";
        let changed = "<trsInput><trs><rules><rule/></rules></trs></trsInput>";
        assert_eq!(
            probe_xml_signature(compact).unwrap(),
            probe_xml_signature(formatted).unwrap()
        );
        assert_ne!(
            probe_xml_signature(compact).unwrap(),
            probe_xml_signature(changed).unwrap()
        );
    }

    #[test]
    fn typed_outcome_separates_inapplicable_failure_and_timeout() {
        assert_eq!(
            typed_probe_outcome("failed", &serde_json::json!({})),
            "Inapplicable"
        );
        assert_eq!(
            typed_probe_outcome(
                "failed",
                &serde_json::json!({"cpf_export": {"status": "error"}})
            ),
            "Failed"
        );
        assert_eq!(
            typed_probe_outcome("timeout", &serde_json::json!({})),
            "TimedOut"
        );
        let context = probe_context_json(
            "<dpInput><contextSensitive/><usableRules/><q/><minimal>true</minimal></dpInput>",
        );
        assert_eq!(context["strategy"], "context-sensitive");
        assert_eq!(context["minimal"], true);
        assert_eq!(context["usable_rules_present"], true);
        assert_eq!(context["q_present"], true);
    }
}
