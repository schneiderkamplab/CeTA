# Ferrum Agent Guidance

Ferrum is a termination and nontermination prover, so processor
correctness is non-negotiable.

- Do not embed benchmark-specific proofs, witnesses, symbol names, or filename
  dispatch in production Ferrum code. Retain example evidence in external
  oracle data and test fixtures. Structural search patterns must be independent
  of symbol naming and describe a useful class of problems, not merely encode
  one benchmark modulo renaming. Independently checking a hard-coded witness
  establishes soundness but does not satisfy this requirement.

- Complete TRS/DP termination and nontermination proof strategy actions are retired and guarded
  by unconditional assertions in parsing and processor execution. Do not
  re-enable them to recover oracle coverage; recover modular actions instead.
  Primitive nontermination terminals (loops, nonloops, automata) remain valid
  modular witnesses; preprocessing must use separately addressed child states.

- Termination processors must be sound/correct. They should be implemented as
  completely as the state-of-the-art literature supports for their intended
  setting, subject to preserving soundness and certifiability.
- Nontermination processors must only report nontermination from complete and
  checkable evidence for the claimed nontermination mechanism. They should also
  be as complete as practical within their intended scope.
- When in doubt about a processor's side conditions, proof shape,
  certification format, or algorithmic completeness, consult the TRS/RTA/WST
  literature before implementing or widening the processor.
- Prefer conservative `Unknown` over an uncertified or unsound YES/NO answer.
- Keep CeTA/CPF certification behavior aligned with the implemented proof
  rules, and add regression tests for any subtle processor side condition.
- When reporting a successful certified improvement, state explicitly whether
  CeTA changed. If it did, report the CeTA tree, branch, commit, and integration
  location; if it did not, say so explicitly.
- Before quoting a campaign baseline, diagnosing a regression, or starting a
  replay campaign, read `docs/state-of-the-art.md`. Treat its latest complete,
  certified category replay and root set as authoritative; do not infer the
  state of the art from chat history, intermediate runs, or raw YES/NO totals.
- Update `docs/state-of-the-art.md` whenever a complete certified category run
  establishes a new high-water mark. Record exact Ferrum and CeTA-CSR commits,
  artifact paths, the oracle checksum, certified YES/NO totals, and unresolved
  roots.
